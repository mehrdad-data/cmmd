package net.imedicaldoctor.imd.Data;

/* loaded from: classes2.dex */
public class UnzipCompleted {
    /* renamed from: a */
    public void mo4057a(String str) {
    }

    /* renamed from: b */
    public void mo4056b(byte[] bArr) {
    }
}
