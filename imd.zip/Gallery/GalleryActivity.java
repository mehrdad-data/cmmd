package net.imedicaldoctor.imd.Gallery;

import android.os.Bundle;
import androidx.viewpager.widget.ViewPager;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class GalleryActivity extends iMDActivity {

    /* renamed from: R2 */
    private static final String f77027R2 = "STATE_POSITION";

    /* renamed from: Q2 */
    private ViewPager f77028Q2;

    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87096activity_gallery);
        ImagePagerFragment imagePagerFragment = new ImagePagerFragment();
        Bundle bundle2 = new Bundle();
        bundle2.putParcelableArrayList("Images", getIntent().getParcelableArrayListExtra("Images"));
        bundle2.putInt("Start", getIntent().getIntExtra("Start", 0));
        if (getIntent().getParcelableArrayListExtra("Images").size() == 0) {
            CompressHelper.m4921e2(this, "There is no image in this document", 1);
            finish();
        }
        imagePagerFragment.m44751k2(bundle2);
        m44690E().m44464r().m44278y(C4804R.C4808id.f86865detail_container, imagePagerFragment).mo44289n();
    }
}
