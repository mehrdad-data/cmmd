package net.imedicaldoctor.imd.Gallery;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Views.ButtonSmall;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;
import org.apache.commons.p024io.IOUtils;

/* loaded from: classes2.dex */
public class ImagePagerFragment extends Fragment {

    /* renamed from: M3 */
    public static final String f77029M3 = "com.nostra13.example.universalimageloader.FRAGMENT_INDEX";

    /* renamed from: N3 */
    public static final String f77030N3 = "com.nostra13.example.universalimageloader.IMAGE_POSITION";

    /* renamed from: O3 */
    public static final int f77031O3 = 2;

    /* renamed from: P3 */
    private static int f77032P3;

    /* renamed from: F3 */
    ArrayList<Bundle> f77033F3;

    /* renamed from: G3 */
    public Toolbar f77034G3;

    /* renamed from: H3 */
    public TextView f77035H3;

    /* renamed from: I3 */
    public MediaController f77036I3;

    /* renamed from: J3 */
    public VideoView f77037J3;

    /* renamed from: K3 */
    public String f77038K3;

    /* renamed from: L3 */
    public Typeface f77039L3;

    /* loaded from: classes2.dex */
    private class ImageAdapter extends PagerAdapter {

        /* renamed from: g */
        static final /* synthetic */ boolean f77051g = false;

        /* renamed from: e */
        private LayoutInflater f77052e;

        ImageAdapter() {
            this.f77052e = LayoutInflater.from(ImagePagerFragment.this.m44716w());
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        /* renamed from: b */
        public void mo3497b(ViewGroup viewGroup, int i, Object obj) {
            viewGroup.removeView((View) obj);
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        /* renamed from: e */
        public int mo3486e() {
            return ImagePagerFragment.this.f77033F3.size();
        }

        /* JADX WARN: Removed duplicated region for block: B:30:0x027c  */
        /* JADX WARN: Removed duplicated region for block: B:31:0x028c  */
        @Override // androidx.viewpager.widget.PagerAdapter
        /* renamed from: j */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public java.lang.Object mo3496j(android.view.ViewGroup r20, final int r21) {
            /*
                Method dump skipped, instructions count: 757
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.ImageAdapter.mo3496j(android.view.ViewGroup, int):java.lang.Object");
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        /* renamed from: k */
        public boolean mo3495k(View view, Object obj) {
            return view.equals(obj);
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        /* renamed from: n */
        public void mo3494n(Parcelable parcelable, ClassLoader classLoader) {
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        /* renamed from: o */
        public Parcelable mo3493o() {
            return null;
        }
    }

    /* renamed from: P2 */
    public static void m3504P2(String str, Context context) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("datetaken", Long.valueOf(System.currentTimeMillis()));
        contentValues.put("mime_type", MimeTypes.f40551f);
        contentValues.put("_data", str);
        context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
    }

    /* renamed from: N2 */
    public Boolean m3506N2() {
        try {
            if (Build.VERSION.SDK_INT < 23 || ContextCompat.m47751a(m44716w(), "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                return Boolean.TRUE;
            }
            if (ActivityCompat.m48583I(m44716w(), "android.permission.WRITE_EXTERNAL_STORAGE")) {
                Toast.makeText(m44716w(), "", 1).show();
            }
            new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Write External Storage permission allows us to save images on your device").mo26266y("Allow it", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.m48589C(ImagePagerFragment.this.m44716w(), new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
                }
            }).mo26284p("Not now", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).m52864I();
            return Boolean.FALSE;
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            Log.e("PremissionGranted", e.getLocalizedMessage());
            return Boolean.FALSE;
        }
    }

    /* renamed from: O2 */
    public void m3505O2(String str, Context context) {
        try {
            m3502Q2(str, context);
        } catch (Exception unused) {
            Toast.makeText(context, "Error in saving image", 0).show();
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: Q0 */
    public void mo3503Q0(Bundle bundle) {
        super.mo3503Q0(bundle);
        this.f77039L3 = Typeface.createFromAsset(m44716w().getAssets(), "fonts/HelveticaNeue-Light.otf");
    }

    /* renamed from: Q2 */
    public void m3502Q2(String str, Context context) throws IOException {
        OutputStream fileOutputStream;
        String name = new File(str).getName();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver contentResolver = context.getContentResolver();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", name);
            contentValues.put("mime_type", "image/png");
            contentValues.put("relative_path", "DCIM/iMD");
            fileOutputStream = contentResolver.openOutputStream(contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues));
        } else if (!m3506N2().booleanValue()) {
            return;
        } else {
            String file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/iMD").toString();
            File file2 = new File(file);
            if (!file2.exists()) {
                file2.mkdir();
            }
            fileOutputStream = new FileOutputStream(new File(file, name));
        }
        FileInputStream fileInputStream = new FileInputStream(str);
        IOUtils.copy(fileInputStream, fileOutputStream);
        fileInputStream.close();
        fileOutputStream.flush();
        fileOutputStream.close();
        Toast.makeText(context, "Image Saved", 0).show();
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f77033F3 = m44859B().getParcelableArrayList("Images");
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87132fr_image_pager, viewGroup, false);
        final ViewPager viewPager = (ViewPager) inflate.findViewById(C4804R.C4808id.f86983pager);
        viewPager.setAdapter(new ImageAdapter());
        Toolbar toolbar = (Toolbar) inflate.findViewById(C4804R.C4808id.f87063toolbar);
        this.f77034G3 = toolbar;
        this.f77035H3 = (TextView) toolbar.findViewById(C4804R.C4808id.f87067toolbar_title);
        ButtonSmall buttonSmall = (ButtonSmall) inflate.findViewById(C4804R.C4808id.f86802back_button);
        this.f77034G3.setNavigationOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ImagePagerFragment.this.m44716w().finish();
                ImagePagerFragment.this.m44716w().overridePendingTransition(C4804R.anim.f85978to_fade_in, C4804R.anim.f85979to_fade_out);
            }
        });
        if (buttonSmall != null) {
            buttonSmall.setDrawableIcon(m44716w().getResources().getDrawable(C4804R.C4807drawable.f86482back_icon));
            buttonSmall.setRippleColor(m44716w().getResources().getColor(C4804R.C4806color.f86409toolbar_item_ripple_color));
            buttonSmall.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.4
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ImagePagerFragment.this.m44716w().finish();
                    ImagePagerFragment.this.m44716w().overridePendingTransition(C4804R.anim.f85978to_fade_in, C4804R.anim.f85979to_fade_out);
                }
            });
        }
        ((TextView) inflate.findViewById(C4804R.C4808id.f87017show_in_text)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        ((ImageButton) inflate.findViewById(C4804R.C4808id.f86791action_share)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                String str;
                String str2;
                FragmentActivity m44716w;
                Bundle bundle2 = ImagePagerFragment.this.f77033F3.get(viewPager.getCurrentItem());
                int i = 0;
                if (bundle2.containsKey("isVideo")) {
                    m44716w = ImagePagerFragment.this.m44716w();
                    str2 = "Can't share video";
                } else {
                    String string = bundle2.containsKey("Description") ? bundle2.getString("Description") : "";
                    String string2 = bundle2.containsKey("DescriptionHTML") ? bundle2.getString("DescriptionHTML") : "";
                    if (bundle2.containsKey("DescriptionHTML2")) {
                        string2 = bundle2.getString("DescriptionHTML2");
                    }
                    if (string.length() == 0) {
                        string = string2;
                    }
                    if (bundle2.containsKey("Encrypted")) {
                        try {
                            File file = new File(bundle2.getString("ImagePath"));
                            byte[] readFileToByteArray = FileUtils.readFileToByteArray(file);
                            String name = file.getName();
                            byte[] m4867w = new CompressHelper(ImagePagerFragment.this.m44716w()).m4867w(readFileToByteArray, name, "127");
                            StringUtils.split(file.getName(), ".");
                            File file2 = new File(new CompressHelper(ImagePagerFragment.this.m44716w()).m4856z1() + "/" + name);
                            if (file2.exists()) {
                                file2.delete();
                            }
                            FileUtils.writeByteArrayToFile(file2, m4867w);
                            Intent intent = new Intent();
                            intent.setAction("android.intent.action.SEND");
                            intent.addFlags(1);
                            FragmentActivity m44716w2 = ImagePagerFragment.this.m44716w();
                            intent.putExtra("android.intent.extra.STREAM", FileProvider.m47727e(m44716w2, ImagePagerFragment.this.m44716w().getApplicationContext().getPackageName() + ".provider", file2));
                            if (string.length() > 0) {
                                intent.putExtra("android.intent.extra.TEXT", string);
                            }
                            intent.setType("image/*");
                            ImagePagerFragment.this.mo4139H2(Intent.createChooser(intent, "Share Image ..."));
                            return;
                        } catch (Exception e) {
                            FirebaseCrashlytics.m18030d().m18027g(e);
                            e.printStackTrace();
                            CompressHelper.m4921e2(ImagePagerFragment.this.m44716w(), "Can't share this photo", 0);
                            return;
                        }
                    } else if (bundle2.containsKey("base64")) {
                        try {
                            String string3 = bundle2.getString("name");
                            StringBuilder sb = new StringBuilder();
                            str = "Can't share this photo";
                            try {
                                sb.append(new CompressHelper(ImagePagerFragment.this.m44716w()).m4856z1());
                                sb.append("/");
                                sb.append(string3);
                                File file3 = new File(sb.toString());
                                if (file3.exists()) {
                                    file3.delete();
                                }
                                FileUtils.writeByteArrayToFile(file3, bundle2.getByteArray("base64"));
                                Intent intent2 = new Intent();
                                intent2.setAction("android.intent.action.SEND");
                                FragmentActivity m44716w3 = ImagePagerFragment.this.m44716w();
                                intent2.putExtra("android.intent.extra.STREAM", FileProvider.m47727e(m44716w3, ImagePagerFragment.this.m44716w().getApplicationContext().getPackageName() + ".provider", file3));
                                if (string.length() > 0) {
                                    intent2.putExtra("android.intent.extra.TEXT", string);
                                }
                                intent2.setType("image/*");
                                intent2.addFlags(1);
                                ImagePagerFragment.this.mo4139H2(Intent.createChooser(intent2, "Share Image ..."));
                                return;
                            } catch (Exception e2) {
                                e = e2;
                                FirebaseCrashlytics.m18030d().m18027g(e);
                                e.printStackTrace();
                                CompressHelper.m4921e2(ImagePagerFragment.this.m44716w(), str, 0);
                                return;
                            }
                        } catch (Exception e3) {
                            e = e3;
                            str = "Can't share this photo";
                        }
                    } else {
                        str2 = "Can't share this photo";
                        i = 0;
                        if (!bundle2.getString("ImagePath").contains("http://")) {
                            File file4 = new File(bundle2.getString("ImagePath"));
                            String name2 = file4.getName();
                            File file5 = new File(new CompressHelper(ImagePagerFragment.this.m44716w()).m4856z1() + "/" + name2);
                            if (file5.exists()) {
                                file5.delete();
                            }
                            try {
                                FileUtils.copyFile(file4, file5);
                            } catch (Exception e4) {
                                FirebaseCrashlytics.m18030d().m18027g(e4);
                                e4.printStackTrace();
                            }
                            Intent intent3 = new Intent();
                            intent3.setAction("android.intent.action.SEND");
                            FragmentActivity m44716w4 = ImagePagerFragment.this.m44716w();
                            intent3.putExtra("android.intent.extra.STREAM", FileProvider.m47727e(m44716w4, ImagePagerFragment.this.m44716w().getApplicationContext().getPackageName() + ".provider", file5));
                            intent3.setType("image/*");
                            intent3.addFlags(1);
                            ImagePagerFragment.this.mo4139H2(Intent.createChooser(intent3, "Share Image ..."));
                            return;
                        }
                        m44716w = ImagePagerFragment.this.m44716w();
                    }
                }
                CompressHelper.m4921e2(m44716w, str2, i);
            }
        });
        ((ImageButton) inflate.findViewById(C4804R.C4808id.f86787action_save)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragmentActivity m44716w;
                String str;
                Bundle bundle2 = ImagePagerFragment.this.f77033F3.get(viewPager.getCurrentItem());
                if (bundle2.containsKey("isVideo")) {
                    CompressHelper.m4921e2(ImagePagerFragment.this.m44716w(), "Can't save video", 0);
                    return;
                }
                if (bundle2.containsKey("Encrypted")) {
                    try {
                        File file = new File(bundle2.getString("ImagePath"));
                        byte[] readFileToByteArray = FileUtils.readFileToByteArray(file);
                        String name = file.getName();
                        byte[] m4867w = new CompressHelper(ImagePagerFragment.this.m44716w()).m4867w(readFileToByteArray, name, "127");
                        StringUtils.split(file.getName(), ".");
                        File file2 = new File(new CompressHelper(ImagePagerFragment.this.m44716w()).m4856z1() + "/" + name);
                        if (file2.exists()) {
                            file2.delete();
                        }
                        FileUtils.writeByteArrayToFile(file2, m4867w);
                        ImagePagerFragment.this.m3505O2(file2.getPath(), ImagePagerFragment.this.m44716w());
                        return;
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        e.printStackTrace();
                        m44716w = ImagePagerFragment.this.m44716w();
                        str = "Can't save this media";
                    }
                } else if (bundle2.containsKey("base64")) {
                    try {
                        String string = bundle2.getString("name");
                        File file3 = new File(new CompressHelper(ImagePagerFragment.this.m44716w()).m4856z1() + "/" + string);
                        if (file3.exists()) {
                            file3.delete();
                        }
                        FileUtils.writeByteArrayToFile(file3, bundle2.getByteArray("base64"));
                        ImagePagerFragment.this.m3505O2(file3.getPath(), ImagePagerFragment.this.m44716w());
                        return;
                    } catch (Exception e2) {
                        FirebaseCrashlytics.m18030d().m18027g(e2);
                        e2.printStackTrace();
                        m44716w = ImagePagerFragment.this.m44716w();
                        str = "Can't save this photo";
                    }
                } else if (!bundle2.getString("ImagePath").contains("http://")) {
                    File file4 = new File(bundle2.getString("ImagePath"));
                    String name2 = file4.getName();
                    File file5 = new File(new CompressHelper(ImagePagerFragment.this.m44716w()).m4856z1() + "/" + name2);
                    if (file5.exists()) {
                        file5.delete();
                    }
                    try {
                        FileUtils.copyFile(file4, file5);
                    } catch (Exception e3) {
                        FirebaseCrashlytics.m18030d().m18027g(e3);
                        e3.printStackTrace();
                    }
                    ImagePagerFragment.this.m3505O2(file5.getPath(), ImagePagerFragment.this.m44716w());
                    return;
                } else {
                    m44716w = ImagePagerFragment.this.m44716w();
                    str = "Can't share this media";
                }
                CompressHelper.m4921e2(m44716w, str, 0);
            }
        });
        final int mo3486e = viewPager.getAdapter().mo3486e();
        viewPager.setCurrentItem(m44859B() != null ? m44859B().getInt("Start", 0) : 0);
        if (bundle != null) {
            f77032P3 = bundle.getInt("Start");
        }
        int i = f77032P3;
        if (i > 0) {
            viewPager.setCurrentItem(i);
        }
        TextView textView = this.f77035H3;
        textView.setText((viewPager.getCurrentItem() + 1) + " of " + mo3486e);
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() { // from class: net.imedicaldoctor.imd.Gallery.ImagePagerFragment.8
            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            /* renamed from: a */
            public void mo3500a(int i2, float f, int i3) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            /* renamed from: c */
            public void mo3499c(int i2) {
                MediaController mediaController = ImagePagerFragment.this.f77036I3;
                if (mediaController != null) {
                    mediaController.hide();
                    ImagePagerFragment.this.f77037J3.pause();
                }
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            /* renamed from: d */
            public void mo3498d(int i2) {
                TextView textView2 = ImagePagerFragment.this.f77035H3;
                textView2.setText((i2 + 1) + " of " + mo3486e);
            }
        });
        return inflate;
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: m1 */
    public void mo3501m1(Bundle bundle) {
        super.mo3501m1(bundle);
    }
}
