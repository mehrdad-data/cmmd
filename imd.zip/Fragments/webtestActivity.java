package net.imedicaldoctor.imd.Fragments;

import androidx.appcompat.app.AppCompatActivity;

/* loaded from: classes2.dex */
public class webtestActivity extends AppCompatActivity {
}
