package net.imedicaldoctor.imd.Fragments.LWW;

import android.os.Bundle;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class LWWChapters extends iMDActivity {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new LWWChaptersFragment());
    }
}
