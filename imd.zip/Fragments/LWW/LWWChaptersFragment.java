package net.imedicaldoctor.imd.Fragments.LWW;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;

/* loaded from: classes2.dex */
public class LWWChaptersFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    private CursorAdapter f74737b4;

    /* renamed from: c4 */
    private CursorAdapter f74738c4;

    /* renamed from: d4 */
    private String f74739d4;

    /* loaded from: classes2.dex */
    public class AMChaptersAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        public Context f74744d;

        /* renamed from: e */
        public ArrayList<Bundle> f74745e;

        /* renamed from: f */
        public String f74746f;

        public AMChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
            this.f74744d = context;
            this.f74745e = arrayList;
            this.f74746f = str;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            return this.f74745e.get(i).getString("leaf").equals(IcyHeaders.f35463C2) ? 0 : 1;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
            RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
            final Bundle bundle = this.f74745e.get(i);
            rippleTextViewHolder.f83300I.setText(bundle.getString(this.f74746f));
            rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LWW.LWWChaptersFragment.AMChaptersAdapter.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    AMChaptersAdapter.this.mo4506d0(bundle, i);
                }
            });
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new RippleTextViewHolder(LayoutInflater.from(this.f74744d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
            }
            if (i == 1) {
                return new RippleTextViewHolder(LayoutInflater.from(this.f74744d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
            }
            return null;
        }

        /* renamed from: d0 */
        public void mo4506d0(Bundle bundle, int i) {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return this.f74745e.size();
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: T0 */
    public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
        this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
        m4337R2();
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        this.f75221R3 = inflate;
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        m4337R2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            str = null;
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.LWW.LWWChaptersFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            str = m44859B().getString("ParentId");
        }
        this.f74739d4 = str;
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle2 = this.f75212I3;
        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select id as _id,* from toc where parentId = " + this.f74739d4);
        this.f75218O3 = m4955V;
        if (m4955V == null) {
            this.f75218O3 = new ArrayList<>();
        }
        this.f75216M3 = new AMChaptersAdapter(m44716w(), this.f75218O3, "name") { // from class: net.imedicaldoctor.imd.Fragments.LWW.LWWChaptersFragment.2
            @Override // net.imedicaldoctor.imd.Fragments.LWW.LWWChaptersFragment.AMChaptersAdapter
            /* renamed from: d0 */
            public void mo4506d0(Bundle bundle3, int i) {
                LWWChaptersFragment.this.m4330Y2();
                String string = bundle3.getString("leaf");
                String string2 = bundle3.getString("docId");
                if (string.equals(IcyHeaders.f35463C2)) {
                    LWWChaptersFragment lWWChaptersFragment = LWWChaptersFragment.this;
                    lWWChaptersFragment.f75215L3.m4883q1(lWWChaptersFragment.f75212I3, string2, null, null);
                    return;
                }
                Bundle bundle4 = new Bundle();
                bundle4.putBundle("DB", LWWChaptersFragment.this.f75212I3);
                bundle4.putString("ParentId", bundle3.getString("id"));
                LWWChaptersFragment.this.f75215L3.m4979N(LWWChapters.class, LWWChaptersFragment.class, bundle4);
            }
        };
        this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.LWW.LWWChaptersFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
            /* renamed from: e0 */
            public void mo3397e0(Bundle bundle3, int i) {
                LWWChaptersFragment.this.m4330Y2();
                String string = bundle3.getString("type");
                String string2 = bundle3.getString("contentId");
                if (string.equals("0")) {
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("DB", LWWChaptersFragment.this.f75212I3);
                    bundle4.putString("ParentId", string2);
                    LWWChaptersFragment.this.f75215L3.m4979N(LWWChapters.class, LWWChaptersFragment.class, bundle4);
                } else if (string.equals(IcyHeaders.f35463C2) || string.equals(ExifInterface.f14403S4) || string.equals(ExifInterface.f14411T4) || string.equals("4")) {
                    LWWChaptersFragment lWWChaptersFragment = LWWChaptersFragment.this;
                    lWWChaptersFragment.f75215L3.m4883q1(lWWChaptersFragment.f75212I3, string2, null, null);
                } else if (string.equals("5")) {
                    LWWChaptersFragment lWWChaptersFragment2 = LWWChaptersFragment.this;
                    lWWChaptersFragment2.f75215L3.m4883q1(lWWChaptersFragment2.f75212I3, string2, lWWChaptersFragment2.m4332W2(bundle3.getString("subText")), null);
                }
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return inflate;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id, Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }
}
