package net.imedicaldoctor.imd.Fragments.LWW;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.GeneralDialogFragment;
import net.imedicaldoctor.imd.iMDLogger;

/* loaded from: classes2.dex */
public class LWWViewerFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public ArrayList<Bundle> f74751A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f74752B4;

    /* renamed from: C4 */
    public ArrayList<Bundle> f74753C4;

    /* renamed from: D4 */
    public String f74754D4;

    /* renamed from: w4 */
    private GeneralDialogFragment f74755w4;

    /* renamed from: x4 */
    private String f74756x4;

    /* renamed from: y4 */
    private MenuItem f74757y4;

    /* renamed from: z4 */
    public ArrayList<Bundle> f74758z4;

    /* renamed from: B4 */
    private void m4504B4(String str) {
        if (this.f74758z4.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
            return;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(this.f74758z4);
        int i = 0;
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            if (((Bundle) arrayList.get(i2)).getString("id").startsWith(str)) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Can't wrap try/catch for region: R(16:11|(2:13|(3:15|16|17))|18|19|20|21|22|23|24|25|26|27|28|29|(2:31|32)(5:33|34|35|36|38)|17) */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x01da, code lost:
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x01dc, code lost:
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x01de, code lost:
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x01df, code lost:
        r16 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x01e1, code lost:
        r17 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x01e5, code lost:
        r0 = e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x01e6, code lost:
        r16 = r2;
        r15 = r17;
        r17 = r5;
     */
    /* renamed from: x4 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void m4503x4() {
        /*
            Method dump skipped, instructions count: 543
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.LWW.LWWViewerFragment.m4503x4():void");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: C3 */
    public void mo4144C3(String str) {
        WebView webView = this.f75853f4;
        webView.loadUrl("javascript:showSection('" + str + "');");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        iMDLogger.m3294f("Javascript Console Message", consoleMessage.message());
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList;
        Bundle m4073v3;
        if (this.f74758z4.size() <= 0 || (arrayList = this.f74758z4) == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f74758z4)) == null) {
            return null;
        }
        return m4073v3.getString("ImagePath");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        super.mo3569S3(webView, str);
        String str2 = this.f74754D4;
        if (str2 != null) {
            mo4144C3(str2);
            this.f74754D4 = null;
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: T0 */
    public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(C4804R.C4811menu.f87329menu_amviewer, menu);
        m4096h4(menu);
        mo3568e3(menu);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        m4094i4(inflate, bundle);
        if (bundle != null) {
            this.f74756x4 = bundle.getString("mResources");
            this.f74758z4 = bundle.getParcelableArrayList("mImages");
            this.f74751A4 = bundle.getParcelableArrayList("mOtherImages");
            this.f74752B4 = bundle.getParcelableArrayList("mSections");
        }
        if (m44859B() == null) {
            return inflate;
        }
        iMDLogger.m3290j("AMViewer", "Loading LWW Document with mDocAddress = " + this.f75851d4);
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.LWW.LWWViewerFragment.1
            @Override // java.lang.Runnable
            public void run() {
                ArrayList<Bundle> m4955V;
                try {
                    CompressHelper compressHelper = new CompressHelper(LWWViewerFragment.this.m44716w());
                    String str = LWWViewerFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(LWWViewerFragment.this.f75850c4, "Select * from Docs where id=" + LWWViewerFragment.this.f75851d4));
                        if (m4858z == null) {
                            Bundle m4858z2 = compressHelper.m4858z(compressHelper.m4955V(LWWViewerFragment.this.f75850c4, "Select * from AllSections where id='" + LWWViewerFragment.this.f75851d4 + "' collate nocase"));
                            if (m4858z2 == null) {
                                Bundle m4858z3 = compressHelper.m4858z(compressHelper.m4955V(LWWViewerFragment.this.f75850c4, "Select * from AllSections where id like '" + LWWViewerFragment.this.f75851d4 + "%' collate nocase"));
                                if (m4858z3 == null) {
                                    LWWViewerFragment.this.f75837P3 = "Document doesn't exist";
                                    return;
                                }
                                LWWViewerFragment.this.f75851d4 = m4858z3.getString("docId");
                                m4955V = compressHelper.m4955V(LWWViewerFragment.this.f75850c4, "Select * from Docs where id=" + LWWViewerFragment.this.f75851d4);
                            } else {
                                LWWViewerFragment.this.f75851d4 = m4858z2.getString("docId");
                                LWWViewerFragment.this.f74754D4 = m4858z2.getString("id");
                                m4955V = compressHelper.m4955V(LWWViewerFragment.this.f75850c4, "Select * from Docs where id=" + LWWViewerFragment.this.f75851d4);
                            }
                            m4858z = compressHelper.m4858z(m4955V);
                        }
                        String string = m4858z.getString("mainContent");
                        LWWViewerFragment.this.f74756x4 = m4858z.getString("resources");
                        LWWViewerFragment.this.f75852e4 = m4858z.getString("name");
                        String str2 = new String(compressHelper.m4870v(string, m4858z.getString("id"), "127"));
                        LWWViewerFragment lWWViewerFragment = LWWViewerFragment.this;
                        String m4117W3 = lWWViewerFragment.m4117W3(lWWViewerFragment.m44716w(), "LWWHeader.css");
                        LWWViewerFragment lWWViewerFragment2 = LWWViewerFragment.this;
                        String m4117W32 = lWWViewerFragment2.m4117W3(lWWViewerFragment2.m44716w(), "LWWFooter.css");
                        String str3 = m4117W3.replace("[size]", "200").replace("[title]", LWWViewerFragment.this.f75852e4) + str2 + m4117W32;
                        LWWViewerFragment.this.m4087m3();
                        LWWViewerFragment lWWViewerFragment3 = LWWViewerFragment.this;
                        lWWViewerFragment3.f75847Z3 = str3;
                        lWWViewerFragment3.m4503x4();
                        if (LWWViewerFragment.this.f74757y4 != null) {
                            if (LWWViewerFragment.this.f74758z4.size() == 0) {
                                LWWViewerFragment.this.f74757y4.setVisible(false);
                            } else {
                                LWWViewerFragment.this.f74757y4.setVisible(true);
                            }
                        }
                    }
                    LWWViewerFragment lWWViewerFragment4 = LWWViewerFragment.this;
                    lWWViewerFragment4.f74753C4 = compressHelper.m4955V(lWWViewerFragment4.f75850c4, "Select * from sections where docId=" + LWWViewerFragment.this.f75851d4);
                    if (compressHelper.m4892n1()) {
                        return;
                    }
                    LWWViewerFragment.this.m4102d4("Chapter");
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    e.printStackTrace();
                    LWWViewerFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.LWW.LWWViewerFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = LWWViewerFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    LWWViewerFragment lWWViewerFragment = LWWViewerFragment.this;
                    lWWViewerFragment.m4078s4(lWWViewerFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4945Y0(LWWViewerFragment.this.f75850c4, "base"));
                LWWViewerFragment lWWViewerFragment2 = LWWViewerFragment.this;
                lWWViewerFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", lWWViewerFragment2.f75847Z3, "text/html", "utf-8", null);
                LWWViewerFragment.this.m4092j4();
                LWWViewerFragment.this.m4098g4();
                LWWViewerFragment.this.m4100f3(C4804R.C4811menu.f87329menu_amviewer);
                LWWViewerFragment.this.m44735q2(false);
                LWWViewerFragment.this.m4140G3();
            }
        });
        return inflate;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4504B4("soheilvb");
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f74753C4);
            bundle.putString("TitleProperty", "name");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "lwwsections");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        this.f74757y4 = menu.findItem(C4804R.C4808id.f86774action_gallery);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: m1 */
    public void mo3501m1(Bundle bundle) {
        super.mo3501m1(bundle);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        if (str2.equals("image")) {
            m4504B4(str3.replace("//", ""));
            return true;
        }
        String str4 = str3 + "&";
        if (str2.equals(Annotation.f59806M2) && str4.contains("content.aspx")) {
            if (!str4.toLowerCase().contains("sectionid=")) {
                return false;
            }
            new CompressHelper(m44716w()).m4883q1(this.f75850c4, CompressHelper.m4920f(str4.toLowerCase() + "&", "sectionid=", "&"), null, null);
        }
        return true;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: t3 */
    public void mo4077t3(String str) {
        super.mo4077t3(str);
    }
}
