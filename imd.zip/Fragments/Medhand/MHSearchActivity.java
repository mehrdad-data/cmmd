package net.imedicaldoctor.imd.Fragments.Medhand;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.StatusAdapter;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class MHSearchActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class MHSearchFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private AsyncTask f74895b4;

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4336S2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87165fragment_mhsearch_new, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4336S2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            appBarLayout.m27445s(false, false);
            appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Medhand.MHSearchActivity.MHSearchFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    relativeLayout.setVisibility(0);
                }
            }, 800L);
            this.f75216M3 = new StatusAdapter(m44716w(), "Search Book");
            this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "Text", "table") { // from class: net.imedicaldoctor.imd.Fragments.Medhand.MHSearchActivity.MHSearchFragment.2
                @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
                /* renamed from: e0 */
                public void mo3397e0(Bundle bundle2, int i) {
                    MHSearchFragment.this.m4330Y2();
                    MHSearchFragment mHSearchFragment = MHSearchFragment.this;
                    mHSearchFragment.f75215L3.m4883q1(mHSearchFragment.f75212I3, bundle2.getString("URL"), null, null);
                }
            };
            ((Button) this.f75221R3.findViewById(C4804R.C4808id.f87016show_book)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Medhand.MHSearchActivity.MHSearchFragment.3
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MHSearchFragment mHSearchFragment = MHSearchFragment.this;
                    mHSearchFragment.f75215L3.m4883q1(mHSearchFragment.f75212I3, "index.html", null, null);
                }
            });
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(true);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4952W(bundle, "select rowid as _id,* from search where text match '" + str + "*'", "fsearch.db");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new MHSearchFragment());
    }
}
