package net.imedicaldoctor.imd.Fragments.Medhand;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.WebView;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.CollapsingToolbar.CollapsingToolbarLayout;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MHViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class MHViewerFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        public boolean f74900A4;

        /* renamed from: B4 */
        public ArrayList<String> f74901B4;

        /* renamed from: C4 */
        public String f74902C4;

        /* renamed from: D4 */
        public int f74903D4;

        /* renamed from: E4 */
        public boolean f74904E4;

        /* renamed from: F4 */
        private boolean f74905F4;

        /* renamed from: w4 */
        public ArrayList<Bundle> f74906w4;

        /* renamed from: x4 */
        public String f74907x4;

        /* renamed from: y4 */
        public String f74908y4;

        /* renamed from: z4 */
        public String f74909z4;

        /* renamed from: B4 */
        private Bundle m4443B4(String str, String str2) {
            Bundle bundle = new Bundle();
            bundle.putString("url", str);
            bundle.putString(TypedValues.Cycle.f5658R, str2);
            return bundle;
        }

        /* renamed from: I4 */
        private void m4436I4(String str) {
            ArrayList<String> arrayList = this.f74901B4;
            if (arrayList == null || arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
                return;
            }
            ArrayList arrayList2 = new ArrayList();
            Iterator<String> it2 = this.f74901B4.iterator();
            while (it2.hasNext()) {
                String next = it2.next();
                Bundle bundle = new Bundle();
                bundle.putString("ImagePath", next);
                bundle.putString("Description", "");
                bundle.putString("id", next);
                if (new File(next).length() > 5000) {
                    arrayList2.add(bundle);
                }
            }
            int i = 0;
            for (int i2 = 0; i2 < arrayList2.size(); i2++) {
                if (((Bundle) arrayList2.get(i2)).getString("id").equals(str)) {
                    i = i2;
                }
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList2);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* renamed from: A4 */
        public void m4444A4() {
            this.f75839R3.findItem(C4804R.C4808id.f86773action_forward).setEnabled(true);
            this.f75839R3.findItem(C4804R.C4808id.f86773action_forward).setIcon(C4804R.C4807drawable.f86585ic_action_next_item);
        }

        /* renamed from: C4 */
        public void m4442C4() {
            if (this.f74906w4.size() == 0) {
                m4435x4();
                m4434y4();
                return;
            }
            if (this.f74903D4 > 0 || this.f74904E4) {
                m4433z4();
            } else {
                m4435x4();
            }
            if (this.f74903D4 >= this.f74906w4.size() - 1) {
                m4434y4();
            } else {
                m4444A4();
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:21:0x00d2  */
        /* renamed from: D4 */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public java.lang.String m4441D4(java.lang.String r8) {
            /*
                Method dump skipped, instructions count: 287
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Medhand.MHViewerActivity.MHViewerFragment.m4441D4(java.lang.String):java.lang.String");
        }

        /* renamed from: E4 */
        public void m4440E4() {
            this.f74905F4 = false;
            if (this.f74903D4 == this.f74906w4.size() - 1 && this.f74904E4) {
                WebView webView = this.f75853f4;
                webView.loadUrl("javascript:console.log(\"history,,,,," + this.f74907x4 + ",,,,,\" + window.pageYOffset);");
                this.f74904E4 = false;
                this.f74905F4 = true;
            }
            if (!this.f74905F4) {
                int i = this.f74903D4;
                if (i - 1 >= 0) {
                    int i2 = i - 1;
                    this.f74903D4 = i2;
                    this.f74902C4 = this.f74906w4.get(i2).getString(TypedValues.Cycle.f5658R);
                    m4438G4(this.f74906w4.get(this.f74903D4).getString("url"), Boolean.TRUE);
                }
            }
            m4442C4();
        }

        /* renamed from: F4 */
        public void m4439F4() {
            if (this.f74906w4.size() == 0) {
                return;
            }
            if (this.f74903D4 + 1 <= this.f74906w4.size() - 1) {
                int i = this.f74903D4 + 1;
                this.f74903D4 = i;
                this.f74902C4 = this.f74906w4.get(i).getString(TypedValues.Cycle.f5658R);
                m4438G4(this.f74906w4.get(this.f74903D4).getString("url"), Boolean.TRUE);
            }
            m4442C4();
        }

        /* renamed from: G4 */
        public void m4438G4(String str, Boolean bool) {
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str, "#");
            String str2 = splitByWholeSeparator[0];
            String str3 = splitByWholeSeparator.length == 2 ? splitByWholeSeparator[1] : null;
            this.f74907x4 = str2;
            ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str2, "/")));
            arrayList.remove(arrayList.size() - 1);
            String str4 = "file://" + new File(CompressHelper.m4945Y0(this.f75850c4, StringUtils.join(arrayList, "/"))).getAbsolutePath() + "/";
            this.f74908y4 = str4;
            this.f75847Z3 = m4441D4(str2.replace("/", "\\"));
            this.f74909z4 = str3;
            if (bool.booleanValue()) {
                this.f75853f4.loadDataWithBaseURL(str4, this.f75847Z3, "text/html", "utf-8", null);
            }
        }

        /* renamed from: H4 */
        public String m4437H4(String str) {
            ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
            arrayList.remove(arrayList.size() - 1);
            return StringUtils.join(arrayList, "/");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: P3 */
        public boolean mo3571P3(ConsoleMessage consoleMessage) {
            String[] splitByWholeSeparator;
            String[] split = consoleMessage.message().split(",,,,,");
            if (split[0].equals("title")) {
                this.f75852e4 = split[1];
                ((CollapsingToolbarLayout) this.f75849b4.findViewById(C4804R.C4808id.f86847collapsing_toolbar)).setTitle(this.f75852e4);
                return true;
            }
            if (split[0].equals("images")) {
                String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
                ArrayList<String> arrayList = new ArrayList<>();
                for (String str : splitByWholeSeparator2) {
                    String replace = this.f74908y4.replace("file://", "");
                    String substring = replace.substring(0, replace.length() - 1);
                    for (String str2 : StringUtils.splitByWholeSeparator(str, "/")) {
                        substring = str2.equals("..") ? m4437H4(substring) : substring + "/" + str2;
                    }
                    if (new File(substring).length() > SimpleExoPlayer.f32068s1) {
                        arrayList.add(substring);
                    }
                    iMDLogger.m3290j("MedhandImages", "Imagepath = : " + substring);
                }
                this.f74901B4 = arrayList;
                if (arrayList.size() > 0) {
                    this.f75839R3.findItem(C4804R.C4808id.f86774action_gallery).setVisible(true);
                } else {
                    this.f75839R3.findItem(C4804R.C4808id.f86774action_gallery).setVisible(false);
                }
                mo3978f4();
            } else if (split[0].equals("history")) {
                this.f74906w4.add(m4443B4(split[1], split[2]));
                int size = this.f74906w4.size() - 1;
                this.f74903D4 = size;
                if (this.f74905F4) {
                    if (size - 1 >= 0) {
                        int i = size - 1;
                        this.f74903D4 = i;
                        this.f74902C4 = this.f74906w4.get(i).getString(TypedValues.Cycle.f5658R);
                        m4438G4(this.f74906w4.get(this.f74903D4).getString("url"), Boolean.TRUE);
                    }
                    this.f74905F4 = false;
                }
                m4442C4();
            }
            return super.mo3571P3(consoleMessage);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: Q3 */
        public boolean mo4126Q3(WebView webView, String str, String str2, JsResult jsResult) {
            jsResult.confirm();
            return true;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            ArrayList<String> arrayList = this.f74901B4;
            if (arrayList == null || arrayList.size() <= 0) {
                return null;
            }
            return m4071w3(this.f74901B4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S3 */
        public void mo3569S3(WebView webView, String str) {
            WebView webView2;
            String str2;
            super.mo3569S3(webView, str);
            this.f75853f4.loadUrl("javascript:console.log(\"title,,,,,\" + document.title);");
            if (this.f74900A4) {
                webView2 = this.f75853f4;
                str2 = "javascript:onBodyLoad();";
            } else {
                webView2 = this.f75853f4;
                str2 = "javascript:console.log(\"images,,,,,\" + getImageList());";
            }
            webView2.loadUrl(str2);
            if (this.f74902C4 != null) {
                WebView webView3 = this.f75853f4;
                webView3.loadUrl("javascript:document.body.scrollTop=" + this.f74902C4);
                this.f74902C4 = null;
            }
            String str3 = this.f74909z4;
            if (str3 != null) {
                mo4144C3(str3);
                this.f74909z4 = null;
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87368menu_mhviewer, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f74906w4 = bundle.getParcelableArrayList("mHistory");
                this.f74907x4 = bundle.getString("mCurrentURL");
                this.f74908y4 = bundle.getString("mLastBasePath");
                this.f74900A4 = bundle.getBoolean("mNewZoom");
                this.f74901B4 = bundle.getStringArrayList("mImages");
                this.f74902C4 = bundle.getString("mGotoOffset");
                this.f74903D4 = bundle.getInt("mHistoryIndex");
                this.f74904E4 = bundle.getBoolean("mRegisterLastPage");
            }
            if (m44859B() == null) {
                return inflate;
            }
            try {
                CompressHelper compressHelper = new CompressHelper(m44716w());
                String str = this.f75847Z3;
                if (str == null || str.length() == 0) {
                    this.f74906w4 = new ArrayList<>();
                    m4438G4(this.f75851d4, Boolean.FALSE);
                }
                compressHelper.m4892n1();
                m4102d4("");
                this.f75853f4.loadDataWithBaseURL(this.f74908y4, this.f75847Z3, "text/html", "utf-8", null);
                m4092j4();
                m4098g4();
                m4100f3(C4804R.C4811menu.f87368menu_mhviewer);
                m44735q2(false);
                m4140G3();
                ((AppBarLayout) this.f75849b4.findViewById(C4804R.C4808id.f86799appbar)).m27445s(false, true);
                return inflate;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                m4080r4(e);
                return inflate;
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86773action_forward) {
                m4439F4();
                return true;
            } else if (itemId == C4804R.C4808id.f86767action_back) {
                m4440E4();
                return true;
            } else if (itemId == C4804R.C4808id.f86774action_gallery) {
                m4436I4("soheilvb");
                return true;
            } else {
                return super.mo3709e1(menuItem);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            this.f75839R3 = menu;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
            new CompressHelper(m44716w());
            this.f74904E4 = true;
            try {
                str3 = URLDecoder.decode(str3, "UTF-8");
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                iMDLogger.m3294f("MHViewerShould", "Error in decoding " + str3 + " : " + e.getMessage());
            }
            String substring = str3.replace(m4437H4(CompressHelper.m4948X0(this.f75850c4)), "").substring(4);
            if (this.f74903D4 != this.f74906w4.size() - 1 && this.f74906w4.size() > 0) {
                int i = this.f74903D4;
                int size = this.f74906w4.size() - this.f74903D4;
                if (size != 0) {
                    for (int i2 = 0; i2 < size; i2++) {
                        this.f74906w4.remove(i);
                    }
                }
            }
            if (this.f74906w4.size() != 0) {
                ArrayList<Bundle> arrayList = this.f74906w4;
                if (arrayList.get(arrayList.size() - 1).getString("url").equals(this.f74907x4)) {
                    ArrayList<Bundle> arrayList2 = this.f74906w4;
                    arrayList2.remove(arrayList2.size() - 1);
                }
            }
            WebView webView2 = this.f75853f4;
            webView2.loadUrl("javascript:console.log(\"history,,,,," + this.f74907x4 + ",,,,,\" + window.pageYOffset);");
            m4442C4();
            if (substring.contains(".html")) {
                m4438G4(substring, Boolean.TRUE);
                return true;
            }
            return true;
        }

        /* renamed from: x4 */
        public void m4435x4() {
            this.f75839R3.findItem(C4804R.C4808id.f86767action_back).setEnabled(false);
            this.f75839R3.findItem(C4804R.C4808id.f86767action_back).setIcon(C4804R.C4807drawable.f86590ic_action_previous_item_disabled);
        }

        /* renamed from: y4 */
        public void m4434y4() {
            this.f75839R3.findItem(C4804R.C4808id.f86773action_forward).setEnabled(false);
            this.f75839R3.findItem(C4804R.C4808id.f86773action_forward).setIcon(C4804R.C4807drawable.f86587ic_action_next_item_disabled);
        }

        /* renamed from: z4 */
        public void m4433z4() {
            this.f75839R3.findItem(C4804R.C4808id.f86767action_back).setEnabled(true);
            this.f75839R3.findItem(C4804R.C4808id.f86767action_back).setIcon(C4804R.C4807drawable.f86588ic_action_previous_item);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new MHViewerFragment(), bundle);
    }
}
