package net.imedicaldoctor.imd.Fragments.VisualDXLookup;

import android.app.ProgressDialog;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.exifinterface.media.ExifInterface;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.GridAutoFitLayoutManager;
import net.imedicaldoctor.imd.iMD;
import net.imedicaldoctor.imd.iMDActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class VDDxResults extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class VDDxResultsFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        private Bundle f76120A4;

        /* renamed from: B4 */
        public ArrayList<Bundle> f76121B4;

        /* renamed from: w4 */
        public Bundle f76122w4;

        /* renamed from: x4 */
        public String f76123x4;

        /* renamed from: y4 */
        public String f76124y4;

        /* renamed from: z4 */
        public RecyclerView f76125z4;

        /* loaded from: classes2.dex */
        public static class HeaderPlaceHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f76148I;

            public HeaderPlaceHolder(View view) {
                super(view);
                this.f76148I = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
            }
        }

        /* loaded from: classes2.dex */
        public static class PhotoCaptionWarningPlaceHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f76149I;

            /* renamed from: J */
            public ImageView f76150J;

            /* renamed from: K */
            public ImageView f76151K;

            /* renamed from: L */
            public MaterialRippleLayout f76152L;

            public PhotoCaptionWarningPlaceHolder(View view) {
                super(view);
                this.f76149I = (TextView) view.findViewById(C4804R.C4808id.f86834caption);
                this.f76150J = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
                this.f76151K = (ImageView) view.findViewById(C4804R.C4808id.f87081warning);
                this.f76152L = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            }
        }

        /* renamed from: A4 */
        public int m3987A4(ArrayList<Bundle> arrayList) {
            Iterator<Bundle> it2 = arrayList.iterator();
            int i = 0;
            while (it2.hasNext()) {
                i += it2.next().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
            }
            return i;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(m4073v3(m4073v3(this.f76121B4).getParcelableArrayList(FirebaseAnalytics.Param.f55203f0)).getString("images"), ",");
            Bundle bundle = this.f76122w4;
            return CompressHelper.m4942Z0(bundle, splitByWholeSeparator[0] + ".jpg", "Large-Encrypted");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            String str;
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
            this.f75863p4 = new CompressHelper(m44716w());
            this.f75849b4 = inflate;
            this.f76122w4 = m44859B().getBundle("DB");
            this.f76120A4 = new Bundle();
            this.f76123x4 = m44859B().getString("URL").replace("ddx-", "");
            this.f76124y4 = m44859B().getString("moduleId");
            final CompressHelper compressHelper = new CompressHelper(m44716w());
            if (bundle != null && bundle.containsKey(FirebaseAnalytics.Param.f55203f0)) {
                this.f76121B4 = bundle.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0);
            }
            final int length = StringUtils.splitByWholeSeparator(this.f76123x4, ",").length;
            final RecyclerView.Adapter adapter = new RecyclerView.Adapter() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.1
                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                /* renamed from: C */
                public int mo3384C(int i) {
                    VDDxResultsFragment vDDxResultsFragment = VDDxResultsFragment.this;
                    return vDDxResultsFragment.m3986x4(i, vDDxResultsFragment.f76121B4).containsKey("Title") ? 0 : 1;
                }

                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                /* renamed from: R */
                public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
                    String str2;
                    VDDxResultsFragment vDDxResultsFragment = VDDxResultsFragment.this;
                    Bundle m3986x4 = vDDxResultsFragment.m3986x4(i, vDDxResultsFragment.f76121B4);
                    if (m3986x4.containsKey("Title")) {
                        boolean equals = m3986x4.getString("Title").equals(String.valueOf(length));
                        TextView textView = ((HeaderPlaceHolder) viewHolder).f76148I;
                        if (equals) {
                            str2 = "Matched All Findings";
                        } else {
                            str2 = "Matched " + m3986x4.getString("Title") + " Findings";
                        }
                        textView.setText(str2);
                        return;
                    }
                    final PhotoCaptionWarningPlaceHolder photoCaptionWarningPlaceHolder = (PhotoCaptionWarningPlaceHolder) viewHolder;
                    Bundle bundle2 = m3986x4.getBundle("Item");
                    String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(bundle2.getString("images"), ",");
                    final String m4942Z0 = CompressHelper.m4942Z0(VDDxResultsFragment.this.f76122w4, splitByWholeSeparator[0] + ".jpg", "Medium");
                    String string = bundle2.getString("diagnosisTitle");
                    if (VDDxResultsFragment.this.f76120A4.containsKey(m4942Z0)) {
                        photoCaptionWarningPlaceHolder.f76152L.setRippleColor(VDDxResultsFragment.this.f76120A4.getInt(m4942Z0));
                    } else {
                        VDDxResultsFragment.this.m4083q3(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Palette.Swatch m43631C = Palette.m43628b(BitmapFactory.decodeFile(m4942Z0)).m43594g().m43631C();
                                if (m43631C == null) {
                                    return;
                                }
                                int m43579e = m43631C.m43579e();
                                if (VDDxResultsFragment.this.f76120A4.containsKey(m4942Z0)) {
                                    return;
                                }
                                VDDxResultsFragment.this.f76120A4.putInt(m4942Z0, m43579e);
                            }
                        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.1.2
                            @Override // java.lang.Runnable
                            public void run() {
                                photoCaptionWarningPlaceHolder.f76152L.setRippleColor(VDDxResultsFragment.this.f76120A4.getInt(m4942Z0));
                            }
                        });
                    }
                    photoCaptionWarningPlaceHolder.f76149I.setText(string);
                    Glide.m40315G(VDDxResultsFragment.this.m44716w()).mo40150i(new File(m4942Z0)).m40191t2(photoCaptionWarningPlaceHolder.f76150J);
                    if (bundle2.getString("severity").equals(ExifInterface.f14403S4)) {
                        photoCaptionWarningPlaceHolder.f76151K.setVisibility(0);
                    } else {
                        photoCaptionWarningPlaceHolder.f76151K.setVisibility(4);
                    }
                    final String string2 = bundle2.getString("diagnosesModulesId");
                    photoCaptionWarningPlaceHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.1.3
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            String str3 = string2;
                            String substring = str3.substring(0, str3.length() - VDDxResultsFragment.this.f76124y4.length());
                            if (((iMD) VDDxResultsFragment.this.m44716w().getApplicationContext()).f83461s != null) {
                                new CompressHelper(VDDxResultsFragment.this.m44716w()).m4883q1((Bundle) new ArrayList(Collections2.m23110e(((iMD) VDDxResultsFragment.this.m44716w().getApplicationContext()).f83461s, new Predicate<Bundle>() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.1.3.1
                                    @Override // com.google.common.base.Predicate
                                    /* renamed from: a */
                                    public boolean apply(Bundle bundle3) {
                                        return bundle3.getString("Type").equals("visualdx");
                                    }
                                })).get(0), substring, null, null);
                            }
                        }
                    });
                }

                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                /* renamed from: T */
                public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup2, int i) {
                    return mo3384C(i) == 0 ? new HeaderPlaceHolder(LayoutInflater.from(VDDxResultsFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup2, false)) : new PhotoCaptionWarningPlaceHolder(LayoutInflater.from(VDDxResultsFragment.this.m44716w()).inflate(C4804R.C4810layout.f87210grid_view_item_image_caption_danger, viewGroup2, false));
                }

                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                /* renamed from: s */
                public int mo3359s() {
                    VDDxResultsFragment vDDxResultsFragment = VDDxResultsFragment.this;
                    ArrayList<Bundle> arrayList = vDDxResultsFragment.f76121B4;
                    if (arrayList == null) {
                        return 0;
                    }
                    return vDDxResultsFragment.m3984z4(arrayList);
                }
            };
            final RecyclerView recyclerView = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
            this.f76125z4 = recyclerView;
            if (this.f76121B4 == null) {
                if (this.f76123x4.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("SELECT diagnosesModulesId,count(*) c, diagnosisTitle, images, severity, sort FROM diagnosesmodulesfindings Where moduleId=");
                    sb.append(this.f76124y4);
                    sb.append(" AND findingId IN(");
                    sb.append(this.f76123x4);
                    sb.append(") GROUP BY diagnosesModulesId having c > ");
                    sb.append((StringUtils.splitByWholeSeparator(this.f76123x4, ",").length / 2) - 1);
                    sb.append(" order by c desc, sort asc, diagnosisTitle asc");
                    str = sb.toString();
                } else {
                    str = "SELECT diagnosesModulesId,0 c, diagnosisTitle, images, severity, sort FROM diagnosesmodulesfindings Where moduleId=" + this.f76124y4 + " GROUP BY diagnosesModulesId order by sort asc, diagnosisTitle asc";
                }
                final String str2 = str;
                new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.2

                    /* renamed from: a */
                    private ProgressDialog f76136a;

                    {
                        this.f76136a = new ProgressDialog(VDDxResultsFragment.this.m44716w());
                    }

                    @Override // android.os.AsyncTask
                    protected Object doInBackground(Object[] objArr) {
                        VDDxResultsFragment vDDxResultsFragment = VDDxResultsFragment.this;
                        CompressHelper compressHelper2 = compressHelper;
                        vDDxResultsFragment.f76121B4 = compressHelper2.m4941Z1(compressHelper2.m4955V(vDDxResultsFragment.f76122w4, str2), "c");
                        return null;
                    }

                    @Override // android.os.AsyncTask
                    protected void onPostExecute(Object obj) {
                        if (this.f76136a.isShowing()) {
                            this.f76136a.dismiss();
                        }
                        VDDxResultsFragment vDDxResultsFragment = VDDxResultsFragment.this;
                        if (vDDxResultsFragment.f76121B4 == null) {
                            vDDxResultsFragment.m44716w().setTitle("Nothing Found !");
                            VDDxResultsFragment vDDxResultsFragment2 = VDDxResultsFragment.this;
                            vDDxResultsFragment2.f75852e4 = "Nothing Found !";
                            vDDxResultsFragment2.m4101e4("Nothing Found !");
                            VDDxResultsFragment.this.mo3978f4();
                            return;
                        }
                        StringBuilder sb2 = new StringBuilder();
                        VDDxResultsFragment vDDxResultsFragment3 = VDDxResultsFragment.this;
                        sb2.append(vDDxResultsFragment3.m3987A4(vDDxResultsFragment3.f76121B4));
                        sb2.append(" Diagnosis Found !");
                        vDDxResultsFragment.f75852e4 = sb2.toString();
                        VDDxResultsFragment.this.m44716w().setTitle(VDDxResultsFragment.this.f75852e4);
                        VDDxResultsFragment vDDxResultsFragment4 = VDDxResultsFragment.this;
                        vDDxResultsFragment4.m4101e4(vDDxResultsFragment4.f75852e4);
                        VDDxResultsFragment.this.mo3978f4();
                        recyclerView.setAdapter(adapter);
                        VDDxResultsFragment.this.m4130O2();
                    }

                    @Override // android.os.AsyncTask
                    protected void onPreExecute() {
                        this.f76136a.setMessage("Searching");
                        this.f76136a.show();
                    }
                }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
            }
            final GridAutoFitLayoutManager gridAutoFitLayoutManager = new GridAutoFitLayoutManager(m44716w(), (int) (m44782a0().getDisplayMetrics().density * 100.0f));
            gridAutoFitLayoutManager.m43287N3(new GridLayoutManager.SpanSizeLookup() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.3
                @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
                /* renamed from: f */
                public int mo3768f(int i) {
                    if (recyclerView.getAdapter().mo3384C(i) == 0) {
                        return gridAutoFitLayoutManager.f83243b0;
                    }
                    return 1;
                }
            });
            recyclerView.setLayoutManager(gridAutoFitLayoutManager);
            recyclerView.setItemAnimator(new DefaultItemAnimator());
            this.f75849b4 = inflate;
            this.f75858k4 = (Toolbar) inflate.findViewById(C4804R.C4808id.f87063toolbar);
            m4100f3(C4804R.C4811menu.f87324empty);
            m44735q2(false);
            m4140G3();
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: f4 */
        public void mo3978f4() {
            new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.5

                /* renamed from: a */
                byte[] f76146a;

                @Override // android.os.AsyncTask
                protected Object doInBackground(Object[] objArr) {
                    try {
                        File file = new File(VDDxResultsFragment.this.mo3979S2());
                        this.f76146a = new CompressHelper(VDDxResultsFragment.this.m44716w()).m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127");
                        return null;
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        iMDLogger.m3294f("ImageGallery", "Error in decrypting image");
                        return null;
                    }
                }

                @Override // android.os.AsyncTask
                protected void onPostExecute(Object obj) {
                    super.onPostExecute(obj);
                    Glide.m40315G(VDDxResultsFragment.this.m44716w()).mo40151h(this.f76146a).m40191t2(VDDxResultsFragment.this.f75859l4);
                }
            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: m4 */
        public boolean mo3567m4() {
            return false;
        }

        @Override // androidx.fragment.app.Fragment, android.content.ComponentCallbacks
        public void onConfigurationChanged(Configuration configuration) {
            super.onConfigurationChanged(configuration);
            this.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxResults.VDDxResultsFragment.4
                @Override // java.lang.Runnable
                public void run() {
                    VDDxResultsFragment.this.f76125z4.getAdapter().m42860G();
                }
            }, 500L);
        }

        /* renamed from: x4 */
        public Bundle m3986x4(int i, ArrayList<Bundle> arrayList) {
            Iterator<Bundle> it2 = arrayList.iterator();
            int i2 = 0;
            while (it2.hasNext()) {
                Bundle next = it2.next();
                if (i == i2) {
                    Bundle bundle = new Bundle();
                    bundle.putString("Title", next.getString("title"));
                    return bundle;
                }
                int size = i2 + next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
                if (i <= size) {
                    Bundle bundle2 = new Bundle();
                    bundle2.putBundle("Item", (Bundle) next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).get((i - (size - next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size())) - 1));
                    return bundle2;
                }
                i2 = size + 1;
            }
            return null;
        }

        /* renamed from: z4 */
        public int m3984z4(ArrayList<Bundle> arrayList) {
            int i = 0;
            if (arrayList == null) {
                return 0;
            }
            Iterator<Bundle> it2 = arrayList.iterator();
            while (it2.hasNext()) {
                i = i + it2.next().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size() + 1;
            }
            return i;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new VDDxResultsFragment());
    }
}
