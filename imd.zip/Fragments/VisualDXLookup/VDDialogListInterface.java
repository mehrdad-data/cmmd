package net.imedicaldoctor.imd.Fragments.VisualDXLookup;

import android.os.Bundle;

/* loaded from: classes2.dex */
public interface VDDialogListInterface {
    /* renamed from: g */
    void mo3977g(Bundle bundle, String str);
}
