package net.imedicaldoctor.imd.Fragments.VisualDXLookup;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity;

/* loaded from: classes2.dex */
public class VDDxFindingsDialog extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f76100g4;

    /* renamed from: h4 */
    private String f76101h4;

    /* renamed from: i4 */
    private Bundle f76102i4;

    /* renamed from: j4 */
    private ArrayList<String> f76103j4;

    /* renamed from: k4 */
    private ArrayList<String> f76104k4;

    /* renamed from: l4 */
    private String f76105l4;

    /* renamed from: m4 */
    private Bundle f76106m4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        String str;
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f76100g4 = m44859B().getBundle("db");
        this.f76106m4 = m44859B().getBundle("parent");
        this.f76102i4 = m44859B().getBundle("allFindings");
        this.f76103j4 = m44859B().getStringArrayList("selectedFindings");
        this.f76104k4 = m44859B().getStringArrayList("disabledItems");
        this.f76105l4 = m44859B().getString("moduleId");
        this.f76101h4 = !this.f76106m4.containsKey("id") ? "0" : this.f76106m4.getString("id");
        if (this.f76106m4.containsKey("leaf") && this.f76106m4.getString("leaf").equals(IcyHeaders.f35463C2)) {
            str = ("Select -1 as _id, '" + this.f76106m4.getString("id") + "' as id, '" + this.f76106m4.getString("shortName") + "' as shortName, '" + this.f76106m4.getString("longName") + "' as longName, '' as children, '1' as leaf, '' as modules UNION ") + "SELECT id as _id, id, shortName, longName, children, leaf, ',' || supportedModules || ',' as modules FROM Findings where parentId = " + this.f76101h4 + " and modules like '%," + this.f76105l4 + ",%' order by shortName asc";
        } else {
            str = "SELECT id as _id,id, shortName, longName, children, leaf, ',' || supportedModules || ',' as modules FROM Findings where parentId = " + this.f76101h4 + " and modules like '%," + this.f76105l4 + ",%' order by shortName asc";
        }
        final CompressHelper compressHelper = new CompressHelper(m44716w());
        final CursorAdapter cursorAdapter = new CursorAdapter(m44716w(), compressHelper.m4912h(compressHelper.m4955V(this.f76100g4, str)), 0) { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxFindingsDialog.1
            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: d */
            public void mo3522d(View view, Context context, Cursor cursor) {
                TextView textView = (TextView) view.getTag();
                Bundle m4956U1 = compressHelper.m4956U1(cursor);
                if (m4956U1.getString("children").length() == 0) {
                    ImageView imageView = (ImageView) view.findViewById(C4804R.C4808id.f86840check_icon);
                    String string = m4956U1.getString("id");
                    if (VDDxFindingsDialog.this.f76103j4.contains(string)) {
                        imageView.setVisibility(0);
                    } else {
                        imageView.setVisibility(4);
                    }
                    if (VDDxFindingsDialog.this.f76104k4.contains(string)) {
                        textView.setTextColor(-7829368);
                        imageView.setVisibility(0);
                    }
                }
                textView.setText(cursor.getString(cursor.getColumnIndex("shortName")));
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getItemViewType(int i) {
                Cursor cursor = (Cursor) getItem(i);
                return cursor.getString(cursor.getColumnIndex("children")).length() > 0 ? 0 : 1;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getViewTypeCount() {
                return 2;
            }

            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: i */
            public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                View inflate2 = LayoutInflater.from(context).inflate(cursor.getString(cursor.getColumnIndex("children")).length() > 0 ? C4804R.C4810layout.f87285list_view_item_simple_text_arrow : C4804R.C4810layout.f87288list_view_item_simple_text_check, viewGroup, false);
                inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                return inflate2;
            }

            @Override // android.widget.BaseAdapter, android.widget.ListAdapter
            public boolean isEnabled(int i) {
                Bundle m4956U1 = compressHelper.m4956U1((Cursor) getItem(i));
                if (m4956U1.getString("children").length() == 0) {
                    return !VDDxFindingsDialog.this.f76104k4.contains(m4956U1.getString("id"));
                }
                return true;
            }
        };
        listView.setAdapter((ListAdapter) cursorAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxFindingsDialog.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                if (mo45341b.moveToPosition(i)) {
                    Bundle m4956U1 = compressHelper.m4956U1(mo45341b);
                    if (m4956U1.getString("children").length() == 0) {
                        String string = m4956U1.getString("id");
                        if (VDDxFindingsDialog.this.f76103j4.contains(string)) {
                            VDDxFindingsDialog.this.f76103j4.remove(string);
                        } else {
                            VDDxFindingsDialog.this.f76103j4.add(string);
                        }
                        ((VDDxBuilderActivity.VDDXBuilderFragment) VDDxFindingsDialog.this.m44753k0()).m4022y4();
                        cursorAdapter.notifyDataSetChanged();
                        return;
                    }
                    VDDxFindingsDialog vDDxFindingsDialog = new VDDxFindingsDialog();
                    Bundle bundle2 = new Bundle();
                    bundle2.putBundle("db", VDDxFindingsDialog.this.f76100g4);
                    bundle2.putBundle("allFindings", VDDxFindingsDialog.this.f76102i4);
                    bundle2.putStringArrayList("selectedFindings", VDDxFindingsDialog.this.f76103j4);
                    bundle2.putBundle("parent", m4956U1);
                    bundle2.putString("moduleId", VDDxFindingsDialog.this.f76105l4);
                    bundle2.putStringArrayList("disabledItems", VDDxFindingsDialog.this.f76104k4);
                    vDDxFindingsDialog.m44751k2(bundle2);
                    vDDxFindingsDialog.m44870c3(true);
                    vDDxFindingsDialog.m44844E2(VDDxFindingsDialog.this.m44753k0(), 0);
                    vDDxFindingsDialog.mo29915h3(VDDxFindingsDialog.this.m44820L(), "VDDialogFragment");
                    VDDxFindingsDialog.this.mo27003Q2();
                }
            }
        });
        builder.setView(inflate);
        return builder.create();
    }
}
