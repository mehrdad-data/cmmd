package net.imedicaldoctor.imd.Fragments.VisualDXLookup;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.exifinterface.media.ExifInterface;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import java.io.File;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.GridAutoFitLayoutManager;
import net.imedicaldoctor.imd.ViewHolders.ImageViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class VDDiagnosisActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class VDDiagnosisFragment extends ViewerHelperFragment implements VDDialogListInterface {

        /* renamed from: A4 */
        private int f76056A4;

        /* renamed from: B4 */
        private Bundle f76057B4;

        /* renamed from: C4 */
        public RecyclerView f76058C4;

        /* renamed from: w4 */
        private Bundle f76059w4;

        /* renamed from: x4 */
        private ArrayList<Bundle> f76060x4;

        /* renamed from: y4 */
        private ArrayList<Bundle> f76061y4;

        /* renamed from: z4 */
        private ArrayList<Bundle> f76062z4;

        /* loaded from: classes2.dex */
        public class DatabaseHeaderViewHolder {

            /* renamed from: a */
            public final TextView f76070a;

            public DatabaseHeaderViewHolder(View view) {
                this.f76070a = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
            }
        }

        /* loaded from: classes2.dex */
        public static class EmergencyTextViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f76072I;

            /* renamed from: J */
            public TextView f76073J;

            public EmergencyTextViewHolder(View view) {
                super(view);
                this.f76072I = (TextView) view.findViewById(C4804R.C4808id.text);
                this.f76073J = (TextView) view.findViewById(C4804R.C4808id.f86884emergency_text);
            }
        }

        /* loaded from: classes2.dex */
        public static class GridViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public GridView f76074I;

            public GridViewHolder(View view) {
                super(view);
                this.f76074I = (GridView) view.findViewById(C4804R.C4808id.f86908grid_view);
            }
        }

        /* loaded from: classes2.dex */
        public static class HeaderCellViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f76075I;

            public HeaderCellViewHolder(View view) {
                super(view);
                this.f76075I = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
            }
        }

        /* loaded from: classes2.dex */
        public static class RecyclerViewViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public RecyclerView f76076I;

            public RecyclerViewViewHolder(View view) {
                super(view);
                this.f76076I = (RecyclerView) view.findViewById(C4804R.C4808id.f87001recycler_view);
            }
        }

        /* loaded from: classes2.dex */
        public static class TextViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f76077I;

            public TextViewHolder(View view) {
                super(view);
                this.f76077I = (TextView) view.findViewById(C4804R.C4808id.text);
            }
        }

        /* loaded from: classes2.dex */
        public class VDDiagnosisAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f76078d;

            public VDDiagnosisAdapter(Context context) {
                this.f76078d = context;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                String string = m4003d0(i).getString("Type");
                if (string.equals("Header")) {
                    return 0;
                }
                if (string.equals("SimpleTextEmergency")) {
                    return 1;
                }
                if (string.equals("TextList")) {
                    return 2;
                }
                if (string.equals("GridView")) {
                    return 3;
                }
                return string.equals("Item") ? 4 : -1;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                Bundle m4003d0 = m4003d0(i);
                int m42556F = viewHolder.m42556F();
                if (m42556F == 0) {
                    ((HeaderCellViewHolder) viewHolder).f76075I.setText(m4003d0.getString("Text"));
                } else if (m42556F == 1) {
                    EmergencyTextViewHolder emergencyTextViewHolder = (EmergencyTextViewHolder) viewHolder;
                    emergencyTextViewHolder.f76072I.setText(m4003d0.getString("Text"));
                    emergencyTextViewHolder.f76073J.setVisibility(m4003d0.getInt("Emergency") == 0 ? 8 : 0);
                } else if (m42556F == 2) {
                    TextViewHolder textViewHolder = (TextViewHolder) viewHolder;
                    textViewHolder.f76077I.setText(m4003d0.getString("Text"));
                    textViewHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.VDDiagnosisAdapter.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            VDDialogList vDDialogList = new VDDialogList();
                            Bundle bundle = new Bundle();
                            bundle.putBundle("db", VDDiagnosisFragment.this.f75850c4);
                            bundle.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, VDDiagnosisFragment.this.f76060x4);
                            bundle.putString("titleProperty", "longName");
                            bundle.putString("type", "Module");
                            vDDialogList.m44751k2(bundle);
                            vDDialogList.m44870c3(true);
                            vDDialogList.m44844E2(VDDiagnosisFragment.this, 0);
                            vDDialogList.mo29915h3(VDDiagnosisFragment.this.m44820L(), "VDDialogFragment");
                        }
                    });
                } else if (m42556F != 3) {
                    if (m42556F == 4) {
                        RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                        rippleTextViewHolder.f83300I.setText(m4003d0.getBundle("Item").getString("fieldName"));
                        rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.VDDiagnosisAdapter.4
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                Bundle bundle = VDDiagnosisAdapter.this.m4003d0(i).getBundle("Item");
                                VDDiagnosisFragment vDDiagnosisFragment = VDDiagnosisFragment.this;
                                vDDiagnosisFragment.f75863p4.m4883q1(vDDiagnosisFragment.f75850c4, "Doc-" + ((Bundle) VDDiagnosisFragment.this.f76060x4.get(VDDiagnosisFragment.this.f76056A4)).getString("id"), null, "field" + bundle.getString("fieldId"));
                            }
                        });
                    }
                } else {
                    RecyclerViewViewHolder recyclerViewViewHolder = (RecyclerViewViewHolder) viewHolder;
                    final ChaptersAdapter chaptersAdapter = new ChaptersAdapter(VDDiagnosisFragment.this.m44716w(), VDDiagnosisFragment.this.f76062z4, "title", C4804R.C4810layout.f87246list_view_item_image) { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.VDDiagnosisAdapter.2
                        @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                        /* renamed from: e0 */
                        public void mo3406e0(RecyclerView.ViewHolder viewHolder2, final Bundle bundle, int i2) {
                            final ImageViewHolder imageViewHolder = (ImageViewHolder) viewHolder2;
                            Bundle bundle2 = VDDiagnosisFragment.this.f75850c4;
                            final String m4942Z0 = CompressHelper.m4942Z0(bundle2, bundle.getString("imageId") + ".jpg", "Medium");
                            Glide.m40315G(VDDiagnosisFragment.this.m44716w()).mo40150i(new File(m4942Z0)).m40191t2(imageViewHolder.f83246I);
                            if (VDDiagnosisFragment.this.f76057B4.containsKey(m4942Z0)) {
                                imageViewHolder.f83247J.setRippleColor(VDDiagnosisFragment.this.f76057B4.getInt(m4942Z0));
                            } else {
                                VDDiagnosisFragment.this.m4083q3(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.VDDiagnosisAdapter.2.1
                                    @Override // java.lang.Runnable
                                    public void run() {
                                        Palette.Swatch m43631C = Palette.m43628b(BitmapFactory.decodeFile(m4942Z0)).m43594g().m43631C();
                                        if (m43631C == null) {
                                            return;
                                        }
                                        int m43579e = m43631C.m43579e();
                                        if (VDDiagnosisFragment.this.f76057B4.containsKey(m4942Z0)) {
                                            return;
                                        }
                                        VDDiagnosisFragment.this.f76057B4.putInt(m4942Z0, m43579e);
                                    }
                                }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.VDDiagnosisAdapter.2.2
                                    @Override // java.lang.Runnable
                                    public void run() {
                                        imageViewHolder.f83247J.setRippleColor(VDDiagnosisFragment.this.f76057B4.getInt(m4942Z0));
                                    }
                                });
                            }
                            imageViewHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.VDDiagnosisAdapter.2.3
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    VDDiagnosisFragment.this.m4009J4(bundle.getString("imageId"));
                                }
                            });
                        }

                        @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                        /* renamed from: h0 */
                        public RecyclerView.ViewHolder mo3403h0(View view) {
                            return new ImageViewHolder(view);
                        }
                    };
                    recyclerViewViewHolder.f76076I.setAdapter(chaptersAdapter);
                    final GridAutoFitLayoutManager gridAutoFitLayoutManager = new GridAutoFitLayoutManager(VDDiagnosisFragment.this.m44716w(), (int) (VDDiagnosisFragment.this.m44782a0().getDisplayMetrics().density * 100.0f));
                    gridAutoFitLayoutManager.m43287N3(new GridLayoutManager.SpanSizeLookup() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.VDDiagnosisAdapter.3
                        @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
                        /* renamed from: f */
                        public int mo3768f(int i2) {
                            if (chaptersAdapter.mo3384C(i2) == 1) {
                                return gridAutoFitLayoutManager.f83243b0;
                            }
                            return 1;
                        }
                    });
                    recyclerViewViewHolder.f76076I.setLayoutManager(gridAutoFitLayoutManager);
                }
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                if (i == 0) {
                    return new HeaderCellViewHolder(LayoutInflater.from(VDDiagnosisFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false));
                }
                if (i == 1) {
                    return new EmergencyTextViewHolder(LayoutInflater.from(VDDiagnosisFragment.this.m44716w()).inflate(C4804R.C4810layout.f87289list_view_item_simple_text_emergency, viewGroup, false));
                }
                if (i == 2) {
                    return new TextViewHolder(LayoutInflater.from(VDDiagnosisFragment.this.m44716w()).inflate(C4804R.C4810layout.f87291list_view_item_simple_text_list_icon, viewGroup, false));
                }
                if (i == 3) {
                    return new RecyclerViewViewHolder(LayoutInflater.from(VDDiagnosisFragment.this.m44716w()).inflate(C4804R.C4810layout.f87253list_view_item_recyclerview, viewGroup, false));
                }
                if (i == 4) {
                    return new RippleTextViewHolder(LayoutInflater.from(VDDiagnosisFragment.this.m44716w()).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
                }
                return null;
            }

            /* renamed from: d0 */
            public Bundle m4003d0(int i) {
                String str;
                String str2;
                Bundle bundle = new Bundle();
                String str3 = "TypeInteger";
                if (i == 0) {
                    bundle.putString("Type", "SimpleTextEmergency");
                    VDDiagnosisFragment vDDiagnosisFragment = VDDiagnosisFragment.this;
                    bundle.putString("Text", vDDiagnosisFragment.m4010I4(Integer.valueOf(vDDiagnosisFragment.f76059w4.getString("sortPriority")).intValue()));
                    bundle.putInt("TypeInteger", 0);
                    str3 = "Emergency";
                    if (!VDDiagnosisFragment.this.f76059w4.getString("severityLevel").equals(ExifInterface.f14403S4)) {
                        bundle.putInt("Emergency", 0);
                    }
                    bundle.putInt(str3, 1);
                } else {
                    if (i == 1) {
                        bundle.putString("Type", "Header");
                        str = "CLINICAL SCENARIO";
                    } else {
                        int i2 = 2;
                        if (i == 2) {
                            bundle.putString("Type", "TextList");
                            str2 = ((Bundle) VDDiagnosisFragment.this.f76060x4.get(VDDiagnosisFragment.this.f76056A4)).getString("longName");
                        } else {
                            i2 = 3;
                            if (i == 3) {
                                bundle.putString("Type", "Header");
                                str = VDDiagnosisFragment.this.f76062z4.size() + " IMAGES";
                            } else if (i == 4) {
                                bundle.putString("Type", "GridView");
                                str2 = "";
                            } else if (i == 5) {
                                bundle.putString("Type", "Header");
                                str = PdfWriterPipeline.f66103f;
                            } else if (i > 5) {
                                bundle.putString("Type", "Item");
                                bundle.putBundle("Item", (Bundle) VDDiagnosisFragment.this.f76061y4.get(i - 6));
                                bundle.putInt("TypeInteger", 4);
                            }
                        }
                        bundle.putString("Text", str2);
                        bundle.putInt("TypeInteger", i2);
                    }
                    bundle.putString("Text", str);
                    bundle.putInt(str3, 1);
                }
                return bundle;
            }

            /* renamed from: e0 */
            public void m4002e0(Bundle bundle, int i) {
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                return VDDiagnosisFragment.this.f76061y4.size() + 6;
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: I4 */
        public String m4010I4(int i) {
            return i == 1 ? "Very common or important" : i == 2 ? "Common" : i == 3 ? "Uncommon" : i == 4 ? "Extremely rare" : "";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: J4 */
        public void m4009J4(String str) {
            ArrayList<Bundle> arrayList = this.f76062z4;
            if (arrayList == null || arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
                return;
            }
            ArrayList arrayList2 = new ArrayList();
            int i = 0;
            for (int i2 = 0; i2 < this.f76062z4.size(); i2++) {
                Bundle bundle = this.f76062z4.get(i2);
                Bundle bundle2 = this.f75850c4;
                String m4942Z0 = CompressHelper.m4942Z0(bundle2, bundle.getString("imageId") + ".jpg", "Large-Encrypted");
                Bundle bundle3 = new Bundle();
                bundle3.putString("ImagePath", m4942Z0);
                bundle3.putString("id", bundle.getString("imageId"));
                bundle3.putString("Encrypted", IcyHeaders.f35463C2);
                if (bundle.getString("imageId").startsWith(str)) {
                    i = i2;
                }
                arrayList2.add(bundle3);
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList2);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* renamed from: F4 */
        public void m4013F4() {
        }

        /* renamed from: G4 */
        public void m4012G4() {
            this.f76058C4.setItemAnimator(new DefaultItemAnimator());
            this.f76058C4.m42923n(new DividerItemDecoration(m44716w(), 1));
            this.f76058C4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
        }

        /* renamed from: H4 */
        public int m4011H4(int i) {
            return (int) ((i * m44782a0().getDisplayMetrics().density) + 0.5f);
        }

        /* renamed from: K4 */
        public void m4008K4() {
            ((ListView) this.f75849b4.findViewById(C4804R.C4808id.f86950list_view)).setVisibility(0);
            ((TextView) this.f75849b4.findViewById(C4804R.C4808id.f87029status_label)).setVisibility(8);
            ((LinearLayout) this.f75849b4.findViewById(C4804R.C4808id.f87030status_layout)).setVisibility(8);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            ArrayList<Bundle> arrayList = this.f76062z4;
            if (arrayList == null || arrayList.size() <= 0) {
                return null;
            }
            Bundle m4073v3 = m4073v3(this.f76062z4);
            Bundle bundle = this.f75850c4;
            return CompressHelper.m4942Z0(bundle, m4073v3.getString("imageId") + ".jpg", "Large-Encrypted");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
            this.f75863p4 = new CompressHelper(m44716w());
            this.f76057B4 = new Bundle();
            if (bundle != null && bundle.containsKey("Restoring")) {
                this.f75827F3 = true;
                if (bundle.containsKey("Find")) {
                    this.f75828G3 = bundle.getString("Find");
                    this.f75836O3 = bundle.getInt("FindIndex");
                }
                if (bundle.containsKey("mFinalHTML")) {
                    this.f75847Z3 = bundle.getString("mFinalHTML");
                }
                if (bundle.containsKey("mTitle")) {
                    this.f75852e4 = bundle.getString("mTitle");
                }
                this.f76060x4 = bundle.getParcelableArrayList("mModules");
                this.f76061y4 = bundle.getParcelableArrayList("mFields");
                this.f76062z4 = bundle.getParcelableArrayList("mImages");
                this.f76056A4 = bundle.getInt("mSelectedModule");
                this.f76059w4 = bundle.getBundle("mDiagnosis");
            }
            this.f75849b4 = inflate;
            this.f76058C4 = (RecyclerView) inflate.findViewById(C4804R.C4808id.f87001recycler_view);
            this.f75850c4 = m44859B().getBundle("DB");
            this.f75851d4 = m44859B().getString("URL");
            this.f75858k4 = (Toolbar) this.f75849b4.findViewById(C4804R.C4808id.f87063toolbar);
            TabHost tabHost = (TabHost) inflate.findViewById(C4804R.C4808id.f86896findtabhost);
            this.f75844W3 = tabHost;
            if (tabHost != null) {
                tabHost.setup();
            }
            if (m44859B() == null) {
                return inflate;
            }
            try {
                final CompressHelper compressHelper = new CompressHelper(m44716w());
                if (this.f76059w4 == null) {
                    Bundle bundle2 = this.f75850c4;
                    this.f76059w4 = compressHelper.m4907i1(compressHelper.m4955V(bundle2, "select * from diagnoses where id = " + this.f75851d4));
                    Bundle bundle3 = this.f75850c4;
                    this.f76060x4 = compressHelper.m4955V(bundle3, "SELECT DiagnosesModules.id,moduleId, imageCount,modules.longName FROM DiagnosesModules,modules where diagnosisId=" + this.f75851d4 + " And diagnosesModules.moduleId=modules.id");
                    final int i = m44859B().containsKey("defaultModule") ? m44859B().getInt("defaultModule") : Integer.valueOf(this.f76059w4.getString("defaultModule")).intValue();
                    this.f76056A4 = this.f76060x4.indexOf((Bundle) new ArrayList(Collections2.m23110e(this.f76060x4, new Predicate<Bundle>() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.1
                        @Override // com.google.common.base.Predicate
                        /* renamed from: a */
                        public boolean apply(Bundle bundle4) {
                            return bundle4.getString("moduleId").equals(String.valueOf(i));
                        }
                    })).get(0));
                    Bundle bundle4 = this.f75850c4;
                    this.f76062z4 = compressHelper.m4955V(bundle4, "select imageId ,copyRight from Images where diagnosesModulesid=" + this.f76060x4.get(this.f76056A4).getString("id"));
                    Bundle bundle5 = this.f75850c4;
                    this.f76061y4 = compressHelper.m4955V(bundle5, "select fieldId, fieldName,doc  from Documents, fields where DiagnosesModulesId=" + this.f76060x4.get(this.f76056A4).getString("id") + " and documents.fieldId = fields.id");
                    this.f75852e4 = this.f76059w4.getString("dName");
                    this.f75847Z3 = "";
                    if (m44859B().containsKey("SEARCH") && m44859B().getStringArray("SEARCH") != null) {
                        new Timer().schedule(new TimerTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.2
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                CompressHelper compressHelper2 = compressHelper;
                                Bundle bundle6 = VDDiagnosisFragment.this.f75850c4;
                                compressHelper2.m4883q1(bundle6, "Doc-" + ((Bundle) VDDiagnosisFragment.this.f76060x4.get(VDDiagnosisFragment.this.f76056A4)).getString("id"), VDDiagnosisFragment.this.m44859B().getStringArray("SEARCH"), null);
                                VDDiagnosisFragment.this.m44859B().remove("SEARCH");
                            }
                        }, SimpleExoPlayer.f32068s1);
                    }
                }
                if (!compressHelper.m4892n1()) {
                    m4102d4(this.f75852e4);
                }
                m44716w().setTitle(this.f75852e4);
                this.f76058C4.setAdapter(new VDDiagnosisAdapter(m44716w()));
                m4012G4();
                m4100f3(C4804R.C4811menu.f87326favorite);
                m44735q2(false);
                m4099g3();
                m4140G3();
                return inflate;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                m4080r4(e);
                return inflate;
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: f4 */
        public void mo3978f4() {
            new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.3

                /* renamed from: a */
                byte[] f76067a;

                @Override // android.os.AsyncTask
                protected Object doInBackground(Object[] objArr) {
                    try {
                        File file = new File(VDDiagnosisFragment.this.mo3979S2());
                        this.f76067a = new CompressHelper(VDDiagnosisFragment.this.m44716w()).m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127");
                        return null;
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        iMDLogger.m3294f("ImageGallery", "Error in decrypting image");
                        return null;
                    }
                }

                @Override // android.os.AsyncTask
                protected void onPostExecute(Object obj) {
                    super.onPostExecute(obj);
                    Glide.m40315G(VDDiagnosisFragment.this.m44716w()).mo40151h(this.f76067a).m40191t2(VDDiagnosisFragment.this.f75859l4);
                }
            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
        }

        @Override // net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDialogListInterface
        /* renamed from: g */
        public void mo3977g(Bundle bundle, String str) {
            CompressHelper compressHelper = new CompressHelper(m44716w());
            if (str.equals("Module")) {
                this.f76056A4 = this.f76060x4.indexOf(bundle);
                Bundle bundle2 = this.f75850c4;
                this.f76062z4 = compressHelper.m4955V(bundle2, "select imageId ,copyRight from Images where diagnosesModulesid=" + this.f76060x4.get(this.f76056A4).getString("id"));
                Bundle bundle3 = this.f75850c4;
                this.f76061y4 = compressHelper.m4955V(bundle3, "select fieldId, fieldName,doc  from Documents, fields where DiagnosesModulesId=" + this.f76060x4.get(this.f76056A4).getString("id") + " and documents.fieldId = fields.id");
                this.f76058C4.setAdapter(new VDDiagnosisAdapter(m44716w()));
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: l1 */
        public void mo3541l1() {
            super.mo3541l1();
            m4140G3();
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // androidx.fragment.app.Fragment, android.content.ComponentCallbacks
        public void onConfigurationChanged(Configuration configuration) {
            super.onConfigurationChanged(configuration);
            this.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDiagnosisActivity.VDDiagnosisFragment.4
                @Override // java.lang.Runnable
                public void run() {
                    VDDiagnosisFragment.this.f76058C4.getAdapter().m42860G();
                }
            }, 500L);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new VDDiagnosisFragment(), bundle);
    }
}
