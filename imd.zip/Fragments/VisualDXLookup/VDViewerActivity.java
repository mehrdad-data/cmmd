package net.imedicaldoctor.imd.Fragments.VisualDXLookup;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class VDViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class VDViewerFragment extends ViewerHelperFragment implements VDDialogListInterface {

        /* renamed from: w4 */
        public ArrayList<Bundle> f76156w4;

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            String str = this.f75851d4.split("-")[1];
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "select imageId ,copyRight from Images where diagnosesModulesid=" + str);
            if (m4955V == null || m4955V.size() <= 0) {
                return null;
            }
            Bundle m4073v3 = m4073v3(m4955V);
            Bundle bundle2 = this.f75850c4;
            return CompressHelper.m4942Z0(bundle2, m4073v3.getString("imageId") + ".jpg", "Large-Encrypted");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87402menu_vdviewer, menu);
            m4096h4(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            Bundle next;
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f76156w4 = bundle.getParcelableArrayList("mFields");
            }
            if (m44859B() == null) {
                return inflate;
            }
            iMDLogger.m3290j("VDViewer", "Loading VD Document with mDocAddress = " + this.f75851d4);
            try {
                CompressHelper compressHelper = new CompressHelper(m44716w());
                String str = this.f75847Z3;
                if (str == null || str.length() == 0) {
                    String str2 = this.f75851d4.split("-")[1];
                    Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(this.f75850c4, "select * from DiagnosesModules where id =" + str2));
                    this.f75852e4 = compressHelper.m4907i1(compressHelper.m4955V(this.f75850c4, "select * from Diagnoses where id =" + m4907i1.getString("diagnosisId"))).getString("dName");
                    ArrayList<Bundle> m4955V = compressHelper.m4955V(this.f75850c4, "select fieldId, fieldName,doc  from Documents, fields where DiagnosesModulesId=" + str2 + " and documents.fieldId = fields.id");
                    this.f76156w4 = m4955V;
                    String str3 = "";
                    Iterator<Bundle> it2 = m4955V.iterator();
                    while (it2.hasNext()) {
                        str3 = str3 + "<span class=\"h1\" id=\"field" + next.getString("fieldId") + "\">" + next.getString("fieldName") + "</span>" + compressHelper.m5015B(it2.next().getString("doc"), str2, "127");
                    }
                    String m4117W3 = m4117W3(m44716w(), "VDHeader.css");
                    String m4117W32 = m4117W3(m44716w(), "VDFooter.css");
                    m4087m3();
                    this.f75847Z3 = m4117W3.replace("[size]", "200").replace("[title]", this.f75852e4) + str3 + m4117W32;
                    if (!compressHelper.m4892n1()) {
                        m4102d4("Diagnosis");
                    }
                    File file = new File(CompressHelper.m4945Y0(this.f75850c4, "base"));
                    this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
                    m4092j4();
                }
                m4098g4();
                m4100f3(C4804R.C4811menu.f87402menu_vdviewer);
                m44735q2(false);
                m4140G3();
                return inflate;
            } catch (Exception e) {
                m4080r4(e);
                return inflate;
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            if (menuItem.getItemId() == C4804R.C4808id.f86776action_menu) {
                m3976x4();
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: f4 */
        public void mo3978f4() {
            new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDViewerActivity.VDViewerFragment.1

                /* renamed from: a */
                byte[] f76157a;

                @Override // android.os.AsyncTask
                protected Object doInBackground(Object[] objArr) {
                    try {
                        File file = new File(VDViewerFragment.this.mo3979S2());
                        this.f76157a = new CompressHelper(VDViewerFragment.this.m44716w()).m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127");
                        return null;
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        iMDLogger.m3294f("ImageGallery", "Error in decrypting image");
                        return null;
                    }
                }

                @Override // android.os.AsyncTask
                protected void onPostExecute(Object obj) {
                    super.onPostExecute(obj);
                    Glide.m40315G(VDViewerFragment.this.m44716w()).mo40151h(this.f76157a).m40191t2(VDViewerFragment.this.f75859l4);
                }
            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
        }

        @Override // net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDialogListInterface
        /* renamed from: g */
        public void mo3977g(Bundle bundle, String str) {
            new CompressHelper(m44716w());
            if (str.equals("Field")) {
                mo4144C3("field" + bundle.getString("fieldId"));
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
            return true;
        }

        /* renamed from: x4 */
        public void m3976x4() {
            VDDialogList vDDialogList = new VDDialogList();
            Bundle bundle = new Bundle();
            bundle.putBundle("db", this.f75850c4);
            bundle.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, this.f76156w4);
            bundle.putString("titleProperty", "fieldName");
            bundle.putString("type", "Field");
            vDDialogList.m44751k2(bundle);
            vDDialogList.m44870c3(true);
            vDDialogList.m44844E2(this, 0);
            vDDialogList.mo29915h3(m44820L(), "VDDialogFragment");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new VDViewerFragment(), bundle);
    }
}
