package net.imedicaldoctor.imd.Fragments.VisualDXLookup;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity;

/* loaded from: classes2.dex */
public class VDDxKeyQuestionsDialog extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f76112g4;

    /* renamed from: h4 */
    private ArrayList<String> f76113h4;

    /* renamed from: i4 */
    private ArrayList<Bundle> f76114i4;

    /* renamed from: j4 */
    private Bundle f76115j4;

    /* renamed from: k4 */
    public ArrayList<String> f76116k4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        final ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f76112g4 = m44859B().getBundle("db");
        this.f76115j4 = m44859B().getBundle("allFindings");
        this.f76113h4 = m44859B().getStringArrayList("selectedKeyQuestions");
        this.f76114i4 = m44859B().getParcelableArrayList("allKeyQuestions");
        this.f76116k4 = new ArrayList<>();
        Iterator<Bundle> it2 = this.f76114i4.iterator();
        while (it2.hasNext()) {
            this.f76116k4.add(it2.next().getString("title"));
        }
        new CompressHelper(m44716w());
        BaseAdapter baseAdapter = new BaseAdapter() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxKeyQuestionsDialog.1
            @Override // android.widget.BaseAdapter, android.widget.ListAdapter
            public boolean areAllItemsEnabled() {
                return false;
            }

            @Override // android.widget.Adapter
            public int getCount() {
                VDDxKeyQuestionsDialog vDDxKeyQuestionsDialog = VDDxKeyQuestionsDialog.this;
                return vDDxKeyQuestionsDialog.m3988o3(vDDxKeyQuestionsDialog.f76116k4);
            }

            @Override // android.widget.Adapter
            public Object getItem(int i) {
                VDDxKeyQuestionsDialog vDDxKeyQuestionsDialog = VDDxKeyQuestionsDialog.this;
                return vDDxKeyQuestionsDialog.m3993j3(i, vDDxKeyQuestionsDialog.f76116k4);
            }

            @Override // android.widget.Adapter
            public long getItemId(int i) {
                return 0L;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getItemViewType(int i) {
                return ((Bundle) getItem(i)).getString("Type").equals("Header") ? 0 : 1;
            }

            @Override // android.widget.Adapter
            public View getView(int i, View view, ViewGroup viewGroup) {
                Bundle bundle2 = (Bundle) getItem(i);
                if (bundle2.getString("Type").equals("Header")) {
                    if (view == null) {
                        view = LayoutInflater.from(VDDxKeyQuestionsDialog.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false);
                        view.setTag(view.findViewById(C4804R.C4808id.f86913header_text));
                    }
                    ((TextView) view.findViewById(C4804R.C4808id.f86913header_text)).setText(bundle2.getString("Text"));
                    return view;
                }
                if (view == null) {
                    view = LayoutInflater.from(VDDxKeyQuestionsDialog.this.m44716w()).inflate(C4804R.C4810layout.f87288list_view_item_simple_text_check, viewGroup, false);
                }
                ImageView imageView = (ImageView) view.findViewById(C4804R.C4808id.f86840check_icon);
                String string = bundle2.getString("Section");
                String string2 = ((Bundle) ((Bundle) VDDxKeyQuestionsDialog.this.f76114i4.get(VDDxKeyQuestionsDialog.this.f76116k4.indexOf(string))).getParcelableArrayList("findings").get(bundle2.getInt("Index"))).getString("findingId");
                ((TextView) view.findViewById(C4804R.C4808id.text)).setText(VDDxKeyQuestionsDialog.this.f76115j4.getString(string2));
                if (VDDxKeyQuestionsDialog.this.f76113h4.contains(string2)) {
                    imageView.setVisibility(0);
                } else {
                    imageView.setVisibility(4);
                }
                return view;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getViewTypeCount() {
                return 2;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public boolean hasStableIds() {
                return false;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public boolean isEmpty() {
                return false;
            }

            @Override // android.widget.BaseAdapter, android.widget.ListAdapter
            public boolean isEnabled(int i) {
                return ((Bundle) getItem(i)).getString("Type").equals("Item");
            }
        };
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxKeyQuestionsDialog.2
            /* JADX WARN: Type inference failed for: r2v1, types: [android.widget.Adapter] */
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Bundle bundle2 = (Bundle) adapterView.getAdapter().getItem(i);
                if (bundle2.getString("Type").equals("Header")) {
                    return;
                }
                int i2 = bundle2.getInt("Index");
                Bundle bundle3 = (Bundle) VDDxKeyQuestionsDialog.this.f76114i4.get(VDDxKeyQuestionsDialog.this.f76116k4.indexOf(bundle2.getString("Section")));
                String string = ((Bundle) bundle3.getParcelableArrayList("findings").get(i2)).getString("findingId");
                if (VDDxKeyQuestionsDialog.this.f76113h4.contains(string)) {
                    VDDxKeyQuestionsDialog.this.f76113h4.remove(string);
                } else {
                    if (bundle3.getString("type").equals("radiogroup")) {
                        Iterator it3 = bundle3.getParcelableArrayList("findings").iterator();
                        while (it3.hasNext()) {
                            String string2 = ((Bundle) it3.next()).getString("findingId");
                            if (VDDxKeyQuestionsDialog.this.f76113h4.contains(string2)) {
                                VDDxKeyQuestionsDialog.this.f76113h4.remove(string2);
                            }
                        }
                    }
                    VDDxKeyQuestionsDialog.this.f76113h4.add(string);
                }
                ((VDDxBuilderActivity.VDDXBuilderFragment) VDDxKeyQuestionsDialog.this.m44753k0()).m4022y4();
                ((BaseAdapter) listView.getAdapter()).notifyDataSetChanged();
            }
        });
        listView.setAdapter((ListAdapter) baseAdapter);
        builder.setView(inflate);
        return builder.create();
    }

    /* renamed from: j3 */
    public Bundle m3993j3(int i, ArrayList<String> arrayList) {
        Iterator<String> it2 = arrayList.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            String next = it2.next();
            if (i == i2) {
                Bundle bundle = new Bundle();
                bundle.putString("Text", next);
                bundle.putString("Type", "Header");
                return bundle;
            }
            int m3989n3 = i2 + m3989n3(next);
            if (i <= m3989n3) {
                Bundle bundle2 = new Bundle();
                bundle2.putString("Section", next);
                bundle2.putInt("Index", (i - (m3989n3 - m3989n3(next))) - 1);
                bundle2.putString("Type", "Item");
                return bundle2;
            }
            i2 = m3989n3 + 1;
        }
        return null;
    }

    /* renamed from: n3 */
    public int m3989n3(String str) {
        return this.f76114i4.get(this.f76116k4.indexOf(str)).getStringArrayList("findings").size();
    }

    /* renamed from: o3 */
    public int m3988o3(ArrayList<String> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return 0;
        }
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            i = i + m3989n3(it2.next()) + 1;
        }
        return i;
    }
}
