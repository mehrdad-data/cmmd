package net.imedicaldoctor.imd.Fragments.VisualDXLookup;

import android.animation.Animator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.core.internal.view.SupportMenu;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.payActivity;
import net.imedicaldoctor.imd.Views.ProgressBarCircularIndeterminate;
import net.imedicaldoctor.imd.iMDActivity;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class registerActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class registerFragment extends Fragment {

        /* renamed from: G3 */
        private String f76160G3;

        /* renamed from: H3 */
        private TextView f76161H3;

        /* renamed from: I3 */
        private View f76162I3;

        /* renamed from: F3 */
        private int f76159F3 = 0;

        /* renamed from: J3 */
        public BroadcastReceiver f76163J3 = new C44524();

        /* renamed from: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity$registerFragment$4 */
        /* loaded from: classes2.dex */
        class C44524 extends BroadcastReceiver {
            C44524() {
            }

            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                if (intent.getIntExtra("result", 0) == 1) {
                    registerFragment.this.m3957c3();
                    registerFragment.this.m3954f3("Successsful . Login Now");
                    new Timer().schedule(new TimerTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.4.1
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            registerFragment.this.f76161H3.post(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.4.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    registerFragment.this.m44716w().finish();
                                }
                            });
                        }
                    }, 1000L);
                    return;
                }
                registerFragment.this.m3963W2();
                registerFragment registerfragment = registerFragment.this;
                registerfragment.m3954f3("Failed . " + intent.getStringExtra("message"));
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:34:0x0141  */
        /* JADX WARN: Removed duplicated region for block: B:39:0x014b  */
        /* JADX WARN: Removed duplicated region for block: B:50:0x0150 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* renamed from: N2 */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private java.lang.String m3972N2(java.lang.String r10) {
            /*
                Method dump skipped, instructions count: 379
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.m3972N2(java.lang.String):java.lang.String");
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: W2 */
        public void m3963W2() {
            if (m44716w() == null) {
                return;
            }
            try {
                TextView textView = (TextView) m44716w().findViewById(C4804R.C4808id.f87029status_label);
                textView.setVisibility(0);
                textView.setTextColor(SupportMenu.f12537c);
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: X2 */
        public String m3962X2(int i) {
            return ((EditText) this.f76162I3.findViewById(i)).getText().toString();
        }

        /* renamed from: Y2 */
        private void m3961Y2() {
            ((ProgressBarCircularIndeterminate) m44716w().findViewById(C4804R.C4808id.f86992progress_bar)).setVisibility(8);
        }

        /* renamed from: Z2 */
        private void m3960Z2() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: a3 */
        public void m3959a3() {
            try {
                InputMethodManager inputMethodManager = (InputMethodManager) m44716w().getSystemService("input_method");
                if (m44716w().getCurrentFocus() != null) {
                    inputMethodManager.hideSoftInputFromWindow(m44716w().getCurrentFocus().getWindowToken(), 0);
                }
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
            }
        }

        /* renamed from: b3 */
        private void m3958b3(final View view, long j) {
            view.animate().alpha(0.0f).setDuration(j).setListener(new Animator.AnimatorListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.5
                @Override // android.animation.Animator.AnimatorListener
                public void onAnimationCancel(Animator animator) {
                }

                @Override // android.animation.Animator.AnimatorListener
                public void onAnimationEnd(Animator animator) {
                    view.setVisibility(8);
                }

                @Override // android.animation.Animator.AnimatorListener
                public void onAnimationRepeat(Animator animator) {
                }

                @Override // android.animation.Animator.AnimatorListener
                public void onAnimationStart(Animator animator) {
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: c3 */
        public void m3957c3() {
            TextView textView = (TextView) m44716w().findViewById(C4804R.C4808id.f87029status_label);
            textView.setVisibility(0);
            textView.setTextColor(-16711936);
        }

        /* renamed from: d3 */
        private void m3956d3(String str) {
            mo4139H2(new Intent("android.intent.action.VIEW", Uri.parse(str)));
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: f3 */
        public void m3954f3(String str) {
            m3961Y2();
            TextView textView = this.f76161H3;
            if (str != null) {
                textView.setText(str);
                this.f76161H3.setVisibility(0);
                return;
            }
            textView.setText("");
            this.f76161H3.setVisibility(8);
            this.f76160G3 = str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: g3 */
        public void m3953g3() {
            ProgressBarCircularIndeterminate progressBarCircularIndeterminate = (ProgressBarCircularIndeterminate) m44716w().findViewById(C4804R.C4808id.f86992progress_bar);
            progressBarCircularIndeterminate.setVisibility(0);
            progressBarCircularIndeterminate.setBackgroundColor(Color.parseColor("#1e88e5"));
            this.f76161H3.setVisibility(8);
        }

        /* renamed from: h3 */
        private void m3952h3() {
        }

        /* renamed from: i3 */
        private void m3951i3(String str) {
            m3961Y2();
            this.f76161H3.setVisibility(0);
            this.f76160G3 = null;
            this.f76161H3.setText(str);
            m3963W2();
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: L0 */
        public void mo3973L0(int i, int i2, Intent intent) {
            if (intent == null) {
                return;
            }
            if (intent.getIntExtra("result", 0) == 1) {
                m3957c3();
                m3954f3("Successsful . Login Now");
                new Timer().schedule(new TimerTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.3
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        registerFragment.this.f76161H3.post(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.3.1
                            @Override // java.lang.Runnable
                            public void run() {
                                registerFragment.this.m44716w().finish();
                                registerFragment.this.m44716w().overridePendingTransition(C4804R.anim.f85978to_fade_in, C4804R.anim.f85979to_fade_out);
                            }
                        });
                    }
                }, SimpleExoPlayer.f32068s1);
            } else {
                m3963W2();
                m3954f3("Failed . " + intent.getStringExtra("message"));
            }
            super.mo3973L0(i, i2, intent);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: Q0 */
        public void mo3503Q0(Bundle bundle) {
            super.mo3503Q0(bundle);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f76162I3;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87173fragment_new_register, viewGroup, false);
            this.f76162I3 = inflate;
            this.f76161H3 = (TextView) inflate.findViewById(C4804R.C4808id.f87029status_label);
            final CompressHelper compressHelper = new CompressHelper(m44716w());
            RadioGroup radioGroup = (RadioGroup) this.f76162I3.findViewById(C4804R.C4808id.f86999radio_group);
            radioGroup.check(C4804R.C4808id.f86996radio_1);
            m3955e3();
            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.1
                @Override // android.widget.RadioGroup.OnCheckedChangeListener
                public void onCheckedChanged(RadioGroup radioGroup2, int i) {
                    registerFragment.this.m3955e3();
                }
            });
            ((Button) inflate.findViewById(C4804R.C4808id.f87003register_button)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    String str;
                    final String str2;
                    registerFragment.this.m3959a3();
                    final String m3962X2 = registerFragment.this.m3962X2(C4804R.C4808id.f87078user_text);
                    final String m3962X22 = registerFragment.this.m3962X2(C4804R.C4808id.f86987password_text);
                    final String m3962X23 = registerFragment.this.m3962X2(C4804R.C4808id.f86958mail_text);
                    final String m3962X24 = registerFragment.this.m3962X2(C4804R.C4808id.f86963mobile_text);
                    if (m3962X2.length() == 0) {
                        registerFragment.this.m3963W2();
                        registerFragment.this.m3954f3("Username can't be empty");
                    } else if (m3962X22.length() == 0) {
                        registerFragment.this.m3963W2();
                        registerFragment.this.m3954f3("Password can't be empty");
                    } else if (m3962X23.length() == 0) {
                        registerFragment.this.m3963W2();
                        registerFragment.this.m3954f3("Mail can't be empty");
                    } else if (m3962X24.length() == 0) {
                        registerFragment.this.m3963W2();
                        registerFragment.this.m3954f3("Mobile can't be empty");
                    } else {
                        int checkedRadioButtonId = ((RadioGroup) registerFragment.this.f76162I3.findViewById(C4804R.C4808id.f86999radio_group)).getCheckedRadioButtonId();
                        if (checkedRadioButtonId != C4804R.C4808id.f86996radio_1) {
                            if (checkedRadioButtonId == C4804R.C4808id.f86997radio_2) {
                                str = IcyHeaders.f35463C2;
                            } else if (checkedRadioButtonId == C4804R.C4808id.f86998radio_3) {
                                str = ExifInterface.f14403S4;
                            }
                            str2 = str;
                            registerFragment.this.m3957c3();
                            registerFragment.this.m3953g3();
                            CompressHelper compressHelper2 = compressHelper;
                            compressHelper2.m4890o0("checkRegister|||||" + m3962X2 + "|||||" + m3962X22 + "|||||" + m3962X23 + "|||||" + m3962X24).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7329f6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.2.1
                                @Override // io.reactivex.rxjava3.functions.Consumer
                                /* renamed from: a */
                                public void accept(String str3) throws Throwable {
                                    registerFragment registerfragment;
                                    String str4;
                                    String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "|||||");
                                    if (!splitByWholeSeparator[0].equals(IcyHeaders.f35463C2)) {
                                        if (splitByWholeSeparator.length == 1) {
                                            registerFragment.this.m3963W2();
                                            registerfragment = registerFragment.this;
                                            str4 = splitByWholeSeparator[0];
                                        } else {
                                            registerFragment.this.m3963W2();
                                            registerfragment = registerFragment.this;
                                            str4 = splitByWholeSeparator[1];
                                        }
                                        registerfragment.m3954f3(str4);
                                        return;
                                    }
                                    registerFragment.this.m3957c3();
                                    registerFragment.this.m3954f3("Successfull , Redirecting ...");
                                    Intent intent = new Intent(registerFragment.this.m44716w(), payActivity.class);
                                    intent.putExtra("AccountCommand", m3962X2 + "|||||" + m3962X22 + "|||||" + m3962X23 + "|||||" + m3962X24 + "|||||" + str2);
                                    intent.putExtra("Type", "account");
                                    registerFragment.this.startActivityForResult(intent, 1);
                                    registerFragment.this.m44716w().overridePendingTransition(C4804R.anim.f85970from_fade_in, C4804R.anim.f85971from_fade_out);
                                }
                            }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.2.2
                                @Override // io.reactivex.rxjava3.functions.Consumer
                                /* renamed from: a */
                                public void accept(Throwable th) throws Throwable {
                                    try {
                                        CompressHelper.m4921e2(registerFragment.this.m44716w(), "Error occured on contacting server, try again later.", 1);
                                        registerFragment.this.m3963W2();
                                        registerFragment.this.m3954f3("Error occured");
                                    } catch (Exception e) {
                                        FirebaseCrashlytics.m18030d().m18027g(e);
                                    }
                                }
                            });
                        }
                        str2 = "0";
                        registerFragment.this.m3957c3();
                        registerFragment.this.m3953g3();
                        CompressHelper compressHelper22 = compressHelper;
                        compressHelper22.m4890o0("checkRegister|||||" + m3962X2 + "|||||" + m3962X22 + "|||||" + m3962X23 + "|||||" + m3962X24).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7329f6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.2.1
                            @Override // io.reactivex.rxjava3.functions.Consumer
                            /* renamed from: a */
                            public void accept(String str3) throws Throwable {
                                registerFragment registerfragment;
                                String str4;
                                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "|||||");
                                if (!splitByWholeSeparator[0].equals(IcyHeaders.f35463C2)) {
                                    if (splitByWholeSeparator.length == 1) {
                                        registerFragment.this.m3963W2();
                                        registerfragment = registerFragment.this;
                                        str4 = splitByWholeSeparator[0];
                                    } else {
                                        registerFragment.this.m3963W2();
                                        registerfragment = registerFragment.this;
                                        str4 = splitByWholeSeparator[1];
                                    }
                                    registerfragment.m3954f3(str4);
                                    return;
                                }
                                registerFragment.this.m3957c3();
                                registerFragment.this.m3954f3("Successfull , Redirecting ...");
                                Intent intent = new Intent(registerFragment.this.m44716w(), payActivity.class);
                                intent.putExtra("AccountCommand", m3962X2 + "|||||" + m3962X22 + "|||||" + m3962X23 + "|||||" + m3962X24 + "|||||" + str2);
                                intent.putExtra("Type", "account");
                                registerFragment.this.startActivityForResult(intent, 1);
                                registerFragment.this.m44716w().overridePendingTransition(C4804R.anim.f85970from_fade_in, C4804R.anim.f85971from_fade_out);
                            }
                        }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.VisualDXLookup.registerActivity.registerFragment.2.2
                            @Override // io.reactivex.rxjava3.functions.Consumer
                            /* renamed from: a */
                            public void accept(Throwable th) throws Throwable {
                                try {
                                    CompressHelper.m4921e2(registerFragment.this.m44716w(), "Error occured on contacting server, try again later.", 1);
                                    registerFragment.this.m3963W2();
                                    registerFragment.this.m3954f3("Error occured");
                                } catch (Exception e) {
                                    FirebaseCrashlytics.m18030d().m18027g(e);
                                }
                            }
                        });
                    }
                }
            });
            return inflate;
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: V0 */
        public void mo3638V0() {
            super.mo3638V0();
        }

        /* renamed from: e3 */
        public void m3955e3() {
            String str;
            Button button = (Button) this.f76162I3.findViewById(C4804R.C4808id.f87003register_button);
            int checkedRadioButtonId = ((RadioGroup) this.f76162I3.findViewById(C4804R.C4808id.f86999radio_group)).getCheckedRadioButtonId();
            RadioButton radioButton = (RadioButton) this.f76162I3.findViewById(C4804R.C4808id.f86996radio_1);
            RadioButton radioButton2 = (RadioButton) this.f76162I3.findViewById(C4804R.C4808id.f86997radio_2);
            RadioButton radioButton3 = (RadioButton) this.f76162I3.findViewById(C4804R.C4808id.f86998radio_3);
            if (checkedRadioButtonId == C4804R.C4808id.f86996radio_1) {
                button.setText("Register - 10,000 Toman");
                radioButton2.setChecked(false);
                radioButton3.setChecked(false);
                return;
            }
            if (checkedRadioButtonId == C4804R.C4808id.f86997radio_2) {
                str = "Register - 17,000 Toman";
            } else if (checkedRadioButtonId != C4804R.C4808id.f86998radio_3) {
                return;
            } else {
                str = "Register - 249,000 Toman";
            }
            button.setText(str);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: p1 */
        public void mo3867p1(View view, Bundle bundle) {
            super.mo3867p1(view, bundle);
        }
    }

    /* renamed from: q0 */
    public static Bitmap m3975q0(Context context, String str) {
        try {
            return BitmapFactory.decodeStream(context.getAssets().open(str));
        } catch (IOException unused) {
            return null;
        }
    }

    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        super.onBackPressed();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87109activity_register);
        if (bundle == null) {
            m44690E().m44464r().m44292k("register").m44301b(C4804R.C4808id.container, new registerFragment()).mo44289n();
        }
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }

    /* renamed from: r0 */
    public void m3974r0(ColorStateList colorStateList) {
    }
}
