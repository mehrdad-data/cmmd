package net.imedicaldoctor.imd.Fragments.TOL;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class TolFragment extends Fragment {

    /* renamed from: F3 */
    public LinearLayout f75528F3;

    /* renamed from: G3 */
    public LinearLayout f75529G3;

    /* renamed from: H3 */
    public LinearLayout f75530H3;

    /* renamed from: I3 */
    public LinearLayout f75531I3;

    /* renamed from: J3 */
    public LinearLayout f75532J3;

    /* renamed from: K3 */
    public LinearLayout f75533K3;

    /* renamed from: L3 */
    public RelativeLayout f75534L3;

    /* renamed from: M3 */
    public TextView f75535M3;

    /* renamed from: N3 */
    public TextView f75536N3;

    /* renamed from: O3 */
    public ImageView f75537O3;

    /* renamed from: P3 */
    public TextView f75538P3;

    /* renamed from: Q3 */
    public ArrayList<String> f75539Q3;

    /* renamed from: R3 */
    public int f75540R3;

    /* renamed from: S3 */
    public String[] f75541S3;

    /* renamed from: T3 */
    public String[] f75542T3;

    /* renamed from: U3 */
    public long f75543U3;

    /* renamed from: V3 */
    public long f75544V3;

    /* renamed from: W3 */
    public long f75545W3;

    /* renamed from: T2 */
    public static TolFragment m4268T2() {
        return new TolFragment();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: U2 */
    public void m4267U2(int i) {
        String str;
        String str2;
        this.f75545W3++;
        if (this.f75537O3.getVisibility() == 0) {
            this.f75542T3[i] = this.f75542T3[i] + this.f75537O3.getTag().toString();
            this.f75537O3.setVisibility(8);
        } else if (this.f75542T3[i].length() <= 0) {
            return;
        } else {
            String substring = this.f75542T3[i].substring(str.length() - 1);
            String[] strArr = this.f75542T3;
            strArr[i] = strArr[i].substring(0, str2.length() - 1);
            this.f75537O3.setImageDrawable(m4270R2(substring));
            this.f75537O3.setVisibility(0);
            this.f75537O3.setTag(substring);
        }
        m4263Y2();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: V2 */
    public void m4266V2() {
        if (this.f75540R3 < this.f75539Q3.size() - 1) {
            m4269S2();
            this.f75534L3.setVisibility(8);
        }
    }

    /* renamed from: P2 */
    public void m4272P2(LinearLayout linearLayout, String str) {
        ImageView imageView = new ImageView(m44716w());
        imageView.setImageDrawable(m4270R2(str));
        Math.round(TypedValue.applyDimension(1, 150.0f, m44782a0().getDisplayMetrics()));
        imageView.setLayoutParams(new LinearLayout.LayoutParams(-1, Math.round(TypedValue.applyDimension(1, 50.0f, m44782a0().getDisplayMetrics()))));
        linearLayout.addView(imageView, 0);
    }

    /* renamed from: Q2 */
    public void m4271Q2(LinearLayout linearLayout, String str) {
        linearLayout.removeAllViews();
        for (char c : str.toCharArray()) {
            m4272P2(linearLayout, String.valueOf(c));
        }
    }

    /* renamed from: R2 */
    public Drawable m4270R2(String str) {
        FragmentActivity m44716w;
        int i;
        if (str.equals("R")) {
            m44716w = m44716w();
            i = C4804R.C4807drawable.f86742tolred;
        } else if (str.equals("B")) {
            m44716w = m44716w();
            i = C4804R.C4807drawable.f86739tolblue;
        } else if (str.equals("G")) {
            m44716w = m44716w();
            i = C4804R.C4807drawable.f86740tolgreen;
        } else if (str.equals("Y")) {
            m44716w = m44716w();
            i = C4804R.C4807drawable.f86744tolyellow;
        } else if (!str.equals(ExifInterface.f14347L4)) {
            return null;
        } else {
            m44716w = m44716w();
            i = C4804R.C4807drawable.f86743tolyashmi;
        }
        return m44716w.getDrawable(i);
    }

    /* renamed from: S2 */
    public void m4269S2() {
        this.f75544V3 = System.currentTimeMillis();
        this.f75540R3++;
        this.f75538P3.setText("مرحله " + m4265W2(this.f75540R3 + 1) + " از " + m4265W2(this.f75539Q3.size()));
        String[] splitPreserveAllTokens = StringUtils.splitPreserveAllTokens(this.f75539Q3.get(this.f75540R3), "-");
        this.f75541S3 = new String[]{splitPreserveAllTokens[0], splitPreserveAllTokens[1], splitPreserveAllTokens[2]};
        this.f75542T3 = new String[]{splitPreserveAllTokens[3], splitPreserveAllTokens[4], splitPreserveAllTokens[5]};
        m4263Y2();
    }

    @Override // androidx.fragment.app.Fragment
    @Nullable
    /* renamed from: U0 */
    public View mo3277U0(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87305main_tol, viewGroup, false);
        m44716w().getWindow().setFlags(1024, 1024);
        this.f75528F3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f87068topleft);
        this.f75529G3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f87069topmiddle);
        this.f75530H3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f87070topright);
        this.f75531I3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f86819bottomleft);
        this.f75532J3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f86818bottomcenter);
        this.f75533K3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f86820bottomright);
        this.f75538P3 = (TextView) inflate.findViewById(C4804R.C4808id.f87060title_text);
        this.f75535M3 = (TextView) inflate.findViewById(C4804R.C4808id.f86981overlay_text_1);
        this.f75536N3 = (TextView) inflate.findViewById(C4804R.C4808id.f86982overlay_text_2);
        this.f75534L3 = (RelativeLayout) inflate.findViewById(C4804R.C4808id.f86980overlay_layout);
        this.f75537O3 = (ImageView) inflate.findViewById(C4804R.C4808id.f86938imagehand);
        this.f75539Q3 = new ArrayList<>(Arrays.asList(StringUtils.splitPreserveAllTokens(new CompressHelper(m44716w()).m4977N1(CompressHelper.m4945Y0(m44859B().getBundle("DB"), "tol.txt")), "\n")));
        this.f75540R3 = -1;
        this.f75543U3 = 0L;
        this.f75545W3 = 0L;
        this.f75535M3.setText("به بازی برج های لندن خوش آمدید");
        this.f75536N3.setText((("هدف از این بازی جابجایی مهره ها در سه ستون پایین است تا مشابه ستون های بالا شوند.\nبا کلیک بر روی هر ستون ، مهره را می توانید بردارید") + "\nو با کلیک بر روی ستون دیگر آن مهره را به آنجا منتقل کنید.") + "\n\nبرای شروع کلیک کنید");
        this.f75534L3.setVisibility(0);
        this.f75534L3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.TolFragment.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TolFragment.this.m4266V2();
            }
        });
        this.f75534L3.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.TolFragment.2
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View view) {
                TolFragment tolFragment = TolFragment.this;
                if (tolFragment.f75540R3 == tolFragment.f75539Q3.size() - 1) {
                    TolFragment.this.m4264X2();
                    return true;
                }
                return false;
            }
        });
        this.f75531I3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.TolFragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TolFragment.this.m4267U2(0);
            }
        });
        this.f75532J3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.TolFragment.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TolFragment.this.m4267U2(1);
            }
        });
        this.f75533K3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.TolFragment.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                TolFragment.this.m4267U2(2);
            }
        });
        return inflate;
    }

    /* renamed from: W2 */
    public String m4265W2(long j) {
        return (j + "").replace(IcyHeaders.f35463C2, "۱").replace(ExifInterface.f14403S4, "۲").replace(ExifInterface.f14411T4, "۳").replace("4", "۴").replace("5", "۵").replace("6", "۶").replace("7", "۷").replace("8", "۸").replace("9", "۹").replace("0", "۰");
    }

    /* renamed from: X2 */
    public void m4264X2() {
        final String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        final CompressHelper compressHelper = new CompressHelper(m44716w());
        final EditText editText = new EditText(m44716w());
        editText.setTextColor(m44782a0().getColor(C4804R.C4806color.f86093black));
        new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("لطفا نام و نام خانوادگی را وارد کنید").setView(editText).mo26266y("ذخیره", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.TolFragment.7
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentActivity m44716w;
                String str;
                String m4963S0 = compressHelper.m4963S0(editText.getText().toString());
                if (m4963S0.length() == 0) {
                    m44716w = TolFragment.this.m44716w();
                    str = "لطفا یک نام وارد کنید";
                } else {
                    CompressHelper compressHelper2 = compressHelper;
                    String m4967R = compressHelper2.m4967R();
                    compressHelper2.m4885q(m4967R, "Insert into tol values (null, '" + m4963S0 + "', " + TolFragment.this.f75543U3 + ", " + TolFragment.this.f75545W3 + ", '" + format + "')");
                    m44716w = TolFragment.this.m44716w();
                    str = "با موفقیت ذخیره شد";
                }
                CompressHelper.m4921e2(m44716w, str, 1);
            }
        }).mo26284p("بستن", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.TolFragment.6
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }).m52864I();
    }

    /* renamed from: Y2 */
    public void m4263Y2() {
        TextView textView;
        String str;
        m4271Q2(this.f75528F3, this.f75541S3[0]);
        m4271Q2(this.f75529G3, this.f75541S3[1]);
        m4271Q2(this.f75530H3, this.f75541S3[2]);
        m4271Q2(this.f75531I3, this.f75542T3[0]);
        m4271Q2(this.f75532J3, this.f75542T3[1]);
        m4271Q2(this.f75533K3, this.f75542T3[2]);
        if (StringUtils.join(this.f75541S3, "-").equals(StringUtils.join(this.f75542T3, "-"))) {
            CompressHelper.m5001F1(m44716w(), "success.mp3");
            this.f75543U3 += System.currentTimeMillis() - this.f75544V3;
            this.f75534L3.setVisibility(0);
            if (this.f75540R3 < this.f75539Q3.size() - 1) {
                this.f75535M3.setText("مرحله با موفقیت به پایان رسید.");
                textView = this.f75536N3;
                str = "برای ادامه کلیک کنید";
            } else {
                this.f75535M3.setText("آزمون به پایان رسید .\n با تشکر فراوان از شما");
                textView = this.f75536N3;
                str = "مجموع زمان : " + m4265W2(this.f75543U3 / 1000) + " ثانیه\nمجموع حرکات : " + m4265W2(this.f75545W3) + " تا";
            }
            textView.setText(str);
        }
    }

    /* renamed from: Z2 */
    public void m4262Z2(String str) {
        String[] splitPreserveAllTokens = StringUtils.splitPreserveAllTokens(str, "-");
        m4271Q2(this.f75528F3, splitPreserveAllTokens[0]);
        m4271Q2(this.f75529G3, splitPreserveAllTokens[1]);
        m4271Q2(this.f75530H3, splitPreserveAllTokens[2]);
        m4271Q2(this.f75531I3, splitPreserveAllTokens[3]);
        m4271Q2(this.f75532J3, splitPreserveAllTokens[4]);
        m4271Q2(this.f75533K3, splitPreserveAllTokens[5]);
    }
}
