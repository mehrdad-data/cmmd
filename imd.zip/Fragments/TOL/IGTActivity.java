package net.imedicaldoctor.imd.Fragments.TOL;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class IGTActivity extends AppCompatActivity {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87212igt_activity);
        if (bundle == null) {
            m44690E().m44464r().m44278y(C4804R.C4808id.container, IGTFragment.m4280N2()).mo44288o();
        }
    }
}
