package net.imedicaldoctor.imd.Fragments.TOL;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextGotoViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class PsychoListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f75522b4;

    /* renamed from: c4 */
    public String f75523c4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        m4337R2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        ArrayList<Bundle> arrayList = new ArrayList<>();
        this.f75218O3 = arrayList;
        arrayList.add(m4276l3("Tower Of London Test", 1));
        this.f75218O3.add(m4276l3("IOWA Gambling Test", 10));
        this.f75218O3.add(m4276l3("Share Result", 100));
        ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87259list_view_item_ripple_goto_arrow) { // from class: net.imedicaldoctor.imd.Fragments.TOL.PsychoListActivityFragment.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, final int i) {
                RippleTextGotoViewHolder rippleTextGotoViewHolder = (RippleTextGotoViewHolder) viewHolder;
                rippleTextGotoViewHolder.f83289I.setText(bundle2.getString("title"));
                rippleTextGotoViewHolder.f83292L.setVisibility(8);
                rippleTextGotoViewHolder.f83291K.setVisibility(8);
                rippleTextGotoViewHolder.f83290J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.PsychoListActivityFragment.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        PsychoListActivityFragment.this.m4275m3(bundle2, i);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new RippleTextGotoViewHolder(view);
            }
        };
        this.f75216M3 = chaptersAdapter;
        this.f75227X3.setAdapter(chaptersAdapter);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "Psychological Tests";
    }

    /* renamed from: l3 */
    public Bundle m4276l3(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("title", str);
        bundle.putInt("id", i);
        return bundle;
    }

    /* renamed from: m3 */
    public void m4275m3(Bundle bundle, int i) {
        m4330Y2();
        if (bundle.getInt("id") == 100) {
            CompressHelper compressHelper = this.f75215L3;
            compressHelper.m4929c2(compressHelper.m4967R(), "*/*");
            return;
        }
        CompressHelper compressHelper2 = this.f75215L3;
        Bundle bundle2 = this.f75212I3;
        compressHelper2.m4883q1(bundle2, bundle.getInt("id") + "", null, null);
    }
}
