package net.imedicaldoctor.imd.Fragments.TOL;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;

/* loaded from: classes2.dex */
public class IGTFragment extends Fragment {

    /* renamed from: F3 */
    public long f75486F3;

    /* renamed from: G3 */
    public TextView f75487G3;

    /* renamed from: H3 */
    public TextView f75488H3;

    /* renamed from: I3 */
    public TextView f75489I3;

    /* renamed from: J3 */
    public TextView f75490J3;

    /* renamed from: K3 */
    public LinearLayout f75491K3;

    /* renamed from: L3 */
    public LinearLayout f75492L3;

    /* renamed from: M3 */
    public LinearLayout f75493M3;

    /* renamed from: N3 */
    public LinearLayout f75494N3;

    /* renamed from: O3 */
    public RelativeLayout f75495O3;

    /* renamed from: P3 */
    public TextView f75496P3;

    /* renamed from: Q3 */
    public TextView f75497Q3;

    /* renamed from: R3 */
    public int f75498R3;

    /* renamed from: S3 */
    public int f75499S3;

    /* renamed from: T3 */
    public int f75500T3;

    /* renamed from: U3 */
    public int f75501U3;

    /* renamed from: V3 */
    public ImageView f75502V3;

    /* renamed from: W3 */
    public ImageView f75503W3;

    /* renamed from: X3 */
    public ImageView f75504X3;

    /* renamed from: Y3 */
    public ImageView f75505Y3;

    /* renamed from: Z3 */
    public Long f75506Z3;

    /* renamed from: a4 */
    public Random f75507a4;

    /* renamed from: b4 */
    public int[] f75508b4;

    /* renamed from: N2 */
    public static IGTFragment m4280N2() {
        return new IGTFragment();
    }

    /* renamed from: O2 */
    public String m4279O2(long j) {
        return (j + "").replace(IcyHeaders.f35463C2, "۱").replace(ExifInterface.f14403S4, "۲").replace(ExifInterface.f14411T4, "۳").replace("4", "۴").replace("5", "۵").replace("6", "۶").replace("7", "۷").replace("8", "۸").replace("9", "۹").replace("0", "۰");
    }

    /* renamed from: P2 */
    public void m4278P2() {
        final String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        final CompressHelper compressHelper = new CompressHelper(m44716w());
        final EditText editText = new EditText(m44716w());
        editText.setTextColor(m44782a0().getColor(C4804R.C4806color.f86093black));
        new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("لطفا نام و نام خانوادگی را وارد کنید").setView(editText).mo26266y("ذخیره", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.8
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                FragmentActivity m44716w;
                String str;
                String m4963S0 = compressHelper.m4963S0(editText.getText().toString());
                if (m4963S0.length() == 0) {
                    m44716w = IGTFragment.this.m44716w();
                    str = "لطفا یک نام وارد کنید";
                } else {
                    CompressHelper compressHelper2 = compressHelper;
                    String m4967R = compressHelper2.m4967R();
                    compressHelper2.m4885q(m4967R, "Insert into igt values (null, '" + m4963S0 + "', " + IGTFragment.this.f75499S3 + ", " + IGTFragment.this.f75506Z3 + ", " + IGTFragment.this.f75508b4[0] + ", " + IGTFragment.this.f75508b4[1] + ", " + IGTFragment.this.f75508b4[2] + ", " + IGTFragment.this.f75508b4[3] + ", " + IGTFragment.this.f75501U3 + ", " + IGTFragment.this.f75500T3 + ", '" + format + "')");
                    m44716w = IGTFragment.this.m44716w();
                    str = "با موفقیت ذخیره شد";
                }
                CompressHelper.m4921e2(m44716w, str, 1);
            }
        }).mo26284p("بستن", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.7
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        }).m52864I();
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x00f9  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x01fb  */
    /* renamed from: Q2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void m4277Q2(int r13) {
        /*
            Method dump skipped, instructions count: 537
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.m4277Q2(int):void");
    }

    @Override // androidx.fragment.app.Fragment
    @Nullable
    /* renamed from: U0 */
    public View mo3277U0(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87213igt_fragment, viewGroup, false);
        m44716w().getWindow().setFlags(1024, 1024);
        this.f75487G3 = (TextView) inflate.findViewById(C4804R.C4808id.f86964money);
        this.f75488H3 = (TextView) inflate.findViewById(C4804R.C4808id.f86805benefit);
        this.f75489I3 = (TextView) inflate.findViewById(C4804R.C4808id.f87085zarar);
        this.f75490J3 = (TextView) inflate.findViewById(C4804R.C4808id.f87074trials);
        this.f75491K3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f87025stack1);
        this.f75492L3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f87026stack2);
        this.f75493M3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f87027stack3);
        this.f75494N3 = (LinearLayout) inflate.findViewById(C4804R.C4808id.f87028stack4);
        this.f75502V3 = (ImageView) inflate.findViewById(C4804R.C4808id.f86933image1);
        this.f75503W3 = (ImageView) inflate.findViewById(C4804R.C4808id.f86934image2);
        this.f75504X3 = (ImageView) inflate.findViewById(C4804R.C4808id.f86935image3);
        this.f75505Y3 = (ImageView) inflate.findViewById(C4804R.C4808id.f86936image4);
        this.f75496P3 = (TextView) inflate.findViewById(C4804R.C4808id.f86981overlay_text_1);
        this.f75497Q3 = (TextView) inflate.findViewById(C4804R.C4808id.f86982overlay_text_2);
        this.f75495O3 = (RelativeLayout) inflate.findViewById(C4804R.C4808id.f86980overlay_layout);
        this.f75498R3 = 100;
        this.f75508b4 = new int[]{0, 0, 0, 0};
        this.f75500T3 = 0;
        this.f75501U3 = 0;
        this.f75488H3.setVisibility(8);
        this.f75489I3.setVisibility(8);
        this.f75495O3.setVisibility(0);
        this.f75499S3 = 2000;
        this.f75487G3.setText("موجودی شما : " + m4279O2(this.f75499S3) + " دلار");
        this.f75487G3.setVisibility(0);
        this.f75496P3.setText("به آزمون تصمیم گیری آیوا خوش آمدید");
        this.f75497Q3.setText(((("در این آزمون شما یکی از ۴ دسته موجود را انتخاب می کنید\nبا انتخاب هر دسته مبلغی را برنده می شوید و گاهی مقداری جریمه می شوید که ممکن است از میزان برد شما بیشتر باشد.") + "\nشما در شروع ۲۰۰۰ دلار پول دارید و ۱۰۰ بار می توانید از بین ۴ دسته انتخاب کنید") + "\nهدف آزمون به دست آوردن بیشترین سود می باشد") + "\n\nبرای شروع کلیک کنید");
        this.f75495O3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IGTFragment iGTFragment = IGTFragment.this;
                if (iGTFragment.f75498R3 > 0) {
                    iGTFragment.f75495O3.setVisibility(8);
                    IGTFragment.this.f75486F3 = System.currentTimeMillis();
                }
            }
        });
        this.f75495O3.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.2
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View view) {
                IGTFragment iGTFragment = IGTFragment.this;
                if (iGTFragment.f75498R3 == 0) {
                    iGTFragment.m4278P2();
                    return true;
                }
                return false;
            }
        });
        this.f75507a4 = new Random();
        this.f75491K3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IGTFragment.this.m4277Q2(1);
            }
        });
        this.f75492L3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IGTFragment.this.m4277Q2(2);
            }
        });
        this.f75493M3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IGTFragment.this.m4277Q2(3);
            }
        });
        this.f75494N3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.TOL.IGTFragment.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IGTFragment.this.m4277Q2(4);
            }
        });
        return inflate;
    }
}
