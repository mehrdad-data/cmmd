package net.imedicaldoctor.imd.Fragments.IranDaru;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes2.dex */
public class IDViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class IDViewerFragment extends ViewerHelperFragment {

        /* renamed from: w4 */
        private String f74725w4;

        /* renamed from: x4 */
        private String f74726x4;

        /* renamed from: y4 */
        private ArrayList<Bundle> f74727y4;

        /* renamed from: B4 */
        private String m4513B4(String str, String str2, String str3, String str4, String str5) {
            return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + str5 + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: C4 */
        public String m4512C4(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
            return "<a name=\"f" + str8 + "\"><div id=\"h" + str8 + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" text-align=\"center\" onclick=\"collapse(f" + str8 + ");toggleHeaderExpanded(h" + str8 + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + str8 + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: D4 */
        public void m4511D4(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
            int eventType = xmlPullParser.getEventType();
            while (eventType != 1) {
                if (eventType == 0) {
                    this.f74727y4 = new ArrayList<>();
                } else if (eventType == 2) {
                    Bundle m4510E4 = m4510E4(xmlPullParser);
                    this.f74725w4 = m4510E4.containsKey("TitlePe") ? m4510E4.getString("TitlePe") : null;
                    this.f74726x4 = "";
                } else if (eventType != 3) {
                    if (eventType == 4) {
                        this.f74726x4 += xmlPullParser.getText();
                    }
                } else if (this.f74725w4 != null && this.f74726x4.length() > 0) {
                    Bundle bundle = new Bundle();
                    bundle.putString("title", this.f74725w4);
                    bundle.putString("value", this.f74726x4);
                    bundle.putString("element", xmlPullParser.getName());
                    this.f74727y4.add(bundle);
                }
                eventType = xmlPullParser.next();
            }
        }

        /* renamed from: E4 */
        private Bundle m4510E4(XmlPullParser xmlPullParser) {
            Bundle bundle = new Bundle();
            for (int i = 0; i < xmlPullParser.getAttributeCount(); i++) {
                bundle.putString(xmlPullParser.getAttributeName(i), xmlPullParser.getAttributeValue(i));
            }
            return bundle;
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87322elsviewer, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f74727y4 = bundle.getParcelableArrayList("mFields");
            }
            if (m44859B() == null) {
                return inflate;
            }
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.IranDaru.IDViewerActivity.IDViewerFragment.1
                /* JADX WARN: Removed duplicated region for block: B:112:0x066b  */
                /* JADX WARN: Removed duplicated region for block: B:121:0x06d6 A[Catch: Exception -> 0x06de, TRY_LEAVE, TryCatch #0 {Exception -> 0x06de, blocks: (B:3:0x0014, B:5:0x0025, B:119:0x06d0, B:121:0x06d6, B:9:0x0030, B:11:0x014c, B:13:0x0152, B:15:0x0185, B:17:0x0195, B:19:0x019b, B:21:0x01c6, B:22:0x01cb, B:23:0x01d0, B:26:0x01e0, B:27:0x0228, B:29:0x0230, B:31:0x025d, B:32:0x0262, B:33:0x0268, B:35:0x026e, B:36:0x02aa, B:38:0x02b0, B:39:0x02db, B:40:0x02e5, B:42:0x02eb, B:45:0x0322, B:47:0x0326, B:49:0x0330, B:50:0x0369, B:57:0x0395, B:51:0x036d, B:53:0x0379, B:56:0x0382, B:58:0x039e, B:115:0x067f, B:59:0x03a7, B:61:0x03b1, B:65:0x03c2, B:67:0x03ca, B:69:0x03ce, B:71:0x03d6, B:78:0x045a, B:72:0x03e1, B:74:0x0400, B:75:0x0429, B:77:0x0451, B:76:0x042d, B:79:0x0464, B:80:0x0472, B:118:0x06af), top: B:126:0x0014 }] */
                /* JADX WARN: Removed duplicated region for block: B:143:? A[RETURN, SYNTHETIC] */
                @Override // java.lang.Runnable
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                public void run() {
                    /*
                        Method dump skipped, instructions count: 1778
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.IranDaru.IDViewerActivity.IDViewerFragment.RunnableC39311.run():void");
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.IranDaru.IDViewerActivity.IDViewerFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = IDViewerFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        IDViewerFragment iDViewerFragment = IDViewerFragment.this;
                        iDViewerFragment.m4078s4(iDViewerFragment.f75837P3);
                        return;
                    }
                    File file = new File(CompressHelper.m4945Y0(IDViewerFragment.this.f75850c4, "base"));
                    IDViewerFragment iDViewerFragment2 = IDViewerFragment.this;
                    iDViewerFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", iDViewerFragment2.f75847Z3, "text/html", "utf-8", null);
                    IDViewerFragment.this.m4092j4();
                    IDViewerFragment.this.m4098g4();
                    IDViewerFragment.this.m4100f3(C4804R.C4811menu.f87322elsviewer);
                    IDViewerFragment.this.m44735q2(false);
                    IDViewerFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            menuItem.getItemId();
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            menu.removeItem(C4804R.C4808id.f86776action_menu);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            CompressHelper compressHelper;
            Bundle bundle;
            String str4;
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
            if (str2.equals(Annotation.f59806M2)) {
                try {
                    if (!str3.contains("@\"")) {
                        return true;
                    }
                    new CompressHelper(m44716w());
                    String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(URLDecoder.decode(CompressHelper.m4920f(str3, "@\"", "\""), "UTF-8"), "://");
                    String str5 = "";
                    if (splitByWholeSeparator[0].equals("medCategory")) {
                        str5 = "medical";
                    } else if (splitByWholeSeparator[0].equals("pharmCategory")) {
                        str5 = "pharm";
                    }
                    String str6 = splitByWholeSeparator[1];
                    URLDecoder.decode(splitByWholeSeparator[2]);
                    new ArrayList();
                    if (str5.equals("medical")) {
                        compressHelper = this.f75863p4;
                        bundle = this.f75850c4;
                        str4 = "Select  tDrugGenerics.fDrugGenericId as _id,tDrugGenerics.fDrugGenericId, fDrugGenericName from tMedicalGroupGenerics,tDrugGenerics where tMedicalGroupGenerics.fMedicalGroupId=" + str6 + " AND tDrugGenerics.fDrugGenericId=tMedicalGroupGenerics.fDrugGenericId";
                    } else {
                        compressHelper = this.f75863p4;
                        bundle = this.f75850c4;
                        str4 = "Select tDrugGenerics.fDrugGenericId as _id,tDrugGenerics.fDrugGenericId, fDrugGenericName from tPharmGroupGenerics,tDrugGenerics where tPharmGroupGenerics.fPharmGroupId=" + str6 + " AND tDrugGenerics.fDrugGenericId=tPharmGroupGenerics.fDrugGenericId";
                    }
                    ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, str4);
                    ASSectionViewer aSSectionViewer = new ASSectionViewer();
                    Bundle bundle2 = new Bundle();
                    bundle2.putParcelableArrayList("Items", m4955V);
                    bundle2.putString("TitleProperty", "fDrugGenericName");
                    aSSectionViewer.m44844E2(this, 0);
                    aSSectionViewer.m44751k2(bundle2);
                    aSSectionViewer.m44870c3(true);
                    aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    iMDLogger.m3294f("IDViewer ShouldOverride", "Error " + e.toString());
                }
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new IDViewerFragment(), bundle);
    }
}
