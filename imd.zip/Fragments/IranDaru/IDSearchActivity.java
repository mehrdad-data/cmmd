package net.imedicaldoctor.imd.Fragments.IranDaru;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.StatusAdapter;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class IDSearchActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class IDSearchFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private AsyncTask f74722b4;

        /* renamed from: c4 */
        private SpellSearchAdapter f74723c4;

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            mo4335T2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            mo4335T2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
            this.f75216M3 = new StatusAdapter(m44716w(), "Search Drugs");
            this.f74723c4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "drug", null) { // from class: net.imedicaldoctor.imd.Fragments.IranDaru.IDSearchActivity.IDSearchFragment.1
                @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
                /* renamed from: g0 */
                public void mo3380g0(Bundle bundle2, int i) {
                    IDSearchFragment.this.m4330Y2();
                    IDSearchFragment iDSearchFragment = IDSearchFragment.this;
                    iDSearchFragment.f75215L3.m4883q1(iDSearchFragment.f75212I3, bundle2.getString("drugId"), null, null);
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
                /* renamed from: h0 */
                public void mo3379h0(Bundle bundle2) {
                    IDSearchFragment.this.m4330Y2();
                    IDSearchFragment.this.f75223T3.m51655i0(bundle2.getString("word"), true);
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(false);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: a3 */
        public void mo3982a3() {
            this.f74723c4.m3378i0(this.f75219P3, this.f75220Q3);
            this.f75227X3.setAdapter(this.f74723c4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id,* from Search where drugSearch match '" + str + "*' order by drug asc");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new IDSearchFragment());
    }
}
