package net.imedicaldoctor.imd.Fragments.IranDaru;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.cursoradapter.widget.CursorAdapter;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class IDCategoryViewer extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class IDCategoryViewerFragment extends SearchHelperFragment {
        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            ArrayList<Bundle> arrayList;
            Bundle bundle2;
            StringBuilder sb;
            String str;
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87153fragment_general_list, viewGroup, false);
            this.f75221R3 = inflate;
            super.mo3277U0(layoutInflater, viewGroup, bundle);
            final CompressHelper compressHelper = new CompressHelper(m44716w());
            String string = m44859B().getString("ID");
            this.f75212I3 = m44859B().getBundle("DB");
            String string2 = m44859B().getString("Category");
            m44859B().getString("Name");
            if (string2.equals("medical")) {
                bundle2 = this.f75212I3;
                sb = new StringBuilder();
                sb.append("Select  tDrugGenerics.fDrugGenericId as _id,tDrugGenerics.fDrugGenericId, fDrugGenericName from tMedicalGroupGenerics,tDrugGenerics where tMedicalGroupGenerics.fMedicalGroupId=");
                sb.append(string);
                str = " AND tDrugGenerics.fDrugGenericId=tMedicalGroupGenerics.fDrugGenericId";
            } else if (!string2.equals("pharm")) {
                arrayList = null;
                this.f75211H3.setAdapter((ListAdapter) new CursorAdapter(m44716w(), compressHelper.m4912h(arrayList), 0) { // from class: net.imedicaldoctor.imd.Fragments.IranDaru.IDCategoryViewer.IDCategoryViewerFragment.1
                    @Override // androidx.cursoradapter.widget.CursorAdapter
                    /* renamed from: d */
                    public void mo3522d(View view, Context context, Cursor cursor) {
                        ((TextView) view.getTag()).setText(cursor.getString(cursor.getColumnIndex("fDrugGenericName")));
                    }

                    @Override // androidx.cursoradapter.widget.CursorAdapter
                    /* renamed from: i */
                    public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup2) {
                        View inflate2 = LayoutInflater.from(context).inflate(C4804R.C4810layout.f87284list_view_item_simple_text, viewGroup2, false);
                        inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                        return inflate2;
                    }
                });
                this.f75211H3.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.IranDaru.IDCategoryViewer.IDCategoryViewerFragment.2
                    @Override // android.widget.AdapterView.OnItemClickListener
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                        IDCategoryViewerFragment.this.f75209F3 = i;
                        Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                        if (mo45341b.moveToPosition(i)) {
                            compressHelper.m4883q1(IDCategoryViewerFragment.this.f75212I3, compressHelper.m4956U1(mo45341b).getString("fDrugGenericID"), null, null);
                        }
                    }
                });
                mo3543h3();
                m44716w().setTitle("Drugs");
                return inflate;
            } else {
                bundle2 = this.f75212I3;
                sb = new StringBuilder();
                sb.append("Select tDrugGenerics.fDrugGenericId as _id,tDrugGenerics.fDrugGenericId, fDrugGenericName from tPharmGroupGenerics,tDrugGenerics where tPharmGroupGenerics.fPharmGroupId=");
                sb.append(string);
                str = " AND tDrugGenerics.fDrugGenericId=tPharmGroupGenerics.fDrugGenericId";
            }
            sb.append(str);
            arrayList = compressHelper.m4955V(bundle2, sb.toString());
            this.f75211H3.setAdapter((ListAdapter) new CursorAdapter(m44716w(), compressHelper.m4912h(arrayList), 0) { // from class: net.imedicaldoctor.imd.Fragments.IranDaru.IDCategoryViewer.IDCategoryViewerFragment.1
                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: d */
                public void mo3522d(View view, Context context, Cursor cursor) {
                    ((TextView) view.getTag()).setText(cursor.getString(cursor.getColumnIndex("fDrugGenericName")));
                }

                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: i */
                public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup2) {
                    View inflate2 = LayoutInflater.from(context).inflate(C4804R.C4810layout.f87284list_view_item_simple_text, viewGroup2, false);
                    inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                    return inflate2;
                }
            });
            this.f75211H3.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.IranDaru.IDCategoryViewer.IDCategoryViewerFragment.2
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    IDCategoryViewerFragment.this.f75209F3 = i;
                    Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                    if (mo45341b.moveToPosition(i)) {
                        compressHelper.m4883q1(IDCategoryViewerFragment.this.f75212I3, compressHelper.m4956U1(mo45341b).getString("fDrugGenericID"), null, null);
                    }
                }
            });
            mo3543h3();
            m44716w().setTitle("Drugs");
            return inflate;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new IDCategoryViewerFragment());
    }
}
