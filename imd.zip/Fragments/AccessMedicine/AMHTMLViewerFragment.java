package net.imedicaldoctor.imd.Fragments.AccessMedicine;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class AMHTMLViewerFragment extends ViewerHelperFragment {
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:adjustTableLinks()");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: T0 */
    public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(C4804R.C4811menu.f87329menu_amviewer, menu);
        m4096h4(menu);
        mo3568e3(menu);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        String str2 = "";
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87175fragment_new_table_viewer, viewGroup, false);
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return inflate;
        }
        try {
            new CompressHelper(m44716w());
            String str3 = this.f75847Z3;
            if (str3 == null || str3.length() == 0) {
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(this.f75851d4.replace("html-", ""), ",,,,,");
                this.f75852e4 = splitByWholeSeparator[0];
                String str4 = splitByWholeSeparator[1];
                if (this.f75850c4.getString("Type").equals("accessmedicine")) {
                    String m4117W3 = m4117W3(m44716w(), "AMHeader.css");
                    String m4117W32 = m4117W3(m44716w(), "AMFooter.css");
                    String replace = m4117W3.replace("[size]", "200").replace("[title]", this.f75852e4);
                    m4089l3("mgh.Popup.Dialog.js");
                    str2 = replace;
                    str = m4117W32;
                } else {
                    str = "";
                }
                m4087m3();
                this.f75847Z3 = str2 + str4 + str;
            }
            File file = new File(CompressHelper.m4945Y0(this.f75850c4, "base"));
            this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
            m4092j4();
            if (m44859B() == null || !m44859B().containsKey("Dialog")) {
                m4098g4();
                m4100f3(C4804R.C4811menu.f87329menu_amviewer);
            } else {
                if (this.f75852e4 == null) {
                    this.f75852e4 = "Unknown";
                }
                this.f75858k4.setTitle(this.f75852e4);
            }
            m44735q2(false);
            m4140G3();
            return inflate;
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            m4080r4(e);
            return inflate;
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
        menu.removeItem(C4804R.C4808id.f86776action_menu);
    }

    /* JADX WARN: Code restructure failed: missing block: B:37:0x0146, code lost:
        if (r9.getString("sectionId").equals(r7.f75851d4) != false) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x017f, code lost:
        if (r9.getString("sectionId").equals(r7.f75851d4) != false) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0181, code lost:
        mo4144C3(r8);
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0185, code lost:
        r7.f75863p4.m4883q1(r7.f75850c4, r9.getString("sectionId"), null, r8);
     */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean mo3564p4(android.webkit.WebView r8, java.lang.String r9, java.lang.String r10, java.lang.String r11) {
        /*
            Method dump skipped, instructions count: 401
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMHTMLViewerFragment.mo3564p4(android.webkit.WebView, java.lang.String, java.lang.String, java.lang.String):boolean");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: q4 */
    public boolean mo4082q4() {
        if (m44859B() == null || !m44859B().containsKey("Dialog")) {
            return PreferenceManager.getDefaultSharedPreferences(m44851D()).getBoolean("NestedScroll", true);
        }
        return false;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: t3 */
    public void mo4077t3(String str) {
        m4804x4();
        super.mo4077t3(str);
    }

    /* renamed from: x4 */
    public void m4804x4() {
    }
}
