package net.imedicaldoctor.imd.Fragments.AccessMedicine;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.GeneralDialogFragment;
import net.imedicaldoctor.imd.iMDLogger;

/* loaded from: classes2.dex */
public class AMViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class AMViewerFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        public ArrayList<Bundle> f73932A4;

        /* renamed from: B4 */
        public ArrayList<Bundle> f73933B4;

        /* renamed from: C4 */
        public ArrayList<Bundle> f73934C4;

        /* renamed from: w4 */
        private GeneralDialogFragment f73935w4;

        /* renamed from: x4 */
        private String f73936x4;

        /* renamed from: y4 */
        private MenuItem f73937y4;

        /* renamed from: z4 */
        public ArrayList<Bundle> f73938z4;

        /* renamed from: C4 */
        private void m4801C4(String str) {
            if (this.f73938z4.size() + this.f73932A4.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
                return;
            }
            ArrayList arrayList = new ArrayList();
            arrayList.addAll(this.f73938z4);
            arrayList.addAll(this.f73932A4);
            Boolean bool = Boolean.FALSE;
            int i = 0;
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                if (((Bundle) arrayList.get(i2)).getString("id").startsWith(str)) {
                    bool = Boolean.TRUE;
                    i = i2;
                }
            }
            if (!bool.booleanValue()) {
                for (int i3 = 0; i3 < arrayList.size(); i3++) {
                    if (((Bundle) arrayList.get(i3)).getString("id").replace("m_", "").startsWith(str.replace("m_", ""))) {
                        i = i3;
                    }
                }
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX WARN: Can't wrap try/catch for region: R(9:14|(2:16|(4:18|19|20|21))|22|23|24|25|26|27|(4:29|19|20|21)(6:30|31|32|33|35|21)) */
        /* JADX WARN: Code restructure failed: missing block: B:71:0x0293, code lost:
            r0 = e;
         */
        /* JADX WARN: Code restructure failed: missing block: B:73:0x0295, code lost:
            r0 = e;
         */
        /* JADX WARN: Code restructure failed: missing block: B:74:0x0296, code lost:
            r13 = r21;
         */
        /* renamed from: x4 */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void m4800x4() {
            /*
                Method dump skipped, instructions count: 713
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMViewerActivity.AMViewerFragment.m4800x4():void");
        }

        /* renamed from: B4 */
        public void m4802B4() {
            this.f75853f4.loadUrl("javascript:$(\".contentJump\").each(function(){justShowSection($(this).find(\"a[name]\").first().attr(\"name\"))});");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: C3 */
        public void mo4144C3(String str) {
            WebView webView = this.f75853f4;
            webView.loadUrl("javascript:showSection('" + str + "');");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: P3 */
        public boolean mo3571P3(ConsoleMessage consoleMessage) {
            String str;
            iMDLogger.m3294f("Javascript Console", consoleMessage.message());
            String[] split = consoleMessage.message().split(",,,,,");
            if (split[0].equals("tableAction")) {
                String replace = split[1].replace(" rs_skip_always", "");
                String str2 = "Caption";
                try {
                    CompressHelper.m4920f(replace, "class=\"tableLabel\">", "</span>");
                    str2 = CompressHelper.m4920f(replace, "class=\"tableCaption\">", "</span>");
                    str = Html.fromHtml(str2).toString();
                } catch (Exception unused) {
                    str = str2;
                }
                if (Boolean.valueOf(PreferenceManager.getDefaultSharedPreferences(m44716w()).getBoolean("amtable", true)).booleanValue()) {
                    Bundle bundle = new Bundle();
                    bundle.putBundle("DB", this.f75850c4);
                    bundle.putString("URL", "html-" + str + ",,,,," + replace);
                    bundle.putString("Dialog", IcyHeaders.f35463C2);
                    AMHTMLViewerFragment aMHTMLViewerFragment = new AMHTMLViewerFragment();
                    aMHTMLViewerFragment.m44751k2(bundle);
                    GeneralDialogFragment generalDialogFragment = new GeneralDialogFragment(aMHTMLViewerFragment);
                    this.f73935w4 = generalDialogFragment;
                    generalDialogFragment.m44870c3(true);
                    this.f73935w4.m44844E2(this, 0);
                    this.f73935w4.mo29915h3(m44820L(), "AMSectionsViewer");
                } else {
                    CompressHelper compressHelper = this.f75863p4;
                    Bundle bundle2 = this.f75850c4;
                    compressHelper.m4883q1(bundle2, "html-" + str + ",,,,," + replace, null, null);
                }
            }
            return super.mo3571P3(consoleMessage);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            ArrayList<Bundle> arrayList;
            Bundle m4073v3;
            if (this.f73938z4.size() <= 0 || (arrayList = this.f73938z4) == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f73938z4)) == null) {
                return null;
            }
            return m4073v3.getString("ImagePath");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S3 */
        public void mo3569S3(WebView webView, String str) {
            this.f75853f4.loadUrl("javascript:adjustTableLinks()");
            this.f75853f4.loadUrl("javascript:$(\"img[data-original]\").each(function(){if (this.style.display==\"none\"){$(this).attr(\"src\",$(this).attr(\"data-original\"));$(this).css(\"width\",\"50%\");$(this).show();}});");
            super.mo3569S3(webView, str);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87329menu_amviewer, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f73936x4 = bundle.getString("mResources");
                this.f73938z4 = bundle.getParcelableArrayList("mImages");
                this.f73932A4 = bundle.getParcelableArrayList("mVideos");
                this.f73933B4 = bundle.getParcelableArrayList("mOtherImages");
                this.f73934C4 = bundle.getParcelableArrayList("mSections");
            }
            if (m44859B() == null) {
                return inflate;
            }
            this.f75837P3 = null;
            iMDLogger.m3290j("AMViewer", "Loading AM Document with mDocAddress = " + this.f75851d4);
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMViewerActivity.AMViewerFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    Bundle bundle2;
                    String str;
                    try {
                        CompressHelper compressHelper = new CompressHelper(AMViewerFragment.this.m44716w());
                        String str2 = AMViewerFragment.this.f75847Z3;
                        if (str2 == null || str2.length() == 0) {
                            Bundle m4923e0 = compressHelper.m4923e0(AMViewerFragment.this.f75850c4, "Select * from Docs where id=" + AMViewerFragment.this.f75851d4);
                            if (m4923e0 == null) {
                                m4923e0 = compressHelper.m4923e0(AMViewerFragment.this.f75850c4, "Select * from Docs where aid=" + AMViewerFragment.this.f75851d4);
                                if (m4923e0 == null) {
                                    Bundle m4923e02 = compressHelper.m4923e0(AMViewerFragment.this.f75850c4, "Select * from Sections Where id = " + AMViewerFragment.this.f75851d4);
                                    if (m4923e02 == null) {
                                        Bundle m4923e03 = compressHelper.m4923e0(AMViewerFragment.this.f75850c4, "Select * from AllSections Where section like '" + AMViewerFragment.this.f75851d4 + "%'");
                                        if (m4923e03 == null) {
                                            AMViewerFragment.this.f75837P3 = "Document doesn't exist";
                                            return;
                                        }
                                        AMViewerFragment.this.f75851d4 = m4923e03.getString("sectionId");
                                        bundle2 = AMViewerFragment.this.f75850c4;
                                        str = "Select * from Docs where id=" + AMViewerFragment.this.f75851d4;
                                    } else {
                                        AMViewerFragment.this.f75851d4 = m4923e02.getString("sectionId");
                                        bundle2 = AMViewerFragment.this.f75850c4;
                                        str = "Select * from Docs where id=" + AMViewerFragment.this.f75851d4;
                                    }
                                    m4923e0 = compressHelper.m4923e0(bundle2, str);
                                } else {
                                    AMViewerFragment.this.f75851d4 = m4923e0.getString("id");
                                }
                            }
                            String string = m4923e0.getString("mainContent");
                            AMViewerFragment.this.f73936x4 = m4923e0.getString("resources");
                            AMViewerFragment.this.f75852e4 = m4923e0.getString("name");
                            String replace = new String(compressHelper.m4870v(string, m4923e0.getString("id"), "127")).replace(">Print Section<", "><").replace(">Favorite Table<", "><").replace(">Download (.pdf)<", "><").replace(">|<", "><").replace(">Favorite Figure<", "><").replace(">Download Slide (.ppt)<", "><");
                            AMViewerFragment aMViewerFragment = AMViewerFragment.this;
                            String m4117W3 = aMViewerFragment.m4117W3(aMViewerFragment.m44716w(), "AMHeader.css");
                            AMViewerFragment aMViewerFragment2 = AMViewerFragment.this;
                            String m4117W32 = aMViewerFragment2.m4117W3(aMViewerFragment2.m44716w(), "AMFooter.css");
                            String str3 = m4117W3.replace("[size]", "200").replace("[title]", AMViewerFragment.this.f75852e4) + replace.replace("<img data-original=\"s_audio_intext.jpeg\" src=\"spinnerLarge.gif\" alt=\"Image not available.\" class=\"contentFigures\" />", "<img src=\"s_audio_intext.jpeg\">").replace(">Download Section PDF</", "></") + m4117W32;
                            AMViewerFragment.this.m4089l3("mgh.Popup.Dialog.js");
                            AMViewerFragment.this.m4087m3();
                            AMViewerFragment aMViewerFragment3 = AMViewerFragment.this;
                            aMViewerFragment3.f75847Z3 = str3;
                            aMViewerFragment3.m4800x4();
                        }
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        e.printStackTrace();
                        AMViewerFragment.this.f75837P3 = e.getLocalizedMessage();
                    }
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMViewerActivity.AMViewerFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = AMViewerFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        AMViewerFragment aMViewerFragment = AMViewerFragment.this;
                        aMViewerFragment.m4078s4(aMViewerFragment.f75837P3);
                        return;
                    }
                    if (AMViewerFragment.this.f73937y4 != null) {
                        if (AMViewerFragment.this.f73938z4.size() + AMViewerFragment.this.f73932A4.size() == 0) {
                            AMViewerFragment.this.f73937y4.setVisible(false);
                        } else {
                            AMViewerFragment.this.f73937y4.setVisible(true);
                        }
                    }
                    if (!AMViewerFragment.this.f75863p4.m4892n1()) {
                        AMViewerFragment.this.m4102d4("Chapter");
                    }
                    String m4945Y0 = CompressHelper.m4945Y0(AMViewerFragment.this.f75850c4, "base");
                    File file = new File(m4945Y0);
                    String str2 = "file://" + file.getAbsolutePath() + "/";
                    AMViewerFragment aMViewerFragment2 = AMViewerFragment.this;
                    aMViewerFragment2.f75847Z3 = aMViewerFragment2.f75847Z3.replace("href=\"#", "href=\"svbfile://somewhere#");
                    AMViewerFragment.this.m4097h3(m4945Y0);
                    AMViewerFragment aMViewerFragment3 = AMViewerFragment.this;
                    aMViewerFragment3.f75853f4.loadDataWithBaseURL(str2, aMViewerFragment3.f75847Z3, "text/html", "utf-8", null);
                    AMViewerFragment.this.m4092j4();
                    AMViewerFragment.this.m4098g4();
                    AMViewerFragment.this.m4100f3(C4804R.C4811menu.f87329menu_amviewer);
                    AMViewerFragment.this.m44735q2(false);
                    AMViewerFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86774action_gallery) {
                m4801C4("soheilvb");
            }
            if (itemId == C4804R.C4808id.f86776action_menu) {
                AMSectionsViewer aMSectionsViewer = new AMSectionsViewer();
                Bundle bundle = new Bundle();
                bundle.putBundle("db", this.f75850c4);
                bundle.putString("docId", this.f75851d4);
                bundle.putString("parentId", "0");
                aMSectionsViewer.m44751k2(bundle);
                aMSectionsViewer.m44870c3(true);
                aMSectionsViewer.m44844E2(this, 0);
                aMSectionsViewer.mo29915h3(m44820L(), "AMSectionsViewer");
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            this.f73937y4 = menu.findItem(C4804R.C4808id.f86774action_gallery);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        /* JADX WARN: Code restructure failed: missing block: B:47:0x0191, code lost:
            if (r9.getString("sectionId").equals(r7.f75851d4) != false) goto L50;
         */
        /* JADX WARN: Code restructure failed: missing block: B:56:0x01ca, code lost:
            if (r9.getString("sectionId").equals(r7.f75851d4) != false) goto L50;
         */
        /* JADX WARN: Code restructure failed: missing block: B:57:0x01cc, code lost:
            mo4144C3(r8);
         */
        /* JADX WARN: Code restructure failed: missing block: B:58:0x01d0, code lost:
            r7.f75863p4.m4883q1(r7.f75850c4, r9.getString("sectionId"), null, r8);
         */
        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public boolean mo3564p4(android.webkit.WebView r8, java.lang.String r9, java.lang.String r10, java.lang.String r11) {
            /*
                Method dump skipped, instructions count: 476
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMViewerActivity.AMViewerFragment.mo3564p4(android.webkit.WebView, java.lang.String, java.lang.String, java.lang.String):boolean");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: t3 */
        public void mo4077t3(String str) {
            m4802B4();
            super.mo4077t3(str);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: z3 */
        public void mo4067z3() {
            Bundle m4907i1;
            if (PreferenceManager.getDefaultSharedPreferences(m44716w()).getBoolean("lastred", false)) {
                CompressHelper compressHelper = this.f75863p4;
                if (compressHelper.m4907i1(compressHelper.m4946Y(m4137I3(), "select save from highlight where dbName='" + this.f75850c4.getString("Name").replace("'", "''") + "' AND dbAddress='" + this.f75863p4.m4963S0(this.f75851d4) + "' AND save like '%$highlightRed$%'")) == null) {
                    return;
                }
                m4802B4();
                this.f75853f4.loadUrl("javascript:gotoHighlight('" + m4907i1.getString("save") + "');");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new AMViewerFragment(), bundle);
    }
}
