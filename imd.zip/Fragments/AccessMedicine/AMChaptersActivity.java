package net.imedicaldoctor.imd.Fragments.AccessMedicine;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class AMChaptersActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class AMChaptersFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private CursorAdapter f73913b4;

        /* renamed from: c4 */
        private CursorAdapter f73914c4;

        /* renamed from: d4 */
        private String f73915d4;

        /* loaded from: classes2.dex */
        public class AMChaptersAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f73920d;

            /* renamed from: e */
            public ArrayList<Bundle> f73921e;

            /* renamed from: f */
            public String f73922f;

            public AMChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
                this.f73920d = context;
                this.f73921e = arrayList;
                this.f73922f = str;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                return this.f73921e.get(i).getString("leaf").equals(IcyHeaders.f35463C2) ? 0 : 1;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                final Bundle bundle = this.f73921e.get(i);
                rippleTextViewHolder.f83300I.setText(bundle.getString(this.f73922f));
                rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMChaptersActivity.AMChaptersFragment.AMChaptersAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        AMChaptersAdapter.this.mo4805d0(bundle, i);
                    }
                });
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                if (i == 0) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f73920d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
                }
                if (i == 1) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f73920d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
                }
                return null;
            }

            /* renamed from: d0 */
            public void mo4805d0(Bundle bundle, int i) {
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                return this.f73921e.size();
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4337R2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            String str;
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4337R2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            if (m44859B() == null || !m44859B().containsKey("ParentId")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
                str = null;
            } else {
                if (m44859B().getString("ParentId").equals("0")) {
                    appBarLayout.m27445s(true, false);
                    relativeLayout.setVisibility(0);
                } else {
                    appBarLayout.m27445s(false, false);
                    appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMChaptersActivity.AMChaptersFragment.1
                        @Override // java.lang.Runnable
                        public void run() {
                            relativeLayout.setVisibility(0);
                        }
                    }, 800L);
                }
                str = m44859B().getString("ParentId");
            }
            this.f73915d4 = str;
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle2 = this.f75212I3;
            ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select id as _id,* from toc where parentId = " + this.f73915d4);
            this.f75218O3 = m4955V;
            if (m4955V == null) {
                this.f75218O3 = new ArrayList<>();
            }
            this.f75216M3 = new AMChaptersAdapter(m44716w(), this.f75218O3, "name") { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMChaptersActivity.AMChaptersFragment.2
                @Override // net.imedicaldoctor.imd.Fragments.AccessMedicine.AMChaptersActivity.AMChaptersFragment.AMChaptersAdapter
                /* renamed from: d0 */
                public void mo4805d0(Bundle bundle3, int i) {
                    AMChaptersFragment.this.m4330Y2();
                    String string = bundle3.getString("leaf");
                    String string2 = bundle3.getString("docId");
                    if (string.equals(IcyHeaders.f35463C2)) {
                        AMChaptersFragment aMChaptersFragment = AMChaptersFragment.this;
                        aMChaptersFragment.f75215L3.m4883q1(aMChaptersFragment.f75212I3, string2, null, null);
                        return;
                    }
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("DB", AMChaptersFragment.this.f75212I3);
                    bundle4.putString("ParentId", bundle3.getString("id"));
                    AMChaptersFragment.this.f75215L3.m4979N(AMChaptersActivity.class, AMChaptersFragment.class, bundle4);
                }
            };
            this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMChaptersActivity.AMChaptersFragment.3
                @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
                /* renamed from: e0 */
                public void mo3397e0(Bundle bundle3, int i) {
                    Bundle m4926d1;
                    AMChaptersFragment.this.m4330Y2();
                    String string = bundle3.getString("type");
                    String string2 = bundle3.getString("contentId");
                    if (string.equals("0")) {
                        Bundle bundle4 = new Bundle();
                        bundle4.putBundle("DB", AMChaptersFragment.this.f75212I3);
                        bundle4.putString("ParentId", string2);
                        AMChaptersFragment.this.f75215L3.m4979N(AMChaptersActivity.class, AMChaptersFragment.class, bundle4);
                    } else if (string.equals(IcyHeaders.f35463C2)) {
                        AMChaptersFragment aMChaptersFragment = AMChaptersFragment.this;
                        aMChaptersFragment.f75215L3.m4883q1(aMChaptersFragment.f75212I3, string2, null, null);
                    } else {
                        if (string.equals(ExifInterface.f14403S4)) {
                            AMChaptersFragment aMChaptersFragment2 = AMChaptersFragment.this;
                            CompressHelper compressHelper2 = aMChaptersFragment2.f75215L3;
                            Bundle bundle5 = aMChaptersFragment2.f75212I3;
                            m4926d1 = compressHelper2.m4926d1(compressHelper2.m4955V(bundle5, "select * from videos where id=" + string2));
                            if (m4926d1 == null) {
                                return;
                            }
                        } else if (string.equals(ExifInterface.f14411T4)) {
                            AMChaptersFragment aMChaptersFragment3 = AMChaptersFragment.this;
                            CompressHelper compressHelper3 = aMChaptersFragment3.f75215L3;
                            Bundle bundle6 = aMChaptersFragment3.f75212I3;
                            m4926d1 = compressHelper3.m4926d1(compressHelper3.m4955V(bundle6, "select * from images where id=" + string2));
                            if (m4926d1 == null) {
                                return;
                            }
                        } else if (!string.equals("4")) {
                            if (string.equals("5")) {
                                AMChaptersFragment aMChaptersFragment4 = AMChaptersFragment.this;
                                aMChaptersFragment4.f75215L3.m4883q1(aMChaptersFragment4.f75212I3, string2, aMChaptersFragment4.m4332W2(bundle3.getString("subText")), null);
                                return;
                            }
                            return;
                        } else {
                            AMChaptersFragment aMChaptersFragment5 = AMChaptersFragment.this;
                            CompressHelper compressHelper4 = aMChaptersFragment5.f75215L3;
                            Bundle bundle7 = aMChaptersFragment5.f75212I3;
                            m4926d1 = compressHelper4.m4926d1(compressHelper4.m4955V(bundle7, "select * from tables where id=" + string2));
                            if (m4926d1 == null) {
                                return;
                            }
                        }
                        String string3 = m4926d1.getString("sectionId");
                        String string4 = m4926d1.getString("goto");
                        AMChaptersFragment aMChaptersFragment6 = AMChaptersFragment.this;
                        aMChaptersFragment6.f75215L3.m4883q1(aMChaptersFragment6.f75212I3, string3, null, string4);
                    }
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(false);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id, Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new AMChaptersFragment());
    }
}
