package net.imedicaldoctor.imd.Fragments.AccessMedicine;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.AccessMedicine.AMViewerActivity;
import net.imedicaldoctor.imd.iMDLogger;

/* loaded from: classes2.dex */
public class AMSectionsViewer extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f73927g4;

    /* renamed from: h4 */
    private String f73928h4;

    /* renamed from: i4 */
    private String f73929i4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f73927g4 = m44859B().getBundle("db");
        this.f73928h4 = m44859B().getString("docId");
        this.f73929i4 = m44859B().getString("parentId");
        CompressHelper compressHelper = new CompressHelper(m44716w());
        Bundle bundle2 = this.f73927g4;
        listView.setAdapter((ListAdapter) new CursorAdapter(m44716w(), compressHelper.m4912h(compressHelper.m4955V(bundle2, "Select rowid as _id, * from sections where sectionId = " + this.f73928h4)), 0) { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMSectionsViewer.1
            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: d */
            public void mo3522d(View view, Context context, Cursor cursor) {
                ((TextView) view.getTag()).setText(cursor.getString(cursor.getColumnIndex("name")));
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getItemViewType(int i) {
                return 0;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getViewTypeCount() {
                return 1;
            }

            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: i */
            public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                View inflate2 = LayoutInflater.from(AMSectionsViewer.this.m44716w()).inflate(C4804R.C4810layout.f87284list_view_item_simple_text, viewGroup, false);
                inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                return inflate2;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.AccessMedicine.AMSectionsViewer.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                if (mo45341b.moveToPosition(i)) {
                    String string = mo45341b.getString(mo45341b.getColumnIndex("id"));
                    iMDLogger.m3290j("AMSectionsViewer", "Goto : " + string);
                    ((AMViewerActivity.AMViewerFragment) AMSectionsViewer.this.m44753k0()).mo4144C3(string);
                    AMSectionsViewer.this.mo27003Q2();
                }
            }
        });
        builder.setView(inflate);
        return builder.create();
    }
}
