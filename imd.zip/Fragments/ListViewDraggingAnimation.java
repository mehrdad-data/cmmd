package net.imedicaldoctor.imd.Fragments;

import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class ListViewDraggingAnimation extends iMDActivity {
}
