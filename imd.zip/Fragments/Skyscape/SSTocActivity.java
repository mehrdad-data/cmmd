package net.imedicaldoctor.imd.Fragments.Skyscape;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.MessageViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class SSTocActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class SSTocFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private String f75305b4;

        /* renamed from: c4 */
        private SSTOCSearchChaptersAdapter f75306c4;

        /* loaded from: classes2.dex */
        public class RippleInfoTextViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f75311I;

            /* renamed from: J */
            public ImageView f75312J;

            /* renamed from: K */
            public MaterialRippleLayout f75313K;

            public RippleInfoTextViewHolder(View view) {
                super(view);
                this.f75311I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
                this.f75313K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
                this.f75312J = (ImageView) view.findViewById(C4804R.C4808id.f86940info_button);
            }
        }

        /* loaded from: classes2.dex */
        public class SSTOCChaptersAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f75315d;

            /* renamed from: e */
            public ArrayList<Bundle> f75316e;

            /* renamed from: f */
            public String f75317f;

            public SSTOCChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
                this.f75315d = context;
                this.f75316e = arrayList;
                this.f75317f = str;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                Bundle bundle = this.f75316e.get(i);
                if (bundle.getString("leaf").equals(IcyHeaders.f35463C2)) {
                    return 0;
                }
                return bundle.getString("docId").length() > 0 ? 1 : 2;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                if (viewHolder.m42556F() == 0 || viewHolder.m42556F() == 2) {
                    RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                    final Bundle bundle = this.f75316e.get(i);
                    rippleTextViewHolder.f83300I.setText(bundle.getString(this.f75317f));
                    rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCChaptersAdapter.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SSTOCChaptersAdapter.this.mo4312e0(bundle, i);
                        }
                    });
                } else if (viewHolder.m42556F() == 1) {
                    RippleInfoTextViewHolder rippleInfoTextViewHolder = (RippleInfoTextViewHolder) viewHolder;
                    final Bundle bundle2 = this.f75316e.get(i);
                    rippleInfoTextViewHolder.f75311I.setText(bundle2.getString(this.f75317f));
                    rippleInfoTextViewHolder.f75313K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCChaptersAdapter.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SSTOCChaptersAdapter.this.mo4312e0(bundle2, i);
                        }
                    });
                    rippleInfoTextViewHolder.f75312J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCChaptersAdapter.3
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SSTOCChaptersAdapter.this.mo4313d0(bundle2, i);
                        }
                    });
                }
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                if (i == 0) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f75315d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
                }
                if (i == 1) {
                    return new RippleInfoTextViewHolder(LayoutInflater.from(this.f75315d).inflate(C4804R.C4810layout.f87259list_view_item_ripple_goto_arrow, viewGroup, false));
                } else if (i == 2) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f75315d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
                } else {
                    return null;
                }
            }

            /* renamed from: d0 */
            public void mo4313d0(Bundle bundle, int i) {
            }

            /* renamed from: e0 */
            public void mo4312e0(Bundle bundle, int i) {
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                return this.f75316e.size();
            }
        }

        /* loaded from: classes2.dex */
        public class SSTOCSearchChaptersAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f75328d;

            /* renamed from: e */
            public ArrayList<Bundle> f75329e;

            /* renamed from: f */
            public String f75330f;

            public SSTOCSearchChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
                this.f75328d = context;
                this.f75329e = arrayList;
                this.f75330f = str;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                Bundle bundle = this.f75329e.get(i);
                if (bundle.getString("leaf").equals(IcyHeaders.f35463C2)) {
                    return 0;
                }
                return bundle.getString("docId").length() > 0 ? 1 : 2;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                ArrayList<Bundle> arrayList = this.f75329e;
                if (arrayList == null || arrayList.size() == 0) {
                    MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
                } else if (viewHolder.m42556F() == 0 || viewHolder.m42556F() == 2) {
                    RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                    final Bundle bundle = this.f75329e.get(i);
                    rippleTextViewHolder.f83300I.setText(bundle.getString(this.f75330f));
                    rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCSearchChaptersAdapter.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SSTOCSearchChaptersAdapter.this.mo4310e0(bundle, i);
                        }
                    });
                } else if (viewHolder.m42556F() == 1) {
                    RippleInfoTextViewHolder rippleInfoTextViewHolder = (RippleInfoTextViewHolder) viewHolder;
                    final Bundle bundle2 = this.f75329e.get(i);
                    rippleInfoTextViewHolder.f75311I.setText(bundle2.getString(this.f75330f));
                    rippleInfoTextViewHolder.f75313K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCSearchChaptersAdapter.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SSTOCSearchChaptersAdapter.this.mo4310e0(bundle2, i);
                        }
                    });
                    rippleInfoTextViewHolder.f75312J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCSearchChaptersAdapter.3
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SSTOCSearchChaptersAdapter.this.mo4311d0(bundle2, i);
                        }
                    });
                }
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                ArrayList<Bundle> arrayList = this.f75329e;
                if (arrayList == null || arrayList.size() == 0) {
                    return new MessageViewHolder(this.f75328d, LayoutInflater.from(this.f75328d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
                } else if (i == 0) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f75328d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
                } else {
                    if (i == 1) {
                        return new RippleInfoTextViewHolder(LayoutInflater.from(this.f75328d).inflate(C4804R.C4810layout.f87259list_view_item_ripple_goto_arrow, viewGroup, false));
                    } else if (i == 2) {
                        return new RippleTextViewHolder(LayoutInflater.from(this.f75328d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
                    } else {
                        return null;
                    }
                }
            }

            /* renamed from: d0 */
            public void mo4311d0(Bundle bundle, int i) {
            }

            /* renamed from: e0 */
            public void mo4310e0(Bundle bundle, int i) {
            }

            /* renamed from: f0 */
            public void m4309f0(ArrayList<Bundle> arrayList) {
                this.f75329e = arrayList;
                m42860G();
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                return this.f75329e.size();
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4336S2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4336S2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            if (m44859B() == null || !m44859B().containsKey("ParentId")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
                this.f75305b4 = "0";
            } else {
                if (m44859B().getString("ParentId").equals("0")) {
                    appBarLayout.m27445s(true, false);
                    relativeLayout.setVisibility(0);
                } else {
                    appBarLayout.m27445s(false, false);
                    appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.1
                        @Override // java.lang.Runnable
                        public void run() {
                            relativeLayout.setVisibility(0);
                        }
                    }, 800L);
                }
                this.f75305b4 = m44859B().getString("ParentId");
            }
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle2 = this.f75212I3;
            this.f75218O3 = compressHelper.m4955V(bundle2, "Select * from toc where parentId = " + this.f75305b4);
            this.f75216M3 = new SSTOCChaptersAdapter(m44716w(), this.f75218O3, "name") { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.2
                @Override // net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCChaptersAdapter
                /* renamed from: d0 */
                public void mo4313d0(Bundle bundle3, int i) {
                    SSTocFragment.this.m4330Y2();
                    new CompressHelper(SSTocFragment.this.m44716w()).m4883q1(SSTocFragment.this.f75212I3, bundle3.getString("docId"), null, null);
                }

                @Override // net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCChaptersAdapter
                /* renamed from: e0 */
                public void mo4312e0(Bundle bundle3, int i) {
                    SSTocFragment.this.m4330Y2();
                    String string = bundle3.getString("leaf");
                    String string2 = bundle3.getString("docId");
                    if (string.equals(IcyHeaders.f35463C2)) {
                        new CompressHelper(SSTocFragment.this.m44716w()).m4883q1(SSTocFragment.this.f75212I3, string2, null, null);
                        return;
                    }
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("DB", SSTocFragment.this.f75212I3);
                    bundle4.putString("ParentId", bundle3.getString("id"));
                    new CompressHelper(SSTocFragment.this.m44716w()).m4979N(SSTocActivity.class, SSTocFragment.class, bundle4);
                }
            };
            this.f75306c4 = new SSTOCSearchChaptersAdapter(m44716w(), this.f75219P3, "name") { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.3
                @Override // net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCSearchChaptersAdapter
                /* renamed from: d0 */
                public void mo4311d0(Bundle bundle3, int i) {
                    SSTocFragment.this.m4330Y2();
                    new CompressHelper(SSTocFragment.this.m44716w()).m4883q1(SSTocFragment.this.f75212I3, bundle3.getString("docId"), null, null);
                }

                @Override // net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity.SSTocFragment.SSTOCSearchChaptersAdapter
                /* renamed from: e0 */
                public void mo4310e0(Bundle bundle3, int i) {
                    SSTocFragment.this.m4330Y2();
                    String string = bundle3.getString("leaf");
                    String string2 = bundle3.getString("docId");
                    if (string.equals(IcyHeaders.f35463C2)) {
                        new CompressHelper(SSTocFragment.this.m44716w()).m4883q1(SSTocFragment.this.f75212I3, string2, null, null);
                        return;
                    }
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("DB", SSTocFragment.this.f75212I3);
                    bundle4.putString("ParentId", bundle3.getString("id"));
                    new CompressHelper(SSTocFragment.this.m44716w()).m4979N(SSTocActivity.class, SSTocFragment.class, bundle4);
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(true);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: a3 */
        public void mo3982a3() {
            this.f75306c4.m4309f0(this.f75219P3);
            this.f75227X3.setAdapter(this.f75306c4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id, Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new SSTocFragment());
    }
}
