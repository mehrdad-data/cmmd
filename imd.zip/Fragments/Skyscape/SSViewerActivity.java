package net.imedicaldoctor.imd.Fragments.Skyscape;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Data.UnzipCompleted;
import net.imedicaldoctor.imd.Decompress;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;
import org.apache.commons.p024io.IOUtils;

/* loaded from: classes2.dex */
public class SSViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class SSViewerFragment extends ViewerHelperFragment {

        /* renamed from: w4 */
        private int f75341w4;

        /* renamed from: x4 */
        public ArrayList<Bundle> f75342x4;

        /* renamed from: y4 */
        public ArrayList<Bundle> f75343y4;

        /* renamed from: A4 */
        private void m4308A4(String str) {
            ArrayList<Bundle> arrayList = this.f75343y4;
            if (arrayList == null || arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
                return;
            }
            ArrayList arrayList2 = new ArrayList();
            arrayList2.addAll(this.f75343y4);
            int i = 0;
            for (int i2 = 0; i2 < arrayList2.size(); i2++) {
                if (((Bundle) arrayList2.get(i2)).getString("id").contains(str)) {
                    i = i2;
                }
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList2);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* renamed from: B4 */
        public void m4307B4() {
            SSSectionsViewer sSSectionsViewer = new SSSectionsViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, this.f75342x4);
            bundle.putString("titleProperty", HTML.Tag.f65890V);
            bundle.putString("sectionProperty", "sectionId");
            sSSectionsViewer.m44751k2(bundle);
            sSSectionsViewer.m44870c3(true);
            sSSectionsViewer.m44844E2(this, 0);
            sSSectionsViewer.mo29915h3(m44820L(), "SSSectionViewer");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: C3 */
        public void mo4144C3(String str) {
            WebView webView = this.f75853f4;
            webView.loadUrl("javascript:document.getElementsByName(\"section__" + str + "\")[0].scrollIntoView(true);");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: P3 */
        public boolean mo3571P3(ConsoleMessage consoleMessage) {
            super.mo3571P3(consoleMessage);
            iMDLogger.m3294f("SSViewer - console", consoleMessage.message());
            new CompressHelper(m44716w());
            String[] split = consoleMessage.message().split(",,,,,");
            if (split.length == 2 && split[0].equals("SSImage")) {
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(split[1], "|");
                if (splitByWholeSeparator.length > 0) {
                    ArrayList<Bundle> arrayList = new ArrayList<>();
                    for (String str : splitByWholeSeparator) {
                        if (!str.contains("ssimages")) {
                            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str, "/");
                            String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, splitByWholeSeparator2[1] + "_" + splitByWholeSeparator2[2], "Images");
                            if (new File(m4942Z0).length() > SimpleExoPlayer.f32068s1) {
                                Bundle bundle = new Bundle();
                                bundle.putString("ImagePath", m4942Z0);
                                bundle.putString("Description", null);
                                bundle.putString("id", m4942Z0);
                                arrayList.add(bundle);
                            }
                        }
                    }
                    this.f75343y4 = arrayList;
                    arrayList.size();
                    mo3978f4();
                }
                for (String str2 : splitByWholeSeparator) {
                    if (!str2.contains("ssimages")) {
                        String[] splitByWholeSeparator3 = StringUtils.splitByWholeSeparator(str2, "/");
                        this.f75853f4.loadUrl("javascript:updateImageSource(\"" + str2 + "\", \"" + (splitByWholeSeparator3[0] + "/Images/" + splitByWholeSeparator3[1] + "_" + splitByWholeSeparator3[2]) + "\")");
                    }
                }
            }
            return true;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            Bundle m4073v3;
            ArrayList<Bundle> arrayList = this.f75343y4;
            if (arrayList == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f75343y4)) == null) {
                return null;
            }
            return m4073v3.getString("ImagePath");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S3 */
        public void mo3569S3(WebView webView, String str) {
            super.mo3569S3(webView, str);
            this.f75853f4.loadUrl("javascript:updatePlayImage();");
            this.f75853f4.loadUrl("javascript:console.log('SSImage,,,,,' +getImageList());");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87329menu_amviewer, menu);
            m4096h4(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (m44859B().containsKey("Mode")) {
                this.f75341w4 = m44859B().getInt("Mode");
            } else {
                this.f75341w4 = 0;
            }
            if (bundle != null) {
                this.f75342x4 = bundle.getParcelableArrayList("mSections");
                this.f75341w4 = bundle.getInt("Mode");
                this.f75343y4 = bundle.getParcelableArrayList("mImages");
            }
            if (m44859B() == null) {
                return inflate;
            }
            iMDLogger.m3290j("AMViewer", "Loading AM Document with mDocAddress = " + this.f75851d4);
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSViewerActivity.SSViewerFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        CompressHelper compressHelper = new CompressHelper(SSViewerFragment.this.m44716w());
                        String str = SSViewerFragment.this.f75847Z3;
                        if (str == null || str.length() == 0) {
                            if (SSViewerFragment.this.f75341w4 == 0) {
                                ArrayList<Bundle> m4955V = compressHelper.m4955V(SSViewerFragment.this.f75850c4, "select * from document where id = " + SSViewerFragment.this.f75851d4);
                                if (m4955V.size() == 0) {
                                    SSViewerFragment.this.f75837P3 = "Document doesn't exist";
                                    return;
                                }
                                Bundle bundle2 = m4955V.get(0);
                                String m5015B = compressHelper.m5015B(bundle2.getString("doc"), bundle2.getString("id"), "127");
                                SSViewerFragment.this.f75852e4 = bundle2.getString("title");
                                String replace = m5015B.replace("<img data-original=\"s_audio_intext.jpeg\" src=\"spinnerLarge.gif\" alt=\"Image not available.\" class=\"contentFigures\" />", "<img src=\"s_audio_intext.jpeg\">").replace("<body>", "<body >");
                                String m4920f = CompressHelper.m4920f(replace, "<body", ">");
                                if (m4920f == null) {
                                    m4920f = "";
                                }
                                String replace2 = replace.replace("<body" + m4920f + ">", "<body onload=\\\"onBodyLoad();\\\" style=\\\"-webkit-text-size-adjust:200%;\" " + m4920f + "> <script src=\"log4javascript.js\" ></script><script src=\"core.js\" ></script><script src=\"dom.js\" ></script><script src=\"domrange.js\" ></script><script src=\"wrappedrange.js\" ></script><script src=\"wrappedselection.js\" ></script><script src=\"rangy-cssclassapplier.js\" ></script><script src=\"rangy-highlighter.js\" ></script><script src=\"hightlight.js\" ></script><script src=\"find.js\" ></script>").replace("../../../", "ss");
                                SSViewerFragment sSViewerFragment = SSViewerFragment.this;
                                sSViewerFragment.f75342x4 = compressHelper.m4955V(sSViewerFragment.f75850c4, "Select * from documentSections where docId=" + SSViewerFragment.this.f75851d4);
                                SSViewerFragment.this.m4087m3();
                                SSViewerFragment.this.f75847Z3 = replace2;
                            }
                            if (!compressHelper.m4892n1()) {
                                SSViewerFragment.this.m4102d4("Chapter");
                            }
                            SSViewerFragment.this.m4306x4();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        SSViewerFragment.this.f75837P3 = e.getLocalizedMessage();
                    }
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSViewerActivity.SSViewerFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = SSViewerFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        SSViewerFragment sSViewerFragment = SSViewerFragment.this;
                        sSViewerFragment.m4078s4(sSViewerFragment.f75837P3);
                        return;
                    }
                    File file = new File(CompressHelper.m4945Y0(SSViewerFragment.this.f75850c4, "base"));
                    SSViewerFragment sSViewerFragment2 = SSViewerFragment.this;
                    sSViewerFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", sSViewerFragment2.f75847Z3, "text/html", "utf-8", null);
                    if (SSViewerFragment.this.f75852e4.contains("- Calculator")) {
                        SSViewerFragment.this.m4090k4();
                    } else {
                        SSViewerFragment.this.m4092j4();
                    }
                    SSViewerFragment.this.m4098g4();
                    SSViewerFragment.this.m4100f3(C4804R.C4811menu.f87329menu_amviewer);
                    SSViewerFragment.this.m44735q2(false);
                    SSViewerFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86774action_gallery) {
                m4308A4("soheilvb");
            }
            if (itemId == C4804R.C4808id.f86776action_menu) {
                m4307B4();
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            try {
                iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
                CompressHelper compressHelper = new CompressHelper(m44716w());
                if (str2.equals("skyscape")) {
                    if (str3.contains("artinart:KAUD:url=")) {
                        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "/");
                        final String str4 = splitByWholeSeparator[splitByWholeSeparator.length - 1];
                        String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, str4, "base");
                        if (new File(m4942Z0).exists()) {
                            m4121U3(m4942Z0);
                            return true;
                        }
                        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "Sounds.zip");
                        Decompress.m4828e(m4945Y0, "Sounds/" + str4, new UnzipCompleted() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSViewerActivity.SSViewerFragment.3
                            @Override // net.imedicaldoctor.imd.Data.UnzipCompleted
                            /* renamed from: a */
                            public void mo4057a(String str5) {
                            }

                            @Override // net.imedicaldoctor.imd.Data.UnzipCompleted
                            /* renamed from: b */
                            public void mo4056b(byte[] bArr) {
                                String m4942Z02 = CompressHelper.m4942Z0(SSViewerFragment.this.f75850c4, str4, "base");
                                File file = new File(m4942Z02);
                                if (file.exists()) {
                                    return;
                                }
                                try {
                                    FileUtils.writeByteArrayToFile(file, bArr);
                                    SSViewerFragment.this.m4121U3(m4942Z02);
                                    file.deleteOnExit();
                                } catch (Exception e) {
                                    FirebaseCrashlytics.m18030d().m18027g(e);
                                    iMDLogger.m3294f("GetResrouce Error", "Unable to write byte array to " + file.getAbsolutePath() + " :" + e.getLocalizedMessage());
                                }
                            }
                        });
                        return true;
                    } else if (str3.contains("artinart:KVID:url=")) {
                        String m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, compressHelper.m4904j1(StringUtils.splitByWholeSeparator(str3, "=")), "Videos");
                        Bundle bundle = new Bundle();
                        bundle.putString("isVideo", IcyHeaders.f35463C2);
                        bundle.putString("ImagePath", m4942Z02);
                        bundle.putString("Description", null);
                        bundle.putString("id", m4942Z02);
                        this.f75343y4.add(bundle);
                        m4308A4(m4942Z02);
                        return true;
                    } else if (str3.equals("#section_list")) {
                        m4307B4();
                    } else if (!str3.startsWith("#")) {
                        String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str3, "/");
                        String[] splitByWholeSeparator3 = StringUtils.splitByWholeSeparator(splitByWholeSeparator2[splitByWholeSeparator2.length - 2] + "/" + splitByWholeSeparator2[splitByWholeSeparator2.length - 1], "#");
                        new Bundle();
                        Bundle bundle2 = this.f75850c4;
                        Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(bundle2, "select * from document where name = '" + splitByWholeSeparator3[0] + "'"));
                        if (m4907i1 == null) {
                            CompressHelper.m4921e2(m44716w(), "Document is not available", 1);
                            return true;
                        }
                        compressHelper.m4883q1(this.f75850c4, m4907i1.getString("id"), null, splitByWholeSeparator3.length > 1 ? splitByWholeSeparator3[1] : null);
                        return true;
                    } else {
                        WebView webView2 = this.f75853f4;
                        webView2.loadUrl("javascript:document.getElementsByName(\"" + str3.substring(1) + "\")[0].scrollIntoView(true);");
                        this.f75853f4.loadUrl("javascript:document.body.scrollTop = window.pageYOffset - 50;");
                    }
                } else if (str2.equals("myskycape")) {
                    String[] split = StringUtils.split(str3, "=");
                    if (!split[0].equals("?url") || split[1].contains("../")) {
                        return true;
                    }
                    String[] splitByWholeSeparator4 = StringUtils.splitByWholeSeparator(StringUtils.splitByWholeSeparator(split[1], "&")[0], "/");
                    String[] splitByWholeSeparator5 = StringUtils.splitByWholeSeparator(splitByWholeSeparator4[splitByWholeSeparator4.length - 2] + "/" + splitByWholeSeparator4[splitByWholeSeparator4.length - 1], "#");
                    new Bundle();
                    Bundle bundle3 = this.f75850c4;
                    Bundle m4907i12 = compressHelper.m4907i1(compressHelper.m4955V(bundle3, "select * from document where name = '" + splitByWholeSeparator5[0] + "'"));
                    if (m4907i12 == null) {
                        CompressHelper.m4921e2(m44716w(), "Document is not available", 1);
                        return true;
                    }
                    compressHelper.m4883q1(this.f75850c4, m4907i12.getString("id"), null, splitByWholeSeparator5.length > 1 ? splitByWholeSeparator5[1] : null);
                    return true;
                }
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
            }
            return true;
        }

        /* renamed from: x4 */
        public void m4306x4() {
            try {
                m4304z4("ssimages");
                m4304z4("ssscripts");
                m4304z4("ssstyles");
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                iMDLogger.m3294f("SSViewer", "Error in getting ss resources : " + e.getLocalizedMessage());
            }
        }

        /* renamed from: z4 */
        public void m4304z4(String str) {
            String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
            if (!new File(m4945Y0).exists()) {
                new File(m4945Y0).mkdirs();
            }
            String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, str, "base");
            if (!new File(m4942Z0).exists()) {
                new File(m4942Z0).mkdirs();
            }
            String[] strArr = new String[0];
            try {
                strArr = m44716w().getAssets().list(str);
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                iMDLogger.m3294f("SSViewer copyfolder", "Can't list files");
            }
            for (String str2 : strArr) {
                File file = new File(m4942Z0 + '/' + str2);
                if (!file.exists()) {
                    try {
                        InputStream open = m44716w().getAssets().open(str + "/" + str2);
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        IOUtils.copyLarge(open, fileOutputStream);
                        open.close();
                        fileOutputStream.close();
                    } catch (Exception unused) {
                        iMDLogger.m3294f("CopyJavascript", "Error in Copying " + str2 + " to " + m4945Y0 + "/" + str2);
                    }
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new SSViewerFragment(), bundle);
    }
}
