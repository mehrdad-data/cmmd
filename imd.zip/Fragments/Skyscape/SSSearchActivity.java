package net.imedicaldoctor.imd.Fragments.Skyscape;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import com.itextpdf.tool.xml.html.HTML;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Fragments.Skyscape.SSTocActivity;
import net.imedicaldoctor.imd.ViewHolders.MessageViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleSearchContentViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.iMDActivity;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class SSSearchActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class SSSearchFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private int f75278b4;

        /* renamed from: c4 */
        private Bundle f75279c4;

        /* renamed from: d4 */
        private SkyscapeContentSearchAdapter f75280d4;

        /* renamed from: e4 */
        private String f75281e4;

        /* loaded from: classes2.dex */
        public class SkyscapeAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f75286d;

            /* renamed from: e */
            public ArrayList<Bundle> f75287e;

            public SkyscapeAdapter(Context context, ArrayList<Bundle> arrayList) {
                this.f75286d = context;
                this.f75287e = arrayList;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                final Bundle bundle = this.f75287e.get(i);
                rippleTextViewHolder.f83300I.setText(this.f75287e.get(i).getString(SSSearchFragment.this.f75278b4 == 0 ? "name" : SSSearchFragment.this.f75278b4 == 1 ? "Name" : SSSearchFragment.this.f75278b4 == 2 ? "title" : ""));
                rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity.SSSearchFragment.SkyscapeAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SkyscapeAdapter.this.mo4319d0(bundle, i);
                    }
                });
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                return new RippleTextViewHolder(LayoutInflater.from(this.f75286d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
            }

            /* renamed from: d0 */
            public void mo4319d0(Bundle bundle, int i) {
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                ArrayList<Bundle> arrayList = this.f75287e;
                if (arrayList == null) {
                    return 0;
                }
                return arrayList.size();
            }
        }

        /* loaded from: classes2.dex */
        public class SkyscapeContentSearchAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f75292d;

            /* renamed from: e */
            public ArrayList<Bundle> f75293e;

            /* renamed from: f */
            public String f75294f;

            /* renamed from: g */
            public String f75295g;

            public SkyscapeContentSearchAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2) {
                this.f75292d = context;
                this.f75293e = arrayList;
                this.f75294f = str;
                this.f75295g = str2;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                String str;
                String str2;
                ArrayList<Bundle> arrayList = this.f75293e;
                if (arrayList == null || arrayList.size() == 0) {
                    MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
                    return;
                }
                RippleSearchContentViewHolder rippleSearchContentViewHolder = (RippleSearchContentViewHolder) viewHolder;
                final Bundle bundle = this.f75293e.get(i);
                if (SSSearchFragment.this.f75278b4 == 0) {
                    str = bundle.getString("Name");
                    str2 = bundle.getString("indexType");
                } else {
                    if (SSSearchFragment.this.f75278b4 == 1) {
                        str = bundle.getString("Name");
                    } else if (SSSearchFragment.this.f75278b4 == 2) {
                        str = bundle.getString("title");
                    } else {
                        str = "";
                        str2 = str;
                    }
                    str2 = "";
                }
                rippleSearchContentViewHolder.f83264I.setText(str);
                if (str2.length() > 0) {
                    rippleSearchContentViewHolder.f83265J.setVisibility(0);
                    rippleSearchContentViewHolder.f83265J.setText(str2);
                } else {
                    rippleSearchContentViewHolder.f83265J.setVisibility(8);
                }
                rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity.SSSearchFragment.SkyscapeContentSearchAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        SkyscapeContentSearchAdapter.this.mo4318d0(bundle, i);
                    }
                });
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                ArrayList<Bundle> arrayList = this.f75293e;
                if (arrayList == null || arrayList.size() == 0) {
                    return new MessageViewHolder(this.f75292d, LayoutInflater.from(this.f75292d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
                }
                return new RippleSearchContentViewHolder(LayoutInflater.from(this.f75292d).inflate(C4804R.C4810layout.f87274list_view_item_search_content_ripple, viewGroup, false));
            }

            /* renamed from: d0 */
            public void mo4318d0(Bundle bundle, int i) {
            }

            /* renamed from: e0 */
            public void m4317e0(ArrayList<Bundle> arrayList) {
                this.f75293e = arrayList;
                m42860G();
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                ArrayList<Bundle> arrayList = this.f75293e;
                if (arrayList == null || arrayList.size() == 0) {
                    return 1;
                }
                return this.f75293e.size();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: n3 */
        public Bundle m4320n3(Bundle bundle) {
            String str;
            String str2;
            Bundle bundle2 = new Bundle();
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(bundle.getString("docId"), "|");
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(bundle.getString(HTML.Tag.f65890V), "|");
            for (int i = 0; i < splitByWholeSeparator.length; i++) {
                if (splitByWholeSeparator2.length > i) {
                    str = splitByWholeSeparator[i];
                    str2 = splitByWholeSeparator2[i];
                } else {
                    str = splitByWholeSeparator[i];
                    str2 = "";
                }
                bundle2.putString(str, str2);
            }
            return bundle2;
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4337R2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            CompressHelper compressHelper;
            Bundle bundle2;
            String str;
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4337R2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            this.f75279c4 = (m44859B() == null || !m44859B().containsKey("SelectedItem")) ? null : m44859B().getBundle("SelectedItem");
            if (m44859B() == null || !m44859B().containsKey("Mode")) {
                this.f75278b4 = 0;
            } else {
                this.f75278b4 = m44859B().getInt("Mode");
            }
            ArrayList<Bundle> arrayList = new ArrayList<>();
            int i = this.f75278b4;
            if (i == 0) {
                arrayList = this.f75215L3.m4955V(this.f75212I3, "select * from indexType");
                ArrayList<Bundle> m4955V = this.f75215L3.m4955V(this.f75212I3, "select * from sqlite_master where name='TOC'");
                if (m4955V != null && m4955V.size() != 0) {
                    Bundle bundle3 = new Bundle();
                    bundle3.putString("id", "-1");
                    bundle3.putString("name", "Table Of Contents");
                    arrayList.add(bundle3);
                }
            } else {
                if (i == 1) {
                    compressHelper = this.f75215L3;
                    bundle2 = this.f75212I3;
                    str = "select * from indexes where indexTypeId=" + this.f75279c4.getString("id");
                } else if (i == 2) {
                    compressHelper = this.f75215L3;
                    bundle2 = this.f75212I3;
                    str = "select * from document where id in (" + this.f75279c4.getString("docId").replace("|", ",") + ")";
                }
                arrayList = compressHelper.m4955V(bundle2, str);
            }
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            if (this.f75278b4 == 0) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity.SSSearchFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            this.f75216M3 = new SkyscapeAdapter(m44716w(), arrayList) { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity.SSSearchFragment.2
                @Override // net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity.SSSearchFragment.SkyscapeAdapter
                /* renamed from: d0 */
                public void mo4319d0(Bundle bundle4, int i2) {
                    SSSearchFragment.this.m4330Y2();
                    if (SSSearchFragment.this.f75278b4 == 0) {
                        if (bundle4.getString("id").equals("-1")) {
                            Bundle bundle5 = new Bundle();
                            bundle5.putBundle("DB", SSSearchFragment.this.f75212I3);
                            SSSearchFragment.this.f75215L3.m4979N(SSTocActivity.class, SSTocActivity.SSTocFragment.class, bundle5);
                            return;
                        }
                        Bundle bundle6 = new Bundle();
                        bundle6.putBundle("SelectedItem", bundle4);
                        bundle6.putBundle("DB", SSSearchFragment.this.f75212I3);
                        bundle6.putInt("Mode", 1);
                        SSSearchFragment.this.f75215L3.m4979N(SSSearchActivity.class, SSSearchFragment.class, bundle6);
                    } else if (SSSearchFragment.this.f75278b4 != 1) {
                        if (SSSearchFragment.this.f75278b4 == 2) {
                            SSSearchFragment sSSearchFragment = SSSearchFragment.this;
                            sSSearchFragment.f75215L3.m4883q1(sSSearchFragment.f75212I3, bundle4.getString("id"), null, bundle4.getString("id"));
                        }
                    } else if (!bundle4.getString("docId").contains("|")) {
                        SSSearchFragment sSSearchFragment2 = SSSearchFragment.this;
                        sSSearchFragment2.f75215L3.m4883q1(sSSearchFragment2.f75212I3, bundle4.getString("docId"), null, bundle4.getString(HTML.Tag.f65890V));
                    } else {
                        Bundle m4320n3 = SSSearchFragment.this.m4320n3(bundle4);
                        Bundle bundle7 = new Bundle();
                        bundle7.putBundle("SelectedItem", bundle4);
                        bundle7.putBundle("DB", SSSearchFragment.this.f75212I3);
                        bundle7.putInt("Mode", 2);
                        bundle7.putBundle("GotoSections", m4320n3);
                        SSSearchFragment.this.f75215L3.m4979N(SSSearchActivity.class, SSSearchFragment.class, bundle7);
                    }
                }
            };
            this.f75280d4 = new SkyscapeContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity.SSSearchFragment.3
                @Override // net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity.SSSearchFragment.SkyscapeContentSearchAdapter
                /* renamed from: d0 */
                public void mo4318d0(Bundle bundle4, int i2) {
                    SSSearchFragment.this.m4330Y2();
                    if (SSSearchFragment.this.f75278b4 != 0 && SSSearchFragment.this.f75278b4 != 1) {
                        if (SSSearchFragment.this.f75278b4 == 2) {
                            SSSearchFragment sSSearchFragment = SSSearchFragment.this;
                            sSSearchFragment.f75215L3.m4883q1(sSSearchFragment.f75212I3, bundle4.getString("id"), null, bundle4.getString("id"));
                        }
                    } else if (!bundle4.getString("docId").contains("|")) {
                        SSSearchFragment sSSearchFragment2 = SSSearchFragment.this;
                        sSSearchFragment2.f75215L3.m4883q1(sSSearchFragment2.f75212I3, bundle4.getString("docId"), null, bundle4.getString(HTML.Tag.f65890V));
                    } else {
                        Bundle bundle5 = new Bundle();
                        bundle5.putBundle("SelectedItem", bundle4);
                        bundle5.putBundle("DB", SSSearchFragment.this.f75212I3);
                        bundle5.putInt("Mode", 2);
                        bundle5.putBundle("GotoSections", SSSearchFragment.this.m4320n3(bundle4));
                        SSSearchFragment.this.f75215L3.m4979N(SSSearchActivity.class, SSSearchFragment.class, bundle5);
                    }
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(true);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: a3 */
        public void mo3982a3() {
            this.f75280d4.m4317e0(this.f75219P3);
            this.f75227X3.setAdapter(this.f75280d4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            String str2;
            StringBuilder sb;
            String str3;
            int i = this.f75278b4;
            if (i == 0) {
                sb = new StringBuilder();
                sb.append("Select rowid as _id,Id as docId, indexName as Name,indexType,section  from search where indexName match '");
                sb.append(str);
                str3 = "*'";
            } else if (i == 1) {
                sb = new StringBuilder();
                sb.append("Select rowid as _id,Id as docId, indexName as Name,indexType,section from search where search match 'indexName:");
                sb.append(str);
                sb.append("* AND indexType:");
                sb.append(this.f75279c4.getString("name"));
                str3 = "'";
            } else if (i != 2) {
                str2 = "";
                return this.f75215L3.m4955V(this.f75212I3, str2);
            } else {
                sb = new StringBuilder();
                sb.append("select * from document where id in (");
                sb.append(this.f75279c4.getString("docId").replace("|", ","));
                sb.append(") and lower(title) like '");
                sb.append(str.toLowerCase());
                str3 = "%'";
            }
            sb.append(str3);
            str2 = sb.toString();
            return this.f75215L3.m4955V(this.f75212I3, str2);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new SSSearchFragment());
    }
}
