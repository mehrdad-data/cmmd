package net.imedicaldoctor.imd.Fragments.Skyscape;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Skyscape.SSViewerActivity;

/* loaded from: classes2.dex */
public class SSSectionsViewer extends DialogFragment {

    /* renamed from: g4 */
    private ArrayList<Bundle> f75300g4;

    /* renamed from: h4 */
    private String f75301h4;

    /* renamed from: i4 */
    private String f75302i4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f75300g4 = m44859B().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0);
        this.f75301h4 = m44859B().getString("titleProperty");
        this.f75302i4 = m44859B().getString("sectionProperty");
        new CompressHelper(m44716w());
        if (this.f75300g4 == null) {
            Toast.makeText(m44716w(), "No Section Available", 1).show();
            mo27003Q2();
        } else {
            listView.setAdapter((ListAdapter) new ArrayAdapter<Bundle>(m44716w(), C4804R.C4810layout.f87284list_view_item_simple_text, C4804R.C4808id.text, this.f75300g4) { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSSectionsViewer.1
                @Override // android.widget.ArrayAdapter, android.widget.Adapter
                public View getView(int i, View view, ViewGroup viewGroup) {
                    if (view == null) {
                        view = LayoutInflater.from(SSSectionsViewer.this.m44716w()).inflate(C4804R.C4810layout.f87284list_view_item_simple_text, viewGroup, false);
                        view.setTag(view.findViewById(C4804R.C4808id.text));
                    }
                    ((TextView) view.getTag()).setText(((Bundle) SSSectionsViewer.this.f75300g4.get(i)).getString(SSSectionsViewer.this.f75301h4));
                    return view;
                }
            });
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Skyscape.SSSectionsViewer.2
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    ((SSViewerActivity.SSViewerFragment) SSSectionsViewer.this.m44753k0()).mo4144C3(((Bundle) SSSectionsViewer.this.f75300g4.get(i)).getString(SSSectionsViewer.this.f75302i4));
                    SSSectionsViewer.this.mo27003Q2();
                }
            });
        }
        builder.setView(inflate);
        return builder.create();
    }
}
