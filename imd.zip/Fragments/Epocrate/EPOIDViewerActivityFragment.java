package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import java.io.File;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Lexi.LXSectionsViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class EPOIDViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public ArrayList<Bundle> f74490w4;

    /* renamed from: x4 */
    public int f74491x4;

    /* renamed from: y4 */
    public String f74492y4;

    /* renamed from: z4 */
    public JSONObject f74493z4;

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        String str2;
        String str3;
        String str4;
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        int i = 0;
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        try {
            String str5 = this.f75847Z3;
            if (str5 == null || str5.length() == 0) {
                this.f74491x4 = 0;
                this.f74490w4 = new ArrayList<>();
                iMDLogger.m3294f("Loading Document", this.f75851d4);
                String[] split = this.f75851d4.split("-");
                int i2 = 1;
                String str6 = split[1];
                if (split.length == 3) {
                    this.f74492y4 = split[2];
                }
                ArrayList<Bundle> m4955V = this.f75863p4.m4955V(this.f75850c4, "Select * from id_monographs where id=" + str6);
                if (m4955V != null && m4955V.size() != 0) {
                    Bundle bundle2 = m4955V.get(0);
                    this.f75852e4 = bundle2.getString("title");
                    JSONObject jSONObject = new JSONObject(this.f75863p4.m5015B(bundle2.getString("monograph"), str6, "127")).getJSONObject("content");
                    this.f74493z4 = jSONObject;
                    String[] strArr = {"empiric", "specific", "other"};
                    String str7 = "";
                    if (this.f74492y4 == null) {
                        str2 = "";
                        int i3 = 0;
                        for (int i4 = 3; i3 < i4; i4 = 3) {
                            String replace = this.f75863p4.m4910h1(this.f74493z4.getJSONArray("views"), "id", strArr[i3]).getString("content").replace("<html>", str7).replace("</html>", str7);
                            str2 = str2 + m4590y4(str4, "", "LTR", replace, "", "", "");
                            m4591x4(str3.substring(i, i2).toUpperCase() + str3.substring(i2).toLowerCase(), this.f74491x4);
                            i3++;
                            str7 = str7;
                            i = 0;
                            i2 = 1;
                        }
                        str = str7;
                    } else {
                        str = "";
                        JSONObject m4910h1 = this.f75863p4.m4910h1(jSONObject.getJSONArray("views"), "id", this.f74492y4);
                        str2 = "<div style=\"margin:0px\">" + m4910h1.getString("content") + "</div>";
                    }
                    String m4117W3 = m4117W3(m44716w(), "EPOHeader.css");
                    String m4117W32 = m4117W3(m44716w(), "EPOFooter.css");
                    this.f75847Z3 = m4117W3.replace("[size]", "200").replace("[title]", this.f75852e4).replace("[include]", str) + str2.replace("..", ".") + m4117W32;
                }
                CompressHelper.m4921e2(m44716w(), "Document doesn't exist", 1);
                return this.f75849b4;
            }
            File file = new File(CompressHelper.m4948X0(this.f75850c4));
            this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
            m4092j4();
            m4098g4();
            m4100f3(C4804R.C4811menu.f87323elsviewer2);
            m44735q2(false);
            m4140G3();
        } catch (Exception e) {
            m4080r4(e);
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86776action_menu) {
            LXSectionsViewer lXSectionsViewer = new LXSectionsViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("fields", this.f74490w4);
            lXSectionsViewer.m44751k2(bundle);
            lXSectionsViewer.m44870c3(true);
            lXSectionsViewer.m44844E2(this, 0);
            lXSectionsViewer.mo29915h3(m44820L(), "LXSectionsViewer");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        if (!this.f75863p4.m5016A1(this.f75850c4, str) && str3.contains("//current/")) {
            String str4 = StringUtils.splitByWholeSeparator(str3, "//current/")[1];
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            compressHelper.m4883q1(bundle, this.f75851d4 + "-" + str4, null, null);
        }
        return true;
    }

    /* renamed from: x4 */
    public void m4591x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f74490w4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4590y4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74491x4 + 1;
        this.f74491x4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }
}
