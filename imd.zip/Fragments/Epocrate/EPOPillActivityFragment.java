package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.ObservableEmitter;
import io.reactivex.rxjava3.core.ObservableOnSubscribe;
import io.reactivex.rxjava3.functions.Action;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class EPOPillActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74576b4;

    /* renamed from: c4 */
    public String f74577c4;

    /* renamed from: d4 */
    public Button f74578d4;

    /* renamed from: e4 */
    public String f74579e4;

    /* renamed from: f4 */
    public Bundle f74580f4;

    /* renamed from: g4 */
    public Bundle f74581g4;

    /* renamed from: h4 */
    public Bundle f74582h4;

    /* renamed from: i4 */
    public String f74583i4;

    /* renamed from: j4 */
    public String f74584j4;

    /* renamed from: k4 */
    public String f74585k4;

    /* renamed from: l4 */
    public ArrayList<Bundle> f74586l4;

    /* loaded from: classes2.dex */
    public class InputTextViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74592I;

        /* renamed from: J */
        public EditText f74593J;

        public InputTextViewHolder(View view) {
            super(view);
            this.f74592I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
            this.f74593J = (EditText) view.findViewById(C4804R.C4808id.f87050text_edit);
        }
    }

    /* loaded from: classes2.dex */
    public class PillIDAdapter extends RecyclerView.Adapter {
        public PillIDAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            return i < 2 ? 0 : 1;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            MaterialRippleLayout materialRippleLayout;
            View.OnClickListener onClickListener;
            if (viewHolder.m42556F() == 0) {
                InputTextViewHolder inputTextViewHolder = (InputTextViewHolder) viewHolder;
                inputTextViewHolder.f74593J.setHint("type");
                inputTextViewHolder.f74593J.addTextChangedListener(new TextWatcher() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.PillIDAdapter.1
                    @Override // android.text.TextWatcher
                    public void afterTextChanged(Editable editable) {
                        EPOPillActivityFragment.this.m4571m3();
                    }

                    @Override // android.text.TextWatcher
                    public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                    }

                    @Override // android.text.TextWatcher
                    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                    }
                });
                inputTextViewHolder.f74592I.setText(i == 0 ? "Imprint - Side 1" : "Imprint - Side 2");
                if (i == 0) {
                    inputTextViewHolder.f74593J.addTextChangedListener(new TextWatcher() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.PillIDAdapter.2
                        @Override // android.text.TextWatcher
                        public void afterTextChanged(Editable editable) {
                            EPOPillActivityFragment.this.f74583i4 = editable.toString();
                        }

                        @Override // android.text.TextWatcher
                        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                        }

                        @Override // android.text.TextWatcher
                        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                        }
                    });
                }
                if (i == 1) {
                    inputTextViewHolder.f74593J.addTextChangedListener(new TextWatcher() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.PillIDAdapter.3
                        @Override // android.text.TextWatcher
                        public void afterTextChanged(Editable editable) {
                            EPOPillActivityFragment.this.f74584j4 = editable.toString();
                        }

                        @Override // android.text.TextWatcher
                        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                        }

                        @Override // android.text.TextWatcher
                        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                        }
                    });
                    return;
                }
                return;
            }
            SettingViewHolder settingViewHolder = (SettingViewHolder) viewHolder;
            if (i == 2) {
                settingViewHolder.f74602I.setText("Shape");
                Bundle bundle = EPOPillActivityFragment.this.f74580f4;
                if (bundle == null) {
                    settingViewHolder.f74604K.setText("Any Shape");
                } else {
                    settingViewHolder.f74604K.setText(bundle.getString("STRING_TEXT"));
                }
                materialRippleLayout = settingViewHolder.f74603J;
                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.PillIDAdapter.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPOPillActivityFragment.this.m4568p3("shape");
                    }
                };
            } else if (i == 3) {
                settingViewHolder.f74602I.setText("Color");
                Bundle bundle2 = EPOPillActivityFragment.this.f74581g4;
                if (bundle2 == null) {
                    settingViewHolder.f74604K.setText("Any Color");
                } else {
                    settingViewHolder.f74604K.setText(bundle2.getString("STRING_TEXT"));
                }
                materialRippleLayout = settingViewHolder.f74603J;
                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.PillIDAdapter.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPOPillActivityFragment.this.m4568p3("color");
                    }
                };
            } else if (i != 4) {
                return;
            } else {
                settingViewHolder.f74602I.setText("Score");
                Bundle bundle3 = EPOPillActivityFragment.this.f74582h4;
                if (bundle3 == null) {
                    settingViewHolder.f74604K.setText("Any Score");
                } else {
                    settingViewHolder.f74604K.setText(bundle3.getString("STRING_TEXT"));
                }
                materialRippleLayout = settingViewHolder.f74603J;
                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.PillIDAdapter.6
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPOPillActivityFragment.this.m4568p3(FirebaseAnalytics.Param.f55169D);
                    }
                };
            }
            materialRippleLayout.setOnClickListener(onClickListener);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new InputTextViewHolder(LayoutInflater.from(EPOPillActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87249list_view_item_input_text, viewGroup, false));
            } else if (i == 1) {
                return new SettingViewHolder(LayoutInflater.from(EPOPillActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87298list_view_item_text_setting, viewGroup, false));
            } else {
                return null;
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return 5;
        }
    }

    /* loaded from: classes2.dex */
    public class SettingViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74602I;

        /* renamed from: J */
        public MaterialRippleLayout f74603J;

        /* renamed from: K */
        public TextView f74604K;

        public SettingViewHolder(View view) {
            super(view);
            this.f74602I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
            this.f74604K = (TextView) view.findViewById(C4804R.C4808id.f87034subtext_view);
            this.f74603J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87183fragment_pill_identifier, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f74583i4 = "";
        this.f74584j4 = "";
        this.f74579e4 = "RX.sqlite";
        SearchView searchView = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        this.f75223T3 = searchView;
        if (Build.VERSION.SDK_INT >= 26) {
            searchView.setImportantForAutofill(8);
        }
        this.f75223T3.setVisibility(8);
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f75222S3.setTitle("Pill Identifier");
        ((AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar)).m27445s(true, false);
        ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
        Button button = (Button) this.f75221R3.findViewById(C4804R.C4808id.f87006result_button);
        this.f74578d4 = button;
        button.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Bundle bundle2 = new Bundle();
                bundle2.putString("Query", EPOPillActivityFragment.this.f74585k4);
                EPOPillActivityFragment ePOPillActivityFragment = EPOPillActivityFragment.this;
                ePOPillActivityFragment.f75215L3.m4880r1(ePOPillActivityFragment.f75212I3, "pillid-adf", null, null, bundle2);
            }
        });
        PillIDAdapter pillIDAdapter = new PillIDAdapter();
        this.f75216M3 = pillIDAdapter;
        this.f75227X3.setAdapter(pillIDAdapter);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74576b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74576b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: f3 */
    public void mo4326f3() {
        this.f75224U3.setImageDrawable(m44782a0().getDrawable(C4804R.C4807drawable.f86673pill_id_icon));
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "";
    }

    /* renamed from: l3 */
    public void m4572l3() {
        ArrayList<Bundle> m4949X;
        ArrayList arrayList = new ArrayList();
        String str = this.f74583i4;
        String str2 = this.f74584j4;
        if (str.length() > 0) {
            String m4570n3 = m4570n3(str);
            if (m4570n3 == null) {
                m4949X = new ArrayList<>();
                this.f74586l4 = m4949X;
            }
            arrayList.add("(imprint1_string_id in (" + m4570n3 + ") OR imprint2_string_id in (" + m4570n3 + "))");
        }
        if (str2.length() > 0) {
            String m4570n32 = m4570n3(str2);
            if (m4570n32 == null) {
                m4949X = new ArrayList<>();
                this.f74586l4 = m4949X;
            }
            arrayList.add("(imprint2_string_id in (" + m4570n32 + ") OR imprint1_string_id in (" + m4570n32 + "))");
        }
        Bundle bundle = this.f74580f4;
        if (bundle != null) {
            String string = bundle.getString("ID");
            arrayList.add("shape_string_id=" + string);
        }
        Bundle bundle2 = this.f74582h4;
        if (bundle2 != null) {
            String string2 = bundle2.getString("ID");
            arrayList.add("score_string_id=" + string2);
        }
        Bundle bundle3 = this.f74581g4;
        if (bundle3 != null) {
            String string3 = bundle3.getString("ID");
            arrayList.add("color_string_id=" + string3);
        }
        String join = StringUtils.join(arrayList, " AND ");
        this.f74585k4 = join;
        m4949X = this.f75215L3.m4949X(this.f75212I3, "Select id from pill_pictures where " + join, this.f74579e4, true);
        this.f74586l4 = m4949X;
    }

    /* renamed from: m3 */
    public void m4571m3() {
        Observable.m7156x1(new ObservableOnSubscribe<String>() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.2
            @Override // io.reactivex.rxjava3.core.ObservableOnSubscribe
            /* renamed from: a */
            public void mo3518a(@NonNull ObservableEmitter<String> observableEmitter) throws Throwable {
                EPOPillActivityFragment.this.m4572l3();
                observableEmitter.onNext("asdf");
            }
        }).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7319g6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.3
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(String str) throws Throwable {
                if (EPOPillActivityFragment.this.f74586l4.size() == 0) {
                    EPOPillActivityFragment.this.f74578d4.setEnabled(false);
                    EPOPillActivityFragment.this.f74578d4.setBackgroundColor(Color.rgb(100, 100, 100));
                    EPOPillActivityFragment.this.f74578d4.setText("Nothing Found");
                    return;
                }
                Button button = EPOPillActivityFragment.this.f74578d4;
                button.setText(EPOPillActivityFragment.this.f74586l4.size() + " Drugs Found");
                EPOPillActivityFragment.this.f74578d4.setEnabled(true);
                EPOPillActivityFragment.this.f74578d4.setBackgroundColor(Color.rgb(64, 140, 83));
            }
        }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.4
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(Throwable th) throws Throwable {
            }
        }, new Action() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillActivityFragment.5
            @Override // io.reactivex.rxjava3.functions.Action
            public void run() throws Throwable {
            }
        });
    }

    /* renamed from: n3 */
    public String m4570n3(String str) {
        if (str == null || str.length() == 0) {
            return null;
        }
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4952W(bundle, "select  group_concat(id) as ids from imprint_strings where string_text like '%" + str + "%'", this.f74579e4));
        if (m4907i1 == null) {
            return null;
        }
        String string = m4907i1.getString("ids");
        if (string.length() == 0) {
            return null;
        }
        return string;
    }

    /* renamed from: o3 */
    public void m4569o3(String str, Bundle bundle) {
        if (str.equals("shape")) {
            this.f74580f4 = bundle;
        }
        if (str.equals("color")) {
            this.f74581g4 = bundle;
        }
        if (str.equals(FirebaseAnalytics.Param.f55169D)) {
            this.f74582h4 = bundle;
        }
        this.f75227X3.setAdapter(this.f75216M3);
        m4571m3();
    }

    /* renamed from: p3 */
    public void m4568p3(String str) {
        Bundle bundle;
        Bundle bundle2;
        Bundle bundle3;
        m4330Y2();
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle4 = this.f75212I3;
        ArrayList<Bundle> m4949X = compressHelper.m4949X(bundle4, "select * from " + str + "_strings", this.f74579e4, true);
        String string = (!str.equals("shape") || (bundle3 = this.f74580f4) == null) ? "" : bundle3.getString("ID");
        if (str.equals(FirebaseAnalytics.Param.f55169D) && (bundle2 = this.f74582h4) != null) {
            string = bundle2.getString("ID");
        }
        if (str.equals("color") && (bundle = this.f74581g4) != null) {
            string = bundle.getString("ID");
        }
        if (string.length() == 0) {
            string = "-1";
        }
        EPOPillSelectDialog ePOPillSelectDialog = new EPOPillSelectDialog();
        Bundle bundle5 = new Bundle();
        bundle5.putParcelableArrayList("Items", m4949X);
        bundle5.putString("Category", str);
        bundle5.putString("Selected", string);
        ePOPillSelectDialog.m44751k2(bundle5);
        ePOPillSelectDialog.m44870c3(true);
        ePOPillSelectDialog.m44844E2(this, 0);
        ePOPillSelectDialog.mo29915h3(m44820L(), "EPOPillSelectDialog");
    }
}
