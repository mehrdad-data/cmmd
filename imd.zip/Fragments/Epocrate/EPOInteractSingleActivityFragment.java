package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersDecoration;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.StickySectionAdapter;

/* loaded from: classes2.dex */
public class EPOInteractSingleActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public String f74528A4;

    /* renamed from: B4 */
    public String f74529B4;

    /* renamed from: C4 */
    public String f74530C4;

    /* renamed from: D4 */
    private StickyRecyclerHeadersDecoration f74531D4;

    /* renamed from: E4 */
    public OverviewAdapter f74532E4;

    /* renamed from: F4 */
    public StickySectionAdapter f74533F4;

    /* renamed from: G4 */
    public StickySectionAdapter f74534G4;

    /* renamed from: w4 */
    public RecyclerView f74535w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f74536x4;

    /* renamed from: y4 */
    public TabLayout f74537y4;

    /* renamed from: z4 */
    public String f74538z4;

    /* loaded from: classes2.dex */
    public class OverviewAdapter extends RecyclerView.Adapter {
        public OverviewAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            ((TextViewHolder) viewHolder).f74543I.setText(Html.fromHtml(EPOInteractSingleActivityFragment.this.f74530C4));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            View inflate = LayoutInflater.from(EPOInteractSingleActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87297list_view_item_text, viewGroup, false);
            EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment = EPOInteractSingleActivityFragment.this;
            return new TextViewHolder(ePOInteractSingleActivityFragment.m44716w(), inflate);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return 1;
        }
    }

    /* loaded from: classes2.dex */
    public class TextViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74543I;

        public TextViewHolder(Context context, View view) {
            super(view);
            this.f74543I = (TextView) view.findViewById(C4804R.C4808id.text);
            this.f74543I.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/HelveticaNeue-Light.otf"));
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String string;
        Iterator<Bundle> it2;
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87150fragment_epointeract_single, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74535w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        this.f74529B4 = "RX.sqlite";
        this.f74537y4 = (TabLayout) this.f75849b4.findViewById(C4804R.C4808id.f87042tabs);
        String[] strArr = {"Overview", "By Category", "By Drug"};
        for (int i = 0; i < 3; i++) {
            TabLayout.Tab m24950D = this.f74537y4.m24950D();
            m24950D.m24890D(strArr[i]);
            this.f74537y4.m24926e(m24950D);
        }
        this.f74537y4.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractSingleActivityFragment.1
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: a */
            public void mo4174a(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: b */
            public void mo4173b(TabLayout.Tab tab) {
                RecyclerView recyclerView;
                RecyclerView.Adapter adapter;
                int selectedTabPosition = EPOInteractSingleActivityFragment.this.f74537y4.getSelectedTabPosition();
                if (selectedTabPosition == 0) {
                    if (EPOInteractSingleActivityFragment.this.f74531D4 != null) {
                        EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment = EPOInteractSingleActivityFragment.this;
                        ePOInteractSingleActivityFragment.f74535w4.m42906s1(ePOInteractSingleActivityFragment.f74531D4);
                        EPOInteractSingleActivityFragment.this.f74531D4.m8633n();
                        EPOInteractSingleActivityFragment.this.f74531D4 = null;
                    }
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment2 = EPOInteractSingleActivityFragment.this;
                    recyclerView = ePOInteractSingleActivityFragment2.f74535w4;
                    adapter = ePOInteractSingleActivityFragment2.f74532E4;
                } else if (selectedTabPosition == 1) {
                    if (EPOInteractSingleActivityFragment.this.f74531D4 != null) {
                        EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment3 = EPOInteractSingleActivityFragment.this;
                        ePOInteractSingleActivityFragment3.f74535w4.m42906s1(ePOInteractSingleActivityFragment3.f74531D4);
                        EPOInteractSingleActivityFragment.this.f74531D4.m8633n();
                        EPOInteractSingleActivityFragment.this.f74531D4 = null;
                    }
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment4 = EPOInteractSingleActivityFragment.this;
                    ePOInteractSingleActivityFragment4.f74531D4 = new StickyRecyclerHeadersDecoration(ePOInteractSingleActivityFragment4.f74533F4);
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment5 = EPOInteractSingleActivityFragment.this;
                    ePOInteractSingleActivityFragment5.f74535w4.m42923n(ePOInteractSingleActivityFragment5.f74531D4);
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment6 = EPOInteractSingleActivityFragment.this;
                    recyclerView = ePOInteractSingleActivityFragment6.f74535w4;
                    adapter = ePOInteractSingleActivityFragment6.f74533F4;
                } else if (selectedTabPosition != 2) {
                    return;
                } else {
                    if (EPOInteractSingleActivityFragment.this.f74531D4 != null) {
                        EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment7 = EPOInteractSingleActivityFragment.this;
                        ePOInteractSingleActivityFragment7.f74535w4.m42906s1(ePOInteractSingleActivityFragment7.f74531D4);
                        EPOInteractSingleActivityFragment.this.f74531D4.m8633n();
                        EPOInteractSingleActivityFragment.this.f74531D4 = null;
                    }
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment8 = EPOInteractSingleActivityFragment.this;
                    ePOInteractSingleActivityFragment8.f74531D4 = new StickyRecyclerHeadersDecoration(ePOInteractSingleActivityFragment8.f74534G4);
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment9 = EPOInteractSingleActivityFragment.this;
                    ePOInteractSingleActivityFragment9.f74535w4.m42923n(ePOInteractSingleActivityFragment9.f74531D4);
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment10 = EPOInteractSingleActivityFragment.this;
                    recyclerView = ePOInteractSingleActivityFragment10.f74535w4;
                    adapter = ePOInteractSingleActivityFragment10.f74534G4;
                }
                recyclerView.setAdapter(adapter);
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: c */
            public void mo4172c(TabLayout.Tab tab) {
            }
        });
        String str = this.f75851d4.split("-")[1];
        this.f74538z4 = str;
        ArrayList<Bundle> m4949X = this.f75863p4.m4949X(this.f75850c4, "Select * from drug where ID=" + str, this.f74529B4, true);
        if (m4949X == null || m4949X.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "Sorry, Drug can't be found", 1);
        } else {
            Bundle bundle2 = m4949X.get(0);
            this.f74536x4 = this.f75863p4.m4949X(this.f75850c4, "Select * from pill_pictures where drug_id=" + str, this.f74529B4, true);
            if (bundle2.getString("GENERIC_ID").length() == 0 || bundle2.getString("GENERIC_ID").equals("0")) {
                string = bundle2.getString("ID");
                bundle2.getString("NAME");
            } else {
                string = bundle2.getString("GENERIC_ID");
                try {
                    CompressHelper compressHelper = this.f75863p4;
                    compressHelper.m4907i1(compressHelper.m4949X(this.f75850c4, "SELECT  DRUG.ID ,  DRUG.CLINICAL_ID ,  DRUG.GENERIC_ID ,  DRUG.NAME ,  DRUG.DRUG_TYPE ,  DRUG.ACTIVE ,  DRUG.ADULT_DSG_ID ,  DRUG.PEDS_DSG_ID ,  DRUG.MFR_STRING_ID ,  DRUG.BBW_ID   FROM DRUG   WHERE  ID =  " + str, this.f74529B4, true)).getString("NAME");
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    e.printStackTrace();
                }
            }
            this.f75852e4 = bundle2.getString("NAME");
            this.f74528A4 = string;
            CompressHelper compressHelper2 = this.f75863p4;
            Bundle m4907i1 = compressHelper2.m4907i1(compressHelper2.m4952W(this.f75850c4, "SELECT  DDI_GROUP.ID ,  DDI_GROUP.NAME ,  DDI_GROUP.PHARMACOLOGIC_CLASS_ID                      FROM DDI_GROUP                     JOIN DRUG_TO_DDI_GROUP ON DDI_GROUP.ID = DRUG_TO_DDI_GROUP.GROUP_ID                     WHERE DRUG_TO_DDI_GROUP.DRUG_ID=" + string, this.f74529B4));
            String string2 = m4907i1.getString("ID");
            String string3 = m4907i1.getString("NAME");
            ArrayList<Bundle> m4949X2 = this.f75863p4.m4949X(this.f75850c4, "SELECT  CHARACTERISTIC.ID ,  CHARACTERISTIC.NAME                             FROM INGREDIENT_CHARACTERISTIC                            JOIN CHARACTERISTIC ON INGREDIENT_CHARACTERISTIC.CHARACTERISTIC_ID = CHARACTERISTIC.ID                            WHERE INGREDIENT_CHARACTERISTIC.INGREDIENT_ID = " + string2 + "                            ORDER BY INGREDIENT_CHARACTERISTIC.DISPLAY_ORDER", this.f74529B4, true);
            String str2 = "<div><font color=\"#009900\"><b>" + string3 + "</b></font></div>Interaction Characteristics : <br/>";
            while (m4949X2.iterator().hasNext()) {
                str2 = str2 + "<br/>   • " + it2.next().getString("NAME");
            }
            this.f74530C4 = str2;
            if (m4949X2.size() == 0) {
                this.f74530C4 = "<b>No Information<b>";
            }
            this.f74532E4 = new OverviewAdapter();
            this.f74533F4 = new StickySectionAdapter(m44716w(), this.f75863p4.m4941Z1(this.f75863p4.m4949X(this.f75850c4, "SELECT                     DDI.ID AS DDI_ID,                    DRUG_TO_DDI_GROUP.GROUP_ID AS GROUP_0_ID,                    CASE WHEN DDI.GROUP_0_ID = DRUG_TO_DDI_GROUP.GROUP_ID THEN DDI.GROUP_1_ID ELSE DDI.GROUP_0_ID END AS GROUP_1_ID,                    DDI_GROUP.NAME AS GROUP_1_NAME,                    DDI.CATEGORY_ID,                    DDI.ACTION_STRING_ID,                    DDI.EFFECT_STRING_ID,                    DDI.MECHANISM_STRING_ID,                    (select name from ddi_category where ddi_category.id=ddi.category_id) as CATEGORY,                     (select name from ddi_group where ddi_group.id=DRUG_TO_DDI_GROUP.GROUP_ID) as GROUP_0_NAME,                     (select string from general_string where general_string.id=ddi.action_string_id) as ACTION_STRING,                     (select string from general_string where general_string.id=ddi.effect_string_id) as EFFECT_STRING,                     (select string from general_string where general_string.id=ddi.mechanism_string_id) as MECHANISM_STRING                     FROM DRUG                     JOIN DRUG_TO_DDI_GROUP ON DRUG_TO_DDI_GROUP.DRUG_ID = DRUG.ID                     JOIN DDI ON DDI.GROUP_0_ID = DRUG_TO_DDI_GROUP.GROUP_ID OR DDI.GROUP_1_ID = DRUG_TO_DDI_GROUP.GROUP_ID                     JOIN DDI_GROUP ON DDI_GROUP.ID = CASE WHEN DDI.GROUP_0_ID = DRUG_TO_DDI_GROUP.GROUP_ID THEN DDI.GROUP_1_ID ELSE DDI.GROUP_0_ID END                    WHERE DRUG.ID = " + string + "                    ORDER BY CATEGORY_ID, GROUP_1_NAME, GROUP_0_NAME", this.f74529B4, true), "CATEGORY_ID"), "GROUP_1_NAME") { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractSingleActivityFragment.2
                @Override // net.imedicaldoctor.imd.ViewHolders.StickySectionAdapter
                /* renamed from: h0 */
                public void mo3371h0(Bundle bundle3, int i2) {
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment = EPOInteractSingleActivityFragment.this;
                    CompressHelper compressHelper3 = ePOInteractSingleActivityFragment.f75863p4;
                    Bundle bundle4 = ePOInteractSingleActivityFragment.f75850c4;
                    compressHelper3.m4883q1(bundle4, "interactview-" + bundle3.getString("DDI_ID"), null, null);
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.StickySectionAdapter
                /* renamed from: j0 */
                public String mo3369j0(String str3) {
                    return str3.equals("5") ? "Caution Advised" : str3.equals("4") ? "Therapeutic Advantage" : str3.equals(ExifInterface.f14411T4) ? "Monitor / Modify Tx" : str3.equals(ExifInterface.f14403S4) ? "Avoid / Use Alternative" : str3.equals(IcyHeaders.f35463C2) ? "Contraindicated" : str3;
                }
            };
            this.f74534G4 = new StickySectionAdapter(m44716w(), this.f75863p4.m4937a2(this.f75863p4.m4949X(this.f75850c4, "SELECT DISTINCT                            DRUG.ID,                           DRUG.CLINICAL_ID,                           DRUG.GENERIC_ID,                           DRUG.NAME,                           DRUG.DRUG_TYPE,                           DRUG.ACTIVE,                           DRUG.ADULT_DSG_ID,                           DRUG.PEDS_DSG_ID,                           DRUG.MFR_STRING_ID,                           DRUG.BBW_ID                           FROM DRUG_TO_INTERACTING_DRUG                           JOIN DRUG ON (                            DRUG.ID = CASE WHEN DRUG_TO_INTERACTING_DRUG.DRUG_0_ID = " + string + " THEN DRUG_TO_INTERACTING_DRUG.DRUG_1_ID ELSE DRUG_TO_INTERACTING_DRUG.DRUG_0_ID END  or                            DRUG.GENERIC_ID = CASE WHEN DRUG_TO_INTERACTING_DRUG.DRUG_0_ID = " + string + " THEN DRUG_TO_INTERACTING_DRUG.DRUG_1_ID ELSE DRUG_TO_INTERACTING_DRUG.DRUG_0_ID END                            )                            WHERE                            DRUG_TO_INTERACTING_DRUG.DRUG_1_ID = " + string + " OR                           DRUG_TO_INTERACTING_DRUG.DRUG_0_ID = " + string + "                           ORDER BY DRUG.NAME", this.f74529B4, true), "NAME"), "NAME") { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractSingleActivityFragment.3
                @Override // net.imedicaldoctor.imd.ViewHolders.StickySectionAdapter
                /* renamed from: h0 */
                public void mo3371h0(Bundle bundle3, int i2) {
                    String string4 = bundle3.getString("ID");
                    if (bundle3.getString("GENERIC_ID").length() > 0 && !bundle3.getString("GENERIC_ID").equals("0")) {
                        string4 = bundle3.getString("GENERIC_ID");
                    }
                    EPOInteractSingleActivityFragment ePOInteractSingleActivityFragment = EPOInteractSingleActivityFragment.this;
                    CompressHelper compressHelper3 = ePOInteractSingleActivityFragment.f75863p4;
                    Bundle bundle4 = ePOInteractSingleActivityFragment.f75850c4;
                    compressHelper3.m4883q1(bundle4, "interactview-" + EPOInteractSingleActivityFragment.this.f74528A4 + "-" + string4, null, null);
                }
            };
            this.f74535w4.setAdapter(this.f74532E4);
            m4582z4();
            m4100f3(C4804R.C4811menu.f87326favorite);
            m44735q2(false);
            m4140G3();
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f74536x4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f74536x4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    /* renamed from: z4 */
    public void m4582z4() {
        this.f74535w4.setItemAnimator(new DefaultItemAnimator());
        this.f74535w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f74535w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }
}
