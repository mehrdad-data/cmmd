package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.StickySectionAdapter;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class EPOIDListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74483b4;

    /* renamed from: c4 */
    public String f74484c4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RecyclerView.Adapter adapter;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            this.f74484c4 = null;
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
        } else {
            this.f74484c4 = m44859B().getString("ParentId");
            appBarLayout.m27445s(false, false);
            appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOIDListActivityFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    relativeLayout.setVisibility(0);
                }
            }, 800L);
        }
        String str = this.f74484c4;
        if (str == null) {
            this.f75218O3 = this.f75215L3.m4955V(this.f75212I3, "Select * from id_locations");
            adapter = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOIDListActivityFragment.2
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: f0 */
                public void mo3405f0(Bundle bundle2, int i) {
                    EPOIDListActivityFragment.this.m4593l3(bundle2, i);
                }
            };
        } else {
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str, ",,,,,");
            String valueOf = String.valueOf(Integer.valueOf(splitByWholeSeparator[0]).intValue() + 1);
            String str2 = splitByWholeSeparator[1];
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle2 = this.f75212I3;
            ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "select * from id_cats_indications inner join id_indications on id_indications.id=id_cats_indications.indicationId where id_indications.source=" + valueOf + " and id_cats_indications.source=" + valueOf + " and catId=" + str2);
            this.f75218O3 = m4955V;
            adapter = new StickySectionAdapter(m44716w(), m4592m3(m4955V), "title", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOIDListActivityFragment.3
                @Override // net.imedicaldoctor.imd.ViewHolders.StickySectionAdapter
                /* renamed from: h0 */
                public void mo3371h0(Bundle bundle3, int i) {
                    EPOIDListActivityFragment.this.m4593l3(bundle3, i);
                }
            };
        }
        this.f75216M3 = adapter;
        this.f74483b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOIDListActivityFragment.4
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: g0 */
            public void mo3380g0(Bundle bundle3, int i) {
                EPOIDListActivityFragment.this.m4330Y2();
                EPOIDListActivityFragment ePOIDListActivityFragment = EPOIDListActivityFragment.this;
                CompressHelper compressHelper2 = ePOIDListActivityFragment.f75215L3;
                Bundle bundle4 = ePOIDListActivityFragment.f75212I3;
                compressHelper2.m4883q1(bundle4, "id-" + bundle3.getString("contentId"), null, null);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle3) {
                EPOIDListActivityFragment.this.m4330Y2();
                EPOIDListActivityFragment.this.f75223T3.m51655i0(bundle3.getString("word"), true);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74483b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74483b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match 'text:" + str + "* AND typeText:ID AND type:1'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: f3 */
    public void mo4326f3() {
        this.f75224U3.setImageDrawable(m44782a0().getDrawable(C4804R.C4807drawable.f86605id_tx_icon));
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "Infectious Disease Treatment";
    }

    /* renamed from: l3 */
    public void m4593l3(Bundle bundle, int i) {
        m4330Y2();
        String string = bundle.getString("type");
        if (string.equals(ExifInterface.f14403S4)) {
            Bundle bundle2 = new Bundle();
            bundle2.putBundle("DB", this.f75212I3);
            bundle2.putString("ParentId", bundle.getString("source") + ",,,,," + bundle.getString("id2"));
            this.f75215L3.m4979N(EPOIDListActivity.class, EPOIDListActivityFragment.class, bundle2);
        } else if (string.equals(ExifInterface.f14411T4)) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle3 = this.f75212I3;
            compressHelper.m4883q1(bundle3, "id-" + bundle.getString("id2"), null, null);
        }
    }

    /* renamed from: m3 */
    public ArrayList<Bundle> m4592m3(ArrayList<Bundle> arrayList) {
        ArrayList<Bundle> arrayList2 = new ArrayList<>();
        ArrayList<? extends Parcelable> arrayList3 = new ArrayList<>();
        Iterator<Bundle> it2 = arrayList.iterator();
        String str = "";
        while (it2.hasNext()) {
            Bundle next = it2.next();
            String string = next.getString("type");
            String string2 = next.getString("title");
            if (string.equals(IcyHeaders.f35463C2)) {
                arrayList3 = new ArrayList<>();
                str = string2;
            } else if (string.equals("0")) {
                Bundle bundle = new Bundle();
                bundle.putString("title", str);
                bundle.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, arrayList3);
                arrayList2.add(bundle);
            } else {
                arrayList3.add(next);
            }
        }
        if (arrayList3.size() > 0) {
            Bundle bundle2 = new Bundle();
            bundle2.putString("title", str);
            bundle2.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, arrayList3);
            arrayList2.add(bundle2);
        }
        return arrayList2;
    }
}
