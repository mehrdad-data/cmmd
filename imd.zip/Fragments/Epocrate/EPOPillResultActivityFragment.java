package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextImageViewHolder;

/* loaded from: classes2.dex */
public class EPOPillResultActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public ArrayList<Bundle> f74606w4;

    /* renamed from: x4 */
    public RecyclerView f74607x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f74608y4;

    /* renamed from: z4 */
    public ChaptersAdapter f74609z4;

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: z4 */
    public void m4563z4(int i) {
        ArrayList<Bundle> arrayList = this.f74608y4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", this.f74608y4);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74607x4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        String string = m44859B().getString("Query");
        CompressHelper compressHelper = this.f75863p4;
        Bundle bundle2 = this.f75850c4;
        this.f74606w4 = compressHelper.m4949X(bundle2, "select drug.name as drugName, genericname_strings.string_text as genericName, formulation_strings.string_text,pill_pictures.filename from (( pill_pictures inner join genericname_strings on genericname_strings.id=pill_pictures.genericname_string_id) inner join drug on drug.id=pill_pictures.drug_id) inner join formulation_strings on formulation_strings.id=pill_pictures.formulation_string_id where " + string + " order by drugName collate nocase asc", "RX.sqlite", true);
        this.f75852e4 = "Found " + this.f74606w4.size() + " Drugs";
        this.f74608y4 = new ArrayList<>();
        Iterator<Bundle> it2 = this.f74606w4.iterator();
        while (it2.hasNext()) {
            Bundle next = it2.next();
            Bundle bundle3 = new Bundle();
            bundle3.putString("ImagePath", "http://www.epocrates.com/pillimages/" + next.getString("FILENAME") + ".jpg");
            bundle3.putString("DescriptionHTML", "<font color=\"#000099\"><b>" + next.getString("drugName") + "</b></font><br/>" + next.getString("genericName") + "<br/>" + next.getString("STRING_TEXT"));
            this.f74608y4.add(bundle3);
        }
        ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f74606w4, "", C4804R.C4810layout.f87252list_view_item_pill_image) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillResultActivityFragment.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, Bundle bundle4, final int i) {
                RippleTextImageViewHolder rippleTextImageViewHolder = (RippleTextImageViewHolder) viewHolder;
                Bundle bundle5 = EPOPillResultActivityFragment.this.f74606w4.get(i);
                rippleTextImageViewHolder.f83297I.setText(Html.fromHtml("<font color=\"#000099\"><b>" + bundle5.getString("drugName") + "</b></font><br/>" + bundle5.getString("genericName") + "<br/>" + bundle5.getString("STRING_TEXT")));
                RequestManager m40315G = Glide.m40315G(EPOPillResultActivityFragment.this.m44716w());
                StringBuilder sb = new StringBuilder();
                sb.append("http://www.epocrates.com/pillimages/");
                sb.append(bundle5.getString("FILENAME"));
                sb.append("_thumb.jpg");
                m40315G.mo40145t(sb.toString()).m40191t2(rippleTextImageViewHolder.f83298J);
                rippleTextImageViewHolder.f83299K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillResultActivityFragment.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        EPOPillResultActivityFragment.this.m4563z4(i);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view2) {
                return new RippleTextImageViewHolder(view2);
            }
        };
        this.f74609z4 = chaptersAdapter;
        this.f74607x4.setAdapter(chaptersAdapter);
        m4564y4();
        m4100f3(C4804R.C4811menu.f87324empty);
        m44735q2(false);
        m4140G3();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f74606w4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f74606w4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    /* renamed from: y4 */
    public void m4564y4() {
        this.f74607x4.setItemAnimator(new DefaultItemAnimator());
        this.f74607x4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f74607x4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }
}
