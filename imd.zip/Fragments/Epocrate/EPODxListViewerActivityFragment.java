package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.ViewHolders.RippleTextImageArrowViewHolder;
import net.imedicaldoctor.imd.iMDLogger;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class EPODxListViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public ArrayList<Bundle> f74448A4;

    /* renamed from: B4 */
    public String f74449B4;

    /* renamed from: C4 */
    public String f74450C4;

    /* renamed from: w4 */
    public JSONObject f74451w4;

    /* renamed from: x4 */
    public String f74452x4;

    /* renamed from: y4 */
    public RecyclerView f74453y4;

    /* renamed from: z4 */
    public JSONObject f74454z4;

    /* loaded from: classes2.dex */
    public class EpocrateAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        public ArrayList<Bundle> f74455d;

        /* renamed from: e */
        public String f74456e;

        /* renamed from: f */
        public int f74457f;

        public EpocrateAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            return EPODxListViewerActivityFragment.this.m4605x4(i).containsKey("Title") ? 1 : 0;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            if (viewHolder.m42556F() != 0) {
                if (viewHolder.m42556F() == 1) {
                    ((HeaderCellViewHolder) viewHolder).f74465I.setText(EPODxListViewerActivityFragment.this.m4605x4(i).getString("Title"));
                    return;
                }
                return;
            }
            RippleTextImageArrowViewHolder rippleTextImageArrowViewHolder = (RippleTextImageArrowViewHolder) viewHolder;
            final Bundle bundle = EPODxListViewerActivityFragment.this.m4605x4(i).getBundle("Item");
            if (bundle.containsKey(TypedValues.Attributes.f5596M)) {
                rippleTextImageArrowViewHolder.f83293I.setText(bundle.getString("title"));
                rippleTextImageArrowViewHolder.f83294J.setVisibility(8);
                rippleTextImageArrowViewHolder.f83295K.setVisibility(0);
                rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPODxListViewerActivityFragment.EpocrateAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        try {
                            EPODxListViewerActivityFragment ePODxListViewerActivityFragment = EPODxListViewerActivityFragment.this;
                            JSONObject m4910h1 = ePODxListViewerActivityFragment.f75863p4.m4910h1(ePODxListViewerActivityFragment.f74451w4.getJSONArray("views"), "id", bundle.getString(TypedValues.Attributes.f5596M));
                            if (!m4910h1.getString("type").equals("web")) {
                                Bundle bundle2 = new Bundle();
                                bundle2.putBundle("DB", EPODxListViewerActivityFragment.this.f75850c4);
                                bundle2.putString("ViewId", bundle.getString(TypedValues.Attributes.f5596M));
                                bundle2.putString("mDB", EPODxListViewerActivityFragment.this.f74449B4);
                                bundle2.putString("URL", EPODxListViewerActivityFragment.this.f75851d4);
                                EPODxListViewerActivityFragment.this.f75863p4.m4979N(EPODxListViewerActivity.class, EPODxListViewerActivityFragment.class, bundle2);
                                return;
                            }
                            String string = m4910h1.getString(HTML.Tag.f65946y);
                            Bundle bundle3 = new Bundle();
                            bundle3.putString("Title", m4910h1.getString("title"));
                            bundle3.putString("Html", string);
                            bundle3.putString("DocAddress", EPODxListViewerActivityFragment.this.f75851d4);
                            bundle3.putString("mDB", EPODxListViewerActivityFragment.this.f74449B4);
                            bundle3.putParcelableArrayList("Images", EPODxListViewerActivityFragment.this.f74448A4);
                            EPODxListViewerActivityFragment ePODxListViewerActivityFragment2 = EPODxListViewerActivityFragment.this;
                            CompressHelper compressHelper = ePODxListViewerActivityFragment2.f75863p4;
                            Bundle bundle4 = ePODxListViewerActivityFragment2.f75850c4;
                            compressHelper.m4880r1(bundle4, "web-" + EPODxListViewerActivityFragment.this.f75851d4, null, null, bundle3);
                        } catch (Exception e) {
                            FirebaseCrashlytics.m18030d().m18027g(e);
                            e.printStackTrace();
                        }
                    }
                });
            } else if (bundle.containsKey("targetHTML")) {
                rippleTextImageArrowViewHolder.f83293I.setText(bundle.getString("title"));
                rippleTextImageArrowViewHolder.f83294J.setVisibility(8);
                rippleTextImageArrowViewHolder.f83295K.setVisibility(0);
                rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPODxListViewerActivityFragment.EpocrateAdapter.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        String string = bundle.getString("targetHTML");
                        Bundle bundle2 = new Bundle();
                        bundle2.putString("Title", bundle.getString("title"));
                        bundle2.putString("Html", string);
                        bundle2.putString("DocAddress", EPODxListViewerActivityFragment.this.f75851d4);
                        bundle2.putParcelableArrayList("Images", EPODxListViewerActivityFragment.this.f74448A4);
                        EPODxListViewerActivityFragment ePODxListViewerActivityFragment = EPODxListViewerActivityFragment.this;
                        CompressHelper compressHelper = ePODxListViewerActivityFragment.f75863p4;
                        Bundle bundle3 = ePODxListViewerActivityFragment.f75850c4;
                        compressHelper.m4880r1(bundle3, "web-" + EPODxListViewerActivityFragment.this.f75851d4, null, null, bundle2);
                    }
                });
            } else if (bundle.containsKey("targetURL")) {
                rippleTextImageArrowViewHolder.f83293I.setText(bundle.getString("title"));
                String string = bundle.getString("targetURL");
                String str = string.contains("rx/monograph/") ? "plus_rx.png" : string.contains("dx/monograph/") ? "plus_dx.png" : string.contains("lab/monograph/") ? "plus_lab.png" : string.contains("lab/list/panel/") ? "plus_panel.png" : "";
                rippleTextImageArrowViewHolder.f83294J.setVisibility(0);
                ImageView imageView = rippleTextImageArrowViewHolder.f83294J;
                EPODxListViewerActivityFragment ePODxListViewerActivityFragment = EPODxListViewerActivityFragment.this;
                imageView.setImageBitmap(ePODxListViewerActivityFragment.m4609A4(ePODxListViewerActivityFragment.m44716w(), str));
                rippleTextImageArrowViewHolder.f83295K.setVisibility(0);
                rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPODxListViewerActivityFragment.EpocrateAdapter.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        String string2 = bundle.getString("targetURL");
                        EPODxListViewerActivityFragment ePODxListViewerActivityFragment2 = EPODxListViewerActivityFragment.this;
                        ePODxListViewerActivityFragment2.f75863p4.m5016A1(ePODxListViewerActivityFragment2.f75850c4, string2);
                    }
                });
            } else if (!bundle.containsKey("flag")) {
                rippleTextImageArrowViewHolder.f83293I.setText("title");
                rippleTextImageArrowViewHolder.f83294J.setVisibility(8);
                rippleTextImageArrowViewHolder.f83295K.setVisibility(8);
            } else {
                rippleTextImageArrowViewHolder.f83293I.setText(bundle.getString("title"));
                rippleTextImageArrowViewHolder.f83294J.setVisibility(0);
                ImageView imageView2 = rippleTextImageArrowViewHolder.f83294J;
                EPODxListViewerActivityFragment ePODxListViewerActivityFragment2 = EPODxListViewerActivityFragment.this;
                FragmentActivity m44716w = ePODxListViewerActivityFragment2.m44716w();
                imageView2.setImageBitmap(ePODxListViewerActivityFragment2.m4609A4(m44716w, "orb" + bundle.getString("flag") + ".png"));
                rippleTextImageArrowViewHolder.f83295K.setVisibility(0);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new RippleTextImageArrowViewHolder(LayoutInflater.from(EPODxListViewerActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87269list_view_item_ripple_text_image_arrow, viewGroup, false));
            }
            if (i == 1) {
                return new HeaderCellViewHolder(LayoutInflater.from(EPODxListViewerActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87238list_view_item_dx_list_header, viewGroup, false));
            }
            return null;
        }

        /* renamed from: d0 */
        public String m4602d0(String str) {
            return str;
        }

        /* renamed from: e0 */
        public void m4601e0(Bundle bundle, int i) {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return EPODxListViewerActivityFragment.this.m4606D4();
        }
    }

    /* loaded from: classes2.dex */
    public static class HeaderCellViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74465I;

        public HeaderCellViewHolder(View view) {
            super(view);
            this.f74465I = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
        }
    }

    /* renamed from: C4 */
    private void m4607C4(String str) {
        ArrayList<Bundle> arrayList = this.f74448A4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        arrayList2.addAll(this.f74448A4);
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (((Bundle) arrayList2.get(i2)).getString("id").startsWith(str)) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public Bitmap m4609A4(Context context, String str) {
        InputStream inputStream;
        InputStream inputStream2 = null;
        try {
            inputStream = context.getAssets().open(str);
        } catch (Exception unused) {
            inputStream = null;
        } catch (Throwable th) {
            th = th;
        }
        try {
            Bitmap decodeStream = BitmapFactory.decodeStream(inputStream);
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (Exception unused2) {
                }
            }
            return decodeStream;
        } catch (Exception unused3) {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (Exception unused4) {
                }
            }
            return null;
        } catch (Throwable th2) {
            th = th2;
            inputStream2 = inputStream;
            if (inputStream2 != null) {
                try {
                    inputStream2.close();
                } catch (Exception unused5) {
                }
            }
            throw th;
        }
    }

    /* renamed from: B4 */
    public void m4608B4() {
        try {
            JSONObject m4910h1 = this.f75863p4.m4910h1(this.f74451w4.getJSONArray("views"), "id", this.f74452x4);
            if (m4910h1.getString("id").equals("root") && this.f74450C4.length() > 0) {
                m4910h1.getJSONArray("sections").put(new JSONObject("{\"cells\":[{\"type\":\"flex0\",\"title\":\"Citations\", \"targetHTML\":\"" + this.f74450C4.replace("\"", "\\\"") + "\"}]}"));
            }
            this.f74454z4 = m4910h1;
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            e.printStackTrace();
        }
    }

    /* renamed from: D4 */
    public int m4606D4() {
        if (this.f74454z4 == null) {
            return 0;
        }
        int i = 0;
        for (int i2 = 0; i2 < this.f74454z4.getJSONArray("sections").length(); i2++) {
            try {
                i = i + this.f74454z4.getJSONArray("sections").getJSONObject(i2).getJSONArray("cells").length() + 1;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                e.printStackTrace();
                return 0;
            }
        }
        return i;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList;
        Bundle m4073v3;
        if (this.f74448A4.size() <= 0 || (arrayList = this.f74448A4) == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f74448A4)) == null) {
            return null;
        }
        return m4073v3.getString("ImagePath");
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        JSONObject jSONObject;
        String str = "";
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74453y4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        try {
            String str2 = this.f75847Z3;
            if (str2 == null || str2.length() == 0) {
                if (m44859B().containsKey("ViewId")) {
                    this.f74452x4 = m44859B().getString("ViewId");
                }
                if (m44859B().containsKey("mDB")) {
                    this.f74449B4 = m44859B().getString("mDB");
                }
                if (this.f74449B4 == null) {
                    this.f74449B4 = "Dx";
                }
                iMDLogger.m3294f("Loading Document", this.f75851d4);
                String str3 = this.f75851d4.split("-")[1];
                ArrayList<Bundle> m4955V = this.f75863p4.m4955V(this.f75850c4, "Select * from " + this.f74449B4 + "_monographs where id=" + str3);
                if (m4955V != null && m4955V.size() != 0) {
                    JSONObject jSONObject2 = new JSONObject(this.f75863p4.m5015B(m4955V.get(0).getString("monograph"), str3, "127"));
                    this.f75852e4 = jSONObject2.getString("title");
                    this.f74451w4 = jSONObject2;
                    if (this.f74452x4 == null) {
                        this.f74452x4 = "root";
                    }
                    this.f74450C4 = "";
                    if (jSONObject2.has("citations") && this.f74451w4.getJSONObject("citations").has("articles")) {
                        for (int i = 0; i < this.f74451w4.getJSONObject("citations").getJSONArray("articles").length(); i++) {
                            JSONObject jSONObject3 = this.f74451w4.getJSONObject("citations").getJSONArray("articles").getJSONObject(i);
                            str = str + "<div id=\"articleCitation" + jSONObject3.getString("id") + "\" style=\"margin:10px\"><b>" + jSONObject3.getString("id") + ": </b>" + jSONObject3.getString(HTML.Tag.f65946y) + "</div>";
                        }
                        this.f74450C4 = str;
                    }
                    m4608B4();
                    ArrayList<Bundle> arrayList = new ArrayList<>();
                    if (this.f74451w4.has("media")) {
                        for (int i2 = 0; i2 < this.f74451w4.getJSONArray("media").length(); i2++) {
                            String string = this.f74451w4.getJSONArray("media").getJSONObject(i2).getString(Annotation.f59806M2);
                            String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, string, "pictures");
                            if (new File(m4942Z0).exists()) {
                                Bundle bundle2 = new Bundle();
                                bundle2.putString("ImagePath", m4942Z0);
                                bundle2.putString("id", string);
                                bundle2.putString("Description", jSONObject.getString(HTML.Tag.f65910g) + "\n" + jSONObject.getString("source"));
                                arrayList.add(bundle2);
                            }
                        }
                    }
                    this.f74448A4 = arrayList;
                }
                CompressHelper.m4921e2(m44716w(), "Document doesn't exist", 1);
                return this.f75849b4;
            }
            this.f74453y4.setAdapter(new EpocrateAdapter());
            m4604y4();
            m4100f3(C4804R.C4811menu.f87325epolistmenu);
            m44735q2(false);
            m4140G3();
        } catch (Exception e) {
            m4080r4(e);
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86774action_gallery) {
            m4607C4("soheilvb");
        }
        return super.mo3709e1(menuItem);
    }

    /* renamed from: x4 */
    public Bundle m4605x4(int i) {
        int i2 = 0;
        int i3 = 0;
        for (int i4 = 0; i4 < this.f74454z4.getJSONArray("sections").length(); i4++) {
            try {
                JSONObject jSONObject = this.f74454z4.getJSONArray("sections").getJSONObject(i4);
                if (i == i2) {
                    Bundle bundle = new Bundle();
                    String string = jSONObject.has("headerText") ? jSONObject.getString("headerText") : "";
                    if (jSONObject.has("headers")) {
                        string = jSONObject.getJSONArray("headers").getJSONObject(0).getString("title");
                    }
                    bundle.putString("Title", string);
                    bundle.putInt("Row", 0);
                    bundle.putInt("Section", i3);
                    bundle.putInt("Row2", 1);
                    bundle.putInt("Section2", i3 - 1);
                    return bundle;
                }
                int length = i2 + jSONObject.getJSONArray("cells").length();
                if (i <= length) {
                    int length2 = (i - (length - jSONObject.getJSONArray("cells").length())) - 1;
                    Bundle bundle2 = new Bundle();
                    bundle2.putBundle("Item", this.f75863p4.m5000G(jSONObject.getJSONArray("cells").getJSONObject(length2)));
                    bundle2.putInt("Row", length2);
                    bundle2.putInt("Section", i3);
                    return bundle2;
                }
                i2 = length + 1;
                i3++;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                e.printStackTrace();
                return null;
            }
        }
        return null;
    }

    /* renamed from: y4 */
    public void m4604y4() {
        this.f74453y4.setItemAnimator(new DefaultItemAnimator());
        this.f74453y4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f74453y4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }

    /* renamed from: z4 */
    public String m4603z4(JSONObject jSONObject) {
        try {
            return jSONObject.has(TypedValues.Attributes.f5596M) ? jSONObject.getString(TypedValues.Attributes.f5596M) : jSONObject.getString("targetHTML");
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            e.printStackTrace();
            return null;
        }
    }
}
