package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class EPORxListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74626b4;

    /* renamed from: c4 */
    public String f74627c4;

    /* renamed from: d4 */
    public Bundle f74628d4;

    /* renamed from: e4 */
    public boolean f74629e4;

    /* renamed from: f4 */
    public String f74630f4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f74630f4 = "RX.sqlite";
        this.f74628d4 = new Bundle();
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            str = null;
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPORxListActivityFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            str = m44859B().getString("ParentId");
        }
        this.f74627c4 = str;
        if (this.f74627c4 == null) {
            this.f75218O3 = this.f75215L3.m4952W(this.f75212I3, "SELECT  DRUG_CLASS.ID ,  DRUG_CLASS.NAME   FROM DRUG_CLASS_HIERARCHY   JOIN DRUG_CLASS ON  DRUG_CLASS_HIERARCHY.PARENT_ID =  ''  AND DRUG_CLASS.ID = DRUG_CLASS_HIERARCHY.CHILD_ID    ORDER BY  DRUG_CLASS.NAME COLLATE NOCASE", this.f74630f4);
        } else {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle2 = this.f75212I3;
            ArrayList<Bundle> m4952W = compressHelper.m4952W(bundle2, "SELECT  DRUG_CLASS.ID ,  DRUG_CLASS.NAME   FROM DRUG_CLASS_HIERARCHY   JOIN DRUG_CLASS ON  DRUG_CLASS_HIERARCHY.PARENT_ID =  " + this.f74627c4 + " AND DRUG_CLASS.ID = DRUG_CLASS_HIERARCHY.CHILD_ID    ORDER BY  DRUG_CLASS.NAME COLLATE NOCASE", this.f74630f4);
            this.f75218O3 = m4952W;
            if (m4952W == null || m4952W.size() == 0) {
                this.f74629e4 = true;
                CompressHelper compressHelper2 = this.f75215L3;
                Bundle bundle3 = this.f75212I3;
                this.f75218O3 = compressHelper2.m4952W(bundle3, "SELECT  DRUG.ID ,  DRUG.CLINICAL_ID ,  DRUG.GENERIC_ID ,  DRUG.NAME ,  DRUG.DRUG_TYPE ,  DRUG.ACTIVE ,  DRUG.ADULT_DSG_ID ,  DRUG.PEDS_DSG_ID ,  DRUG.MFR_STRING_ID ,  DRUG.BBW_ID   FROM DRUG_TO_DRUG_CLASS   JOIN DRUG ON  DRUG_TO_DRUG_CLASS.DRUG_CLASS_ID =  " + this.f74627c4 + "   AND DRUG.ID = DRUG_TO_DRUG_CLASS.DRUG_ID    WHERE ACTIVE = 1 ORDER BY  DRUG.NAME COLLATE NOCASE", this.f74630f4);
                CompressHelper compressHelper3 = this.f75215L3;
                Bundle bundle4 = this.f75212I3;
                String string = compressHelper3.m4907i1(compressHelper3.m4952W(bundle4, "SELECT  group_concat(generic_ID) as a  FROM DRUG_TO_DRUG_CLASS   JOIN DRUG ON  DRUG_TO_DRUG_CLASS.DRUG_CLASS_ID =  " + this.f74627c4 + "   AND DRUG.ID = DRUG_TO_DRUG_CLASS.DRUG_ID    WHERE ACTIVE = 1 AND generic_ID<>''   ORDER BY  DRUG.NAME COLLATE NOCASE", this.f74630f4)).getString("a");
                ArrayList<Bundle> arrayList = this.f75218O3;
                if (arrayList == null || arrayList.size() == 0) {
                    this.f75218O3 = this.f75215L3.m4952W(this.f75212I3, "SELECT  DRUG.ID ,  DRUG.CLINICAL_ID ,  DRUG.GENERIC_ID ,  DRUG.NAME ,  DRUG.DRUG_TYPE ,  DRUG.ACTIVE ,  DRUG.ADULT_DSG_ID ,  DRUG.PEDS_DSG_ID ,  DRUG.MFR_STRING_ID ,  DRUG.BBW_ID   FROM DRUG  WHERE DRUG_TYPE=7 order by NAME asc", this.f74630f4);
                    CompressHelper compressHelper4 = this.f75215L3;
                    string = compressHelper4.m4907i1(compressHelper4.m4952W(this.f75212I3, "SELECT  group_concat(generic_ID) as a  FROM DRUG WHERE DRUG_TYPE=7 AND generic_id<>'' ORDER BY NAME COLLATE NOCASE", this.f74630f4)).getString("a");
                }
                CompressHelper compressHelper5 = this.f75215L3;
                Bundle bundle5 = this.f75212I3;
                ArrayList<Bundle> m4952W2 = compressHelper5.m4952W(bundle5, "SELECT  DRUG.ID ,  DRUG.CLINICAL_ID ,  DRUG.GENERIC_ID ,  DRUG.NAME ,  DRUG.DRUG_TYPE ,  DRUG.ACTIVE ,  DRUG.ADULT_DSG_ID ,  DRUG.PEDS_DSG_ID ,  DRUG.MFR_STRING_ID ,  DRUG.BBW_ID   FROM DRUG   WHERE  ID in (" + string + ")", this.f74630f4);
                if (m4952W2 != null) {
                    Iterator<Bundle> it2 = m4952W2.iterator();
                    while (it2.hasNext()) {
                        Bundle next = it2.next();
                        String string2 = next.getString("ID");
                        String string3 = next.getString("NAME");
                        if (!this.f74628d4.containsKey(string2)) {
                            this.f74628d4.putString(string2, string3);
                        }
                    }
                }
            }
        }
        this.f75216M3 = this.f74629e4 ? new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPORxListActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle6, final int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle6.getString("NAME"));
                String string4 = bundle6.getString("GENERIC_ID");
                String string5 = bundle6.getString("ID");
                rippleTextFullViewHolder.f83285J.setText(bundle6.getString("content"));
                String string6 = bundle6.getString("DRUG_TYPE");
                int i2 = string6.equals("7") ? C4804R.C4807drawable.f86677plus_alt : string6.equals("6") ? C4804R.C4807drawable.f86688plus_otc : C4804R.C4807drawable.f86691plus_rx;
                if (!string4.equals(string5) && EPORxListActivityFragment.this.f74628d4.containsKey(string4)) {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    rippleTextFullViewHolder.f83285J.setText(EPORxListActivityFragment.this.f74628d4.getString(string4));
                } else {
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                }
                rippleTextFullViewHolder.f83286K.setImageDrawable(EPORxListActivityFragment.this.m44716w().getResources().getDrawable(i2));
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPORxListActivityFragment.2.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPORxListActivityFragment.this.m4558l3(bundle6, i);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new RippleTextFullViewHolder(view);
            }
        } : new ChaptersAdapter(m44716w(), this.f75218O3, "NAME", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPORxListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: f0 */
            public void mo3405f0(Bundle bundle6, int i) {
                EPORxListActivityFragment.this.m4558l3(bundle6, i);
            }
        };
        this.f74626b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPORxListActivityFragment.4
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle6, int i) {
                TextView textView;
                int i2;
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle6.getString("text"));
                rippleTextFullViewHolder.f83285J.setText(bundle6.getString("content"));
                if (bundle6.getString("content").length() == 0) {
                    textView = rippleTextFullViewHolder.f83285J;
                    i2 = 8;
                } else {
                    textView = rippleTextFullViewHolder.f83285J;
                    i2 = 0;
                }
                textView.setVisibility(i2);
                String string4 = bundle6.getString("type");
                rippleTextFullViewHolder.f83286K.setImageDrawable(EPORxListActivityFragment.this.m44716w().getResources().getDrawable(string4.equals("7") ? C4804R.C4807drawable.f86677plus_alt : string4.equals("6") ? C4804R.C4807drawable.f86688plus_otc : C4804R.C4807drawable.f86691plus_rx));
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPORxListActivityFragment.4.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPORxListActivityFragment.this.m4330Y2();
                        EPORxListActivityFragment ePORxListActivityFragment = EPORxListActivityFragment.this;
                        CompressHelper compressHelper6 = ePORxListActivityFragment.f75215L3;
                        Bundle bundle7 = ePORxListActivityFragment.f75212I3;
                        compressHelper6.m4883q1(bundle7, "rx-" + bundle6.getString("contentId"), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle6) {
                EPORxListActivityFragment.this.m4330Y2();
                EPORxListActivityFragment.this.f75223T3.m51655i0(bundle6.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                return new RippleTextFullViewHolder(view);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74626b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74626b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match '(text:" + str + "* OR content:" + str + "*) AND typeText:RX NOT (type:5)'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: f3 */
    public void mo4326f3() {
        this.f75224U3.setImageDrawable(m44782a0().getDrawable(C4804R.C4807drawable.f86568drugs_icon));
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "Drugs";
    }

    /* renamed from: l3 */
    public void m4558l3(Bundle bundle, int i) {
        m4330Y2();
        if (!this.f74629e4) {
            Bundle bundle2 = new Bundle();
            bundle2.putBundle("DB", this.f75212I3);
            bundle2.putString("ParentId", bundle.getString("ID"));
            this.f75215L3.m4979N(EPORxListActivity.class, EPORxListActivityFragment.class, bundle2);
            return;
        }
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle3 = this.f75212I3;
        compressHelper.m4883q1(bundle3, "rx-" + bundle.getString("ID"), null, null);
    }
}
