package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class EPOInteractResultActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public Bundle f74516A4;

    /* renamed from: B4 */
    public ArrayList<String> f74517B4;

    /* renamed from: C4 */
    public NotStickySectionAdapter f74518C4;

    /* renamed from: D4 */
    public ArrayList<Bundle> f74519D4;

    /* renamed from: E4 */
    public ArrayList<Bundle> f74520E4;

    /* renamed from: w4 */
    public RecyclerView f74521w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f74522x4;

    /* renamed from: y4 */
    public String f74523y4;

    /* renamed from: z4 */
    public Bundle f74524z4;

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74521w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        this.f74524z4 = new Bundle();
        this.f74517B4 = new ArrayList<>();
        this.f74516A4 = new Bundle();
        this.f74523y4 = "RX.sqlite";
        for (String str : StringUtils.splitByWholeSeparator(this.f75851d4.split("-")[1], ";;;;;")) {
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str, ",,,,,");
            this.f74524z4.putString(splitByWholeSeparator[0], splitByWholeSeparator[1]);
            this.f74517B4.add(splitByWholeSeparator[0]);
        }
        String join = StringUtils.join(this.f74517B4, ",");
        this.f74522x4 = this.f75863p4.m4949X(this.f75850c4, "Select * from pill_pictures where drug_id in (" + join + ")", this.f74523y4, true);
        ArrayList<Bundle> m4949X = this.f75863p4.m4949X(this.f75850c4, "SELECT                     ID,                     DRUG_ID AS DRUG_0_ID,                     INTERACTING_DRUG_ID AS DRUG_1_ID,                     DDI_ID,                     GROUP_0_ID,                     GROUP_1_ID                     FROM (                     SELECT DISTINCT                     tDID.ID,                     MIN(d1.ID, d2.ID) AS DRUG_ID,                     MAX(d1.ID, d2.ID) AS INTERACTING_DRUG_ID,                     tDID.DDI_ID,                     DDI.GROUP_0_ID,                     DDI.GROUP_1_ID                     FROM                     DRUG_TO_INTERACTING_DRUG tDID                     JOIN DDI ON tDID.DDI_ID = DDI.ID                     JOIN DRUG d1 ON d1.ID = tDID.DRUG_0_ID OR d1.GENERIC_ID = tDID.DRUG_0_ID OR d1.ID = tDID.DRUG_1_ID OR d1.GENERIC_ID = tDID.DRUG_1_ID                     JOIN DRUG d2 ON                     CASE WHEN d1.ID = tDID.DRUG_0_ID OR d1.GENERIC_ID = tDID.DRUG_0_ID                     THEN d2.ID = tDID.DRUG_1_ID OR d2.GENERIC_ID = tDID.DRUG_1_ID                     ELSE d2.ID = tDID.DRUG_0_ID OR d2.GENERIC_ID = tDID.DRUG_0_ID                     END                     WHERE                     tDID.DRUG_0_ID IN (" + join + ")                     AND                     tDID.DRUG_1_ID IN (" + join + ")                     AND                     DRUG_0_ID <> DRUG_1_ID                     AND                     d1.ID IN (" + join + ")                     AND                     d2.ID IN (" + join + ")                     ORDER BY CATEGORY_ID, d1.name, d2.name                     )", this.f74523y4, true);
        ArrayList arrayList = new ArrayList();
        Iterator<Bundle> it2 = m4949X.iterator();
        while (it2.hasNext()) {
            Bundle next = it2.next();
            arrayList.add(next.getString("DDI_ID"));
            String string = next.getString("DRUG_0_ID");
            String string2 = next.getString("DRUG_1_ID");
            String string3 = next.getString("GROUP_0_ID");
            String string4 = next.getString("GROUP_1_ID");
            String str2 = string3 + "-" + string4;
            if (!this.f74516A4.containsKey(str2)) {
                this.f74516A4.putString(str2, string + "-" + string2);
            }
            String str3 = string4 + "-" + string3;
            if (!this.f74516A4.containsKey(str3)) {
                this.f74516A4.putString(str3, string + "-" + string2);
            }
        }
        ArrayList<Bundle> m4949X2 = this.f75863p4.m4949X(this.f75850c4, "Select * from DDI where id in (" + StringUtils.join(arrayList, ",") + ") order by category_id", this.f74523y4, true);
        this.f74519D4 = m4949X2;
        this.f75852e4 = m4949X2.size() == 0 ? "No Interaction Found" : "Found " + this.f74519D4.size() + " Interactions";
        this.f74520E4 = this.f75863p4.m4941Z1(this.f74519D4, "CATEGORY_ID");
        NotStickySectionAdapter notStickySectionAdapter = new NotStickySectionAdapter(m44716w(), this.f74520E4, "title", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractResultActivityFragment.1
            @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
            /* renamed from: f0 */
            public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                Bundle bundle3 = EPOInteractResultActivityFragment.this.f74516A4;
                String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(bundle3.getString(bundle2.getString("GROUP_1_ID") + "-" + bundle2.getString("GROUP_0_ID")), "-");
                int i2 = 0;
                String string5 = EPOInteractResultActivityFragment.this.f74524z4.getString(splitByWholeSeparator2[0]);
                String string6 = EPOInteractResultActivityFragment.this.f74524z4.getString(splitByWholeSeparator2[1]);
                rippleTextFullViewHolder.f83284I.setText(string5);
                rippleTextFullViewHolder.f83285J.setText(string6);
                String string7 = bundle2.getString("CATEGORY_ID");
                if (string7.equals(IcyHeaders.f35463C2)) {
                    i2 = C4804R.C4807drawable.f86754xinteraction;
                } else if (string7.equals(ExifInterface.f14403S4)) {
                    i2 = C4804R.C4807drawable.f86564dinteraction;
                } else if (string7.equals(ExifInterface.f14411T4)) {
                    i2 = C4804R.C4807drawable.f86552cinteraction;
                } else if (string7.equals("4")) {
                    i2 = C4804R.C4807drawable.f86515binteraction;
                } else if (string7.equals("5")) {
                    i2 = C4804R.C4807drawable.f86476ainteraction;
                }
                rippleTextFullViewHolder.f83286K.setImageDrawable(EPOInteractResultActivityFragment.this.m44782a0().getDrawable(i2));
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractResultActivityFragment.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        EPOInteractResultActivityFragment ePOInteractResultActivityFragment = EPOInteractResultActivityFragment.this;
                        CompressHelper compressHelper = ePOInteractResultActivityFragment.f75863p4;
                        Bundle bundle4 = ePOInteractResultActivityFragment.f75850c4;
                        compressHelper.m4883q1(bundle4, "interactview-" + bundle2.getString("ID"), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
            /* renamed from: i0 */
            public String mo3387i0(String str4) {
                return str4.equals("5") ? "Caution Advised" : str4.equals("4") ? "Therapeutic Advantage" : str4.equals(ExifInterface.f14411T4) ? "Monitor / Modify Tx" : str4.equals(ExifInterface.f14403S4) ? "Avoid / Use Alternative" : str4.equals(IcyHeaders.f35463C2) ? "Contraindicated" : str4;
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
            /* renamed from: k0 */
            public RecyclerView.ViewHolder mo3385k0(View view2) {
                return new RippleTextFullViewHolder(view2);
            }
        };
        this.f74518C4 = notStickySectionAdapter;
        this.f74521w4.setAdapter(notStickySectionAdapter);
        m4585x4();
        m4100f3(C4804R.C4811menu.f87326favorite);
        m44735q2(false);
        m4140G3();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f74522x4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f74522x4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    /* renamed from: x4 */
    public void m4585x4() {
        this.f74521w4.setItemAnimator(new DefaultItemAnimator());
        this.f74521w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f74521w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }
}
