package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.util.ArrayList;
import java.util.HashMap;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class EPOMainActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public GridLayoutManager f74558b4;

    /* renamed from: c4 */
    public SpellSearchAdapter f74559c4;

    /* renamed from: d4 */
    private DividerItemDecoration f74560d4;

    /* loaded from: classes2.dex */
    public static class CardViewPlaceHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        private TextView f74565I;

        /* renamed from: J */
        private ImageView f74566J;

        /* renamed from: K */
        private MaterialRippleLayout f74567K;

        public CardViewPlaceHolder(View view) {
            super(view);
            this.f74565I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
            this.f74566J = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
            this.f74567K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        }
    }

    /* loaded from: classes2.dex */
    public class CollectionAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        HashMap<String, Integer> f74568d = new HashMap<>();

        public CollectionAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: B */
        public long mo3620B(int i) {
            return i;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            return i < EPOMainActivityFragment.this.f75218O3.size() ? 0 : 1;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            SwitchCompat switchCompat;
            CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
            if (viewHolder.m42556F() == 0) {
                final Bundle bundle = EPOMainActivityFragment.this.f75218O3.get(i);
                CardViewPlaceHolder cardViewPlaceHolder = (CardViewPlaceHolder) viewHolder;
                cardViewPlaceHolder.f74565I.setText(bundle.getString("Title"));
                cardViewPlaceHolder.f74566J.setImageDrawable(EPOMainActivityFragment.this.m44716w().getResources().getDrawable(bundle.getInt("Image")));
                cardViewPlaceHolder.f74567K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOMainActivityFragment.CollectionAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CompressHelper compressHelper;
                        Class<?> cls;
                        Class<?> cls2;
                        String string = bundle.getString("Type");
                        Bundle bundle2 = new Bundle();
                        bundle2.putBundle("DB", EPOMainActivityFragment.this.f75212I3);
                        if (string.equals("dx")) {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPODxListActivity.class;
                            cls2 = EPODxListActivityFragment.class;
                        } else if (string.equals("lab")) {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPOLabListActivity.class;
                            cls2 = EPOLabListActivityFragment.class;
                        } else if (string.equals("rx")) {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPORxListActivity.class;
                            cls2 = EPORxListActivityFragment.class;
                        } else if (string.equals("interact")) {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPOInteractActivity.class;
                            cls2 = EPOInteractActivityFragment.class;
                        } else if (string.equals("id")) {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPOIDListActivity.class;
                            cls2 = EPOIDListActivityFragment.class;
                        } else if (string.equals("guideline")) {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPOGuidelineListActivity.class;
                            cls2 = EPOGuidelineListActivityFragment.class;
                        } else if (string.equals("table")) {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPOTableListActivity.class;
                            cls2 = EPOTableListActivityFragment.class;
                        } else if (!string.equals("pillid")) {
                            return;
                        } else {
                            compressHelper = EPOMainActivityFragment.this.f75215L3;
                            cls = EPOPillActivity.class;
                            cls2 = EPOPillActivityFragment.class;
                        }
                        compressHelper.m4979N(cls, cls2, bundle2);
                    }
                });
            } else if (viewHolder.m42556F() == 1) {
                SwitchPlaceHolder switchPlaceHolder = (SwitchPlaceHolder) viewHolder;
                if (i - EPOMainActivityFragment.this.f75218O3.size() == 0) {
                    switchPlaceHolder.f74574I.setText("Show Disease Monograph as List");
                    switchPlaceHolder.f74575J.setChecked(PreferenceManager.getDefaultSharedPreferences(EPOMainActivityFragment.this.m44716w()).getBoolean("DiseaseList", false));
                    switchCompat = switchPlaceHolder.f74575J;
                    onCheckedChangeListener = new CompoundButton.OnCheckedChangeListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOMainActivityFragment.CollectionAdapter.2
                        @Override // android.widget.CompoundButton.OnCheckedChangeListener
                        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                            PreferenceManager.getDefaultSharedPreferences(EPOMainActivityFragment.this.m44716w()).edit().putBoolean("DiseaseList", z).commit();
                        }
                    };
                } else {
                    switchPlaceHolder.f74574I.setText("Show Lab Monograph as List");
                    switchPlaceHolder.f74575J.setChecked(PreferenceManager.getDefaultSharedPreferences(EPOMainActivityFragment.this.m44716w()).getBoolean("LabList", true));
                    switchCompat = switchPlaceHolder.f74575J;
                    onCheckedChangeListener = new CompoundButton.OnCheckedChangeListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOMainActivityFragment.CollectionAdapter.3
                        @Override // android.widget.CompoundButton.OnCheckedChangeListener
                        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                            PreferenceManager.getDefaultSharedPreferences(EPOMainActivityFragment.this.m44716w()).edit().putBoolean("LabList", z).commit();
                        }
                    };
                }
                switchCompat.setOnCheckedChangeListener(onCheckedChangeListener);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new CardViewPlaceHolder(LayoutInflater.from(EPOMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87224list_view_item_card_view_epocrate, viewGroup, false));
            }
            if (i == 1) {
                return new SwitchPlaceHolder(LayoutInflater.from(EPOMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87296list_view_item_switch, viewGroup, false));
            }
            return null;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return EPOMainActivityFragment.this.f75218O3.size() + 2;
        }
    }

    /* loaded from: classes2.dex */
    public static class SwitchPlaceHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        private TextView f74574I;

        /* renamed from: J */
        private SwitchCompat f74575J;

        public SwitchPlaceHolder(View view) {
            super(view);
            this.f74574I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
            this.f74575J = (SwitchCompat) view.findViewById(C4804R.C4808id.f87040switch_view);
        }
    }

    /* renamed from: l3 */
    private Bundle m4578l3(String str, String str2, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("Title", str);
        bundle.putString("Type", str2);
        bundle.putInt("Image", i);
        return bundle;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
        ArrayList<Bundle> arrayList = new ArrayList<>();
        this.f75218O3 = arrayList;
        arrayList.add(m4578l3("Diseases", "dx", C4804R.C4807drawable.f86565diseases_icon));
        this.f75218O3.add(m4578l3("Drugs", "rx", C4804R.C4807drawable.f86568drugs_icon));
        this.f75218O3.add(m4578l3("Labs", "lab", C4804R.C4807drawable.f86626labs_icon));
        this.f75218O3.add(m4578l3("Drug Interactions", "interact", C4804R.C4807drawable.f86616interaction_check_icon));
        this.f75218O3.add(m4578l3("Infectious Disease Treatment", "id", C4804R.C4807drawable.f86605id_tx_icon));
        this.f75218O3.add(m4578l3("Guidelines", "guideline", C4804R.C4807drawable.f86578guidelines_icon));
        this.f75218O3.add(m4578l3("Tables", "table", C4804R.C4807drawable.f86734tables_icon));
        this.f75218O3.add(m4578l3("Pill ID", "pillid", C4804R.C4807drawable.f86673pill_id_icon));
        CollectionAdapter collectionAdapter = new CollectionAdapter();
        this.f75216M3 = collectionAdapter;
        this.f75227X3.setAdapter(collectionAdapter);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(m44716w(), 2);
        this.f74558b4 = gridLayoutManager;
        gridLayoutManager.m43287N3(new GridLayoutManager.SpanSizeLookup() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOMainActivityFragment.1
            @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
            /* renamed from: f */
            public int mo3768f(int i) {
                RecyclerView.Adapter adapter = EPOMainActivityFragment.this.f75227X3.getAdapter();
                EPOMainActivityFragment ePOMainActivityFragment = EPOMainActivityFragment.this;
                return (adapter != ePOMainActivityFragment.f74559c4 && i <= ePOMainActivityFragment.f75218O3.size() - 1) ? 1 : 2;
            }
        });
        this.f74559c4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOMainActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle2.getString("text"));
                rippleTextFullViewHolder.f83285J.setText(bundle2.getString("content"));
                int i2 = 0;
                if (bundle2.getString("content").length() == 0) {
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                } else {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                }
                String string = bundle2.getString("type");
                String string2 = bundle2.getString("typeText");
                if (string2.equals("Dx")) {
                    i2 = C4804R.C4807drawable.f86681plus_dx;
                } else if (string2.equals("Rx")) {
                    i2 = string.equals("7") ? C4804R.C4807drawable.f86677plus_alt : string.equals("6") ? C4804R.C4807drawable.f86688plus_otc : C4804R.C4807drawable.f86691plus_rx;
                } else if (string2.equals("ID")) {
                    i2 = C4804R.C4807drawable.f86685plus_id;
                } else if (string2.equals("Lab")) {
                    i2 = C4804R.C4807drawable.f86687plus_lab;
                } else if (string2.equals("Guideline")) {
                    i2 = C4804R.C4807drawable.f86682plus_gl;
                } else if (string2.equals("Table")) {
                    i2 = C4804R.C4807drawable.f86692plus_table;
                }
                rippleTextFullViewHolder.f83286K.setImageDrawable(EPOMainActivityFragment.this.m44716w().getResources().getDrawable(i2));
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOMainActivityFragment.2.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CompressHelper compressHelper;
                        Bundle bundle3;
                        StringBuilder sb;
                        String str;
                        EPOMainActivityFragment.this.m4330Y2();
                        String string3 = bundle2.getString("typeText");
                        String string4 = bundle2.getString("contentId");
                        if (string3.equals("Dx")) {
                            EPOMainActivityFragment ePOMainActivityFragment = EPOMainActivityFragment.this;
                            compressHelper = ePOMainActivityFragment.f75215L3;
                            bundle3 = ePOMainActivityFragment.f75212I3;
                            sb = new StringBuilder();
                            str = "dx-";
                        } else if (string3.equals("Rx")) {
                            EPOMainActivityFragment ePOMainActivityFragment2 = EPOMainActivityFragment.this;
                            compressHelper = ePOMainActivityFragment2.f75215L3;
                            bundle3 = ePOMainActivityFragment2.f75212I3;
                            sb = new StringBuilder();
                            str = "rx-";
                        } else if (string3.equals("ID")) {
                            EPOMainActivityFragment ePOMainActivityFragment3 = EPOMainActivityFragment.this;
                            compressHelper = ePOMainActivityFragment3.f75215L3;
                            bundle3 = ePOMainActivityFragment3.f75212I3;
                            sb = new StringBuilder();
                            str = "id-";
                        } else if (string3.equals("Lab")) {
                            EPOMainActivityFragment ePOMainActivityFragment4 = EPOMainActivityFragment.this;
                            compressHelper = ePOMainActivityFragment4.f75215L3;
                            bundle3 = ePOMainActivityFragment4.f75212I3;
                            sb = new StringBuilder();
                            str = "lab-";
                        } else if (string3.equals("Guideline")) {
                            EPOMainActivityFragment ePOMainActivityFragment5 = EPOMainActivityFragment.this;
                            compressHelper = ePOMainActivityFragment5.f75215L3;
                            bundle3 = ePOMainActivityFragment5.f75212I3;
                            sb = new StringBuilder();
                            str = "guideline-";
                        } else if (!string3.equals("Table")) {
                            return;
                        } else {
                            EPOMainActivityFragment ePOMainActivityFragment6 = EPOMainActivityFragment.this;
                            compressHelper = ePOMainActivityFragment6.f75215L3;
                            bundle3 = ePOMainActivityFragment6.f75212I3;
                            sb = new StringBuilder();
                            str = "table-";
                        }
                        sb.append(str);
                        sb.append(string4);
                        compressHelper.m4883q1(bundle3, sb.toString(), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle2) {
                EPOMainActivityFragment.this.m4330Y2();
                EPOMainActivityFragment.this.f75223T3.m51655i0(bundle2.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                return new RippleTextFullViewHolder(view);
            }
        };
        this.f74560d4 = new DividerItemDecoration(m44716w(), 1);
        this.f75227X3.setLayoutManager(this.f74558b4);
        this.f75227X3.setItemAnimator(new DefaultItemAnimator());
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        try {
            this.f75227X3.m42906s1(this.f74560d4);
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
        }
        this.f75227X3.m42923n(this.f74560d4);
        this.f74559c4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74559c4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: c3 */
    public void mo4182c3() {
        try {
            this.f75227X3.m42906s1(this.f74560d4);
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match '(text:" + str + "* OR content:" + str + "*) NOT (type:5)'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }
}
