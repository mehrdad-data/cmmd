package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class EPOTableListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74650b4;

    /* renamed from: c4 */
    public String f74651c4;

    /* renamed from: d4 */
    public String f74652d4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        CompressHelper compressHelper;
        Bundle bundle2;
        String str2;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f74652d4 = "RX.sqlite";
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            str = null;
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOTableListActivityFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            str = m44859B().getString("ParentId");
        }
        this.f74651c4 = str;
        if (this.f74651c4 == null) {
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            str2 = "Select * from content_table_cat";
        } else {
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            str2 = "select * from content_table_to_cat inner join content_table on content_table_to_cat.table_id=content_table.id where cat_id=" + this.f74651c4 + " order by display_order";
        }
        this.f75218O3 = compressHelper.m4952W(bundle2, str2, this.f74652d4);
        this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "NAME", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOTableListActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: f0 */
            public void mo3405f0(Bundle bundle3, int i) {
                EPOTableListActivityFragment.this.m4330Y2();
                EPOTableListActivityFragment ePOTableListActivityFragment = EPOTableListActivityFragment.this;
                if (ePOTableListActivityFragment.f74651c4 == null) {
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("DB", EPOTableListActivityFragment.this.f75212I3);
                    bundle4.putString("ParentId", bundle3.getString("ID"));
                    EPOTableListActivityFragment.this.f75215L3.m4979N(EPOTableListActivity.class, EPOTableListActivityFragment.class, bundle4);
                    return;
                }
                CompressHelper compressHelper2 = ePOTableListActivityFragment.f75215L3;
                Bundle bundle5 = ePOTableListActivityFragment.f75212I3;
                compressHelper2.m4883q1(bundle5, "table-" + bundle3.getString("ID"), null, null);
            }
        };
        this.f74650b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOTableListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: g0 */
            public void mo3380g0(Bundle bundle3, int i) {
                EPOTableListActivityFragment.this.m4330Y2();
                EPOTableListActivityFragment ePOTableListActivityFragment = EPOTableListActivityFragment.this;
                CompressHelper compressHelper2 = ePOTableListActivityFragment.f75215L3;
                Bundle bundle4 = ePOTableListActivityFragment.f75212I3;
                compressHelper2.m4883q1(bundle4, "table-" + bundle3.getString("contentId"), null, null);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle3) {
                EPOTableListActivityFragment.this.m4330Y2();
                EPOTableListActivityFragment.this.f75223T3.m51655i0(bundle3.getString("word"), true);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74650b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74650b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match 'text:" + str + "* AND typeText:Table AND type:1'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: f3 */
    public void mo4326f3() {
        this.f75224U3.setImageDrawable(m44782a0().getDrawable(C4804R.C4807drawable.f86734tables_icon));
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "Tables";
    }
}
