package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class EPOPillSelectDialog extends DialogFragment {

    /* renamed from: g4 */
    private ArrayList<Bundle> f74613g4;

    /* renamed from: h4 */
    private String f74614h4;

    /* renamed from: i4 */
    private String f74615i4;

    /* renamed from: j4 */
    private RecyclerView f74616j4;

    /* loaded from: classes2.dex */
    public class ImageTextCheckViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74617I;

        /* renamed from: J */
        public ImageView f74618J;

        /* renamed from: K */
        public ImageView f74619K;

        /* renamed from: L */
        public MaterialRippleLayout f74620L;

        public ImageTextCheckViewHolder(View view) {
            super(view);
            this.f74617I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
            this.f74618J = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
            this.f74619K = (ImageView) view.findViewById(C4804R.C4808id.f86840check_icon);
            this.f74620L = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        }
    }

    /* loaded from: classes2.dex */
    private class SelectAdapter extends RecyclerView.Adapter {
        private SelectAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            ImageTextCheckViewHolder imageTextCheckViewHolder = (ImageTextCheckViewHolder) viewHolder;
            if (i == 0) {
                imageTextCheckViewHolder.f74618J.setVisibility(8);
                if (EPOPillSelectDialog.this.f74615i4.equals("-1")) {
                    imageTextCheckViewHolder.f74619K.setVisibility(0);
                } else {
                    imageTextCheckViewHolder.f74619K.setVisibility(8);
                }
                TextView textView = imageTextCheckViewHolder.f74617I;
                textView.setText("Any " + EPOPillSelectDialog.this.f74614h4);
                imageTextCheckViewHolder.f74620L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillSelectDialog.SelectAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ((EPOPillActivityFragment) EPOPillSelectDialog.this.m44753k0()).m4569o3(EPOPillSelectDialog.this.f74614h4, null);
                    }
                });
                return;
            }
            final Bundle bundle = (Bundle) EPOPillSelectDialog.this.f74613g4.get(i - 1);
            imageTextCheckViewHolder.f74618J.setVisibility(0);
            if (EPOPillSelectDialog.this.f74615i4.equals(bundle.getString("ID"))) {
                imageTextCheckViewHolder.f74619K.setVisibility(0);
            } else {
                imageTextCheckViewHolder.f74619K.setVisibility(8);
            }
            imageTextCheckViewHolder.f74617I.setText(bundle.getString("STRING_TEXT"));
            imageTextCheckViewHolder.f74618J.setImageBitmap(EPOPillSelectDialog.m4559m3(EPOPillSelectDialog.this.m44716w(), "pill" + bundle.getString("STRING_TEXT").replace("-", "").replace("_", "").replace(StringUtils.SPACE, "") + ".png"));
            imageTextCheckViewHolder.f74620L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOPillSelectDialog.SelectAdapter.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ((EPOPillActivityFragment) EPOPillSelectDialog.this.m44753k0()).m4569o3(EPOPillSelectDialog.this.f74614h4, bundle);
                    EPOPillSelectDialog.this.mo27002R2();
                }
            });
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            return new ImageTextCheckViewHolder(LayoutInflater.from(EPOPillSelectDialog.this.m44716w()).inflate(C4804R.C4810layout.f87248list_view_item_image_text_check, viewGroup, false));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return EPOPillSelectDialog.this.f74613g4.size() + 1;
        }
    }

    /* renamed from: m3 */
    public static Bitmap m4559m3(Context context, String str) {
        try {
            return BitmapFactory.decodeStream(context.getAssets().open(str));
        } catch (IOException unused) {
            return null;
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87174fragment_new_section_viewer, (ViewGroup) null);
        this.f74616j4 = (RecyclerView) inflate.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f74613g4 = m44859B().getParcelableArrayList("Items");
        this.f74614h4 = m44859B().getString("Category");
        this.f74615i4 = m44859B().getString("Selected");
        new CompressHelper(m44716w());
        this.f74616j4.setAdapter(new SelectAdapter());
        this.f74616j4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
        builder.setView(inflate);
        return builder.create();
    }
}
