package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class EPOLabListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74550b4;

    /* renamed from: c4 */
    public String f74551c4;

    /* renamed from: d4 */
    public TabLayout f74552d4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        CompressHelper compressHelper;
        Bundle bundle2;
        String str;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87160fragment_lab_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        this.f74552d4 = (TabLayout) this.f75221R3.findViewById(C4804R.C4808id.f87042tabs);
        String[] strArr = {"Specimen Type", "Panel Type"};
        for (int i = 0; i < 2; i++) {
            TabLayout.Tab m24950D = this.f74552d4.m24950D();
            m24950D.m24890D(strArr[i]);
            this.f74552d4.m24926e(m24950D);
        }
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            this.f74552d4.setVisibility(0);
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            this.f74551c4 = null;
            if (this.f74552d4.getSelectedTabPosition() == 0) {
                compressHelper = this.f75215L3;
                bundle2 = this.f75212I3;
                str = "Select * from lab_specimen";
            } else {
                compressHelper = this.f75215L3;
                bundle2 = this.f75212I3;
                str = "Select * from lab_panel";
            }
        } else {
            appBarLayout.m27445s(false, false);
            appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOLabListActivityFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    relativeLayout.setVisibility(0);
                }
            }, 800L);
            this.f74552d4.setVisibility(8);
            CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) this.f75227X3.getLayoutParams();
            layoutParams.setMargins(0, 0, 0, 0);
            this.f75227X3.setLayoutParams(layoutParams);
            this.f74551c4 = m44859B().getString("ParentId");
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            str = "SELECT * FROM lab_topics where id in ( select topicid from lab_cats_topics where catId=" + this.f74551c4 + ")";
        }
        this.f75218O3 = compressHelper.m4955V(bundle2, str);
        this.f74552d4.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOLabListActivityFragment.2
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: a */
            public void mo4174a(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: b */
            public void mo4173b(TabLayout.Tab tab) {
                EPOLabListActivityFragment ePOLabListActivityFragment;
                CompressHelper compressHelper2;
                Bundle bundle3;
                String str2;
                if (EPOLabListActivityFragment.this.f74552d4.getSelectedTabPosition() == 0) {
                    ePOLabListActivityFragment = EPOLabListActivityFragment.this;
                    compressHelper2 = ePOLabListActivityFragment.f75215L3;
                    bundle3 = ePOLabListActivityFragment.f75212I3;
                    str2 = "Select * from lab_specimen";
                } else {
                    ePOLabListActivityFragment = EPOLabListActivityFragment.this;
                    compressHelper2 = ePOLabListActivityFragment.f75215L3;
                    bundle3 = ePOLabListActivityFragment.f75212I3;
                    str2 = "Select * from lab_panel";
                }
                ePOLabListActivityFragment.f75218O3 = compressHelper2.m4955V(bundle3, str2);
                EPOLabListActivityFragment ePOLabListActivityFragment2 = EPOLabListActivityFragment.this;
                ((ChaptersAdapter) ePOLabListActivityFragment2.f75216M3).m3404g0(ePOLabListActivityFragment2.f75218O3);
                EPOLabListActivityFragment ePOLabListActivityFragment3 = EPOLabListActivityFragment.this;
                ePOLabListActivityFragment3.f75227X3.setAdapter(ePOLabListActivityFragment3.f75216M3);
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: c */
            public void mo4172c(TabLayout.Tab tab) {
            }
        });
        this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOLabListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: f0 */
            public void mo3405f0(Bundle bundle3, int i2) {
                EPOLabListActivityFragment.this.m4330Y2();
                EPOLabListActivityFragment ePOLabListActivityFragment = EPOLabListActivityFragment.this;
                if (ePOLabListActivityFragment.f74551c4 == null) {
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("DB", EPOLabListActivityFragment.this.f75212I3);
                    bundle4.putString("ParentId", bundle3.getString("id"));
                    EPOLabListActivityFragment.this.f75215L3.m4979N(EPOLabListActivity.class, EPOLabListActivityFragment.class, bundle4);
                    return;
                }
                CompressHelper compressHelper2 = ePOLabListActivityFragment.f75215L3;
                Bundle bundle5 = ePOLabListActivityFragment.f75212I3;
                compressHelper2.m4883q1(bundle5, "lab-" + bundle3.getString("mId"), null, null);
            }
        };
        this.f74550b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOLabListActivityFragment.4
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: g0 */
            public void mo3380g0(Bundle bundle3, int i2) {
                EPOLabListActivityFragment.this.m4330Y2();
                EPOLabListActivityFragment ePOLabListActivityFragment = EPOLabListActivityFragment.this;
                CompressHelper compressHelper2 = ePOLabListActivityFragment.f75215L3;
                Bundle bundle4 = ePOLabListActivityFragment.f75212I3;
                compressHelper2.m4883q1(bundle4, "lab-" + bundle3.getString("contentId"), null, null);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle3) {
                EPOLabListActivityFragment.this.m4330Y2();
                EPOLabListActivityFragment.this.f75223T3.m51655i0(bundle3.getString("word"), true);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74550b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74550b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match 'text:" + str + "* AND typeText:Lab AND type:1'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: f3 */
    public void mo4326f3() {
        this.f75224U3.setImageDrawable(m44782a0().getDrawable(C4804R.C4807drawable.f86626labs_icon));
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "Labs";
    }
}
