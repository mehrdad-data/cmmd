package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Lexi.LXSectionsViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class EPOTableViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public ArrayList<Bundle> f74657w4;

    /* renamed from: x4 */
    public int f74658x4;

    /* renamed from: y4 */
    public String f74659y4;

    /* renamed from: A4 */
    public String m4542A4(String str) {
        return m4539z4(str, "general");
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74659y4 = "RX.sqlite";
        if (m44859B() == null) {
            return this.f75849b4;
        }
        try {
            String str = this.f75847Z3;
            if (str == null || str.length() == 0) {
                this.f74658x4 = 0;
                this.f74657w4 = new ArrayList<>();
                iMDLogger.m3294f("Loading Document", this.f75851d4);
                String str2 = this.f75851d4.split("-")[1];
                ArrayList<Bundle> m4952W = this.f75863p4.m4952W(this.f75850c4, "Select * from content_table where ID=" + str2, this.f74659y4);
                if (m4952W != null && m4952W.size() != 0) {
                    this.f75852e4 = m4952W.get(0).getString("NAME");
                    ArrayList<Bundle> m4952W2 = this.f75863p4.m4952W(this.f75850c4, "Select * from content_table_entry where table_id=" + bundle2.getString("ID") + " order by display_order asc", this.f74659y4);
                    if (m4952W2 == null) {
                        m4952W2 = new ArrayList<>();
                    }
                    Iterator<Bundle> it2 = m4952W2.iterator();
                    String str3 = "";
                    while (it2.hasNext()) {
                        Bundle next = it2.next();
                        String m4542A4 = m4542A4(next.getString("HEADER_STRING_ID"));
                        String str4 = "<div style=\"margin:10px\"><div class=\"cellTitle\">" + m4542A4(next.getString("BRACKET_STRING_ID")) + "</div><div>" + m4542A4(next.getString("MSG_STRING_ID")) + "</div></div>";
                        if (m4542A4.length() > 0) {
                            str4 = m4540y4(m4542A4, "", "LTR", str4, "", "margin-left: 5px", "");
                            m4541x4(m4542A4, this.f74658x4);
                        }
                        str3 = str3 + str4;
                    }
                    String m4117W3 = m4117W3(m44716w(), "EPOHeader.css");
                    String m4117W32 = m4117W3(m44716w(), "EPOFooter.css");
                    this.f75847Z3 = m4117W3.replace("[size]", "200").replace("[title]", this.f75852e4).replace("[include]", "") + str3.replace("..", ".") + m4117W32;
                }
                CompressHelper.m4921e2(m44716w(), "Document doesn't exist", 1);
                return this.f75849b4;
            }
            File file = new File(CompressHelper.m4948X0(this.f75850c4));
            new File(CompressHelper.m4945Y0(this.f75850c4, "test.html"));
            this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
            m4092j4();
            m4098g4();
            m4100f3(C4804R.C4811menu.f87323elsviewer2);
            m44735q2(false);
            m4140G3();
        } catch (Exception e) {
            m4080r4(e);
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86776action_menu) {
            LXSectionsViewer lXSectionsViewer = new LXSectionsViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("fields", this.f74657w4);
            lXSectionsViewer.m44751k2(bundle);
            lXSectionsViewer.m44870c3(true);
            lXSectionsViewer.m44844E2(this, 0);
            lXSectionsViewer.mo29915h3(m44820L(), "LXSectionsViewer");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        if (!this.f75863p4.m5016A1(this.f75850c4, str) && str3.contains("//current/")) {
            String str4 = StringUtils.splitByWholeSeparator(str3, "//current/")[1];
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            compressHelper.m4883q1(bundle, this.f75851d4 + "-" + str4, null, null);
        }
        return true;
    }

    /* renamed from: x4 */
    public void m4541x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f74657w4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4540y4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74658x4 + 1;
        this.f74658x4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: z4 */
    public String m4539z4(String str, String str2) {
        if (str != null && str.length() != 0) {
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4952W(bundle, "select * from " + str2 + "_string where id=" + str, this.f74659y4));
            if (m4907i1 != null && m4907i1.size() != 0) {
                return m4907i1.getString("STRING");
            }
        }
        return "";
    }
}
