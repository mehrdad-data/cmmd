package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import com.itextpdf.tool.xml.html.HTML;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class EpoDXWebViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f74660w4;

    /* renamed from: x4 */
    public JSONObject f74661x4;

    /* renamed from: y4 */
    public String f74662y4;

    /* renamed from: z4 */
    public ArrayList<Bundle> f74663z4;

    /* renamed from: x4 */
    private void m4538x4(String str) {
        ArrayList<Bundle> arrayList = this.f74663z4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        arrayList2.addAll(this.f74663z4);
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (((Bundle) arrayList2.get(i2)).getString("id").startsWith(str)) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList;
        Bundle m4073v3;
        if (this.f74663z4.size() <= 0 || (arrayList = this.f74663z4) == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f74663z4)) == null) {
            return null;
        }
        return m4073v3.getString("ImagePath");
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EpoDXWebViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    String str = EpoDXWebViewerActivityFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment = EpoDXWebViewerActivityFragment.this;
                        epoDXWebViewerActivityFragment.f75851d4 = epoDXWebViewerActivityFragment.m44859B().getString("DocAddress");
                        iMDLogger.m3294f("Loading Document", EpoDXWebViewerActivityFragment.this.f75851d4);
                        String str2 = EpoDXWebViewerActivityFragment.this.f75851d4.split("-")[1];
                        if (EpoDXWebViewerActivityFragment.this.m44859B().containsKey("mDB")) {
                            EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment2 = EpoDXWebViewerActivityFragment.this;
                            epoDXWebViewerActivityFragment2.f74662y4 = epoDXWebViewerActivityFragment2.m44859B().getString("mDB");
                        }
                        EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment3 = EpoDXWebViewerActivityFragment.this;
                        if (epoDXWebViewerActivityFragment3.f74662y4 == null) {
                            epoDXWebViewerActivityFragment3.f74662y4 = "Dx";
                        }
                        CompressHelper compressHelper = epoDXWebViewerActivityFragment3.f75863p4;
                        Bundle bundle2 = epoDXWebViewerActivityFragment3.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from " + EpoDXWebViewerActivityFragment.this.f74662y4 + "_monographs where id=" + str2);
                        if (m4955V != null && m4955V.size() != 0) {
                            JSONObject jSONObject = new JSONObject(EpoDXWebViewerActivityFragment.this.f75863p4.m5015B(m4955V.get(0).getString("monograph"), str2, "127"));
                            EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment4 = EpoDXWebViewerActivityFragment.this;
                            epoDXWebViewerActivityFragment4.f74661x4 = jSONObject;
                            epoDXWebViewerActivityFragment4.f75852e4 = epoDXWebViewerActivityFragment4.m44859B().getString("Title");
                            EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment5 = EpoDXWebViewerActivityFragment.this;
                            epoDXWebViewerActivityFragment5.f74663z4 = epoDXWebViewerActivityFragment5.m44859B().getParcelableArrayList("Images");
                            EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment6 = EpoDXWebViewerActivityFragment.this;
                            String m4117W3 = epoDXWebViewerActivityFragment6.m4117W3(epoDXWebViewerActivityFragment6.m44716w(), "EPOHeader.css");
                            EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment7 = EpoDXWebViewerActivityFragment.this;
                            String m4117W32 = epoDXWebViewerActivityFragment7.m4117W3(epoDXWebViewerActivityFragment7.m44716w(), "EPOFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", EpoDXWebViewerActivityFragment.this.f75852e4).replace("[include]", "");
                            String replace2 = EpoDXWebViewerActivityFragment.this.m44859B().getString("Html").replace("..", ".");
                            EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment8 = EpoDXWebViewerActivityFragment.this;
                            epoDXWebViewerActivityFragment8.f75847Z3 = replace + replace2 + m4117W32;
                            return;
                        }
                        EpoDXWebViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    EpoDXWebViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EpoDXWebViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = EpoDXWebViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment = EpoDXWebViewerActivityFragment.this;
                    epoDXWebViewerActivityFragment.m4078s4(epoDXWebViewerActivityFragment.f75837P3);
                    return;
                }
                EpoDXWebViewerActivityFragment epoDXWebViewerActivityFragment2 = EpoDXWebViewerActivityFragment.this;
                epoDXWebViewerActivityFragment2.f75853f4.loadDataWithBaseURL(null, epoDXWebViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                EpoDXWebViewerActivityFragment.this.m4092j4();
                EpoDXWebViewerActivityFragment.this.m4098g4();
                EpoDXWebViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87325epolistmenu);
                EpoDXWebViewerActivityFragment.this.m44735q2(false);
                EpoDXWebViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86774action_gallery) {
            m4538x4("soheilvb");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        if (this.f75863p4.m5016A1(this.f75850c4, str)) {
            return true;
        }
        if (str3.contains("//current?view=")) {
            try {
                JSONObject m4910h1 = this.f75863p4.m4910h1(this.f74661x4.getJSONArray("views"), "id", this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(str3, "//current?view=")));
                if (m4910h1 != null && m4910h1.getString("type").equals("image")) {
                    m4538x4(this.f74661x4.getJSONArray("media").getJSONObject(Integer.valueOf(m4910h1.getJSONArray("image_refs").getString(0)).intValue()).getString(Annotation.f59806M2));
                }
                return true;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                e.printStackTrace();
                return true;
            }
        } else if (!str3.contains("//current?article=")) {
            if (str2.equals("http")) {
                this.f75863p4.m4883q1(this.f75850c4, "epourl-" + str, null, null);
                return true;
            }
            return false;
        } else {
            try {
                CompressHelper compressHelper = this.f75863p4;
                Bundle bundle = this.f75850c4;
                compressHelper.m4883q1(bundle, "epohtml-" + ("<div style=\"margin:15px\">" + this.f74661x4.getJSONObject("citations").getJSONArray("articles").getJSONObject(Integer.valueOf(this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(str3, "//current?article="))).intValue() - 1).getString(HTML.Tag.f65946y) + "</div>"), null, null);
            } catch (Exception e2) {
                FirebaseCrashlytics.m18030d().m18027g(e2);
                e2.printStackTrace();
            }
            return true;
        }
    }
}
