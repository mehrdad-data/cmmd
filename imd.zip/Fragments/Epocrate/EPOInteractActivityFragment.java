package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.extractor.p010ts.TsExtractor;
import com.google.android.material.appbar.AppBarLayout;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.ObservableEmitter;
import io.reactivex.rxjava3.core.ObservableOnSubscribe;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullDeleteViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.helper.StringUtil;

/* loaded from: classes2.dex */
public class EPOInteractActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74494b4;

    /* renamed from: c4 */
    public ArrayList<Bundle> f74495c4;

    /* renamed from: d4 */
    public Button f74496d4;

    /* renamed from: e4 */
    public String f74497e4;

    /* renamed from: f4 */
    public ArrayList<String> f74498f4;

    /* renamed from: g4 */
    public ArrayList<Bundle> f74499g4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87149fragment_epointeract, viewGroup, false);
        this.f74495c4 = new ArrayList<>();
        this.f74498f4 = new ArrayList<>();
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f74497e4 = "RX.sqlite";
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        appBarLayout.m27445s(false, false);
        appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                relativeLayout.setVisibility(0);
            }
        }, 800L);
        Button button = (Button) this.f75221R3.findViewById(C4804R.C4808id.f87006result_button);
        this.f74496d4 = button;
        button.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (EPOInteractActivityFragment.this.f74495c4.size() > 0) {
                    new Bundle().putParcelableArrayList("Items", EPOInteractActivityFragment.this.f74495c4);
                    ArrayList arrayList = new ArrayList();
                    Iterator<Bundle> it2 = EPOInteractActivityFragment.this.f74495c4.iterator();
                    while (it2.hasNext()) {
                        Bundle next = it2.next();
                        String string = next.getString("text");
                        String m4588m3 = EPOInteractActivityFragment.this.m4588m3(next.getString("contentId"));
                        arrayList.add(m4588m3 + ",,,,," + string);
                    }
                    EPOInteractActivityFragment ePOInteractActivityFragment = EPOInteractActivityFragment.this;
                    CompressHelper compressHelper = ePOInteractActivityFragment.f75215L3;
                    Bundle bundle2 = ePOInteractActivityFragment.f75212I3;
                    compressHelper.m4883q1(bundle2, "interactresult-" + StringUtil.m897g(arrayList, ";;;;;"), null, null);
                }
            }
        });
        ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f74495c4, "title", C4804R.C4810layout.f87266list_view_item_ripple_text_full_delete) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullDeleteViewHolder rippleTextFullDeleteViewHolder = (RippleTextFullDeleteViewHolder) viewHolder;
                rippleTextFullDeleteViewHolder.f83278I.setText(bundle2.getString("text"));
                rippleTextFullDeleteViewHolder.f83279J.setText(bundle2.getString("content"));
                rippleTextFullDeleteViewHolder.f83283N.setVisibility(0);
                rippleTextFullDeleteViewHolder.f83281L.setVisibility(0);
                if (bundle2.getString("content").length() == 0) {
                    rippleTextFullDeleteViewHolder.f83279J.setVisibility(8);
                } else {
                    rippleTextFullDeleteViewHolder.f83279J.setVisibility(0);
                }
                String string = bundle2.getString("type");
                rippleTextFullDeleteViewHolder.f83280K.setImageDrawable(EPOInteractActivityFragment.this.m44716w().getResources().getDrawable(string.equals("7") ? C4804R.C4807drawable.f86677plus_alt : string.equals("6") ? C4804R.C4807drawable.f86688plus_otc : C4804R.C4807drawable.f86691plus_rx));
                final String m4588m3 = EPOInteractActivityFragment.this.m4588m3(bundle2.getString("contentId"));
                rippleTextFullDeleteViewHolder.f83282M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.3.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPOInteractActivityFragment.this.m4330Y2();
                        EPOInteractActivityFragment ePOInteractActivityFragment = EPOInteractActivityFragment.this;
                        CompressHelper compressHelper = ePOInteractActivityFragment.f75215L3;
                        Bundle bundle3 = ePOInteractActivityFragment.f75212I3;
                        compressHelper.m4883q1(bundle3, "interact-" + m4588m3, null, null);
                    }
                });
                rippleTextFullDeleteViewHolder.f83283N.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.3.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPOInteractActivityFragment.this.f74495c4.remove(bundle2);
                        EPOInteractActivityFragment.this.f74498f4.remove(m4588m3);
                        EPOInteractActivityFragment ePOInteractActivityFragment = EPOInteractActivityFragment.this;
                        ((ChaptersAdapter) ePOInteractActivityFragment.f75216M3).m3404g0(ePOInteractActivityFragment.f74495c4);
                        EPOInteractActivityFragment.this.m4589l3();
                        EPOInteractActivityFragment.this.f75216M3.m42860G();
                        EPOInteractActivityFragment ePOInteractActivityFragment2 = EPOInteractActivityFragment.this;
                        ePOInteractActivityFragment2.f75227X3.setAdapter(ePOInteractActivityFragment2.f75216M3);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new RippleTextFullDeleteViewHolder(view);
            }
        };
        this.f75216M3 = chaptersAdapter;
        chaptersAdapter.f83219h = "Search To Add Drug";
        this.f74494b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.4
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle2.getString("text"));
                rippleTextFullViewHolder.f83285J.setText(bundle2.getString("content"));
                rippleTextFullViewHolder.f83287L.setVisibility(8);
                if (bundle2.getString("content").length() == 0) {
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                } else {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                }
                String string = bundle2.getString("type");
                rippleTextFullViewHolder.f83286K.setImageDrawable(EPOInteractActivityFragment.this.m44716w().getResources().getDrawable(string.equals("7") ? C4804R.C4807drawable.f86677plus_alt : string.equals("6") ? C4804R.C4807drawable.f86688plus_otc : C4804R.C4807drawable.f86691plus_rx));
                final String m4588m3 = EPOInteractActivityFragment.this.m4588m3(bundle2.getString("contentId"));
                if (EPOInteractActivityFragment.this.f74498f4.contains(m4588m3)) {
                    rippleTextFullViewHolder.f83284I.setTextColor(Color.rgb((int) TsExtractor.f35065I, (int) TsExtractor.f35065I, (int) TsExtractor.f35065I));
                    return;
                }
                rippleTextFullViewHolder.f83284I.setTextColor(Color.rgb(0, 0, 0));
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.4.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        EPOInteractActivityFragment.this.m4330Y2();
                        EPOInteractActivityFragment.this.f74495c4.add(bundle2);
                        EPOInteractActivityFragment.this.f74498f4.add(m4588m3);
                        EPOInteractActivityFragment.this.m4589l3();
                        EPOInteractActivityFragment.this.f75223T3.m51655i0("", false);
                        EPOInteractActivityFragment ePOInteractActivityFragment = EPOInteractActivityFragment.this;
                        ((ChaptersAdapter) ePOInteractActivityFragment.f75216M3).m3404g0(ePOInteractActivityFragment.f74495c4);
                        EPOInteractActivityFragment.this.f75216M3.m42860G();
                        EPOInteractActivityFragment ePOInteractActivityFragment2 = EPOInteractActivityFragment.this;
                        ePOInteractActivityFragment2.f75227X3.setAdapter(ePOInteractActivityFragment2.f75216M3);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle2) {
                EPOInteractActivityFragment.this.m4330Y2();
                EPOInteractActivityFragment.this.f75223T3.m51655i0(bundle2.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                return new RippleTextFullViewHolder(view);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74494b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74494b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match '(text:" + str + "* OR content:" + str + "*) AND typeText:RX NOT (type:5)'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: f3 */
    public void mo4326f3() {
        this.f75224U3.setImageDrawable(m44782a0().getDrawable(C4804R.C4807drawable.f86616interaction_check_icon));
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "Drug Interactions";
    }

    /* renamed from: l3 */
    public void m4589l3() {
        Observable.m7156x1(new ObservableOnSubscribe<String>() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.5
            @Override // io.reactivex.rxjava3.core.ObservableOnSubscribe
            /* renamed from: a */
            public void mo3518a(@NonNull ObservableEmitter<String> observableEmitter) throws Throwable {
                EPOInteractActivityFragment.this.f74499g4 = new ArrayList<>();
                ArrayList<String> arrayList = EPOInteractActivityFragment.this.f74498f4;
                if (arrayList != null && arrayList.size() > 0) {
                    String join = StringUtils.join(EPOInteractActivityFragment.this.f74498f4, ",");
                    EPOInteractActivityFragment ePOInteractActivityFragment = EPOInteractActivityFragment.this;
                    CompressHelper compressHelper = ePOInteractActivityFragment.f75215L3;
                    Bundle bundle = ePOInteractActivityFragment.f75212I3;
                    ePOInteractActivityFragment.f74499g4 = compressHelper.m4949X(bundle, "SELECT                     ID,                     DRUG_ID AS DRUG_0_ID,                     INTERACTING_DRUG_ID AS DRUG_1_ID,                     DDI_ID,                     GROUP_0_ID,                     GROUP_1_ID                     FROM (                     SELECT DISTINCT                     tDID.ID,                     MIN(d1.ID, d2.ID) AS DRUG_ID,                     MAX(d1.ID, d2.ID) AS INTERACTING_DRUG_ID,                     tDID.DDI_ID,                     DDI.GROUP_0_ID,                     DDI.GROUP_1_ID                     FROM                     DRUG_TO_INTERACTING_DRUG tDID                     JOIN DDI ON tDID.DDI_ID = DDI.ID                     JOIN DRUG d1 ON d1.ID = tDID.DRUG_0_ID OR d1.GENERIC_ID = tDID.DRUG_0_ID OR d1.ID = tDID.DRUG_1_ID OR d1.GENERIC_ID = tDID.DRUG_1_ID                     JOIN DRUG d2 ON                     CASE WHEN d1.ID = tDID.DRUG_0_ID OR d1.GENERIC_ID = tDID.DRUG_0_ID                     THEN d2.ID = tDID.DRUG_1_ID OR d2.GENERIC_ID = tDID.DRUG_1_ID                     ELSE d2.ID = tDID.DRUG_0_ID OR d2.GENERIC_ID = tDID.DRUG_0_ID                     END                     WHERE                     tDID.DRUG_0_ID IN (" + join + ")                     AND                     tDID.DRUG_1_ID IN (" + join + ")                     AND                     DRUG_0_ID <> DRUG_1_ID                     AND                     d1.ID IN (" + join + ")                     AND                     d2.ID IN (" + join + ")                     ORDER BY CATEGORY_ID, d1.name, d2.name                     ) ", EPOInteractActivityFragment.this.f74497e4, true);
                }
                observableEmitter.onNext("asdf");
            }
        }).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7329f6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.6
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(String str) throws Throwable {
                if (EPOInteractActivityFragment.this.f74499g4.size() == 0) {
                    EPOInteractActivityFragment.this.f74496d4.setEnabled(false);
                    EPOInteractActivityFragment.this.f74496d4.setBackgroundColor(Color.rgb(100, 100, 100));
                    EPOInteractActivityFragment.this.f74496d4.setText("Nothing Found");
                    return;
                }
                Button button = EPOInteractActivityFragment.this.f74496d4;
                button.setText(EPOInteractActivityFragment.this.f74499g4.size() + " Interactions Found");
                EPOInteractActivityFragment.this.f74496d4.setEnabled(true);
                EPOInteractActivityFragment.this.f74496d4.setBackgroundColor(Color.rgb(64, 140, 83));
            }
        }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractActivityFragment.7
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(Throwable th) throws Throwable {
            }
        });
    }

    /* renamed from: m3 */
    public String m4588m3(String str) {
        return str.contains("-") ? str.split("-")[1] : str;
    }
}
