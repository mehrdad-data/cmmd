package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;

/* loaded from: classes2.dex */
public class EPOHTMLViewer extends ViewerHelperActivity {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new EPOHTMLViewerFragment(), bundle);
    }
}
