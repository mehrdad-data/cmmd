package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import com.itextpdf.tool.xml.css.CSS;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Lexi.LXSectionsViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class EPODxViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public ArrayList<Bundle> f74466A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f74467B4;

    /* renamed from: w4 */
    public String f74468w4;

    /* renamed from: x4 */
    public Bundle f74469x4;

    /* renamed from: y4 */
    public JSONObject f74470y4;

    /* renamed from: z4 */
    public int f74471z4;

    /* renamed from: D4 */
    private void m4597D4(String str) {
        ArrayList<Bundle> arrayList = this.f74466A4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        arrayList2.addAll(this.f74466A4);
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (((Bundle) arrayList2.get(i2)).getString("id").startsWith(str)) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public String m4600A4(JSONObject jSONObject, int i) {
        JSONObject jSONObject2;
        String str;
        StringBuilder sb;
        String str2;
        String str3;
        String str4;
        int i2;
        int i3;
        String str5;
        String str6;
        String str7;
        JSONObject jSONObject3;
        String str8;
        String sb2;
        String str9 = "flag";
        String str10 = "cells";
        String str11 = "sections";
        String str12 = "title";
        try {
            if (jSONObject.has("targetHTML")) {
                return jSONObject.getString("targetHTML");
            }
            String str13 = "";
            if (jSONObject.has(TypedValues.Attributes.f5596M)) {
                JSONObject m4910h1 = this.f75863p4.m4910h1(this.f74470y4.getJSONArray("views"), "id", jSONObject.getString(TypedValues.Attributes.f5596M));
                if (m4910h1.getString("type").equals("web")) {
                    return m4910h1.getString(HTML.Tag.f65946y);
                }
                String str14 = "";
                int i4 = 0;
                while (i4 < m4910h1.getJSONArray(str11).length()) {
                    JSONObject jSONObject4 = m4910h1.getJSONArray(str11).getJSONObject(i4);
                    String str15 = str13;
                    int i5 = 0;
                    while (true) {
                        jSONObject2 = m4910h1;
                        str = str14;
                        if (i5 >= jSONObject4.getJSONArray(str10).length()) {
                            break;
                        }
                        JSONObject jSONObject5 = jSONObject4.getJSONArray(str10).getJSONObject(i5);
                        int i6 = i5;
                        String m4600A4 = m4600A4(jSONObject5, i + 1);
                        if (jSONObject5.has(str12)) {
                            JSONObject jSONObject6 = jSONObject4;
                            String string = jSONObject5.getString(str12);
                            int i7 = i4;
                            String str16 = str13;
                            if (jSONObject5.has(str9)) {
                                str8 = str12;
                                StringBuilder sb3 = new StringBuilder();
                                str2 = str10;
                                sb3.append("orb");
                                sb3.append(jSONObject5.getString(str9));
                                sb3.append(".png");
                                string = "<div style=\"display: flex; align-items: center\"><img src=\"" + ("file:///android_asset/" + sb3.toString()) + "\" style=\"margin:2px;width: 100%%;max-width:25px\"/>" + string + "</div>";
                            } else {
                                str8 = str12;
                                str2 = str10;
                            }
                            if (m4600A4.length() <= 0) {
                                i2 = i6;
                                str6 = str8;
                                str7 = str9;
                                jSONObject3 = jSONObject6;
                                str3 = str11;
                                str5 = str16;
                                str4 = str;
                                i3 = i7;
                                if (jSONObject5.has("targetURL")) {
                                    String string2 = jSONObject5.getString("targetURL");
                                    String str17 = "file:///android_asset/" + (string2.contains("rx/monograph/") ? "plus_rx.png" : string2.contains("dx/monograph/") ? "plus_dx.png" : string2.contains("lab/monograph/") ? "plus_lab.png" : string2.contains("lab/list/panel/") ? "plus_panel.png" : str5);
                                    StringBuilder sb4 = new StringBuilder();
                                    sb4.append(str15);
                                    sb4.append(m4594z4("<div style=\"display: flex; align-items: center\"><img src=\"" + str17 + "\" style=\"margin:2px;width: 100%%;max-width:25px\"/><a href=\"" + jSONObject5.getString("targetURL") + "\">" + jSONObject5.getString(str6) + "</a></div>", str5, "margin-left: " + (i * 5) + CSS.Value.f65645h0, str5));
                                    sb2 = sb4.toString();
                                } else {
                                    StringBuilder sb5 = new StringBuilder();
                                    sb5.append(str15);
                                    sb5.append(m4594z4(jSONObject5.getString(str6), str5, "margin-left: " + (i * 5) + CSS.Value.f65645h0, str5));
                                    sb2 = sb5.toString();
                                }
                            } else if (i < 2) {
                                StringBuilder sb6 = new StringBuilder();
                                sb6.append(str15);
                                i2 = i6;
                                str7 = str9;
                                jSONObject3 = jSONObject6;
                                str3 = str11;
                                i3 = i7;
                                str4 = str;
                                str5 = str16;
                                sb6.append(m4598C4(string, "", "LTR", m4600A4, "", "margin-left: " + (i * 5) + CSS.Value.f65645h0, ""));
                                sb2 = sb6.toString();
                                str6 = str8;
                            } else {
                                i2 = i6;
                                str6 = str8;
                                str7 = str9;
                                jSONObject3 = jSONObject6;
                                str3 = str11;
                                str5 = str16;
                                str4 = str;
                                i3 = i7;
                                StringBuilder sb7 = new StringBuilder();
                                sb7.append(str15);
                                sb7.append(m4595y4(string, "", "LTR", m4600A4, "", "margin-left: " + (i * 5) + CSS.Value.f65645h0, ""));
                                sb2 = sb7.toString();
                            }
                            str15 = sb2;
                        } else {
                            str2 = str10;
                            str3 = str11;
                            str4 = str;
                            i2 = i6;
                            i3 = i4;
                            str5 = str13;
                            str6 = str12;
                            str7 = str9;
                            jSONObject3 = jSONObject4;
                            str15 = str15 + m4600A4;
                        }
                        i5 = i2 + 1;
                        m4910h1 = jSONObject2;
                        jSONObject4 = jSONObject3;
                        str12 = str6;
                        str13 = str5;
                        i4 = i3;
                        str9 = str7;
                        str11 = str3;
                        str14 = str4;
                        str10 = str2;
                    }
                    String str18 = str9;
                    String str19 = str10;
                    String str20 = str11;
                    JSONObject jSONObject7 = jSONObject4;
                    int i8 = i4;
                    String str21 = str13;
                    String str22 = str12;
                    if (!jSONObject7.has("headerText")) {
                        sb = new StringBuilder();
                        sb.append(str);
                        sb.append(str15);
                    } else if (i < 2) {
                        StringBuilder sb8 = new StringBuilder();
                        sb8.append(str);
                        sb = sb8;
                        sb.append(m4598C4(jSONObject7.getString("headerText"), "", "LTR", str15, "", "margin-left: " + (i * 5) + CSS.Value.f65645h0, ""));
                    } else {
                        StringBuilder sb9 = new StringBuilder();
                        sb9.append(str);
                        sb = sb9;
                        sb.append(m4595y4(jSONObject7.getString("headerText"), "", "LTR", str15, "", "margin-left: " + (i * 5) + CSS.Value.f65645h0, ""));
                    }
                    str14 = sb.toString();
                    i4 = i8 + 1;
                    m4910h1 = jSONObject2;
                    str12 = str22;
                    str13 = str21;
                    str9 = str18;
                    str11 = str20;
                    str10 = str19;
                }
                return str14;
            }
            return "";
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            e.printStackTrace();
            return null;
        }
    }

    /* renamed from: B4 */
    public String m4599B4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74471z4 + 1;
        this.f74471z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: C3 */
    public void mo4144C3(String str) {
        iMDLogger.m3290j("Gotosection", str);
        WebView webView = this.f75853f4;
        webView.loadUrl("javascript:document.getElementById(\"" + str + "\").scrollIntoView(true);document.body.scrollTop = window.pageYOffset - 50;");
    }

    /* renamed from: C4 */
    public String m4598C4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74471z4 + 1;
        this.f74471z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded2\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded2(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList;
        Bundle m4073v3;
        if (this.f74466A4.size() <= 0 || (arrayList = this.f74466A4) == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f74466A4)) == null) {
            return null;
        }
        return m4073v3.getString("ImagePath");
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPODxViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                JSONObject jSONObject;
                String str;
                String str2 = "cells";
                String str3 = "sections";
                String str4 = "title";
                String str5 = "";
                try {
                    String str6 = EPODxViewerActivityFragment.this.f75847Z3;
                    if (str6 == null || str6.length() == 0) {
                        EPODxViewerActivityFragment ePODxViewerActivityFragment = EPODxViewerActivityFragment.this;
                        ePODxViewerActivityFragment.f74471z4 = 0;
                        ePODxViewerActivityFragment.f74467B4 = new ArrayList<>();
                        iMDLogger.m3294f("Loading Document", EPODxViewerActivityFragment.this.f75851d4);
                        String str7 = EPODxViewerActivityFragment.this.f75851d4.split("-")[1];
                        if (EPODxViewerActivityFragment.this.m44859B().containsKey("mDB")) {
                            EPODxViewerActivityFragment ePODxViewerActivityFragment2 = EPODxViewerActivityFragment.this;
                            ePODxViewerActivityFragment2.f74468w4 = ePODxViewerActivityFragment2.m44859B().getString("mDB");
                        }
                        EPODxViewerActivityFragment ePODxViewerActivityFragment3 = EPODxViewerActivityFragment.this;
                        if (ePODxViewerActivityFragment3.f74468w4 == null) {
                            ePODxViewerActivityFragment3.f74468w4 = "Dx";
                        }
                        ArrayList<Bundle> m4955V = ePODxViewerActivityFragment3.f75863p4.m4955V(ePODxViewerActivityFragment3.f75850c4, "Select * from " + EPODxViewerActivityFragment.this.f74468w4 + "_monographs where id=" + str7);
                        if (m4955V != null && m4955V.size() != 0) {
                            EPODxViewerActivityFragment.this.f74469x4 = m4955V.get(0);
                            EPODxViewerActivityFragment ePODxViewerActivityFragment4 = EPODxViewerActivityFragment.this;
                            EPODxViewerActivityFragment.this.f74470y4 = new JSONObject(ePODxViewerActivityFragment4.f75863p4.m5015B(ePODxViewerActivityFragment4.f74469x4.getString("monograph"), str7, "127"));
                            EPODxViewerActivityFragment ePODxViewerActivityFragment5 = EPODxViewerActivityFragment.this;
                            ePODxViewerActivityFragment5.f75852e4 = ePODxViewerActivityFragment5.f74470y4.getString("title");
                            EPODxViewerActivityFragment ePODxViewerActivityFragment6 = EPODxViewerActivityFragment.this;
                            JSONObject m4910h1 = ePODxViewerActivityFragment6.f75863p4.m4910h1(ePODxViewerActivityFragment6.f74470y4.getJSONArray("views"), "id", "root");
                            EPODxViewerActivityFragment ePODxViewerActivityFragment7 = EPODxViewerActivityFragment.this;
                            String m4117W3 = ePODxViewerActivityFragment7.m4117W3(ePODxViewerActivityFragment7.m44716w(), "EPOHeader.css");
                            EPODxViewerActivityFragment ePODxViewerActivityFragment8 = EPODxViewerActivityFragment.this;
                            String m4117W32 = ePODxViewerActivityFragment8.m4117W3(ePODxViewerActivityFragment8.m44716w(), "EPOFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", EPODxViewerActivityFragment.this.f75852e4).replace("[include]", "");
                            String str8 = "";
                            int i = 0;
                            while (i < m4910h1.getJSONArray(str3).length()) {
                                JSONObject jSONObject2 = m4910h1.getJSONArray(str3).getJSONObject(i);
                                int i2 = 0;
                                while (true) {
                                    str = str3;
                                    if (i2 < jSONObject2.getJSONArray(str2).length()) {
                                        JSONObject jSONObject3 = jSONObject2.getJSONArray(str2).getJSONObject(i2);
                                        String str9 = str2;
                                        String string = jSONObject3.getString(str4);
                                        String replace2 = EPODxViewerActivityFragment.this.m4600A4(jSONObject3, 1).replace("<html>", "").replace("</html>", "");
                                        str8 = str8 + EPODxViewerActivityFragment.this.m4599B4(string, "", "LTR", replace2, "", "", "");
                                        EPODxViewerActivityFragment ePODxViewerActivityFragment9 = EPODxViewerActivityFragment.this;
                                        ePODxViewerActivityFragment9.m4596x4(string, ePODxViewerActivityFragment9.f74471z4);
                                        i2++;
                                        str2 = str9;
                                        str3 = str;
                                        str4 = str4;
                                        m4910h1 = m4910h1;
                                    }
                                }
                                i++;
                                str3 = str;
                                m4910h1 = m4910h1;
                            }
                            if (EPODxViewerActivityFragment.this.f74470y4.has("citations") && EPODxViewerActivityFragment.this.f74470y4.getJSONObject("citations").has("articles")) {
                                for (int i3 = 0; i3 < EPODxViewerActivityFragment.this.f74470y4.getJSONObject("citations").getJSONArray("articles").length(); i3++) {
                                    JSONObject jSONObject4 = EPODxViewerActivityFragment.this.f74470y4.getJSONObject("citations").getJSONArray("articles").getJSONObject(i3);
                                    str5 = str5 + "<div id=\"articleCitation" + jSONObject4.getString("id") + "\" style=\"margin:10px\"><b>" + jSONObject4.getString("id") + ": </b>" + jSONObject4.getString(HTML.Tag.f65946y) + "</div>";
                                }
                                if (str5.length() > 0) {
                                    str8 = str8 + EPODxViewerActivityFragment.this.m4599B4("Citations", "", "LTR", str5, "", "", "");
                                    EPODxViewerActivityFragment ePODxViewerActivityFragment10 = EPODxViewerActivityFragment.this;
                                    ePODxViewerActivityFragment10.m4596x4("Citations", ePODxViewerActivityFragment10.f74471z4);
                                }
                            }
                            ArrayList<Bundle> arrayList = new ArrayList<>();
                            if (EPODxViewerActivityFragment.this.f74470y4.has("media")) {
                                for (int i4 = 0; i4 < EPODxViewerActivityFragment.this.f74470y4.getJSONArray("media").length(); i4++) {
                                    String string2 = EPODxViewerActivityFragment.this.f74470y4.getJSONArray("media").getJSONObject(i4).getString(Annotation.f59806M2);
                                    String m4942Z0 = CompressHelper.m4942Z0(EPODxViewerActivityFragment.this.f75850c4, string2, "pictures");
                                    if (new File(m4942Z0).exists()) {
                                        Bundle bundle2 = new Bundle();
                                        bundle2.putString("ImagePath", m4942Z0);
                                        bundle2.putString("id", string2);
                                        bundle2.putString("Description", jSONObject.getString(HTML.Tag.f65910g) + "\n" + jSONObject.getString("source"));
                                        arrayList.add(bundle2);
                                    }
                                }
                            }
                            EPODxViewerActivityFragment.this.f74466A4 = arrayList;
                            String replace3 = str8.replace("..", ".");
                            EPODxViewerActivityFragment.this.f75847Z3 = replace + replace3 + m4117W32;
                            return;
                        }
                        EPODxViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    EPODxViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPODxViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = EPODxViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    EPODxViewerActivityFragment ePODxViewerActivityFragment = EPODxViewerActivityFragment.this;
                    ePODxViewerActivityFragment.m4078s4(ePODxViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4948X0(EPODxViewerActivityFragment.this.f75850c4));
                EPODxViewerActivityFragment ePODxViewerActivityFragment2 = EPODxViewerActivityFragment.this;
                ePODxViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", ePODxViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                EPODxViewerActivityFragment.this.m4092j4();
                EPODxViewerActivityFragment.this.m4098g4();
                EPODxViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                EPODxViewerActivityFragment.this.m44735q2(false);
                EPODxViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4597D4("soheilvb");
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            LXSectionsViewer lXSectionsViewer = new LXSectionsViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("fields", this.f74467B4);
            lXSectionsViewer.m44751k2(bundle);
            lXSectionsViewer.m44870c3(true);
            lXSectionsViewer.m44844E2(this, 0);
            lXSectionsViewer.mo29915h3(m44820L(), "LXSectionsViewer");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        if (this.f75863p4.m5016A1(this.f75850c4, str)) {
            return true;
        }
        if (str3.contains("//current?view=")) {
            try {
                JSONObject m4910h1 = this.f75863p4.m4910h1(this.f74470y4.getJSONArray("views"), "id", this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(str3, "//current?view=")));
                if (m4910h1 != null && m4910h1.getString("type").equals("image")) {
                    m4597D4(this.f74470y4.getJSONArray("media").getJSONObject(Integer.valueOf(m4910h1.getJSONArray("image_refs").getString(0)).intValue()).getString(Annotation.f59806M2));
                }
                return true;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                e.printStackTrace();
                return true;
            }
        } else if (!str3.contains("//current?article=")) {
            if (str2.equals("http")) {
                this.f75863p4.m4883q1(this.f75850c4, "epourl-" + str, null, null);
                return true;
            }
            return false;
        } else {
            try {
                CompressHelper compressHelper = this.f75863p4;
                Bundle bundle = this.f75850c4;
                compressHelper.m4883q1(bundle, "epohtml-" + ("<div style=\"margin:15px\">" + this.f74470y4.getJSONObject("citations").getJSONArray("articles").getJSONObject(Integer.valueOf(this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(str3, "//current?article="))).intValue() - 1).getString(HTML.Tag.f65946y) + "</div>"), null, null);
            } catch (Exception e2) {
                FirebaseCrashlytics.m18030d().m18027g(e2);
                e2.printStackTrace();
            }
            return true;
        }
    }

    /* renamed from: x4 */
    public void m4596x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f74467B4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4595y4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74471z4 + 1;
        this.f74471z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded3\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded3(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: z4 */
    public String m4594z4(String str, String str2, String str3, String str4) {
        int i = this.f74471z4 + 1;
        this.f74471z4 = i;
        String valueOf = String.valueOf(i);
        return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
    }
}
