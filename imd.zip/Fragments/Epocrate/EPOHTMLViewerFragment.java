package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;

/* loaded from: classes2.dex */
public class EPOHTMLViewerFragment extends ViewerHelperFragment {
    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87206fragment_webview, viewGroup, false);
        this.f75849b4 = inflate;
        this.f75853f4 = (WebView) inflate.findViewById(C4804R.C4808id.f87082webView);
        this.f75863p4 = new CompressHelper(m44716w());
        this.f75850c4 = m44859B().getBundle("DB");
        String string = m44859B().getString("Type");
        String string2 = m44859B().getString("URL");
        if (!string.equals(HTML.Tag.f65946y)) {
            if (string.equals("url")) {
                this.f75853f4.loadUrl(string2.replace("epourl-", ""));
            }
            return this.f75849b4;
        }
        String replace = string2.replace("epohtml-", "");
        try {
            String m4117W3 = m4117W3(m44716w(), "EPOHeader.css");
            String m4117W32 = m4117W3(m44716w(), "EPOFooter.css");
            String replace2 = m4117W3.replace("[size]", "200").replace("[include]", "");
            this.f75853f4.loadData((replace2 + replace + m4117W32).replace("..", "."), "text/html", null);
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            e.printStackTrace();
        }
        m4092j4();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        if (!this.f75863p4.m5016A1(this.f75850c4, str) && str2.equals("http")) {
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            compressHelper.m4883q1(bundle, "epourl-" + str, null, null);
        }
        return true;
    }
}
