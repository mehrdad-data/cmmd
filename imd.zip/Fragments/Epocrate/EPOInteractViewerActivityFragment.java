package net.imedicaldoctor.imd.Fragments.Epocrate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.bumptech.glide.Glide;
import java.io.File;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;

/* loaded from: classes2.dex */
public class EPOInteractViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public ArrayList<Bundle> f74545w4;

    /* renamed from: x4 */
    public String f74546x4;

    /* renamed from: y4 */
    public int f74547y4;

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        this.f74546x4 = "RX.sqlite";
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                Bundle m4907i1;
                String str;
                String str2;
                try {
                    String str3 = EPOInteractViewerActivityFragment.this.f75847Z3;
                    if (str3 == null || str3.length() == 0) {
                        EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment = EPOInteractViewerActivityFragment.this;
                        ePOInteractViewerActivityFragment.f74547y4 = 0;
                        String[] split = ePOInteractViewerActivityFragment.f75851d4.split("-");
                        if (split.length == 3) {
                            String str4 = split[1];
                            String str5 = split[2];
                            EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment2 = EPOInteractViewerActivityFragment.this;
                            CompressHelper compressHelper = ePOInteractViewerActivityFragment2.f75863p4;
                            Bundle m4907i12 = compressHelper.m4907i1(compressHelper.m4952W(ePOInteractViewerActivityFragment2.f75850c4, "SELECT                     ID,                     DRUG_ID AS DRUG_0_ID,                     INTERACTING_DRUG_ID AS DRUG_1_ID,                     DDI_ID,                     GROUP_0_ID,                     GROUP_1_ID                     FROM (                     SELECT DISTINCT                     tDID.ID,                     MIN(d1.ID, d2.ID) AS DRUG_ID,                     MAX(d1.ID, d2.ID) AS INTERACTING_DRUG_ID,                     tDID.DDI_ID,                     DDI.GROUP_0_ID,                     DDI.GROUP_1_ID                     FROM                     DRUG_TO_INTERACTING_DRUG tDID                     JOIN DDI ON tDID.DDI_ID = DDI.ID                     JOIN DRUG d1 ON d1.ID = tDID.DRUG_0_ID OR d1.GENERIC_ID = tDID.DRUG_0_ID OR d1.ID = tDID.DRUG_1_ID OR d1.GENERIC_ID = tDID.DRUG_1_ID                     JOIN DRUG d2 ON                     CASE WHEN d1.ID = tDID.DRUG_0_ID OR d1.GENERIC_ID = tDID.DRUG_0_ID                     THEN d2.ID = tDID.DRUG_1_ID OR d2.GENERIC_ID = tDID.DRUG_1_ID                     ELSE d2.ID = tDID.DRUG_0_ID OR d2.GENERIC_ID = tDID.DRUG_0_ID                     END                     WHERE                     tDID.DRUG_0_ID IN (" + str4 + ", " + str5 + ")                     AND                     tDID.DRUG_1_ID IN (" + str4 + ", " + str5 + ")                     AND                     DRUG_0_ID <> DRUG_1_ID                     AND                     d1.ID IN (" + str4 + ", " + str5 + ")                     AND                     d2.ID IN (" + str4 + ", " + str5 + ")                     ORDER BY CATEGORY_ID, d1.name, d2.name                     )", EPOInteractViewerActivityFragment.this.f74546x4));
                            String string = m4907i12.getString("DRUG_0_ID");
                            String string2 = m4907i12.getString("DRUG_1_ID");
                            String string3 = m4907i12.getString("DDI_ID");
                            EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment3 = EPOInteractViewerActivityFragment.this;
                            CompressHelper compressHelper2 = ePOInteractViewerActivityFragment3.f75863p4;
                            Bundle bundle2 = ePOInteractViewerActivityFragment3.f75850c4;
                            StringBuilder sb = new StringBuilder();
                            sb.append("Select * from Drug where ID=");
                            sb.append(string);
                            str = compressHelper2.m4907i1(compressHelper2.m4952W(bundle2, sb.toString(), EPOInteractViewerActivityFragment.this.f74546x4)).getString("NAME");
                            EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment4 = EPOInteractViewerActivityFragment.this;
                            CompressHelper compressHelper3 = ePOInteractViewerActivityFragment4.f75863p4;
                            Bundle bundle3 = ePOInteractViewerActivityFragment4.f75850c4;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Select * from Drug where ID=");
                            sb2.append(string2);
                            String string4 = compressHelper3.m4907i1(compressHelper3.m4952W(bundle3, sb2.toString(), EPOInteractViewerActivityFragment.this.f74546x4)).getString("NAME");
                            EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment5 = EPOInteractViewerActivityFragment.this;
                            CompressHelper compressHelper4 = ePOInteractViewerActivityFragment5.f75863p4;
                            Bundle bundle4 = ePOInteractViewerActivityFragment5.f75850c4;
                            StringBuilder sb3 = new StringBuilder();
                            str2 = string4;
                            sb3.append("SELECT  DDI.ID ,  DDI.GROUP_0_ID ,  DDI.GROUP_1_ID ,  DDI.CATEGORY_ID ,  DDI.ACTION_STRING_ID ,  DDI.EFFECT_STRING_ID ,  DDI.MECHANISM_STRING_ID   FROM DDI   WHERE  ID =  ");
                            sb3.append(string3);
                            m4907i1 = compressHelper4.m4907i1(compressHelper4.m4952W(bundle4, sb3.toString(), EPOInteractViewerActivityFragment.this.f74546x4));
                            EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment6 = EPOInteractViewerActivityFragment.this;
                            ePOInteractViewerActivityFragment6.f74545w4 = ePOInteractViewerActivityFragment6.f75863p4.m4949X(ePOInteractViewerActivityFragment6.f75850c4, "Select * from pill_pictures where drug_id=" + string + " OR drug_id=" + string2, EPOInteractViewerActivityFragment.this.f74546x4, true);
                        } else {
                            String str6 = split[1];
                            EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment7 = EPOInteractViewerActivityFragment.this;
                            CompressHelper compressHelper5 = ePOInteractViewerActivityFragment7.f75863p4;
                            m4907i1 = compressHelper5.m4907i1(compressHelper5.m4952W(ePOInteractViewerActivityFragment7.f75850c4, "SELECT  DDI.ID ,  DDI.GROUP_0_ID ,  DDI.GROUP_1_ID ,  DDI.CATEGORY_ID ,  DDI.ACTION_STRING_ID ,  DDI.EFFECT_STRING_ID ,  DDI.MECHANISM_STRING_ID   FROM DDI   WHERE  ID = " + str6, EPOInteractViewerActivityFragment.this.f74546x4));
                            EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment8 = EPOInteractViewerActivityFragment.this;
                            ePOInteractViewerActivityFragment8.f74545w4 = ePOInteractViewerActivityFragment8.f75863p4.m4949X(ePOInteractViewerActivityFragment8.f75850c4, "Select * from pill_pictures where drug_id=" + m4907i1.getString("GROUP_0_ID") + " OR drug_id=" + m4907i1.getString("GROUP_1_ID"), EPOInteractViewerActivityFragment.this.f74546x4, true);
                            str = null;
                            str2 = null;
                        }
                        String string5 = m4907i1.getString("GROUP_0_ID");
                        String string6 = m4907i1.getString("GROUP_1_ID");
                        EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment9 = EPOInteractViewerActivityFragment.this;
                        CompressHelper compressHelper6 = ePOInteractViewerActivityFragment9.f75863p4;
                        String string7 = compressHelper6.m4907i1(compressHelper6.m4952W(ePOInteractViewerActivityFragment9.f75850c4, "SELECT  DDI_GROUP.ID ,  DDI_GROUP.NAME   FROM DDI_GROUP   WHERE  ID =  " + string5, EPOInteractViewerActivityFragment.this.f74546x4)).getString("NAME");
                        EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment10 = EPOInteractViewerActivityFragment.this;
                        CompressHelper compressHelper7 = ePOInteractViewerActivityFragment10.f75863p4;
                        String string8 = compressHelper7.m4907i1(compressHelper7.m4952W(ePOInteractViewerActivityFragment10.f75850c4, "SELECT  DDI_GROUP.ID ,  DDI_GROUP.NAME   FROM DDI_GROUP   WHERE  ID =  " + string6, EPOInteractViewerActivityFragment.this.f74546x4)).getString("NAME");
                        if (str == null) {
                            str = string7;
                        }
                        if (str2 != null) {
                            string8 = str2;
                        }
                        EPOInteractViewerActivityFragment.this.f75852e4 = string8 + " - " + str;
                        EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment11 = EPOInteractViewerActivityFragment.this;
                        CompressHelper compressHelper8 = ePOInteractViewerActivityFragment11.f75863p4;
                        String string9 = compressHelper8.m4907i1(compressHelper8.m4952W(ePOInteractViewerActivityFragment11.f75850c4, "Select * from DDI_Category where id = " + m4907i1.getString("CATEGORY_ID"), EPOInteractViewerActivityFragment.this.f74546x4)).getString("NAME");
                        String m4579z4 = EPOInteractViewerActivityFragment.this.m4579z4(m4907i1.getString("ACTION_STRING_ID"));
                        String m4579z42 = EPOInteractViewerActivityFragment.this.m4579z4(m4907i1.getString("EFFECT_STRING_ID"));
                        String m4579z43 = EPOInteractViewerActivityFragment.this.m4579z4(m4907i1.getString("MECHANISM_STRING_ID"));
                        EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment12 = EPOInteractViewerActivityFragment.this;
                        String m4117W3 = ePOInteractViewerActivityFragment12.m4117W3(ePOInteractViewerActivityFragment12.m44716w(), "EPOHeader.css");
                        EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment13 = EPOInteractViewerActivityFragment.this;
                        String m4117W32 = ePOInteractViewerActivityFragment13.m4117W3(ePOInteractViewerActivityFragment13.m44716w(), "EPOFooter.css");
                        String replace = m4117W3.replace("[size]", "200").replace("[title]", EPOInteractViewerActivityFragment.this.f75852e4).replace("[include]", "");
                        String replace2 = ((((("<div class=\"cellTitle\" style=\"margin-left:15px;margin-top:15px\">" + string8 + " + " + str + "</div>") + "<div style=\"color:red;font-weight:bold;margin-left:15px\">" + string9 + "</div>") + EPOInteractViewerActivityFragment.this.m4581x4("Action", "", "", m4579z4, "", "margin-left:15px", "")) + EPOInteractViewerActivityFragment.this.m4581x4("Effect", "", "", m4579z42, "", "margin-left:15px", "")) + EPOInteractViewerActivityFragment.this.m4581x4("Mechanism", "", "", m4579z43, "", "margin-left:15px", "")).replace("..", ".");
                        EPOInteractViewerActivityFragment.this.f75847Z3 = replace + replace2 + m4117W32;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    EPOInteractViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Epocrate.EPOInteractViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = EPOInteractViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment = EPOInteractViewerActivityFragment.this;
                    ePOInteractViewerActivityFragment.m4078s4(ePOInteractViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4948X0(EPOInteractViewerActivityFragment.this.f75850c4));
                EPOInteractViewerActivityFragment ePOInteractViewerActivityFragment2 = EPOInteractViewerActivityFragment.this;
                ePOInteractViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", ePOInteractViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                EPOInteractViewerActivityFragment.this.m4092j4();
                EPOInteractViewerActivityFragment.this.m4098g4();
                EPOInteractViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                EPOInteractViewerActivityFragment.this.m44735q2(false);
                EPOInteractViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
        menu.removeItem(C4804R.C4808id.f86776action_menu);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f74545w4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f74545w4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        this.f75863p4.m5016A1(this.f75850c4, str);
        return true;
    }

    /* renamed from: x4 */
    public String m4581x4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74547y4 + 1;
        this.f74547y4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded2\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded2(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: y4 */
    public String m4580y4(String str, String str2) {
        if (str != null && str.length() != 0) {
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4952W(bundle, "select * from " + str2 + "_string where id=" + str, this.f74546x4));
            if (m4907i1 != null && m4907i1.size() != 0) {
                return m4907i1.getString("STRING");
            }
        }
        return "";
    }

    /* renamed from: z4 */
    public String m4579z4(String str) {
        return m4580y4(str, "general");
    }
}
