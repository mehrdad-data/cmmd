package net.imedicaldoctor.imd.Fragments;

/* renamed from: net.imedicaldoctor.imd.Fragments.c */
/* loaded from: classes2.dex */
public final /* synthetic */ class C4563c {
}
