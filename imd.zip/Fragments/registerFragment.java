package net.imedicaldoctor.imd.Fragments;

import androidx.fragment.app.Fragment;

/* loaded from: classes2.dex */
public class registerFragment extends Fragment {
}
