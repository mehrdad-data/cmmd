package net.imedicaldoctor.imd.Fragments.Elsevier;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMD;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class ELSViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class ELSViewerFragment extends ViewerHelperFragment {

        /* renamed from: w4 */
        private String f74436w4;

        /* renamed from: x4 */
        private MenuItem f74437x4;

        /* renamed from: y4 */
        public ArrayList<Bundle> f74438y4;

        /* renamed from: z4 */
        public ArrayList<Bundle> f74439z4;

        /* renamed from: B4 */
        public static void m4614B4(StringBuilder sb, String str, String str2) {
            while (true) {
                int lastIndexOf = sb.lastIndexOf(str);
                if (lastIndexOf == -1) {
                    return;
                }
                sb.replace(lastIndexOf, str.length() + lastIndexOf, str2);
            }
        }

        /* renamed from: C4 */
        private void m4613C4(String str) {
            Intent intent;
            ArrayList<Bundle> arrayList = this.f74438y4;
            if (arrayList == null || arrayList.size() == 0) {
                ArrayList arrayList2 = new ArrayList();
                Bundle bundle = new Bundle();
                bundle.putString("id", str);
                Bundle bundle2 = this.f75850c4;
                bundle.putString("ImagePath", CompressHelper.m4942Z0(bundle2, str + ".jpg", "base"));
                bundle.putString("Description", "");
                arrayList2.add(bundle);
                intent = new Intent(m44716w(), GalleryActivity.class);
                intent.putExtra("Images", arrayList2);
                intent.putExtra("Start", 0);
            } else {
                int i = 0;
                for (int i2 = 0; i2 < this.f74438y4.size(); i2++) {
                    if (this.f74438y4.get(i2).getString("id").equals(str)) {
                        i = i2;
                    }
                }
                Log.e("Images count", "Images count" + this.f74438y4.size());
                intent = new Intent(m44716w(), GalleryActivity.class);
                intent.putExtra("Images", this.f74438y4);
                intent.putExtra("Start", i);
            }
            mo4139H2(intent);
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX WARN: Removed duplicated region for block: B:114:0x0164 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:44:0x017b  */
        /* renamed from: x4 */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void m4612x4() {
            /*
                Method dump skipped, instructions count: 706
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Elsevier.ELSViewerActivity.ELSViewerFragment.m4612x4():void");
        }

        /* renamed from: A4 */
        public void m4615A4(String str, Boolean bool) {
            StringBuilder sb;
            String str2;
            if (bool.booleanValue()) {
                sb = new StringBuilder();
                sb.append(str);
                str2 = " - Before";
            } else {
                sb = new StringBuilder();
                sb.append(str);
                str2 = " - After";
            }
            sb.append(str2);
            Log.e("TimeProfiler", sb.toString());
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: D3 */
        public boolean mo4143D3() {
            ArrayList<Bundle> arrayList = this.f74438y4;
            return (arrayList == null || arrayList.size() == 0) ? false : true;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            Bundle m4073v3;
            ArrayList<Bundle> arrayList = this.f74438y4;
            if (arrayList == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f74438y4)) == null) {
                return null;
            }
            return m4073v3.getString("ImagePath");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S3 */
        public void mo3569S3(WebView webView, String str) {
            super.mo3569S3(webView, str);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            m4615A4("OnCreateView", Boolean.TRUE);
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f74436w4 = bundle.getString("mResources");
                this.f74438y4 = bundle.getParcelableArrayList("mImages");
                this.f74439z4 = bundle.getParcelableArrayList("mOtherImages");
            }
            if (m44859B() == null) {
                return inflate;
            }
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Elsevier.ELSViewerActivity.ELSViewerFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    String str;
                    try {
                        CompressHelper compressHelper = new CompressHelper(ELSViewerFragment.this.m44716w());
                        String str2 = ELSViewerFragment.this.f75847Z3;
                        if (str2 == null || str2.length() == 0) {
                            ELSViewerFragment eLSViewerFragment = ELSViewerFragment.this;
                            Boolean bool = Boolean.TRUE;
                            eLSViewerFragment.m4615A4("QueryDB", bool);
                            Bundle m4923e0 = compressHelper.m4923e0(ELSViewerFragment.this.f75850c4, "Select id as _id,* from Docs where id=" + ELSViewerFragment.this.f75851d4);
                            if (m4923e0 == null) {
                                ELSViewerFragment.this.f75837P3 = "Document doesn't exist";
                                return;
                            }
                            ELSViewerFragment eLSViewerFragment2 = ELSViewerFragment.this;
                            Boolean bool2 = Boolean.FALSE;
                            eLSViewerFragment2.m4615A4("QueryDB", bool2);
                            String string = m4923e0.getString("mainContent");
                            ELSViewerFragment.this.f74436w4 = m4923e0.getString("resources");
                            ELSViewerFragment.this.f75852e4 = m4923e0.getString("name");
                            if (ELSViewerFragment.this.m4142E3(m4923e0.getString("_id")).booleanValue()) {
                                str = ELSViewerFragment.this.m4068y3(m4923e0.getString("_id"));
                            } else {
                                String str3 = new String(compressHelper.m4870v(string, m4923e0.getString("_id"), "127"));
                                ELSViewerFragment eLSViewerFragment3 = ELSViewerFragment.this;
                                String m4117W3 = eLSViewerFragment3.m4117W3(eLSViewerFragment3.m44716w(), "ELSHeaderNew.css");
                                ELSViewerFragment eLSViewerFragment4 = ELSViewerFragment.this;
                                String m4117W32 = eLSViewerFragment4.m4117W3(eLSViewerFragment4.m44716w(), "ELSFooterNew.css");
                                String replace = m4117W3.replace("[size]", "200").replace("[title]", ELSViewerFragment.this.f75852e4);
                                String replace2 = str3.replace("<div class=\"table\"", "<div class=\"table\" style=\"width:90%%;overflow: scroll;\"").replace("<div once-if=\"item.tables.length &gt; 0\"", "<div once-if=\"item.tables.length &gt; 0\" style=\"width:90%%;overflow: scroll;\"").replace("<div once-if=\"bi.tables.length &gt; 0\"", "<div once-if=\"bi.tables.length &gt; 0\" style=\"width:90%%;overflow: scroll;\"").replace("<div once-if=\"item.math\"", "<div once-if=\"item.math\" style=\"width:90%%;overflow: scroll;\"").replace("ng-click=\"loadPartial('openPane')\"", "onclick=\"window.location='image://'+this.getElementsByTagName('img')[0].getAttribute('eid');\"").replace("javascript:app.eidLink", "eid://").replace("<div class=\"inline-image figure\"", "<div class=\"inline-image figure\" style=\"width:90%%;overflow: scroll;\"").replace("\u200dng-click=\"loadPartial('openPane')\"", "onclick=\"window.location='image://'+this.getElementsByTagName('img')[0].getAttribute('eid');\"").replace("javascript:app.eidLink", "eid://").replace("#!", "chapter:/").replace("ng-click=\"loadPartial('openPane')\"", "onclick=\"window.location='image://'+this.getElementsByTagName('img')[0].getAttribute('eid');\"").replace("javascript:app.eidLink", "eid://").replace("See additional content on Expert Consult", "");
                                int indexOf = replace2.indexOf("c-ckc-bibliography");
                                if (indexOf > -1) {
                                    replace2 = replace2.substring(0, indexOf) + replace2.substring(indexOf).replace("ng-repeat=\"item in XocsCtrl.sections\"", "ng-repeat=\"item in XocsCtrl.sections\" style=\"display:none\"");
                                }
                                str = replace + replace2 + m4117W32;
                                ELSViewerFragment.this.m4107b3(m4923e0.getString("_id"), str);
                            }
                            ELSViewerFragment.this.m4087m3();
                            ELSViewerFragment eLSViewerFragment5 = ELSViewerFragment.this;
                            eLSViewerFragment5.f75847Z3 = str;
                            eLSViewerFragment5.m4615A4("LoadResource", bool);
                            ELSViewerFragment.this.m4612x4();
                            ELSViewerFragment.this.m4615A4("LoadResource", bool2);
                        }
                        String m4945Y0 = CompressHelper.m4945Y0(ELSViewerFragment.this.f75850c4, "base");
                        new File(m4945Y0).getAbsolutePath();
                        if (iMD.m3309a()) {
                            File file = new File(m4945Y0 + "/test.html");
                            if (file.exists()) {
                                file.delete();
                            }
                            FileUtils.writeStringToFile(file, ELSViewerFragment.this.f75847Z3, "UTF-8");
                        }
                        ELSViewerFragment.this.m4097h3(m4945Y0);
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        e.printStackTrace();
                        ELSViewerFragment.this.f75837P3 = e.getLocalizedMessage();
                    }
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Elsevier.ELSViewerActivity.ELSViewerFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = ELSViewerFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        ELSViewerFragment eLSViewerFragment = ELSViewerFragment.this;
                        eLSViewerFragment.m4078s4(eLSViewerFragment.f75837P3);
                        return;
                    }
                    File file = new File(CompressHelper.m4945Y0(ELSViewerFragment.this.f75850c4, "base"));
                    ELSViewerFragment.this.m4092j4();
                    ELSViewerFragment eLSViewerFragment2 = ELSViewerFragment.this;
                    eLSViewerFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", eLSViewerFragment2.f75847Z3, "text/html", "utf-8", null);
                    ELSViewerFragment.this.m4098g4();
                    ELSViewerFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                    ELSViewerFragment.this.m44735q2(false);
                    ELSViewerFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86774action_gallery) {
                m4613C4("soheilvb");
            }
            if (itemId == C4804R.C4808id.f86776action_menu) {
                ELSSectionsViewer eLSSectionsViewer = new ELSSectionsViewer();
                Bundle bundle = new Bundle();
                bundle.putBundle("db", this.f75850c4);
                bundle.putString("docId", this.f75851d4);
                bundle.putString("parentId", "0");
                eLSSectionsViewer.m44751k2(bundle);
                eLSSectionsViewer.m44870c3(true);
                eLSSectionsViewer.m44844E2(this, 0);
                eLSSectionsViewer.mo29915h3(m44796U(), "ELSSectionsViewer");
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            menu.findItem(C4804R.C4808id.f86774action_gallery).setVisible(mo4143D3());
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            String str4;
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
            if (str2.equals("image")) {
                m4613C4(str3.substring(2));
                return true;
            } else if (!str2.equals("chapter")) {
                if (str2.equals(Annotation.f59806M2)) {
                    String[] split = str3.split("/");
                    mo4144C3(split[split.length - 1]);
                }
                return true;
            } else {
                CompressHelper compressHelper = new CompressHelper(m44716w());
                String[] split2 = str3.split("/");
                String str5 = split2[split2.length - 1];
                if (str5.contains("?scroll")) {
                    str4 = StringUtils.splitByWholeSeparator(str5, "scrollTo=#")[1];
                    str5 = StringUtils.splitByWholeSeparator(str5, "?")[0];
                } else {
                    str4 = null;
                }
                Bundle m4923e0 = compressHelper.m4923e0(this.f75850c4, "Select id from docs where eid='" + str5 + "'");
                if (m4923e0 == null) {
                    CompressHelper.m4921e2(m44716w(), "No Document Found", 1);
                    return true;
                }
                compressHelper.m4883q1(this.f75850c4, m4923e0.getString("id"), null, str4);
                return true;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new ELSViewerFragment(), bundle);
    }
}
