package net.imedicaldoctor.imd.Fragments.Elsevier;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class ELSChaptersActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class ELSChaptersFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private static String f74426b4;

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4337R2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4337R2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
            this.f75218O3 = this.f75215L3.m4955V(this.f75212I3, "Select id as _id,* from chapters");
            this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "name") { // from class: net.imedicaldoctor.imd.Fragments.Elsevier.ELSChaptersActivity.ELSChaptersFragment.1
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: f0 */
                public void mo3405f0(Bundle bundle2, int i) {
                    ELSChaptersFragment.this.m4330Y2();
                    ELSChaptersFragment eLSChaptersFragment = ELSChaptersFragment.this;
                    eLSChaptersFragment.f75215L3.m4883q1(eLSChaptersFragment.f75212I3, bundle2.getString("docId"), null, null);
                }
            };
            this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.Elsevier.ELSChaptersActivity.ELSChaptersFragment.2
                @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
                /* renamed from: e0 */
                public void mo3397e0(Bundle bundle2, int i) {
                    Bundle m4923e0;
                    String str;
                    ELSChaptersFragment.this.m4330Y2();
                    String string = bundle2.getString("type");
                    String string2 = bundle2.getString("contentId");
                    if (string.equals(IcyHeaders.f35463C2)) {
                        ELSChaptersFragment eLSChaptersFragment = ELSChaptersFragment.this;
                        eLSChaptersFragment.f75215L3.m4883q1(eLSChaptersFragment.f75212I3, string2, null, null);
                        return;
                    }
                    if (string.equals(ExifInterface.f14411T4)) {
                        ELSChaptersFragment eLSChaptersFragment2 = ELSChaptersFragment.this;
                        CompressHelper compressHelper = eLSChaptersFragment2.f75215L3;
                        Bundle bundle3 = eLSChaptersFragment2.f75212I3;
                        m4923e0 = compressHelper.m4923e0(bundle3, "select * from images where id='" + string2 + "'");
                        if (m4923e0 == null) {
                            return;
                        }
                        str = "docId";
                    } else if (!string.equals("4")) {
                        if (string.equals("5")) {
                            ELSChaptersFragment eLSChaptersFragment3 = ELSChaptersFragment.this;
                            eLSChaptersFragment3.f75215L3.m4883q1(eLSChaptersFragment3.f75212I3, string2, eLSChaptersFragment3.m4332W2(bundle2.getString("subText")), null);
                            return;
                        }
                        return;
                    } else {
                        ELSChaptersFragment eLSChaptersFragment4 = ELSChaptersFragment.this;
                        CompressHelper compressHelper2 = eLSChaptersFragment4.f75215L3;
                        Bundle bundle4 = eLSChaptersFragment4.f75212I3;
                        m4923e0 = compressHelper2.m4923e0(bundle4, "select * from tables where id=" + string2);
                        if (m4923e0 == null) {
                            return;
                        }
                        str = "sectionId";
                    }
                    String string3 = m4923e0.getString(str);
                    String string4 = m4923e0.getString("goto");
                    ELSChaptersFragment eLSChaptersFragment5 = ELSChaptersFragment.this;
                    eLSChaptersFragment5.f75215L3.m4883q1(eLSChaptersFragment5.f75212I3, string3, null, string4);
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(true);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id, Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new ELSChaptersFragment());
    }
}
