package net.imedicaldoctor.imd.Fragments.Elsevier;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Elsevier.ELSViewerActivity;
import net.imedicaldoctor.imd.iMDLogger;

/* loaded from: classes2.dex */
public class ELSSectionsViewer extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f74429g4;

    /* renamed from: h4 */
    private String f74430h4;

    /* renamed from: i4 */
    private String f74431i4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f74429g4 = m44859B().getBundle("db");
        this.f74430h4 = m44859B().getString("docId");
        this.f74431i4 = m44859B().getString("parentId");
        CompressHelper compressHelper = new CompressHelper(m44716w());
        Bundle bundle2 = this.f74429g4;
        listView.setAdapter((ListAdapter) new CursorAdapter(m44716w(), compressHelper.m4912h(compressHelper.m4955V(bundle2, "Select rowid as _id, * from sections where docId = '" + this.f74430h4 + "' And parent = " + this.f74431i4)), 0) { // from class: net.imedicaldoctor.imd.Fragments.Elsevier.ELSSectionsViewer.1
            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: d */
            public void mo3522d(View view, Context context, Cursor cursor) {
                ((TextView) view.getTag()).setText(cursor.getString(cursor.getColumnIndex("sectionName")));
                if (cursor.getString(cursor.getColumnIndex("leaf")).equals("0")) {
                    final String string = cursor.getString(cursor.getColumnIndex("sectionId"));
                    ((ImageView) view.findViewById(C4804R.C4808id.f86968next_icon)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Elsevier.ELSSectionsViewer.1.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            ELSSectionsViewer eLSSectionsViewer = new ELSSectionsViewer();
                            Bundle bundle3 = new Bundle();
                            bundle3.putBundle("db", ELSSectionsViewer.this.f74429g4);
                            bundle3.putString("docId", ELSSectionsViewer.this.f74430h4);
                            bundle3.putString("parentId", string);
                            eLSSectionsViewer.m44751k2(bundle3);
                            eLSSectionsViewer.m44870c3(true);
                            eLSSectionsViewer.m44844E2(ELSSectionsViewer.this.m44753k0(), 0);
                            eLSSectionsViewer.mo29915h3(ELSSectionsViewer.this.m44796U(), "ELSSectionsViewer");
                            ELSSectionsViewer.this.mo27003Q2();
                        }
                    });
                }
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getItemViewType(int i) {
                Cursor cursor = (Cursor) getItem(i);
                return cursor.getString(cursor.getColumnIndex("leaf")).equals(IcyHeaders.f35463C2) ? 0 : 1;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getViewTypeCount() {
                return 2;
            }

            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: i */
            public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                View inflate2 = LayoutInflater.from(ELSSectionsViewer.this.m44716w()).inflate(cursor.getString(cursor.getColumnIndex("leaf")).equals(IcyHeaders.f35463C2) ? C4804R.C4810layout.f87284list_view_item_simple_text : C4804R.C4810layout.f87285list_view_item_simple_text_arrow, viewGroup, false);
                inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                return inflate2;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Elsevier.ELSSectionsViewer.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                if (mo45341b.moveToPosition(i)) {
                    String string = mo45341b.getString(mo45341b.getColumnIndex("sectionhRef"));
                    iMDLogger.m3290j("ElsSectionsViewer", "Goto : " + string);
                    ((ELSViewerActivity.ELSViewerFragment) ELSSectionsViewer.this.m44753k0()).mo4144C3(string);
                    ELSSectionsViewer.this.mo27003Q2();
                }
            }
        });
        builder.setView(inflate);
        return builder.create();
    }
}
