package net.imedicaldoctor.imd.Fragments.Dictionary;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class CDicSimpleWebViewer extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class CDicSimpleWebViewerFragment extends ViewerHelperFragment {
        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87156fragment_general_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (m44859B() == null) {
                return inflate;
            }
            this.f75853f4.loadUrl(this.f75851d4.split("-")[1]);
            m4092j4();
            m44735q2(false);
            m44716w().setTitle("");
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            if (str2.equals("ldoce")) {
                CompressHelper compressHelper = new CompressHelper(m44716w());
                String substring = StringUtils.splitByWholeSeparator(str3, "?")[0].substring(2);
                Bundle bundle = this.f75850c4;
                Bundle m4858z = compressHelper.m4858z(compressHelper.m4952W(bundle, "select * from LongMean where word='" + substring + "'", "LongMean.db"));
                if (m4858z == null) {
                    return true;
                }
                Bundle bundle2 = this.f75850c4;
                compressHelper.m4883q1(bundle2, "EE-5,,,,," + m4858z.getString("id") + ",,,,," + m4858z.getString("word"), null, null);
                return true;
            }
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new CDicSimpleWebViewerFragment());
    }
}
