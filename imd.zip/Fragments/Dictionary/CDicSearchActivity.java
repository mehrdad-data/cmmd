package net.imedicaldoctor.imd.Fragments.Dictionary;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.itextpdf.tool.xml.html.HTML;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.ObservableEmitter;
import io.reactivex.rxjava3.core.ObservableOnSubscribe;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Dictionary.CDicEEActivity;
import net.imedicaldoctor.imd.Fragments.Dictionary.CDicEPActivity;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.Lexi.LXItems;
import net.imedicaldoctor.imd.Fragments.Lexi.LXViewer;
import net.imedicaldoctor.imd.Fragments.SearchDialogHelperFragment;
import net.imedicaldoctor.imd.Fragments.Skyscape.SSSearchActivity;
import net.imedicaldoctor.imd.Fragments.Skyscape.SSViewerActivity;
import net.imedicaldoctor.imd.LinearLayoutManagerWithSmoothScroller;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.StatusAdapter;
import net.imedicaldoctor.imd.iMDActivity;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class CDicSearchActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class CDicSearchFragment extends SearchDialogHelperFragment {

        /* renamed from: z4 */
        private AsyncTask f74305z4;

        /* JADX INFO: Access modifiers changed from: package-private */
        /* renamed from: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity$CDicSearchFragment$5 */
        /* loaded from: classes2.dex */
        public class C37955 implements ObservableOnSubscribe<String> {

            /* renamed from: a */
            final /* synthetic */ CompressHelper f74312a;

            /* JADX INFO: Access modifiers changed from: package-private */
            /* renamed from: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity$CDicSearchFragment$5$1 */
            /* loaded from: classes2.dex */
            public class C37961 implements SearchView.OnQueryTextListener {

                /* renamed from: a */
                final /* synthetic */ ObservableEmitter f74314a;

                C37961(ObservableEmitter observableEmitter) {
                    this.f74314a = observableEmitter;
                }

                @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
                /* renamed from: a */
                public boolean mo3520a(String str) {
                    CDicSearchFragment cDicSearchFragment = CDicSearchFragment.this;
                    if (cDicSearchFragment.f75169k4) {
                        cDicSearchFragment.f75166h4 = str;
                        this.f74314a.onNext(str);
                        return true;
                    }
                    return true;
                }

                @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
                /* renamed from: b */
                public boolean mo3519b(final String str) {
                    C37955 c37955 = C37955.this;
                    CompressHelper compressHelper = c37955.f74312a;
                    Bundle bundle = CDicSearchFragment.this.f75168j4;
                    compressHelper.m4935b0(bundle, "Select rowid as _id,* from search where word match '" + str + "' order by word collate nocase asc", "Search.db").m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7329f6(new Consumer<ArrayList<Bundle>>() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.5.1.1
                        @Override // io.reactivex.rxjava3.functions.Consumer
                        /* renamed from: a */
                        public void accept(ArrayList<Bundle> arrayList) throws Throwable {
                            if (arrayList == null) {
                                CDicSearchFragment.this.mo4362A3("Nothing Found");
                            } else {
                                CDicSearchFragment.this.mo4343z3();
                                CDicSearchFragment.this.mo4343z3();
                                final int i = 0;
                                if (arrayList.size() > 0) {
                                    Iterator<Bundle> it2 = arrayList.iterator();
                                    while (it2.hasNext() && !it2.next().getString("word").toLowerCase().startsWith(str.toLowerCase())) {
                                        i++;
                                    }
                                }
                                CDicSearchFragment.this.f75172n4.m3396f0(arrayList);
                                if (arrayList.size() > 0) {
                                    CDicSearchFragment.this.f75183y4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.5.1.1.1
                                        @Override // java.lang.Runnable
                                        public void run() {
                                            CDicSearchFragment.this.f75183y4.m42990O1(i);
                                        }
                                    }, 1000L);
                                }
                            }
                            CDicSearchFragment.this.m4352q3();
                        }
                    }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.5.1.2
                        @Override // io.reactivex.rxjava3.functions.Consumer
                        /* renamed from: a */
                        public void accept(Throwable th) throws Throwable {
                        }
                    });
                    return false;
                }
            }

            C37955(CompressHelper compressHelper) {
                this.f74312a = compressHelper;
            }

            @Override // io.reactivex.rxjava3.core.ObservableOnSubscribe
            /* renamed from: a */
            public void mo3518a(@NonNull ObservableEmitter<String> observableEmitter) throws Throwable {
                CDicSearchFragment.this.f75179u4.setOnQueryTextListener(new C37961(observableEmitter));
            }
        }

        /* loaded from: classes2.dex */
        public class ListViewItemContentSearchPlaceHolder {

            /* renamed from: a */
            public TextView f74325a;

            /* renamed from: b */
            public TextView f74326b;

            public ListViewItemContentSearchPlaceHolder(View view) {
                this.f74325a = (TextView) view.findViewById(C4804R.C4808id.f87060title_text);
                this.f74326b = (TextView) view.findViewById(C4804R.C4808id.f87036subtitle_text);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: F3 */
        public Bundle m4688F3(Bundle bundle) {
            String str;
            String str2;
            Bundle bundle2 = new Bundle();
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(bundle.getString("docId"), "|");
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(bundle.getString(HTML.Tag.f65890V), "|");
            for (int i = 0; i < splitByWholeSeparator.length; i++) {
                if (splitByWholeSeparator2.length > i) {
                    str = splitByWholeSeparator[i];
                    str2 = splitByWholeSeparator2[i];
                } else {
                    str = splitByWholeSeparator[i];
                    str2 = "";
                }
                bundle2.putString(str, str2);
            }
            return bundle2;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchDialogHelperFragment
        /* renamed from: A3 */
        public void mo4362A3(String str) {
            this.f75183y4.setAdapter(new StatusAdapter(m44716w(), str));
        }

        /* renamed from: E3 */
        public void m4689E3(final SearchView searchView) {
            searchView.setIconifiedByDefault(false);
            searchView.setQueryHint("Search Dictionary");
            m4349t3();
            searchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.2
                @Override // androidx.appcompat.widget.SearchView.OnSuggestionListener
                /* renamed from: a */
                public boolean mo3524a(int i) {
                    Cursor mo45341b = searchView.getSuggestionsAdapter().mo45341b();
                    if (mo45341b.moveToPosition(i)) {
                        String string = mo45341b.getString(mo45341b.getColumnIndex("word"));
                        if (searchView.getTag(1) != null && ((String) searchView.getTag(1)).length() > 0) {
                            string = ((String) searchView.getTag()) + StringUtils.SPACE + string;
                        }
                        searchView.m51655i0(string, true);
                        return false;
                    }
                    return false;
                }

                @Override // androidx.appcompat.widget.SearchView.OnSuggestionListener
                /* renamed from: b */
                public boolean mo3523b(int i) {
                    Cursor mo45341b = searchView.getSuggestionsAdapter().mo45341b();
                    if (mo45341b.moveToPosition(i)) {
                        String string = mo45341b.getString(mo45341b.getColumnIndex("word"));
                        if (searchView.getTag() != null && ((String) searchView.getTag()).length() > 0) {
                            string = ((String) searchView.getTag()) + StringUtils.SPACE + string;
                        }
                        searchView.m51655i0(string, true);
                        return false;
                    }
                    return false;
                }
            });
            ((ImageView) searchView.findViewById(C4804R.C4808id.search_close_btn)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.3
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    searchView.m51655i0("", false);
                    searchView.clearFocus();
                    CDicSearchFragment.this.mo4362A3("Search Anything");
                    CDicSearchFragment.this.m4352q3();
                }
            });
            searchView.setSuggestionsAdapter(new CursorAdapter(m44716w(), null, 0) { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.4
                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: d */
                public void mo3522d(View view, Context context, Cursor cursor) {
                    ((TextView) view.getTag()).setText(cursor.getString(cursor.getColumnIndex("word")));
                }

                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: i */
                public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                    View inflate = LayoutInflater.from(context).inflate(C4804R.C4810layout.f87293list_view_item_spell, viewGroup, false);
                    inflate.setTag(inflate.findViewById(C4804R.C4808id.text));
                    return inflate;
                }
            });
            final CompressHelper compressHelper = new CompressHelper(m44716w());
            Observable.m7156x1(new C37955(compressHelper)).m7146y1(500L, TimeUnit.MILLISECONDS).m7329f6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.6
                @Override // io.reactivex.rxjava3.functions.Consumer
                /* renamed from: a */
                public void accept(String str) throws Throwable {
                    if (str.length() > 1) {
                        String[] split = str.trim().split(StringUtils.SPACE);
                        String str2 = split[split.length - 1];
                        String str3 = "";
                        for (int i = 0; i < split.length - 1; i++) {
                            str3 = str3 + StringUtils.SPACE + split[i];
                        }
                        CDicSearchFragment.this.f75179u4.setTag(str3.trim());
                        compressHelper.m4935b0(CDicSearchFragment.this.f75168j4, "Select rowid as _id,word from spell where word match '" + str2 + "*'", "Search.db").m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7339e6(new Consumer<ArrayList<Bundle>>() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.6.1
                            @Override // io.reactivex.rxjava3.functions.Consumer
                            /* renamed from: a */
                            public void accept(ArrayList<Bundle> arrayList) throws Throwable {
                                CDicSearchFragment.this.f75179u4.getSuggestionsAdapter().mo45336l(compressHelper.m4912h(arrayList));
                            }
                        });
                    }
                }
            }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.7
                @Override // io.reactivex.rxjava3.functions.Consumer
                /* renamed from: a */
                public void accept(Throwable th) throws Throwable {
                }
            });
            String str = this.f75166h4;
            if (str == null || str.length() <= 0) {
                return;
            }
            this.f75179u4.m51655i0(this.f75166h4, true);
        }

        /* renamed from: G3 */
        public void m4687G3(Fragment fragment, String str, Bundle bundle) {
            Bundle bundle2 = new Bundle();
            bundle2.putBundle("DB", bundle);
            bundle2.putString("URL", str);
            bundle2.putString("Dialog", IcyHeaders.f35463C2);
            fragment.m44751k2(bundle2);
            m44855C().m44464r().m44292k("something").m44309I(C4804R.anim.f85970from_fade_in, C4804R.anim.f85971from_fade_out).m44278y(C4804R.C4808id.f86868dic, fragment).mo44289n();
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            SearchView searchView = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            this.f75179u4 = searchView;
            m4689E3(searchView);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchDialogHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            this.f75170l4 = new CompressHelper(m44716w());
            View inflate = layoutInflater.inflate(m44859B().containsKey("Dialog") ? C4804R.C4810layout.f87139fragment_cdic_dialog : C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75177s4 = inflate;
            m4351r3(bundle);
            m4355n3();
            SearchView searchView = (SearchView) this.f75177s4.findViewById(C4804R.C4808id.f87012search_view);
            this.f75179u4 = searchView;
            m4689E3(searchView);
            this.f75183y4 = (RecyclerView) this.f75177s4.findViewById(C4804R.C4808id.f87001recycler_view);
            RelativeLayout relativeLayout = (RelativeLayout) this.f75177s4.findViewById(C4804R.C4808id.f86803background_layout);
            if (relativeLayout != null) {
                relativeLayout.setVisibility(0);
            }
            this.f75172n4 = new ContentSearchAdapter(m44716w(), this.f75174p4, "word", "source") { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicSearchActivity.CDicSearchFragment.1
                @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
                /* renamed from: e0 */
                public void mo3397e0(Bundle bundle2, int i) {
                    String string = bundle2.getString("word");
                    String string2 = bundle2.getString("source");
                    String string3 = bundle2.getString("sourceId");
                    String string4 = bundle2.getString("id");
                    String str = string4 + ",,,,," + string;
                    if (string2.equals("Persian")) {
                        if (CDicSearchFragment.this.m44859B().containsKey("Dialog")) {
                            CDicSearchFragment.this.m4687G3(new CDicEPActivity.CDicEPFragment(), "EP-" + str + ",,,,," + string, CDicSearchFragment.this.f75168j4);
                            return;
                        }
                        CDicSearchFragment cDicSearchFragment = CDicSearchFragment.this;
                        cDicSearchFragment.f75170l4.m4883q1(cDicSearchFragment.f75168j4, "EP-" + str + ",,,,," + string, null, null);
                    } else if (string3.equals("5") || string3.equals("10") || string3.equals("15")) {
                        new Bundle();
                        String string5 = bundle2.getString(HTML.Tag.f65890V).length() > 0 ? bundle2.getString(HTML.Tag.f65890V) : null;
                        if (CDicSearchFragment.this.m44859B().containsKey("Dialog")) {
                            CDicSearchFragment.this.m4687G3(new CDicEEActivity.CDicEEFragment(), "EE-" + string3 + ",,,,," + string4 + ",,,,," + string, CDicSearchFragment.this.f75168j4);
                            return;
                        }
                        CDicSearchFragment cDicSearchFragment2 = CDicSearchFragment.this;
                        cDicSearchFragment2.f75170l4.m4883q1(cDicSearchFragment2.f75168j4, "EE-" + string3 + ",,,,," + string4 + ",,,,," + string, null, string5);
                    } else if (string3.equals("30") || string3.equals("35") || string3.equals("40") || string3.equals("45")) {
                        Bundle m4938a1 = CDicSearchFragment.this.f75170l4.m4938a1(string3.equals("30") ? "K3ZGDATA.db" : string3.equals("35") ? "K2AJDATA.db" : string3.equals("40") ? "K354DATA.db" : string3.equals("45") ? "K2WCDATA.db" : "");
                        if (m4938a1 == null) {
                            CompressHelper.m4921e2(CDicSearchFragment.this.m44716w(), string2 + " Is Not Installed", 1);
                            return;
                        } else if (string4.contains("|")) {
                            Bundle bundle3 = new Bundle();
                            Bundle bundle4 = new Bundle();
                            bundle4.putString("docId", string4);
                            bundle4.putString("name", string);
                            bundle4.putString(HTML.Tag.f65890V, bundle2.getString(HTML.Tag.f65890V));
                            bundle3.putBundle("SelectedItem", bundle4);
                            bundle3.putBundle("DB", m4938a1);
                            bundle3.putInt("Mode", 2);
                            bundle3.putBundle("GotoSections", CDicSearchFragment.this.m4688F3(bundle4));
                            CDicSearchFragment.this.f75170l4.m4979N(SSSearchActivity.class, SSSearchActivity.SSSearchFragment.class, bundle3);
                        } else if (CDicSearchFragment.this.m44859B().containsKey("Dialog")) {
                            CDicSearchFragment.this.m4687G3(new SSViewerActivity.SSViewerFragment(), string4, m4938a1);
                            return;
                        } else {
                            CDicSearchFragment.this.f75170l4.m4883q1(m4938a1, string4, null, bundle2.getString(HTML.Tag.f65890V));
                        }
                    } else if (string3.equals("20")) {
                        Bundle m4938a12 = CDicSearchFragment.this.f75170l4.m4938a1("593_lww_abbrev.sqlite");
                        if (m4938a12 == null) {
                            CompressHelper.m4921e2(CDicSearchFragment.this.m44716w(), string2 + " Is Not Installed", 1);
                            return;
                        }
                        CompressHelper compressHelper = CDicSearchFragment.this.f75170l4;
                        Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(m4938a12, "Select count(*) as c from indexitem_document where indexitem_id=" + string4));
                        if (m4858z == null || m4858z.getString("c").equals(IcyHeaders.f35463C2)) {
                            CompressHelper compressHelper2 = CDicSearchFragment.this.f75170l4;
                            Bundle m4858z2 = compressHelper2.m4858z(compressHelper2.m4955V(m4938a12, "select document_id from indexitem_document where indexitem_id=" + string4));
                            if (CDicSearchFragment.this.m44859B().containsKey("Dialog")) {
                                CDicSearchFragment.this.m4687G3(new LXViewer.LXViewerFragment(), m4858z2.getString("document_id"), m4938a12);
                                return;
                            }
                            CDicSearchFragment.this.f75170l4.m4883q1(m4938a12, m4858z2.getString("document_id"), null, null);
                        } else {
                            Bundle bundle5 = new Bundle();
                            bundle5.putString("ParentId", string4);
                            bundle5.putInt("Mode", 2);
                            bundle5.putBundle("DB", m4938a12);
                            CDicSearchFragment.this.f75170l4.m4979N(LXItems.class, LXItems.LXItemsFragment.class, bundle5);
                        }
                    }
                    try {
                        if (CDicSearchFragment.this.m44859B().containsKey("Dialog")) {
                            CDicSearchFragment.this.mo27003Q2();
                        }
                    } catch (Exception unused) {
                    }
                }
            };
            mo4359j3();
            mo4362A3("Search Anything");
            if (m44859B().containsKey("Dialog")) {
                this.f75179u4.m51655i0(m44859B().getString("Dialog"), true);
                m44878T2().getWindow().requestFeature(1);
            }
            m44735q2(false);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchDialogHelperFragment
        /* renamed from: j3 */
        public void mo4359j3() {
            this.f75183y4.setItemAnimator(new DefaultItemAnimator());
            this.f75183y4.m42923n(new DividerItemDecoration(m44716w(), 1));
            this.f75183y4.setLayoutManager(new LinearLayoutManagerWithSmoothScroller(m44716w(), 1, false));
        }

        @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
        /* renamed from: n1 */
        public void mo4686n1() {
            super.mo4686n1();
            Dialog m44878T2 = m44878T2();
            if (m44878T2 != null) {
                m44878T2.getWindow().setLayout(-1, -1);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchDialogHelperFragment
        /* renamed from: z3 */
        public void mo4343z3() {
            RecyclerView.Adapter adapter = this.f75183y4.getAdapter();
            ContentSearchAdapter contentSearchAdapter = this.f75172n4;
            if (adapter != contentSearchAdapter) {
                this.f75183y4.setAdapter(contentSearchAdapter);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new CDicSearchFragment());
    }
}
