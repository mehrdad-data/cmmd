package net.imedicaldoctor.imd.Fragments.Dictionary;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class CDicEPActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class CDicEPFragment extends ViewerHelperFragment {

        /* renamed from: w4 */
        public String f74302w4;

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: D4 */
        public String m4699D4(int i, String str, String str2) {
            return "<a name=\"f" + i + "\"><div id=\"h" + i + "\" class=\"headerExpanded\" onclick=\"collapse(f" + i + ");toggleHeaderExpanded(h" + i + ");\"><span class=\"fieldname\" style=\"font-family:X Traffic;\">" + str + "</span></div></a><div class=\"content\"  DIR=\"RTL\" id=\"f" + i + "\" style=\"font-family:X Traffic;\">" + str2 + "</div>";
        }

        /* renamed from: E4 */
        private String m4698E4(String str, String str2) {
            return "<div class=\"content\"  DIR=\"" + str2 + "\" style=\"font-family:\"X Traffic\";\">" + str + "</div>";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: F4 */
        public String m4697F4(int i, String str, String str2) {
            return "<a name=\"f" + i + "\"><div id=\"h" + i + "\" class=\"headerExpanded\" onclick=\"collapse(f" + i + ");toggleHeaderExpanded(h" + i + ");\"><span class=\"fieldname\" style=\"font-family:X Traffic;\">" + str + "</span></div></a><div class=\"content\"  DIR=\"LTR\" id=\"f" + i + "\">" + str2 + "</div>";
        }

        /* renamed from: G4 */
        private String m4696G4(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
            return "<a name=\"f" + str8 + "\"><div id=\"h" + str8 + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + str8 + ");toggleHeaderExpanded(h" + str8 + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + str8 + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: H4 */
        public String m4695H4(Bundle bundle) {
            String m5015B = new CompressHelper(m44716w()).m5015B(bundle.getString("TLine"), bundle.getString("id"), "127");
            return "<div class=\"content\"  DIR=\"LTR\" >" + m5015B + " <a href=\"Sample:" + bundle.getString("id") + "\"><img src=\"file:///android_asset/VideoPlayer_Play.png\" height=10 width=10></a></div>";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: I4 */
        public String m4694I4(int i, String str, String str2) {
            return "<a name=\"f" + i + "\"><div id=\"h" + i + "\" class=\"headerExpanded\" onclick=\"collapse(f" + i + ");toggleHeaderExpanded(h" + i + ");\"><span class=\"fieldname\" style=\"font-family:X Traffic;\">" + str + "</span></div></a><div class=\"content\"  DIR=\"LTR\" id=\"f" + i + "\">" + str2 + "</div>";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: x4 */
        public String m4693x4(String str) {
            return str.replace("\n", "<br>");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87333menu_cdic_e, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f74302w4 = bundle.getString("mSoundNumber");
            }
            if (m44859B() == null) {
                return inflate;
            }
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicEPActivity.CDicEPFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    Iterator<Bundle> it2;
                    String str;
                    String str2;
                    String str3;
                    Iterator<Bundle> it3;
                    String str4 = "";
                    String str5 = "Phonetic";
                    try {
                        CompressHelper compressHelper = new CompressHelper(CDicEPFragment.this.m44716w());
                        String str6 = CDicEPFragment.this.f75847Z3;
                        if (str6 == null || str6.length() == 0) {
                            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(CDicEPFragment.this.f75851d4.split("-")[1], ",,,,,");
                            String str7 = splitByWholeSeparator[0];
                            String str8 = splitByWholeSeparator[1];
                            CDicEPFragment cDicEPFragment = CDicEPFragment.this;
                            cDicEPFragment.f75852e4 = str8;
                            ArrayList<Bundle> m4952W = compressHelper.m4952W(cDicEPFragment.f75850c4, "Select english.id as id,Word,Mean,Grammer, Phonetic, USVoice, UKVoice, TCode, type, Type.id as typeId  from English Inner Join Type On English.TCode = Type.ID where english.id in (" + str7 + ")", "HData.db");
                            ArrayList<Bundle> m4952W2 = compressHelper.m4952W(CDicEPFragment.this.f75850c4, "Select * from Sample where word = '" + str8 + "'", "HData.db");
                            ArrayList<Bundle> m4952W3 = compressHelper.m4952W(CDicEPFragment.this.f75850c4, "Select * from Verb where verb = '" + str8 + "'", "HData.db");
                            Iterator<Bundle> it4 = m4952W.iterator();
                            String str9 = null;
                            String str10 = null;
                            String str11 = null;
                            while (it4.hasNext()) {
                                Bundle next = it4.next();
                                if (next.getString("Grammer").length() > 0) {
                                    str10 = next.getString("Grammer");
                                    str11 = next.getString("id");
                                }
                                if (next.getString(str5).length() > 0) {
                                    next.getString(str5);
                                    next.getString("id");
                                }
                                String str12 = str5;
                                if (next.getString("USVoice").equals(IcyHeaders.f35463C2)) {
                                    str9 = next.getString("id");
                                }
                                str5 = str12;
                            }
                            CDicEPFragment cDicEPFragment2 = CDicEPFragment.this;
                            cDicEPFragment2.f74302w4 = str9;
                            String m4117W3 = cDicEPFragment2.m4117W3(cDicEPFragment2.m44716w(), "EPHeader.css");
                            CDicEPFragment cDicEPFragment3 = CDicEPFragment.this;
                            String m4117W32 = cDicEPFragment3.m4117W3(cDicEPFragment3.m44716w(), "EPFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", CDicEPFragment.this.f75852e4);
                            String str13 = "</head><body><a name=\"f0\"><div class=\"title\">" + str8 + "</div></a>";
                            ArrayList arrayList = new ArrayList();
                            ArrayList arrayList2 = new ArrayList();
                            Iterator<Bundle> it5 = m4952W.iterator();
                            while (it5.hasNext()) {
                                Bundle next2 = it5.next();
                                String str14 = str4;
                                String str15 = str13;
                                String m5015B = compressHelper.m5015B(next2.getString("type"), next2.getString("typeId"), "127");
                                String m5015B2 = compressHelper.m5015B(next2.getString("Mean"), next2.getString("id"), "127");
                                if (arrayList.contains(m5015B)) {
                                    int indexOf = arrayList.indexOf(m5015B);
                                    StringBuilder sb = new StringBuilder();
                                    it3 = it5;
                                    sb.append((String) arrayList2.get(indexOf));
                                    sb.append("<br>");
                                    sb.append(m5015B2);
                                    m5015B2 = sb.toString();
                                    arrayList2.remove(indexOf);
                                    arrayList.remove(indexOf);
                                } else {
                                    it3 = it5;
                                }
                                arrayList.add(m5015B);
                                arrayList2.add(m5015B2);
                                str4 = str14;
                                str13 = str15;
                                it5 = it3;
                            }
                            String str16 = str4;
                            String str17 = str13;
                            int i = 0;
                            int i2 = 0;
                            while (i < arrayList.size()) {
                                String str18 = m4117W32;
                                if (((String) arrayList.get(i)).equals("معنی عمومی")) {
                                    StringBuilder sb2 = new StringBuilder();
                                    sb2.append(str17);
                                    str = replace;
                                    str2 = str11;
                                    sb2.append(CDicEPFragment.this.m4699D4(i2, (String) arrayList.get(i), CDicEPFragment.this.m4693x4((String) arrayList2.get(i))));
                                    str3 = sb2.toString();
                                } else {
                                    str = replace;
                                    str2 = str11;
                                    str3 = str17 + CDicEPFragment.this.m4699D4(i2, (String) arrayList.get(i), (String) arrayList2.get(i));
                                }
                                str17 = str3;
                                i2++;
                                i++;
                                m4117W32 = str18;
                                replace = str;
                                str11 = str2;
                            }
                            String str19 = replace;
                            String str20 = m4117W32;
                            String str21 = str11;
                            if (m4952W2 != null && m4952W2.size() > 0) {
                                String str22 = str16;
                                while (m4952W2.iterator().hasNext()) {
                                    str22 = str22 + CDicEPFragment.this.m4695H4(it2.next());
                                }
                                str17 = str17 + CDicEPFragment.this.m4697F4(122, "Samples", str22);
                            }
                            if (m4952W3 != null && m4952W3.size() > 0) {
                                Bundle bundle2 = m4952W3.get(0);
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append(str17);
                                CDicEPFragment cDicEPFragment4 = CDicEPFragment.this;
                                sb3.append(cDicEPFragment4.m4694I4(123, "Verbs", cDicEPFragment4.m4693x4(compressHelper.m5015B(bundle2.getString("forms"), bundle2.getString("id"), "127"))));
                                str17 = sb3.toString();
                            }
                            if (str10 != null) {
                                String m5015B3 = compressHelper.m5015B(str10, str21, "127");
                                str17 = str17 + CDicEPFragment.this.m4697F4(222, "گرامر", m5015B3);
                            }
                            CDicEPFragment.this.m4087m3();
                            CDicEPFragment.this.f75847Z3 = str19 + str17 + str20;
                        }
                        if (compressHelper.m4892n1()) {
                            return;
                        }
                        CDicEPFragment cDicEPFragment5 = CDicEPFragment.this;
                        cDicEPFragment5.m4102d4(cDicEPFragment5.f75852e4);
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        e.printStackTrace();
                        CDicEPFragment.this.f75837P3 = e.getLocalizedMessage();
                    }
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicEPActivity.CDicEPFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = CDicEPFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        CDicEPFragment cDicEPFragment = CDicEPFragment.this;
                        cDicEPFragment.m4078s4(cDicEPFragment.f75837P3);
                        return;
                    }
                    File file = new File(CompressHelper.m4945Y0(CDicEPFragment.this.f75850c4, "base"));
                    CDicEPFragment cDicEPFragment2 = CDicEPFragment.this;
                    cDicEPFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", cDicEPFragment2.f75847Z3, "text/html", "utf-8", null);
                    CDicEPFragment.this.m4092j4();
                    CDicEPFragment.this.m4098g4();
                    CDicEPFragment.this.m4100f3(C4804R.C4811menu.f87333menu_cdic_e);
                    CDicEPFragment.this.m44735q2(false);
                    CDicEPFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86794action_sound_us || itemId == C4804R.C4808id.f86793action_sound_uk) {
                new CompressHelper(m44716w());
                String str = itemId == C4804R.C4808id.f86794action_sound_us ? "US" : "UK";
                String str2 = str + "/" + this.f74302w4 + ".mp3";
                new File(CompressHelper.m4942Z0(this.f75850c4, str + this.f74302w4 + ".mp3", "base"));
                String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, str + ".zip");
                String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, str + this.f74302w4 + ".mp3", "base");
                StringBuilder sb = new StringBuilder();
                sb.append(this.f74302w4);
                sb.append(".mp3");
                m4119V3(m4945Y0, str2, m4942Z0, sb.toString());
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            if (this.f74302w4 == null) {
                menu.removeItem(C4804R.C4808id.f86793action_sound_uk);
                menu.removeItem(C4804R.C4808id.f86794action_sound_us);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
            new CompressHelper(m44716w());
            if (str2.equals("sample")) {
                String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "Samples.zip");
                String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, "sample" + str3 + ".mp3", "base");
                StringBuilder sb = new StringBuilder();
                sb.append(str3);
                sb.append(".mp3");
                m4119V3(m4945Y0, "Samples/" + str3 + ".mp3", m4942Z0, sb.toString());
                return true;
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new CDicEPFragment(), bundle);
    }
}
