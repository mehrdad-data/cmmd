package net.imedicaldoctor.imd.Fragments.Dictionary;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.fragment.app.FragmentManager;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.net.URLDecoder;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class CDicEEActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class CDicEEFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        private Bundle f74292A4;

        /* renamed from: w4 */
        private String f74293w4;

        /* renamed from: x4 */
        private int f74294x4;

        /* renamed from: y4 */
        private Bundle f74295y4;

        /* renamed from: z4 */
        private String f74296z4;

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: C4 */
        public String m4706C4(String str) {
            return str.replace("</S>", "</SPAN>").replace("<SC=", "<SPAN CLASS=").replace("<DC=", "<DIV CLASS=").replace("<PC=", "<P CLASS=");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87333menu_cdic_e, menu);
            m4096h4(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f74295y4 = bundle.getBundle("mSound");
                this.f74296z4 = bundle.getString("mLastSampleSoundFileName");
                this.f74292A4 = bundle.getBundle("mMean");
            }
            if (m44859B() == null) {
                return inflate;
            }
            this.f74294x4++;
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicEEActivity.CDicEEFragment.1
                /* JADX WARN: Removed duplicated region for block: B:38:0x02e3 A[Catch: Exception -> 0x0304, TryCatch #0 {Exception -> 0x0304, blocks: (B:3:0x0006, B:6:0x003a, B:36:0x02d1, B:38:0x02e3, B:42:0x02fe, B:39:0x02ee, B:41:0x02f6, B:10:0x004b, B:13:0x006f, B:15:0x00c2, B:16:0x00e6, B:19:0x00ff, B:22:0x0147, B:24:0x0159, B:26:0x019f, B:28:0x01aa, B:32:0x01fa, B:33:0x022f, B:35:0x023d), top: B:47:0x0006 }] */
                /* JADX WARN: Removed duplicated region for block: B:39:0x02ee A[Catch: Exception -> 0x0304, TryCatch #0 {Exception -> 0x0304, blocks: (B:3:0x0006, B:6:0x003a, B:36:0x02d1, B:38:0x02e3, B:42:0x02fe, B:39:0x02ee, B:41:0x02f6, B:10:0x004b, B:13:0x006f, B:15:0x00c2, B:16:0x00e6, B:19:0x00ff, B:22:0x0147, B:24:0x0159, B:26:0x019f, B:28:0x01aa, B:32:0x01fa, B:33:0x022f, B:35:0x023d), top: B:47:0x0006 }] */
                @Override // java.lang.Runnable
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                public void run() {
                    /*
                        Method dump skipped, instructions count: 792
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Dictionary.CDicEEActivity.CDicEEFragment.RunnableC37861.run():void");
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.CDicEEActivity.CDicEEFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = CDicEEFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        CDicEEFragment cDicEEFragment = CDicEEFragment.this;
                        cDicEEFragment.m4078s4(cDicEEFragment.f75837P3);
                        return;
                    }
                    if (!CDicEEFragment.this.f75863p4.m4892n1()) {
                        CDicEEFragment cDicEEFragment2 = CDicEEFragment.this;
                        cDicEEFragment2.m4102d4(cDicEEFragment2.f75852e4);
                    }
                    File file = new File(CDicEEFragment.this.f74293w4);
                    String str2 = "file://" + file.getAbsolutePath() + "/";
                    CDicEEFragment cDicEEFragment3 = CDicEEFragment.this;
                    cDicEEFragment3.f75853f4.loadDataWithBaseURL(str2, cDicEEFragment3.f75847Z3, "text/html", "utf-8", null);
                    CDicEEFragment.this.m4092j4();
                    CDicEEFragment.this.m4098g4();
                    CDicEEFragment.this.m4100f3(C4804R.C4811menu.f87333menu_cdic_e);
                    CDicEEFragment.this.m44735q2(false);
                    CDicEEFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            menuItem.getItemId();
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            String str4;
            String m4942Z0;
            WebViewDialog webViewDialog;
            FragmentManager m44820L;
            String str5;
            String str6;
            String m4945Y0;
            String str7;
            String m4942Z02;
            String str8;
            try {
                iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
                CompressHelper compressHelper = new CompressHelper(m44716w());
                if (str2.equals("about")) {
                    String substring = StringUtils.splitByWholeSeparator(str3, "?")[0].substring(1);
                    String m4945Y02 = CompressHelper.m4945Y0(this.f75850c4, "about" + substring);
                    compressHelper.m4883q1(this.f75850c4, "URL-file://" + new File(m4945Y02).getAbsolutePath(), null, null);
                    return true;
                } else if (str2.equals("firsttap")) {
                    iMDLogger.m3294f("DicEEShould", "First Tap");
                    return true;
                } else if (str2.equals(Annotation.f59806M2)) {
                    String m4942Z03 = CompressHelper.m4942Z0(this.f75850c4, "us_", "Longman-tmp");
                    String m4942Z04 = CompressHelper.m4942Z0(this.f75850c4, "uk_", "Longman-tmp");
                    try {
                        str8 = URLDecoder.decode(str3, "UTF-8");
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        iMDLogger.m3294f("CDicEEShould", "Error in decoding " + str3 + " : " + e.toString());
                        str8 = str3;
                    }
                    int indexOf = str8.indexOf(m4942Z03);
                    String m4945Y03 = CompressHelper.m4945Y0(this.f75850c4, "LongSounds.zip");
                    if (indexOf >= 0) {
                        if (!new File(m4945Y03).exists()) {
                            CompressHelper.m4921e2(m44716w(), "Not Available", 1);
                            return true;
                        }
                        m4119V3(m4945Y03, "Sounds/" + this.f74295y4.getString("id") + "us.aif", CompressHelper.m4945Y0(this.f75850c4, "USSound" + this.f74295y4.getString("id") + "us.aif"), "USSound");
                        return true;
                    } else if (str8.indexOf(m4942Z04) < 0) {
                        if (str8.indexOf("#") < 0 && str8.indexOf("Oxford-tmp/hide") < 0) {
                            WebViewDialog webViewDialog2 = new WebViewDialog();
                            Bundle bundle = new Bundle();
                            bundle.putBundle("db", this.f75850c4);
                            bundle.putString("url", str);
                            webViewDialog2.m44751k2(bundle);
                            webViewDialog2.m44870c3(true);
                            webViewDialog2.m44844E2(this, 0);
                            webViewDialog2.mo29915h3(m44820L(), "CDicEEFragment");
                            return true;
                        }
                        return true;
                    } else if (!new File(m4945Y03).exists()) {
                        CompressHelper.m4921e2(m44716w(), "Not Available", 1);
                        return true;
                    } else {
                        m4119V3(m4945Y03, "" + this.f74295y4.getString("id") + "uk.aif", CompressHelper.m4945Y0(this.f75850c4, "UKSound" + this.f74295y4.getString("id") + "uk.aif"), "UKSound");
                        return true;
                    }
                } else if (str2.equals("actionmenu")) {
                    StringUtils.splitByWholeSeparator(str3.replace("//", ""), "&");
                    return true;
                } else if (str2.equals("sound")) {
                    int indexOf2 = str3.indexOf("src=");
                    if (indexOf2 < 0) {
                        str6 = compressHelper.m4904j1(StringUtils.splitByWholeSeparator(str3, "/")).replace(".WAV", ".mp3");
                        this.f74296z4 = str6;
                        if (!new File(CompressHelper.m4945Y0(this.f75850c4, "LongSamples.zip")).exists()) {
                            CompressHelper.m4921e2(m44716w(), "Not Available", 1);
                            return true;
                        }
                        m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "LongSamples.zip");
                        str7 = "LongSamples/" + str6;
                        m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, "LongSamples" + str6, "base");
                    } else {
                        str6 = str3.substring(indexOf2 + 4) + ".mp3";
                        if (!new File(CompressHelper.m4945Y0(this.f75850c4, "OxfSounds.zip")).exists()) {
                            CompressHelper.m4921e2(m44716w(), "Not Available", 1);
                            return true;
                        }
                        m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "OxfSounds.zip");
                        str7 = "Sounds/" + str6;
                        m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, "OxfSamples" + str6, "base");
                    }
                    m4119V3(m4945Y0, str7, m4942Z02, str6);
                    return true;
                } else if (str2.equals("soundagain")) {
                    m4119V3(CompressHelper.m4945Y0(this.f75850c4, "LongSamples.zip"), "LongSamples/" + this.f74296z4, CompressHelper.m4942Z0(this.f75850c4, "LongSamples" + this.f74296z4, "base"), this.f74296z4);
                    return true;
                } else {
                    if (str2.equals(HTML.Tag.f65852C)) {
                        String m4920f = CompressHelper.m4920f(str, "list_idx=(", ")");
                        String m4920f2 = CompressHelper.m4920f(str, "entry_idx=(", ")");
                        CompressHelper.m4920f(str, "label=(", ")");
                        if (m4920f.equals("5")) {
                            String m4942Z05 = CompressHelper.m4942Z0(this.f75850c4, "oxfordhelp.html", "Oxford-tmp");
                            WebViewDialog webViewDialog3 = new WebViewDialog();
                            Bundle bundle2 = new Bundle();
                            bundle2.putBundle("db", this.f75850c4);
                            bundle2.putString("url", "file://" + new File(m4942Z05).getAbsolutePath());
                            webViewDialog3.m44751k2(bundle2);
                            webViewDialog3.m44870c3(true);
                            webViewDialog3.m44844E2(this, 0);
                            webViewDialog3.mo29915h3(m44820L(), "CDicEEFragment");
                            return true;
                        }
                        str4 = "CDicEEFragment";
                        if (!m4920f.equals(IcyHeaders.f35463C2)) {
                            return true;
                        }
                        Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4952W(this.f75850c4, "Select * from OxfExtra where id = " + m4920f2, "OxfMean.db"));
                        String m5015B = compressHelper.m5015B(m4907i1.getString("mean"), m4907i1.getString("id"), "127");
                        webViewDialog = new WebViewDialog();
                        Bundle bundle3 = new Bundle();
                        bundle3.putBundle("db", this.f75850c4);
                        bundle3.putString("baseURL", "file://" + new File(CompressHelper.m4945Y0(this.f75850c4, "Oxford-tmp")).getAbsolutePath() + "/");
                        bundle3.putString("htmlString", m5015B);
                        webViewDialog.m44751k2(bundle3);
                        webViewDialog.m44870c3(true);
                        webViewDialog.m44844E2(this, 0);
                        m44820L = m44820L();
                    } else {
                        str4 = "CDicEEFragment";
                        if (str2.equals("extsnd")) {
                            try {
                                str5 = URLDecoder.decode(str, "UTF-8");
                            } catch (Exception unused) {
                                str5 = str;
                            }
                            String string = compressHelper.m4858z(compressHelper.m4955V(this.f75850c4, "select * from OxfSample where wordId=" + this.f74292A4.getString("id") + " AND sample = '" + str5 + "'")).getString("id");
                            StringBuilder sb = new StringBuilder();
                            sb.append(string);
                            sb.append(".mp3");
                            String sb2 = sb.toString();
                            String str9 = "OxfSamples" + (str3.indexOf("43464635") < 0 ? "US" : "UK");
                            m4119V3(CompressHelper.m4945Y0(this.f75850c4, str9 + ".zip"), str9 + "/" + sb2, CompressHelper.m4942Z0(this.f75850c4, str9 + sb2, "base"), sb2);
                            return true;
                        } else if (!str2.equals("image")) {
                            return true;
                        } else {
                            String m4920f3 = CompressHelper.m4920f(str3 + ":::", "src=", ":::");
                            webViewDialog = new WebViewDialog();
                            Bundle bundle4 = new Bundle();
                            bundle4.putBundle("db", this.f75850c4);
                            bundle4.putString("baseURL", "file://" + new File(m4942Z0).getAbsolutePath() + "/");
                            bundle4.putString("htmlString", "<html><head><meta name=\"viewport\" content=\"width=device-width; initial-scale=1.0; maximum-scale=2.0; minimum-scale=0.1; user-scalable=1\"/></head><body><img src='" + (CompressHelper.m4942Z0(this.f75850c4, "Images", "Oxford-tmp") + m4920f3 + ".jpg") + "'/></body></html>");
                            webViewDialog.m44751k2(bundle4);
                            webViewDialog.m44870c3(true);
                            webViewDialog.m44844E2(this, 0);
                            m44820L = m44820L();
                        }
                    }
                    webViewDialog.mo29915h3(m44820L, str4);
                    return true;
                }
            } catch (Exception e2) {
                FirebaseCrashlytics.m18030d().m18027g(e2);
                return true;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new CDicEEFragment(), bundle);
    }
}
