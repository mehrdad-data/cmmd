package net.imedicaldoctor.imd.Fragments.Dictionary;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.iMDLogger;

/* loaded from: classes2.dex */
public class WebViewDialog extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f74328g4;

    /* renamed from: h4 */
    private View f74329h4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87156fragment_general_viewer, (ViewGroup) null);
        this.f74329h4 = inflate;
        WebView webView = (WebView) inflate.findViewById(C4804R.C4808id.f87082webView);
        this.f74328g4 = m44859B().getBundle("db");
        if (m44859B().containsKey("url")) {
            webView.loadUrl(m44859B().getString("url"));
        } else {
            webView.loadDataWithBaseURL(m44859B().getString("baseURL"), m44859B().getString("htmlString"), "text/html", "utf-8", null);
        }
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebChromeClient(new WebChromeClient() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.WebViewDialog.1
            @Override // android.webkit.WebChromeClient
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                iMDLogger.m3294f("DialogConsole", consoleMessage.message());
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() { // from class: net.imedicaldoctor.imd.Fragments.Dictionary.WebViewDialog.2
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView2, String str) {
                return false;
            }
        });
        builder.setView(inflate);
        return builder.create();
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: p1 */
    public void mo3867p1(View view, Bundle bundle) {
        super.mo3867p1(view, bundle);
        ((WebView) this.f74329h4.findViewById(C4804R.C4808id.f87082webView)).loadUrl(m44859B().getString("url"));
    }
}
