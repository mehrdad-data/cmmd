package net.imedicaldoctor.imd.Fragments.mksap;

import android.os.Bundle;
import android.view.Menu;
import android.webkit.ConsoleMessage;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.IOUtils;

/* loaded from: classes2.dex */
public class MKSAPActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public boolean f76955w4;

    /* renamed from: x4 */
    public String f76956x4;

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        iMDLogger.m3294f("Javascript Console Message", consoleMessage.message() + " - " + consoleMessage.sourceId() + " - " + consoleMessage.lineNumber());
        String[] split = consoleMessage.message().split(",,,,,");
        if (split[0].equals("title") && split.length == 2) {
            String str = split[1];
            this.f75852e4 = str;
            this.f75858k4.setTitle(str);
            this.f75863p4.m4872u0(this.f75850c4.getString("Name"), this.f75850c4.getString("Title"), this.f75851d4, this.f75852e4);
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: R3 */
    public void mo3570R3(WebView webView, String str) {
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(final WebView webView, final String str) {
        iMDLogger.m3294f(" Finished", str);
        this.f75851d4 = str;
        this.f75853f4.loadUrl("javascript:console.log('title,,,,,' + document.title )");
        this.f75833L3 = true;
        this.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.mksap.MKSAPActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                MKSAPActivityFragment.super.mo3569S3(webView, str);
            }
        }, 3000L);
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x011d  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0179 A[Catch: Exception -> 0x01dc, TryCatch #0 {Exception -> 0x01dc, blocks: (B:9:0x0030, B:12:0x0054, B:13:0x0056, B:15:0x005e, B:16:0x0076, B:18:0x009e, B:30:0x00ef, B:33:0x011e, B:35:0x0179, B:36:0x017d, B:29:0x00cd, B:37:0x01ad, B:39:0x01c2, B:40:0x01ca), top: B:46:0x0030 }] */
    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View mo3277U0(android.view.LayoutInflater r17, android.view.ViewGroup r18, android.os.Bundle r19) {
        /*
            Method dump skipped, instructions count: 513
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.mksap.MKSAPActivityFragment.mo3277U0(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
        menu.removeItem(C4804R.C4808id.f86776action_menu);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: m4 */
    public boolean mo3567m4() {
        return false;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: n4 */
    public WebResourceResponse mo3566n4(WebView webView, WebResourceRequest webResourceRequest) {
        String uri = webResourceRequest.getUrl().toString();
        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(uri, "/");
        String str = splitByWholeSeparator[splitByWholeSeparator.length - 1];
        if (str.endsWith(".json")) {
            String replace = str.replace(".json", "");
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(bundle, "select * from docs where docName='" + replace + "'"));
            if (m4907i1 == null) {
                iMDLogger.m3294f("MKSAP", "can't find json of " + uri + StringUtils.SPACE + m4907i1);
                return null;
            }
            return new WebResourceResponse("text/json", "utf-8", IOUtils.toInputStream(this.f75863p4.m5015B(m4907i1.getString("content"), m4907i1.getString("docName"), "127")));
        }
        return null;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: o4 */
    public WebResourceResponse mo3565o4(WebView webView, String str) {
        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str, "/");
        String str2 = splitByWholeSeparator[splitByWholeSeparator.length - 1];
        if (str2.endsWith(".json")) {
            String replace = str2.replace(".json", "");
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(bundle, "select * from docs where docName='" + replace + "'"));
            if (m4907i1 == null) {
                iMDLogger.m3294f("MKSAP", "can't find json of " + str + StringUtils.SPACE + m4907i1);
                return null;
            }
            return new WebResourceResponse("text/json", "utf-8", IOUtils.toInputStream(this.f75863p4.m5015B(m4907i1.getString("content"), m4907i1.getString("docName"), "127")));
        }
        return null;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: y4 */
    public Boolean m3562y4() {
        return this.f75850c4.getString("Name").toLowerCase().contains("mksap17") ? Boolean.FALSE : Boolean.TRUE;
    }
}
