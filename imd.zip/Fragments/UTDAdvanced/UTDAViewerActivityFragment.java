package net.imedicaldoctor.imd.Fragments.UTDAdvanced;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class UTDAViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public String f75566A4;

    /* renamed from: w4 */
    public Bundle f75567w4;

    /* renamed from: x4 */
    public ArrayList<String> f75568x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75569y4;

    /* renamed from: z4 */
    public int f75570z4;

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4258z4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f75568x4 = arrayList;
            mo3978f4();
        } else if (split[0].equals("reload")) {
            this.f75566A4 = split[1];
            this.f75847Z3 = m4259y4();
            File file = new File(CompressHelper.m4945Y0(this.f75850c4, "base"));
            this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return m4071w3(this.f75568x4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        String m4920f = CompressHelper.m4920f(this.f75847Z3, "<script>", "</script>");
        WebView webView2 = this.f75853f4;
        webView2.loadUrl("javascript:" + m4920f);
        this.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.UTDAdvanced.UTDAViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
            }
        }, 1000L);
        this.f75853f4.loadUrl("javascript:jQuery.fn.animateTextViewAnswerChange();");
        this.f75853f4.loadUrl("javascript:jQuery.fn.addSummaryButtonProperties();");
        this.f75853f4.loadUrl("javascript:$('table.group').last()[0].scrollIntoView();");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        try {
            String str = this.f75847Z3;
            if (str == null || str.length() == 0) {
                this.f75566A4 = "";
                this.f75847Z3 = m4259y4();
            }
            File file = new File(CompressHelper.m4945Y0(this.f75850c4, "base"));
            m4087m3();
            this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
            m4092j4();
            m4098g4();
            m4100f3(C4804R.C4811menu.f87323elsviewer2);
            m44735q2(false);
            m4140G3();
        } catch (Exception e) {
            m4080r4(e);
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            return true;
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f75569y4);
            bundle.putString("TitleProperty", "label");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        if (str2.equals("image")) {
            return true;
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public void m4260x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f75569y4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4259y4() {
        iMDLogger.m3294f("Loading Document", this.f75851d4);
        String[] split = this.f75851d4.split("-");
        this.f75569y4 = new ArrayList<>();
        this.f75570z4 = 0;
        ArrayList<Bundle> m4952W = this.f75863p4.m4952W(this.f75850c4, "Select * from pages where post='" + this.f75566A4 + "'", "pathways/" + split[1] + ".db");
        if (m4952W == null || m4952W.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "Document doesn't exist", 1);
            return "";
        }
        this.f75567w4 = m4952W.get(0);
        this.f75852e4 = this.f75863p4.m4952W(this.f75850c4, "Select * from TOC where id=" + split[1], "pathways.db").get(0).getString("title");
        String string = this.f75567w4.getString("result");
        if (!string.contains("<form")) {
            string = new String(this.f75863p4.m4870v(string, split[1], "127"));
        }
        String replace = string.replace("jQuery.fn.handleCheckBoxClick(this)", "handleCheckBoxClick(this)");
        String m4117W3 = m4117W3(m44716w(), "UTDAHeader.css");
        String m4117W32 = m4117W3(m44716w(), "UTDAFooter.css");
        return m4117W3.replace("[size]", "200").replace("[title]", this.f75852e4) + replace + m4117W32;
    }

    /* renamed from: z4 */
    public String m4258z4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }
}
