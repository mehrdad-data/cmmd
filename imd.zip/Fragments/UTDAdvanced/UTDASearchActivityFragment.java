package net.imedicaldoctor.imd.Fragments.UTDAdvanced;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.itextpdf.tool.xml.html.HTML;
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter;
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersDecoration;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersSectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class UTDASearchActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    private StickyRecyclerHeadersDecoration f75556b4;

    /* renamed from: c4 */
    public SpellSearchAdapter f75557c4;

    /* renamed from: d4 */
    public String f75558d4;

    /* renamed from: e4 */
    public TabLayout f75559e4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87169fragment_new_list_tab, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f75559e4 = (TabLayout) this.f75221R3.findViewById(C4804R.C4808id.f87042tabs);
        ((AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar)).m27445s(true, false);
        ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
        this.f75558d4 = null;
        this.f75218O3 = this.f75215L3.m4952W(this.f75212I3, "SELECT * FROM toc order by section asc", "pathways.db");
        this.f75559e4.setVisibility(0);
        String[] strArr = {"Pathways", "Lab Interpretation"};
        for (int i = 0; i < 2; i++) {
            TabLayout.Tab m24950D = this.f75559e4.m24950D();
            m24950D.m24890D(strArr[i]);
            this.f75559e4.m24926e(m24950D);
        }
        this.f75559e4.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: net.imedicaldoctor.imd.Fragments.UTDAdvanced.UTDASearchActivityFragment.1
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: a */
            public void mo4174a(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: b */
            public void mo4173b(TabLayout.Tab tab) {
                UTDASearchActivityFragment uTDASearchActivityFragment;
                CompressHelper compressHelper;
                Bundle bundle2;
                String str;
                String str2;
                if (tab.m24878k() == 0) {
                    uTDASearchActivityFragment = UTDASearchActivityFragment.this;
                    compressHelper = uTDASearchActivityFragment.f75215L3;
                    bundle2 = uTDASearchActivityFragment.f75212I3;
                    str = "SELECT * FROM TOC order by section asc";
                    str2 = "pathways.db";
                } else {
                    uTDASearchActivityFragment = UTDASearchActivityFragment.this;
                    compressHelper = uTDASearchActivityFragment.f75215L3;
                    bundle2 = uTDASearchActivityFragment.f75212I3;
                    str = "SELECT * FROM TOC";
                    str2 = "lab.db";
                }
                uTDASearchActivityFragment.f75218O3 = compressHelper.m4952W(bundle2, str, str2);
                if (UTDASearchActivityFragment.this.f75223T3.getQuery().toString().length() > 0) {
                    UTDASearchActivityFragment uTDASearchActivityFragment2 = UTDASearchActivityFragment.this;
                    uTDASearchActivityFragment2.f75219P3 = uTDASearchActivityFragment2.mo3981d3(uTDASearchActivityFragment2.f75223T3.getQuery().toString());
                    UTDASearchActivityFragment.this.mo3982a3();
                    return;
                }
                UTDASearchActivityFragment uTDASearchActivityFragment3 = UTDASearchActivityFragment.this;
                ((ChaptersSectionAdapter) uTDASearchActivityFragment3.f75216M3).m3399g0(uTDASearchActivityFragment3.f75218O3);
                UTDASearchActivityFragment uTDASearchActivityFragment4 = UTDASearchActivityFragment.this;
                uTDASearchActivityFragment4.f75227X3.setAdapter(uTDASearchActivityFragment4.f75216M3);
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: c */
            public void mo4172c(TabLayout.Tab tab) {
            }
        });
        this.f75216M3 = new ChaptersSectionAdapter(m44716w(), this.f75218O3, "title", HTML.Tag.f65890V) { // from class: net.imedicaldoctor.imd.Fragments.UTDAdvanced.UTDASearchActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersSectionAdapter
            /* renamed from: f0 */
            public void mo3400f0(Bundle bundle2, int i2) {
                UTDASearchActivityFragment.this.m4330Y2();
                if (bundle2.getString("leaf").equals(IcyHeaders.f35463C2)) {
                    if (UTDASearchActivityFragment.this.f75559e4.getSelectedTabPosition() == 0) {
                        CompressHelper compressHelper = new CompressHelper(UTDASearchActivityFragment.this.m44716w());
                        Bundle bundle3 = UTDASearchActivityFragment.this.f75212I3;
                        compressHelper.m4883q1(bundle3, "pathway-" + bundle2.getString("id"), null, null);
                        return;
                    }
                    CompressHelper compressHelper2 = new CompressHelper(UTDASearchActivityFragment.this.m44716w());
                    Bundle bundle4 = UTDASearchActivityFragment.this.f75212I3;
                    compressHelper2.m4883q1(bundle4, "lab-" + bundle2.getString("id"), null, null);
                }
            }
        };
        this.f75557c4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.UTDAdvanced.UTDASearchActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i2) {
                TextView textView;
                int i3;
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle2.getString("text"));
                rippleTextFullViewHolder.f83285J.setText(bundle2.getString("content"));
                if (bundle2.getString("content").equals(bundle2.getString("text")) || bundle2.getString("content").length() == 0) {
                    textView = rippleTextFullViewHolder.f83285J;
                    i3 = 8;
                } else {
                    textView = rippleTextFullViewHolder.f83285J;
                    i3 = 0;
                }
                textView.setVisibility(i3);
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UTDAdvanced.UTDASearchActivityFragment.3.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CompressHelper compressHelper;
                        Bundle bundle3;
                        StringBuilder sb;
                        String str;
                        UTDASearchActivityFragment.this.m4330Y2();
                        if (bundle2.getString("typeText").equals("Pathway")) {
                            UTDASearchActivityFragment uTDASearchActivityFragment = UTDASearchActivityFragment.this;
                            compressHelper = uTDASearchActivityFragment.f75215L3;
                            bundle3 = uTDASearchActivityFragment.f75212I3;
                            sb = new StringBuilder();
                            str = "pathway-";
                        } else {
                            UTDASearchActivityFragment uTDASearchActivityFragment2 = UTDASearchActivityFragment.this;
                            compressHelper = uTDASearchActivityFragment2.f75215L3;
                            bundle3 = uTDASearchActivityFragment2.f75212I3;
                            sb = new StringBuilder();
                            str = "lab-";
                        }
                        sb.append(str);
                        sb.append(bundle2.getString("contentId"));
                        compressHelper.m4883q1(bundle3, sb.toString(), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle2) {
                UTDASearchActivityFragment.this.m4330Y2();
                UTDASearchActivityFragment.this.f75223T3.m51655i0(bundle2.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        StickyRecyclerHeadersDecoration stickyRecyclerHeadersDecoration = new StickyRecyclerHeadersDecoration((StickyRecyclerHeadersAdapter) this.f75216M3);
        this.f75556b4 = stickyRecyclerHeadersDecoration;
        this.f75227X3.m42923n(stickyRecyclerHeadersDecoration);
        this.f75227X3.setLayoutManager(new LinearLayoutManager(m44716w()));
        this.f75227X3.setItemAnimator(new DefaultItemAnimator());
        this.f75227X3.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f75216M3.m42849Z(new RecyclerView.AdapterDataObserver() { // from class: net.imedicaldoctor.imd.Fragments.UTDAdvanced.UTDASearchActivityFragment.4
            @Override // androidx.recyclerview.widget.RecyclerView.AdapterDataObserver
            /* renamed from: a */
            public void mo3511a() {
                UTDASearchActivityFragment.this.f75556b4.m8633n();
            }
        });
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75557c4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f75557c4);
        this.f75556b4.m8633n();
        this.f75227X3.m42906s1(this.f75556b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: c3 */
    public void mo4182c3() {
        this.f75227X3.m42923n(this.f75556b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper;
        Bundle bundle;
        StringBuilder sb;
        String str2;
        if (this.f75559e4.getSelectedTabPosition() == 0) {
            compressHelper = this.f75215L3;
            bundle = this.f75212I3;
            sb = new StringBuilder();
            sb.append("Select * from search where search match '(text:");
            sb.append(str);
            sb.append("* OR content:");
            sb.append(str);
            str2 = "*) AND type:1 AND typeText:Pathway'";
        } else {
            compressHelper = this.f75215L3;
            bundle = this.f75212I3;
            sb = new StringBuilder();
            sb.append("Select * from search where search match '(text:");
            sb.append(str);
            sb.append("* OR content:");
            sb.append(str);
            str2 = "*) AND type:1 AND typeText:Lab'";
        }
        sb.append(str2);
        return compressHelper.m4952W(bundle, sb.toString(), "search.db");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4952W(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'", "search.db");
    }
}
