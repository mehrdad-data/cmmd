package net.imedicaldoctor.imd.Fragments.NEJM;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.itextpdf.tool.xml.html.HTML;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class NEJMTOCActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class NEJMTOCFragment extends SearchHelperFragment {

        /* renamed from: e4 */
        private static String f75051e4;

        /* renamed from: b4 */
        private String f75052b4;

        /* renamed from: c4 */
        private String f75053c4;

        /* renamed from: d4 */
        private String f75054d4;

        /* loaded from: classes2.dex */
        public class NEJMTOCAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f75058d;

            /* renamed from: e */
            public ArrayList<Bundle> f75059e;

            /* renamed from: f */
            public String f75060f;

            public NEJMTOCAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
                this.f75058d = context;
                this.f75059e = arrayList;
                this.f75060f = str;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                return 1;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                TextView textView;
                int i2;
                RippleTextSubtitleViewHolder rippleTextSubtitleViewHolder = (RippleTextSubtitleViewHolder) viewHolder;
                final Bundle bundle = this.f75059e.get(i);
                String string = bundle.getString(this.f75060f);
                if (string.length() == 0) {
                    string = "TOC and Adverts";
                }
                if (NEJMTOCFragment.this.f75052b4.equals("0")) {
                    rippleTextSubtitleViewHolder.f75065I.setText(string);
                    rippleTextSubtitleViewHolder.f75066J.setText("");
                    rippleTextSubtitleViewHolder.f75066J.setVisibility(8);
                    if (i % 2 == 0) {
                        textView = rippleTextSubtitleViewHolder.f75065I;
                        i2 = ViewCompat.f13139t;
                    } else {
                        textView = rippleTextSubtitleViewHolder.f75065I;
                        i2 = -12303292;
                    }
                    textView.setTextColor(i2);
                } else {
                    rippleTextSubtitleViewHolder.f75065I.setText(string);
                    rippleTextSubtitleViewHolder.f75066J.setVisibility(0);
                    if (bundle.getString("subtitle").length() == 0) {
                        rippleTextSubtitleViewHolder.f75066J.setVisibility(8);
                    } else {
                        rippleTextSubtitleViewHolder.f75066J.setVisibility(0);
                        rippleTextSubtitleViewHolder.f75066J.setText(bundle.getString("subtitle"));
                    }
                }
                rippleTextSubtitleViewHolder.f75067K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.NEJM.NEJMTOCActivity.NEJMTOCFragment.NEJMTOCAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        NEJMTOCAdapter.this.m4386d0(bundle, i);
                    }
                });
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                return new RippleTextSubtitleViewHolder(LayoutInflater.from(this.f75058d).inflate(C4804R.C4810layout.f87271list_view_item_ripple_text_subtitle, viewGroup, false));
            }

            /* renamed from: d0 */
            public void m4386d0(Bundle bundle, int i) {
                Bundle bundle2;
                CompressHelper compressHelper;
                if (NEJMTOCFragment.this.f75052b4.equals("0")) {
                    bundle2 = new Bundle();
                    bundle2.putBundle("DB", NEJMTOCFragment.this.f75212I3);
                    bundle2.putString("ParentId", bundle.getString("title"));
                    compressHelper = new CompressHelper(NEJMTOCFragment.this.m44716w());
                } else if (NEJMTOCFragment.this.f75052b4.equals("Issues")) {
                    bundle2 = new Bundle();
                    bundle2.putBundle("DB", NEJMTOCFragment.this.f75212I3);
                    bundle2.putString("ParentId", bundle.getString("title"));
                    bundle2.putString("Issue", bundle.getString("issueName"));
                    compressHelper = new CompressHelper(NEJMTOCFragment.this.m44716w());
                } else if (NEJMTOCFragment.this.f75053c4 == null || NEJMTOCFragment.this.f75054d4 != null) {
                    NEJMTOCFragment nEJMTOCFragment = NEJMTOCFragment.this;
                    nEJMTOCFragment.f75215L3.m4883q1(nEJMTOCFragment.f75212I3, bundle.getString("pid"), null, null);
                    return;
                } else {
                    bundle2 = new Bundle();
                    bundle2.putBundle("DB", NEJMTOCFragment.this.f75212I3);
                    bundle2.putString("ParentId", bundle.getString("title"));
                    bundle2.putString("Issue", NEJMTOCFragment.this.f75053c4);
                    bundle2.putString("IssueSection", bundle.getString("title"));
                    compressHelper = new CompressHelper(NEJMTOCFragment.this.m44716w());
                }
                compressHelper.m4979N(NEJMTOCActivity.class, NEJMTOCFragment.class, bundle2);
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                return this.f75059e.size();
            }
        }

        /* loaded from: classes2.dex */
        public class RippleTextSubtitleViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f75065I;

            /* renamed from: J */
            public TextView f75066J;

            /* renamed from: K */
            public MaterialRippleLayout f75067K;

            public RippleTextSubtitleViewHolder(View view) {
                super(view);
                this.f75065I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
                this.f75066J = (TextView) view.findViewById(C4804R.C4808id.f87032sub_text_view);
                this.f75067K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4337R2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            CompressHelper compressHelper;
            Bundle bundle2;
            StringBuilder sb;
            String str;
            ArrayList<Bundle> m4955V;
            CompressHelper compressHelper2;
            Bundle bundle3;
            String str2;
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4337R2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            if (m44859B() == null || !m44859B().containsKey("ParentId")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
                this.f75052b4 = "0";
            } else {
                if (m44859B().getString("ParentId").equals("0")) {
                    appBarLayout.m27445s(true, false);
                    relativeLayout.setVisibility(0);
                } else {
                    appBarLayout.m27445s(false, false);
                    appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.NEJM.NEJMTOCActivity.NEJMTOCFragment.1
                        @Override // java.lang.Runnable
                        public void run() {
                            relativeLayout.setVisibility(0);
                        }
                    }, 800L);
                }
                this.f75052b4 = m44859B().getString("ParentId");
            }
            if (m44859B() != null && m44859B().containsKey("Issue")) {
                this.f75053c4 = m44859B().getString("Issue");
            }
            if (m44859B() != null && m44859B().containsKey("IssueSection")) {
                this.f75054d4 = m44859B().getString("IssueSection");
            }
            if (this.f75052b4.equals("0")) {
                ArrayList arrayList = new ArrayList(Arrays.asList("Perspective", "Original Articles", "Review Article", "Images in Clinical Medicine", "Case Records of the Massachusetts General Hospital", "Editorial", "Correspondence", "Corrections", "Clinical Implications of Basic Research", "Editorials", "Special Article", "Clinical Therapeutics", "Clinical Practice", "Clinical Problem-Solving", "Review Articles", "Clinical Decisions", "Health Policy Report", "Correction", "Videos in Clinical Medicine", "Sounding Board", "Health Law, Ethics, and Human Rights", "Special Report", "Medicine and Society", "Special Articles", "Special Reports", "Occasional Notes", "Statistics in Medicine"));
                Collections.sort(arrayList);
                ArrayList<Bundle> arrayList2 = new ArrayList<>();
                Bundle bundle4 = new Bundle();
                bundle4.putString("title", "Issues");
                arrayList2.add(bundle4);
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    Bundle bundle5 = new Bundle();
                    bundle5.putString("title", (String) it2.next());
                    arrayList2.add(bundle5);
                }
                this.f75218O3 = arrayList2;
            } else {
                if (this.f75052b4.equals("Issues")) {
                    compressHelper2 = this.f75215L3;
                    bundle3 = this.f75212I3;
                    str2 = "Select subtitle as title,title as subtitle,issueName from issues order by publishedDate desc";
                } else {
                    if (this.f75053c4 == null) {
                        compressHelper = this.f75215L3;
                        bundle2 = this.f75212I3;
                        sb = new StringBuilder();
                        sb.append("Select title,issueTitle as subtitle,pid from contents where sectionName = '");
                        str = this.f75052b4;
                    } else if (this.f75054d4 != null) {
                        compressHelper = this.f75215L3;
                        bundle2 = this.f75212I3;
                        sb = new StringBuilder();
                        sb.append("Select title,issueTitle as subtitle,pid from contents where issueName='");
                        sb.append(this.f75053c4);
                        sb.append("' AND sectionName = '");
                        str = this.f75054d4;
                    } else {
                        compressHelper2 = this.f75215L3;
                        bundle3 = this.f75212I3;
                        str2 = "Select distinct(sectionName) as title,'' as subtitle from contents where issueName='" + this.f75053c4 + "'";
                    }
                    sb.append(str);
                    sb.append("' order by issueDate desc");
                    m4955V = compressHelper.m4955V(bundle2, sb.toString());
                    this.f75218O3 = m4955V;
                }
                m4955V = compressHelper2.m4955V(bundle3, str2);
                this.f75218O3 = m4955V;
            }
            this.f75216M3 = new NEJMTOCAdapter(m44716w(), this.f75218O3, "title");
            this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.NEJM.NEJMTOCActivity.NEJMTOCFragment.2
                @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
                /* renamed from: e0 */
                public void mo3397e0(Bundle bundle6, int i) {
                    NEJMTOCFragment.this.m4330Y2();
                    String string = bundle6.getString("type");
                    String string2 = bundle6.getString("contentId");
                    bundle6.getString(HTML.Tag.f65890V);
                    if (string.equals(IcyHeaders.f35463C2)) {
                        new CompressHelper(NEJMTOCFragment.this.m44716w()).m4883q1(NEJMTOCFragment.this.f75212I3, string2, null, null);
                    } else if (string.equals("5")) {
                        CompressHelper compressHelper3 = new CompressHelper(NEJMTOCFragment.this.m44716w());
                        NEJMTOCFragment nEJMTOCFragment = NEJMTOCFragment.this;
                        compressHelper3.m4883q1(nEJMTOCFragment.f75212I3, string2, nEJMTOCFragment.m4332W2(bundle6.getString("subText")), null);
                    }
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(false);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id, Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new NEJMTOCFragment());
    }
}
