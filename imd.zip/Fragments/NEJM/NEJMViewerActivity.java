package net.imedicaldoctor.imd.Fragments.NEJM;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import com.itextpdf.text.xml.xmp.DublinCoreProperties;
import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class NEJMViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class NEJMViewerFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        public String f75069A4;

        /* renamed from: B4 */
        public String f75070B4;

        /* renamed from: C4 */
        public boolean f75071C4;

        /* renamed from: D4 */
        public Bundle f75072D4;

        /* renamed from: w4 */
        private String f75073w4;

        /* renamed from: x4 */
        private MenuItem f75074x4;

        /* renamed from: y4 */
        public ArrayList<String> f75075y4;

        /* renamed from: z4 */
        public Bundle f75076z4;

        /* renamed from: B4 */
        private void m4384B4(String str) {
            ArrayList<String> arrayList = this.f75075y4;
            if (arrayList == null || arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
                return;
            }
            ArrayList arrayList2 = new ArrayList();
            Iterator<String> it2 = this.f75075y4.iterator();
            while (it2.hasNext()) {
                String next = it2.next();
                Bundle bundle = new Bundle();
                bundle.putString("ImagePath", next);
                try {
                    String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(next, "/");
                    String str2 = splitByWholeSeparator[splitByWholeSeparator.length - 1];
                    bundle.putString("Description", this.f75076z4.containsKey(str2) ? this.f75076z4.getString(str2) : "");
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                }
                bundle.putString("id", next);
                if (new File(next).length() > 5000) {
                    arrayList2.add(bundle);
                }
            }
            int i = 0;
            for (int i2 = 0; i2 < arrayList2.size(); i2++) {
                if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                    i = i2;
                }
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList2);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* renamed from: z4 */
        private void m4380z4(String str) {
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", str);
            bundle.putString("isVideo", IcyHeaders.f35463C2);
            ArrayList arrayList = new ArrayList();
            arrayList.add(bundle);
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList);
            intent.putExtra("Start", 0);
            mo4139H2(intent);
        }

        /* renamed from: A4 */
        public String m4385A4(String str) {
            ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
            arrayList.remove(arrayList.size() - 1);
            return StringUtils.join(arrayList, "/");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: C3 */
        public void mo4144C3(String str) {
            WebView webView = this.f75853f4;
            webView.loadUrl("javascript:document.getElementById(\"" + str + "\").scrollIntoView(true);");
            WebView webView2 = this.f75853f4;
            webView2.loadUrl("javascript:document.getElementsByName(\"" + str + "\")[0].scrollIntoView(true);");
        }

        /* renamed from: C4 */
        public void m4383C4(String str) {
            ArrayList arrayList = new ArrayList();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", str);
            bundle.putString("isVideo", IcyHeaders.f35463C2);
            arrayList.add(bundle);
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList);
            intent.putExtra("Start", 0);
            mo4139H2(intent);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: P3 */
        public boolean mo3571P3(ConsoleMessage consoleMessage) {
            String[] split = consoleMessage.message().split(",,,,,");
            if (split[0].equals("images")) {
                if (split.length < 2) {
                    return true;
                }
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(split[1], "|");
                ArrayList<String> arrayList = new ArrayList<>();
                for (String str : splitByWholeSeparator) {
                    String replace = this.f75069A4.replace("file://", "");
                    if (replace.endsWith("/")) {
                        replace = replace.substring(0, replace.length() - 1);
                    }
                    String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str, "/");
                    for (String str2 : splitByWholeSeparator2) {
                        replace = str2.equals("..") ? m4385A4(replace) : replace + "/" + str2;
                    }
                    try {
                        if (this.f75071C4 && splitByWholeSeparator2.length > 0) {
                            String str3 = splitByWholeSeparator2[splitByWholeSeparator2.length - 1];
                            CompressHelper compressHelper = this.f75863p4;
                            Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(this.f75850c4, "Select * from images where imageName='" + str3 + "'"));
                            if (m4858z != null) {
                                String string = m4858z.getString("desc");
                                if (!this.f75076z4.containsKey(str3)) {
                                    this.f75076z4.putString(str3, string);
                                }
                            }
                        }
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                    }
                    File file = new File(replace);
                    file.length();
                    if (file.length() > SimpleExoPlayer.f32068s1) {
                        arrayList.add(replace);
                    }
                    iMDLogger.m3290j("EPUB Images", "Imagepath = : " + replace);
                }
                this.f75075y4 = arrayList;
                mo3978f4();
            }
            return super.mo3571P3(consoleMessage);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            ArrayList<String> arrayList = this.f75075y4;
            if (arrayList == null || arrayList.size() <= 0) {
                return null;
            }
            return m4071w3(this.f75075y4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S3 */
        public void mo3569S3(WebView webView, String str) {
            super.mo3569S3(webView, str);
            this.f75853f4.loadUrl("javascript:IgnoreSmallImages();");
            this.f75853f4.loadUrl("javascript:fixAllImages2();");
            this.f75853f4.loadUrl("javascript:fixAllTables();");
            this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87357menu_epubviewer, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            this.f75076z4 = new Bundle();
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f75075y4 = bundle.getStringArrayList("mImages");
                this.f75069A4 = bundle.getString("mBasePath");
                this.f75070B4 = bundle.getString("mPath");
            }
            if (m44859B() == null) {
                return inflate;
            }
            iMDLogger.m3290j("NEJMViewerActivity", "Loading NEJM Document with mDocAddress = " + this.f75851d4);
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.NEJM.NEJMViewerActivity.NEJMViewerFragment.1
                /* JADX WARN: Removed duplicated region for block: B:22:0x0111  */
                /* JADX WARN: Removed duplicated region for block: B:25:0x0169 A[Catch: Exception -> 0x0183, TryCatch #2 {Exception -> 0x0183, blocks: (B:3:0x000a, B:5:0x001b, B:27:0x0175, B:29:0x017b, B:7:0x0021, B:9:0x0040, B:11:0x0047, B:20:0x00e3, B:23:0x0112, B:25:0x0169, B:26:0x016d, B:19:0x00c1), top: B:38:0x000a }] */
                /* JADX WARN: Removed duplicated region for block: B:29:0x017b A[Catch: Exception -> 0x0183, TRY_LEAVE, TryCatch #2 {Exception -> 0x0183, blocks: (B:3:0x000a, B:5:0x001b, B:27:0x0175, B:29:0x017b, B:7:0x0021, B:9:0x0040, B:11:0x0047, B:20:0x00e3, B:23:0x0112, B:25:0x0169, B:26:0x016d, B:19:0x00c1), top: B:38:0x000a }] */
                /* JADX WARN: Removed duplicated region for block: B:39:? A[RETURN, SYNTHETIC] */
                @Override // java.lang.Runnable
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                public void run() {
                    /*
                        Method dump skipped, instructions count: 407
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.NEJM.NEJMViewerActivity.NEJMViewerFragment.RunnableC40521.run():void");
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.NEJM.NEJMViewerActivity.NEJMViewerFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    NEJMViewerFragment.this.m4092j4();
                    String str = NEJMViewerFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        NEJMViewerFragment nEJMViewerFragment = NEJMViewerFragment.this;
                        nEJMViewerFragment.m4078s4(nEJMViewerFragment.f75837P3);
                        return;
                    }
                    File file = new File(NEJMViewerFragment.this.f75069A4);
                    String str2 = "file://" + file.getAbsolutePath() + "/";
                    NEJMViewerFragment nEJMViewerFragment2 = NEJMViewerFragment.this;
                    nEJMViewerFragment2.f75853f4.loadDataWithBaseURL(str2, nEJMViewerFragment2.f75847Z3, "text/html", "utf-8", null);
                    NEJMViewerFragment.this.m4098g4();
                    NEJMViewerFragment.this.m4100f3(C4804R.C4811menu.f87357menu_epubviewer);
                    NEJMViewerFragment.this.m44735q2(false);
                    NEJMViewerFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            if (menuItem.getItemId() == C4804R.C4808id.f86774action_gallery) {
                m4384B4("soheilvb");
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            this.f75074x4 = menu.findItem(C4804R.C4808id.f86774action_gallery);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            String str4;
            String str5;
            String str6;
            String str7 = str3;
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str7);
            if (str7.startsWith("//")) {
                str7 = str7.substring(2);
            }
            String str8 = str7;
            if (str2.equals("image")) {
                m4384B4(str8);
                return true;
            }
            try {
                str8 = URLDecoder.decode(str8, "UTF-8");
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
            }
            if (str2.equals("svv")) {
                m4383C4(this.f75850c4.getString("Path") + str8.replace("//", ""));
                return true;
            }
            if (str2.equals(Annotation.f59806M2)) {
                CompressHelper compressHelper = new CompressHelper(m44716w());
                String m4948X0 = CompressHelper.m4948X0(this.f75850c4);
                str4 = "NEJM";
                str5 = "image";
                if (str.contains("#")) {
                    str6 = StringUtils.splitByWholeSeparator(str, "#")[1];
                    iMDLogger.m3294f("Testing", "BasePath : " + m4948X0 + ", Resource : " + str8 + ", mPath : " + this.f75070B4);
                    StringBuilder sb = new StringBuilder();
                    sb.append(m4948X0);
                    sb.append("/");
                    str8 = str8.replace(sb.toString(), "").replace(this.f75072D4.getString("issueName") + "/", "");
                    if (this.f75070B4.equalsIgnoreCase(str8)) {
                        mo4144C3(str6);
                        return true;
                    } else if (str8.endsWith("/")) {
                        mo4144C3(str6);
                        return true;
                    }
                } else {
                    str6 = "";
                }
                iMDLogger.m3294f("Testing", "BasePath : " + m4948X0 + ", Resource : " + str8 + ", mPath : " + this.f75070B4);
                StringBuilder sb2 = new StringBuilder();
                sb2.append(m4948X0);
                sb2.append("/");
                str8 = str8.replace(sb2.toString(), "").replace(this.f75072D4.getString("issueName") + "/", "");
                ArrayList<Bundle> m4955V = compressHelper.m4955V(this.f75850c4, "Select * from contents where purl = '" + str8 + "'");
                if (m4955V == null || m4955V.size() == 0) {
                    CompressHelper.m4921e2(m44716w(), "Sorry, Document not available", 1);
                } else {
                    compressHelper.m4883q1(this.f75850c4, m4955V.get(0).getString("pid"), null, str6);
                }
            } else {
                str4 = "NEJM";
                str5 = "image";
            }
            if (str2.equals("opennejmimage")) {
                try {
                    Log.e("Opennejmimage", "Opennejmimage " + str8);
                    JSONObject jSONObject = new JSONObject(str8);
                    m4382x4(jSONObject.getString(str5), jSONObject.getString(DublinCoreProperties.f65372e));
                } catch (Exception e2) {
                    FirebaseCrashlytics.m18030d().m18027g(e2);
                }
            }
            if (str2.equals("resourceproxy")) {
                Log.e("Resourceproxy", "Resourceproxy " + str8);
                if (str8.startsWith("video/")) {
                    str8 = str8.replace("video/", "");
                    try {
                        String string = new JSONObject(str8).getString("video");
                        String str9 = str4;
                        Log.e(str9, "Video  " + string);
                        if (string == null) {
                            return false;
                        }
                        String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, string, "resources");
                        if (!new File(m4942Z0).exists()) {
                            String str10 = this.f75863p4.m4991J() + "/nejm/videos-E/" + string;
                            Log.e(str9, "VideoURL  " + str10 + " Path " + m4942Z0);
                            m4111Z2(str10, m4942Z0);
                            return true;
                        }
                        byte[] m4864x = this.f75863p4.m4864x(FileUtils.readFileToByteArray(new File(m4942Z0)), string.toLowerCase(), "127");
                        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "video.mp4");
                        if (new File(m4945Y0).exists()) {
                            new File(m4945Y0).delete();
                        }
                        FileUtils.writeByteArrayToFile(new File(m4945Y0), m4864x);
                        m4380z4(m4945Y0);
                    } catch (Exception e3) {
                        FirebaseCrashlytics.m18030d().m18027g(e3);
                    }
                }
                if (str8.startsWith("audio/")) {
                    str8 = str8.replace("audio/", "");
                    try {
                        String string2 = new JSONObject(str8).getString("href");
                        if (string2 == null) {
                            string2 = CompressHelper.m4862x1(str8);
                        }
                        String m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, string2, "resources");
                        if (!new File(m4942Z02).exists()) {
                            m4111Z2(this.f75863p4.m4991J() + "/nejm/audios-E/" + string2, m4942Z02);
                        }
                        byte[] m4864x2 = this.f75863p4.m4864x(FileUtils.readFileToByteArray(new File(m4942Z02)), string2.toLowerCase(), "127");
                        String m4945Y02 = CompressHelper.m4945Y0(this.f75850c4, "audio.mp3");
                        if (new File(m4945Y02).exists()) {
                            new File(m4945Y02).delete();
                        }
                        FileUtils.writeByteArrayToFile(new File(m4945Y02), m4864x2);
                        m4380z4(m4945Y02);
                    } catch (Exception e4) {
                        FirebaseCrashlytics.m18030d().m18027g(e4);
                    }
                }
                if (str8.startsWith("doi/")) {
                    String m4862x1 = CompressHelper.m4862x1(str8);
                    ArrayList<Bundle> m4955V2 = this.f75863p4.m4955V(this.f75850c4, "Select * from contents where purl like '%" + m4862x1 + "%'");
                    if (m4955V2 == null || m4955V2.size() == 0) {
                        CompressHelper.m4921e2(m44716w(), "Sorry, Document not available", 1);
                        return true;
                    }
                    this.f75863p4.m4883q1(this.f75850c4, m4955V2.get(0).getString("pid"), null, null);
                }
            }
            return true;
        }

        /* renamed from: x4 */
        public void m4382x4(String str, String str2) {
            ArrayList arrayList = new ArrayList();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", m4381y4(str));
            bundle.putString("Description", str2);
            arrayList.add(bundle);
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList);
            intent.putExtra("Start", 0);
            mo4139H2(intent);
        }

        /* renamed from: y4 */
        public String m4381y4(String str) {
            String m4965R1 = CompressHelper.m4965R1(CompressHelper.m4942Z0(this.f75850c4, this.f75072D4.getString("purl"), this.f75072D4.getString("issueName")));
            while (m4965R1.contains("../")) {
                m4965R1 = CompressHelper.m4965R1(m4965R1);
                str = str.substring(3);
            }
            return m4965R1 + "/" + str;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new NEJMViewerFragment(), bundle);
    }
}
