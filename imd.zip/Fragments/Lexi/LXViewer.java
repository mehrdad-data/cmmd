package net.imedicaldoctor.imd.Fragments.Lexi;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.FragmentActivity;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.net.HttpHeaders;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Lexi.LXItems;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMD;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class LXViewer extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class LXViewerFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        public boolean f74771A4;

        /* renamed from: B4 */
        private String f74772B4;

        /* renamed from: C4 */
        private Bundle f74773C4;

        /* renamed from: D4 */
        private ArrayList<Bundle> f74774D4;

        /* renamed from: E4 */
        private MenuItem f74775E4;

        /* renamed from: F4 */
        private int f74776F4;

        /* renamed from: w4 */
        public ArrayList<String> f74777w4;

        /* renamed from: x4 */
        public Bundle f74778x4;

        /* renamed from: y4 */
        public String f74779y4;

        /* renamed from: z4 */
        public String f74780z4;

        /* renamed from: I4 */
        private String m4490I4() {
            Bundle bundle = this.f74773C4;
            if (bundle == null) {
                return "alaki";
            }
            if (bundle.containsKey("globalid")) {
                Bundle bundle2 = this.f75850c4;
                return CompressHelper.m4942Z0(bundle2, this.f74773C4.getString("globalid") + ".mp3", "sound");
            }
            return "adsf";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: J4 */
        public void m4489J4() {
            MenuItem findItem;
            Menu menu = this.f75839R3;
            if (menu == null || (findItem = menu.findItem(C4804R.C4808id.f86792action_sound)) == null) {
                return;
            }
            findItem.setVisible(new File(m4490I4()).exists());
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: K4 */
        public String m4488K4(String str, String str2, String str3, String str4, String str5) {
            return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + str5 + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: L4 */
        public String m4487L4(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8) {
            return "<a name=\"f" + str8 + "\"><div id=\"h" + str8 + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + str8 + ");toggleHeaderExpanded(h" + str8 + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + str8 + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
        }

        /* renamed from: N4 */
        private void m4485N4(String str) {
            ArrayList<String> arrayList = this.f74777w4;
            if (arrayList == null || arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
                return;
            }
            ArrayList arrayList2 = new ArrayList();
            Iterator<String> it2 = this.f74777w4.iterator();
            while (it2.hasNext()) {
                String next = it2.next();
                Bundle bundle = new Bundle();
                bundle.putString("ImagePath", next);
                try {
                    String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(next, "/");
                    String str2 = splitByWholeSeparator[splitByWholeSeparator.length - 1];
                    bundle.putString("Description", this.f74778x4.containsKey(str2) ? this.f74778x4.getString(str2) : "");
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                }
                bundle.putString("id", next);
                if (new File(next).length() > 5000) {
                    arrayList2.add(bundle);
                }
            }
            int i = 0;
            for (int i2 = 0; i2 < arrayList2.size(); i2++) {
                if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                    i = i2;
                }
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList2);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: x4 */
        public void m4484x4() {
            m4093j3("ivc_compatible.png");
            m4093j3("ivc_conflict.png");
            m4093j3("ivc_incompatible.png");
            m4093j3("ivc_no_info.png");
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: y4 */
        public String m4483y4(ArrayList<Bundle> arrayList, ArrayList<Bundle> arrayList2, String str) {
            StringBuilder sb;
            String str2;
            StringBuilder sb2;
            String str3;
            String str4 = "<div><div class=\"ivc_table_label\">" + str + "</div><table class=\"ivc_compatibility\"><tbody>";
            int i = 0;
            while (i < ((arrayList.size() - 1) / 6) + 1) {
                if (i != 0) {
                    str4 = str4 + "<tr><td class=\"ivc_table_spacer\" colspan=\"6\"></td></tr>";
                }
                String str5 = str4 + "<tr>";
                int i2 = i + 1;
                int i3 = i2 * 6;
                if (arrayList.size() < i3) {
                    i3 = arrayList.size();
                }
                int i4 = i * 6;
                for (int i5 = i4; i5 < i3; i5++) {
                    if (i5 % 2 == 1) {
                        sb2 = new StringBuilder();
                        sb2.append(str5);
                        str3 = "<td class=\"ivc_compatibility_header ivc_compatibility_even_col\">";
                    } else {
                        sb2 = new StringBuilder();
                        sb2.append(str5);
                        str3 = "<td class=\"ivc_compatibility_header ivc_compatibility_odd_col\">";
                    }
                    sb2.append(str3);
                    sb2.append(arrayList.get(i5).getString("name"));
                    sb2.append("</td>");
                    str5 = sb2.toString();
                }
                String str6 = (str5 + "</tr>") + "<tr>";
                while (i4 < i3) {
                    Bundle m4914g1 = CompressHelper.m4914g1(arrayList2, "name", arrayList.get(i4).getString("name"));
                    String str7 = "ivc_no_info.png";
                    if (m4914g1 != null && !m4914g1.getString("content").equals("6")) {
                        str7 = m4914g1.getString("content").equals("5") ? "ivc_compatible.png" : m4914g1.getString("content").equals(ExifInterface.f14411T4) ? "ivc_conflict.png" : m4914g1.getString("content").equals(IcyHeaders.f35463C2) ? "ivc_incompatible.png" : "";
                    }
                    if (i4 % 2 == 1) {
                        sb = new StringBuilder();
                        sb.append(str6);
                        str2 = "<td class=\"ivc_compatibility_content ivc_compatibility_even_col\"><img src=\"";
                    } else {
                        sb = new StringBuilder();
                        sb.append(str6);
                        str2 = "<td class=\"ivc_compatibility_content ivc_compatibility_even_odd\"><img src=\"";
                    }
                    sb.append(str2);
                    sb.append(str7);
                    sb.append("\" width=\"25px\" height=\"25px\"></td>");
                    str6 = sb.toString();
                    i4++;
                }
                str4 = str6 + "</tr>";
                i = i2;
            }
            return str4 + "</tbody></table></div>";
        }

        /* renamed from: z4 */
        private void m4482z4() {
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: C3 */
        public void mo4144C3(String str) {
            iMDLogger.m3290j("Viewer activity , Gotosection", str);
            WebView webView = this.f75853f4;
            webView.loadUrl("javascript:document.getElementById(\"" + str + "\").scrollIntoView(true);document.body.scrollTop = window.pageYOffset - 50;");
        }

        /* renamed from: M4 */
        public String m4486M4(String str) {
            ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
            arrayList.remove(arrayList.size() - 1);
            return StringUtils.join(arrayList, "/");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: P3 */
        public boolean mo3571P3(ConsoleMessage consoleMessage) {
            String[] split = consoleMessage.message().split(",,,,,");
            if (split[0].equals("images")) {
                if (split.length < 2) {
                    return true;
                }
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(split[1], "|");
                ArrayList<String> arrayList = new ArrayList<>();
                for (String str : splitByWholeSeparator) {
                    String replace = this.f74779y4.replace("file://", "");
                    if (replace.endsWith("/")) {
                        replace = replace.substring(0, replace.length() - 1);
                    }
                    String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str, "/");
                    for (String str2 : splitByWholeSeparator2) {
                        replace = str2.equals("..") ? m4486M4(replace) : replace + "/" + str2;
                    }
                    try {
                        if (this.f74771A4 && splitByWholeSeparator2.length > 0) {
                            String str3 = splitByWholeSeparator2[splitByWholeSeparator2.length - 1];
                            CompressHelper compressHelper = this.f75863p4;
                            Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(this.f75850c4, "Select * from images where imageName='" + str3 + "'"));
                            if (m4858z != null) {
                                String string = m4858z.getString("desc");
                                if (!this.f74778x4.containsKey(str3)) {
                                    this.f74778x4.putString(str3, string);
                                }
                            }
                        }
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                    }
                    File file = new File(replace);
                    file.length();
                    if (file.length() > SimpleExoPlayer.f32068s1) {
                        arrayList.add(replace);
                    }
                    iMDLogger.m3290j("EPUB Images", "Imagepath = : " + replace);
                }
                this.f74777w4 = arrayList;
                mo3978f4();
            }
            return super.mo3571P3(consoleMessage);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S3 */
        public void mo3569S3(WebView webView, String str) {
            super.mo3569S3(webView, str);
            this.f75853f4.loadUrl("javascript:ConvertAllImages();");
            this.f75853f4.loadUrl("javascript:fixAllImages2();");
            this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87365menu_lxviewer, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (m44859B().containsKey("Mode")) {
                this.f74776F4 = m44859B().getInt("Mode");
            } else {
                this.f74776F4 = 0;
            }
            if (bundle != null) {
                this.f74772B4 = bundle.getString("mResources");
                this.f74776F4 = bundle.getInt("Mode");
                this.f74773C4 = bundle.getBundle("mDocument");
                this.f74774D4 = bundle.getParcelableArrayList("mFields");
            }
            if (m44859B() == null) {
                return inflate;
            }
            iMDLogger.m3290j("LXViewer", "Loading Lexi Document with mDocAddress = " + this.f75851d4);
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Lexi.LXViewer.LXViewerFragment.1
                /* JADX WARN: Removed duplicated region for block: B:176:0x0945 A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                /* JADX WARN: Removed duplicated region for block: B:177:0x095f  */
                /* JADX WARN: Removed duplicated region for block: B:181:0x096a A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                /* JADX WARN: Removed duplicated region for block: B:193:0x0a99 A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                /* JADX WARN: Removed duplicated region for block: B:227:0x0d47 A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                /* JADX WARN: Removed duplicated region for block: B:231:0x0d6c A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                /* JADX WARN: Removed duplicated region for block: B:243:0x0e76 A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                /* JADX WARN: Removed duplicated region for block: B:43:0x02c5 A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                /* JADX WARN: Removed duplicated region for block: B:92:0x05d2 A[Catch: Exception -> 0x0eae, TryCatch #2 {Exception -> 0x0eae, blocks: (B:3:0x0002, B:5:0x0013, B:241:0x0e6b, B:243:0x0e76, B:244:0x0e7d, B:9:0x001e, B:12:0x004a, B:14:0x0071, B:16:0x0078, B:19:0x00ea, B:21:0x00fe, B:23:0x0179, B:25:0x018d, B:26:0x01d4, B:28:0x01da, B:40:0x029c, B:41:0x02bf, B:43:0x02c5, B:45:0x02eb, B:46:0x0313, B:48:0x0373, B:39:0x027d, B:49:0x0390, B:51:0x03ab, B:52:0x0412, B:54:0x0418, B:57:0x043f, B:60:0x044d, B:62:0x045f, B:63:0x0479, B:72:0x04b9, B:64:0x047d, B:66:0x0487, B:69:0x0492, B:70:0x0497, B:71:0x04b2, B:73:0x04c1, B:76:0x04cd, B:78:0x04f5, B:80:0x0515, B:89:0x05b6, B:92:0x05d2, B:94:0x05fd, B:96:0x0603, B:98:0x062e, B:100:0x0634, B:102:0x063e, B:106:0x0649, B:110:0x0652, B:112:0x0656, B:113:0x065a, B:114:0x0677, B:146:0x07c0, B:148:0x07d8, B:115:0x067d, B:117:0x0685, B:118:0x06a2, B:120:0x06aa, B:122:0x06f0, B:123:0x070d, B:124:0x0730, B:125:0x0736, B:127:0x073e, B:144:0x0779, B:131:0x074b, B:134:0x0756, B:137:0x0761, B:140:0x076c, B:145:0x079b, B:149:0x07ea, B:88:0x0595, B:150:0x0816, B:153:0x0833, B:155:0x0867, B:157:0x0874, B:159:0x08b5, B:160:0x08ba, B:161:0x08c5, B:163:0x08cb, B:174:0x092c, B:176:0x0945, B:178:0x0960, B:179:0x0964, B:181:0x096a, B:183:0x098a, B:184:0x09bf, B:189:0x0a2f, B:185:0x09c4, B:187:0x09d0, B:188:0x0a0b, B:190:0x0a49, B:191:0x0a93, B:193:0x0a99, B:196:0x0ae7, B:197:0x0aef, B:199:0x0af5, B:200:0x0b31, B:203:0x0b4d, B:205:0x0b63, B:206:0x0b6f, B:207:0x0bd2, B:208:0x0c36, B:173:0x090d, B:209:0x0c3a, B:211:0x0c57, B:212:0x0cd1, B:214:0x0cd7, B:225:0x0d34, B:227:0x0d47, B:228:0x0d62, B:229:0x0d66, B:231:0x0d6c, B:233:0x0d8a, B:237:0x0e06, B:239:0x0e2f, B:234:0x0dc0, B:236:0x0dcc, B:238:0x0e0b, B:240:0x0e46, B:224:0x0d16), top: B:253:0x0002 }] */
                @Override // java.lang.Runnable
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                public void run() {
                    /*
                        Method dump skipped, instructions count: 3779
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Lexi.LXViewer.LXViewerFragment.RunnableC39471.run():void");
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Lexi.LXViewer.LXViewerFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = LXViewerFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        LXViewerFragment lXViewerFragment = LXViewerFragment.this;
                        lXViewerFragment.m4078s4(lXViewerFragment.f75837P3);
                        return;
                    }
                    LXViewerFragment lXViewerFragment2 = LXViewerFragment.this;
                    CompressHelper compressHelper = lXViewerFragment2.f75863p4;
                    File file = new File(CompressHelper.m4948X0(lXViewerFragment2.f75850c4));
                    String str2 = "file://" + file.getParentFile().getAbsolutePath() + "/";
                    LXViewerFragment lXViewerFragment3 = LXViewerFragment.this;
                    lXViewerFragment3.f74779y4 = str2;
                    lXViewerFragment3.f75853f4.clearCache(true);
                    LXViewerFragment lXViewerFragment4 = LXViewerFragment.this;
                    lXViewerFragment4.f75853f4.loadDataWithBaseURL(str2, lXViewerFragment4.f75847Z3, "text/html", "utf-8", null);
                    LXViewerFragment.this.m4092j4();
                    LXViewerFragment.this.m4098g4();
                    LXViewerFragment.this.m4100f3(C4804R.C4811menu.f87365menu_lxviewer);
                    LXViewerFragment.this.m44735q2(false);
                    LXViewerFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86792action_sound && new File(m4490I4()).exists()) {
                m4121U3(m4490I4());
            }
            if (itemId == C4804R.C4808id.f86776action_menu) {
                LXSectionsViewer lXSectionsViewer = new LXSectionsViewer();
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("fields", this.f74774D4);
                lXSectionsViewer.m44751k2(bundle);
                lXSectionsViewer.m44870c3(true);
                lXSectionsViewer.m44844E2(this, 0);
                lXSectionsViewer.mo29915h3(m44820L(), "LXSectionsViewer");
            }
            if (itemId == C4804R.C4808id.f86774action_gallery) {
                m4485N4("soheilvb");
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            this.f74775E4 = menu.findItem(C4804R.C4808id.f86792action_sound);
            m4489J4();
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: m4 */
        public boolean mo3567m4() {
            if (this.f74776F4 != 0) {
                return false;
            }
            return super.mo3567m4();
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            String substring;
            Bundle bundle;
            String str4;
            String str5;
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
            CompressHelper compressHelper = new CompressHelper(m44716w());
            if (str2.equals("image")) {
                m4485N4(str3);
                return true;
            }
            if (str2.equals(FirebaseAnalytics.Param.f55189X)) {
                Bundle bundle2 = new Bundle();
                bundle2.putBundle("DB", this.f75850c4);
                Bundle bundle3 = this.f75850c4;
                Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(bundle3, "select * from indexitem where id=" + str3));
                if (m4907i1 == null) {
                    CompressHelper.m4921e2(m44716w(), "There is nothing there . sorry . please report it to support@imedicaldoctor.net", 1);
                    return true;
                }
                bundle2.putString("ParentId", m4907i1.getString("id"));
                bundle2.putInt("Mode", 2);
                compressHelper.m4979N(LXItems.class, LXItems.LXItemsFragment.class, bundle2);
            } else if (str2.equals("urn")) {
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, ":");
                if (splitByWholeSeparator[0].equals("lexicalc")) {
                    ArrayList arrayList = new ArrayList(Collections2.m23110e(((iMD) m44716w().getApplicationContext()).f83461s, new Predicate<Bundle>() { // from class: net.imedicaldoctor.imd.Fragments.Lexi.LXViewer.LXViewerFragment.3
                        @Override // com.google.common.base.Predicate
                        /* renamed from: a */
                        public boolean apply(Bundle bundle4) {
                            return bundle4.getString("Title").equals(r2);
                        }
                    }));
                    if (arrayList.size() == 0) {
                        FragmentActivity m44716w = m44716w();
                        CompressHelper.m4921e2(m44716w, "You Must Install Lexi-CALC", 1);
                        return true;
                    }
                    Bundle bundle4 = (Bundle) arrayList.get(0);
                    bundle = this.f75850c4;
                    substring = splitByWholeSeparator[1];
                } else if (splitByWholeSeparator[0].equals("lims")) {
                    if (splitByWholeSeparator[1].substring(0, 1).equals("s")) {
                        compressHelper.m4883q1(this.f75850c4, splitByWholeSeparator[1].substring(1), null, null);
                        return true;
                    } else if (splitByWholeSeparator[1].substring(0, 1).equals("b")) {
                        final String substring2 = splitByWholeSeparator[1].substring(1);
                        substring = splitByWholeSeparator[2].substring(1);
                        if (this.f75850c4.getString("Name").equals("429_martindale_f.sqlite") && substring2.equals("429")) {
                            try {
                                str4 = URLDecoder.decode(substring, "UTF-8");
                            } catch (Exception unused) {
                                str4 = substring;
                            }
                            if (str4.contains("#")) {
                                str5 = StringUtils.splitByWholeSeparator(str4, "#")[1];
                                str4 = StringUtils.splitByWholeSeparator(str4, "#")[0];
                            } else {
                                str5 = "";
                            }
                            if (this.f75851d4.equals(str4)) {
                                WebView webView2 = this.f75853f4;
                                webView2.loadUrl("javascript:document.getElementById('" + str5 + "').scrollIntoView(true);");
                                WebView webView3 = this.f75853f4;
                                webView3.loadUrl("javascript:element=document.getElementById('" + str5 + "');element.parentNode.removeChild(element);");
                            } else {
                                compressHelper.m4883q1(this.f75850c4, substring, null, str5);
                            }
                            return true;
                        }
                        ArrayList arrayList2 = new ArrayList(Collections2.m23110e(((iMD) m44716w().getApplicationContext()).f83461s, new Predicate<Bundle>() { // from class: net.imedicaldoctor.imd.Fragments.Lexi.LXViewer.LXViewerFragment.4
                            @Override // com.google.common.base.Predicate
                            /* renamed from: a */
                            public boolean apply(Bundle bundle5) {
                                return bundle5.containsKey("lexiID") && bundle5.getString("lexiID").equals(substring2);
                            }
                        }));
                        if (arrayList2.size() == 0) {
                            FragmentActivity m44716w2 = m44716w();
                            CompressHelper.m4921e2(m44716w2, "You Must Install Database with id " + substring2, 1);
                            return true;
                        }
                        bundle = (Bundle) arrayList2.get(0);
                    }
                }
                compressHelper.m4883q1(bundle, substring, null, null);
            } else if (str2.equals("ivcpair")) {
                ArrayList<Bundle> m4955V = compressHelper.m4955V(this.f75850c4, "select vf.sequence as sequence, vf.label as label, f.content as content, vf.fieldtype_id as typeId from document d join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id left join field f on f.document_id = d.id and vf.fieldtype_id = f.fieldtype_id left join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id left join ivsolution l on d.id = l.document_id and vf.fieldtype_id = l.fieldtype_id where d.id =" + str3 + " and (f.content is not null or l.solution_id is not null) and f.fieldtype_id != 38 and f.fieldtype_id != 42 union select vf.sequence, vf.label, iv.content, vf.fieldtype_id from document d join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id left join ivfield iv on iv.document_id = d.id and vf.fieldtype_id = iv.fieldtype_id left join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id left join ivsolution l on d.id = l.document_id and vf.fieldtype_id = l.fieldtype_id where d.id =" + str3 + " and (iv.content is not null or l.solution_id is not null) and iv.fieldtype_id != 38 and iv.fieldtype_id != 42");
                Bundle bundle5 = new Bundle();
                bundle5.putParcelableArrayList("ivMonograph", m4955V);
                bundle5.putParcelableArrayList("Solutions", m44859B().getParcelableArrayList("Solutions"));
                bundle5.putParcelableArrayList("Sites", m44859B().getParcelableArrayList("Sites"));
                bundle5.putInt("Mode", 3);
                if (m44859B().containsKey(HttpHeaders.f53975g)) {
                    bundle5.putString(HttpHeaders.f53975g, m44859B().getString(HttpHeaders.f53975g));
                }
                bundle5.putString("docId", str3);
                Bundle bundle6 = this.f75850c4;
                compressHelper.m4880r1(bundle6, "Pair - " + str3, null, null, bundle5);
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new LXViewerFragment(), bundle);
    }
}
