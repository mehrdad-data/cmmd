package net.imedicaldoctor.imd.Fragments.Lexi;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Epocrate.EPODxViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Epocrate.EPOIDViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Epocrate.EPORxViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Epocrate.EPOTableViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Lexi.LXViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;

/* loaded from: classes2.dex */
public class LXSectionsViewer extends DialogFragment {

    /* renamed from: g4 */
    private ArrayList<Bundle> f74768g4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f74768g4 = m44859B().getParcelableArrayList("fields");
        new CompressHelper(m44716w());
        listView.setAdapter((ListAdapter) new ArrayAdapter<Bundle>(m44716w(), C4804R.C4810layout.f87284list_view_item_simple_text, C4804R.C4808id.text, this.f74768g4) { // from class: net.imedicaldoctor.imd.Fragments.Lexi.LXSectionsViewer.1
            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i, View view, ViewGroup viewGroup) {
                View view2 = super.getView(i, view, viewGroup);
                ((TextView) view2.findViewById(C4804R.C4808id.text)).setText(((Bundle) LXSectionsViewer.this.f74768g4.get(i)).getString("label"));
                return view2;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Lexi.LXSectionsViewer.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                ViewerHelperFragment viewerHelperFragment;
                StringBuilder sb;
                String string = ((Bundle) ((ArrayAdapter) adapterView.getAdapter()).getItem(i)).getString("sequence");
                if (LXSectionsViewer.this.m44753k0().getClass().equals(LXViewer.LXViewerFragment.class)) {
                    ((LXViewer.LXViewerFragment) LXSectionsViewer.this.m44753k0()).mo4144C3("f" + string);
                } else if (LXSectionsViewer.this.m44753k0().getClass().equals(EPODxViewerActivityFragment.class)) {
                    ((EPODxViewerActivityFragment) LXSectionsViewer.this.m44753k0()).mo4144C3("f" + string);
                } else {
                    if (LXSectionsViewer.this.m44753k0().getClass().equals(EPORxViewerActivityFragment.class)) {
                        viewerHelperFragment = (EPORxViewerActivityFragment) LXSectionsViewer.this.m44753k0();
                        sb = new StringBuilder();
                    } else if (LXSectionsViewer.this.m44753k0().getClass().equals(EPOIDViewerActivityFragment.class)) {
                        viewerHelperFragment = (EPOIDViewerActivityFragment) LXSectionsViewer.this.m44753k0();
                        sb = new StringBuilder();
                    } else if (LXSectionsViewer.this.m44753k0().getClass().equals(EPOTableViewerActivityFragment.class)) {
                        viewerHelperFragment = (EPOTableViewerActivityFragment) LXSectionsViewer.this.m44753k0();
                        sb = new StringBuilder();
                    }
                    sb.append("f");
                    sb.append(string);
                    viewerHelperFragment.mo4144C3(sb.toString());
                }
                LXSectionsViewer.this.mo27003Q2();
            }
        });
        builder.setView(inflate);
        return builder.create();
    }
}
