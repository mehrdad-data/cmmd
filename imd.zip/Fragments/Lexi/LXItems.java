package net.imedicaldoctor.imd.Fragments.Lexi;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import androidx.appcompat.widget.SearchView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class LXItems extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class LXItemsFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private int f74761b4;

        /* renamed from: c4 */
        private String f74762c4;

        /* renamed from: d4 */
        private String f74763d4;

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4337R2();
        }

        /* JADX WARN: Removed duplicated region for block: B:27:0x0101  */
        /* JADX WARN: Removed duplicated region for block: B:28:0x0108  */
        /* JADX WARN: Removed duplicated region for block: B:38:0x0134  */
        /* JADX WARN: Removed duplicated region for block: B:40:0x0139  */
        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public android.view.View mo3277U0(android.view.LayoutInflater r12, android.view.ViewGroup r13, android.os.Bundle r14) {
            /*
                Method dump skipped, instructions count: 352
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Lexi.LXItems.LXItemsFragment.mo3277U0(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            StringBuilder sb;
            String str2;
            int i = this.f74761b4;
            if (i == 0) {
                sb = new StringBuilder();
                sb.append("Select rowid as _id,* from search where name match '");
                sb.append(str);
                str2 = "*'";
            } else if (i != 1) {
                if (i == 2) {
                    return this.f75215L3.m4955V(this.f75212I3, "select id as _id,* from indexitem_document inner join document on (indexitem_document.document_id=document.id) where indexitem_id=" + this.f74762c4 + " AND title like '" + str + "%'");
                }
                return null;
            } else {
                sb = new StringBuilder();
                sb.append("Select rowid as _id,* from search where search match 'name:");
                sb.append(str);
                sb.append("* AND type:");
                sb.append(this.f74763d4);
                str2 = "'";
            }
            sb.append(str2);
            return this.f75215L3.m4952W(this.f75212I3, sb.toString(), "fsearch.db");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4952W(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'", "fsearch.db");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new LXItemsFragment());
    }
}
