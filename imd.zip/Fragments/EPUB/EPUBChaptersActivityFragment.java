package net.imedicaldoctor.imd.Fragments.EPUB;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.FragmentActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.itextpdf.tool.xml.html.HTML;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class EPUBChaptersActivityFragment extends SearchHelperFragment {

    /* renamed from: h4 */
    private static String f74378h4;

    /* renamed from: b4 */
    private String f74379b4;

    /* renamed from: c4 */
    private Boolean f74380c4;

    /* renamed from: d4 */
    private ArrayList<String> f74381d4;

    /* renamed from: e4 */
    private ArrayList<String> f74382e4;

    /* renamed from: f4 */
    private ArrayList<String> f74383f4;

    /* renamed from: g4 */
    public BroadcastReceiver f74384g4 = new BroadcastReceiver() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.1
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            try {
                if (PreferenceManager.getDefaultSharedPreferences(EPUBChaptersActivityFragment.this.m44716w()).getBoolean("shake", false)) {
                    LocalBroadcastManager.m43863b(EPUBChaptersActivityFragment.this.m44716w()).m43859f(EPUBChaptersActivityFragment.this.f74384g4);
                    EPUBChaptersActivityFragment.this.m4628u3();
                    EPUBChaptersActivityFragment.this.f75221R3.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            LocalBroadcastManager.m43863b(EPUBChaptersActivityFragment.this.m44716w()).m43862c(EPUBChaptersActivityFragment.this.f74384g4, new IntentFilter("Shake"));
                        }
                    }, 3000L);
                }
            } catch (Exception unused) {
            }
        }
    };

    /* loaded from: classes2.dex */
    public class AccountTextViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        private TextView f74394I;

        /* renamed from: J */
        private MaterialRippleLayout f74395J;

        public AccountTextViewHolder(View view) {
            super(view);
            this.f74394I = (TextView) view.findViewById(C4804R.C4808id.text);
            this.f74395J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        }
    }

    /* loaded from: classes2.dex */
    public class ButtonChaptersAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        public Context f74397d;

        /* renamed from: e */
        public ArrayList<Bundle> f74398e;

        /* renamed from: f */
        public String f74399f;

        /* renamed from: g */
        public String f74400g;

        /* renamed from: h */
        public String f74401h;

        public ButtonChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2, String str3) {
            this.f74397d = context;
            this.f74398e = arrayList;
            this.f74399f = str;
            this.f74401h = str3;
            this.f74400g = str2;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            if (i == this.f74398e.size()) {
                return 2;
            }
            return this.f74398e.get(i).getString("leaf").equals(IcyHeaders.f35463C2) ? 0 : 1;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
            if (i != this.f74398e.size()) {
                RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                final Bundle bundle = this.f74398e.get(i);
                rippleTextViewHolder.f83300I.setText(bundle.getString(this.f74399f));
                rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.ButtonChaptersAdapter.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        ButtonChaptersAdapter.this.mo4623e0(bundle, i);
                    }
                });
                return;
            }
            AccountTextViewHolder accountTextViewHolder = (AccountTextViewHolder) viewHolder;
            accountTextViewHolder.f74394I.setText(this.f74400g);
            accountTextViewHolder.f74394I.setTextColor(EPUBChaptersActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
            accountTextViewHolder.f74395J.setBackgroundColor(Color.parseColor(this.f74401h));
            accountTextViewHolder.f74395J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.ButtonChaptersAdapter.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    ButtonChaptersAdapter.this.mo4624d0();
                }
            });
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new RippleTextViewHolder(LayoutInflater.from(this.f74397d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
            }
            if (i == 1) {
                return new RippleTextViewHolder(LayoutInflater.from(this.f74397d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
            }
            if (i == 2) {
                return new AccountTextViewHolder(LayoutInflater.from(this.f74397d).inflate(C4804R.C4810layout.f87218list_view_item_account_text, viewGroup, false));
            }
            return null;
        }

        /* renamed from: d0 */
        public void mo4624d0() {
        }

        /* renamed from: e0 */
        public void mo4623e0(Bundle bundle, int i) {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return this.f74398e.size() + 1;
        }
    }

    /* loaded from: classes2.dex */
    public class EPUBChaptersAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        public Context f74407d;

        /* renamed from: e */
        public ArrayList<Bundle> f74408e;

        /* renamed from: f */
        public String f74409f;

        public EPUBChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
            this.f74407d = context;
            this.f74408e = arrayList;
            this.f74409f = str;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            return this.f74408e.get(i).getString("leaf").equals(IcyHeaders.f35463C2) ? 0 : 1;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
            RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
            final Bundle bundle = this.f74408e.get(i);
            rippleTextViewHolder.f83300I.setText(bundle.getString(this.f74409f));
            rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.EPUBChaptersAdapter.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    EPUBChaptersAdapter.this.mo4622d0(bundle, i);
                }
            });
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new RippleTextViewHolder(LayoutInflater.from(this.f74407d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
            }
            if (i == 1) {
                return new RippleTextViewHolder(LayoutInflater.from(this.f74407d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
            }
            return null;
        }

        /* renamed from: d0 */
        public void mo4622d0(Bundle bundle, int i) {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return this.f74408e.size();
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: Q0 */
    public void mo3503Q0(Bundle bundle) {
        super.mo3503Q0(bundle);
        LocalBroadcastManager.m43863b(m44716w()).m43862c(this.f74384g4, new IntentFilter("Shake"));
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: T0 */
    public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
        this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
        m4337R2();
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        this.f75221R3 = inflate;
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        m4337R2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            this.f74379b4 = "0";
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.4
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            this.f74379b4 = m44859B().getString("ParentId");
        }
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle2 = this.f75212I3;
        this.f75218O3 = compressHelper.m4955V(bundle2, "Select id as _id,* from TOC where parentId = " + this.f74379b4);
        this.f74380c4 = this.f75212I3.getString("Name").contains("auntminnie") ? Boolean.TRUE : Boolean.FALSE;
        this.f75216M3 = this.f74380c4.booleanValue() ? new ButtonChaptersAdapter(m44716w(), this.f75218O3, "name", "Random Case", "#0e4b06") { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.5
            @Override // net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.ButtonChaptersAdapter
            /* renamed from: d0 */
            public void mo4624d0() {
                EPUBChaptersActivityFragment.this.m4628u3();
            }

            @Override // net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.ButtonChaptersAdapter
            /* renamed from: e0 */
            public void mo4623e0(Bundle bundle3, int i) {
                EPUBChaptersActivityFragment.this.m4330Y2();
                String string = bundle3.getString("leaf");
                String string2 = bundle3.getString("docId");
                String string3 = bundle3.getString(HTML.Tag.f65890V);
                if (string.equals("0")) {
                    new CompressHelper(EPUBChaptersActivityFragment.this.m44716w()).m4883q1(EPUBChaptersActivityFragment.this.f75212I3, string2, null, string3);
                    return;
                }
                Bundle bundle4 = new Bundle();
                bundle4.putBundle("DB", EPUBChaptersActivityFragment.this.f75212I3);
                bundle4.putString("ParentId", bundle3.getString("id"));
                new CompressHelper(EPUBChaptersActivityFragment.this.m44716w()).m4979N(EPUBChaptersActivity.class, EPUBChaptersActivityFragment.class, bundle4);
            }
        } : new EPUBChaptersAdapter(m44716w(), this.f75218O3, "name") { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.6
            @Override // net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.EPUBChaptersAdapter
            /* renamed from: d0 */
            public void mo4622d0(Bundle bundle3, int i) {
                EPUBChaptersActivityFragment.this.m4330Y2();
                String string = bundle3.getString("leaf");
                String string2 = bundle3.getString("docId");
                String string3 = bundle3.getString(HTML.Tag.f65890V);
                if (string.equals("0")) {
                    new CompressHelper(EPUBChaptersActivityFragment.this.m44716w()).m4883q1(EPUBChaptersActivityFragment.this.f75212I3, string2, null, string3);
                    return;
                }
                Bundle bundle4 = new Bundle();
                bundle4.putBundle("DB", EPUBChaptersActivityFragment.this.f75212I3);
                bundle4.putString("ParentId", bundle3.getString("id"));
                new CompressHelper(EPUBChaptersActivityFragment.this.m44716w()).m4979N(EPUBChaptersActivity.class, EPUBChaptersActivityFragment.class, bundle4);
            }
        };
        this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.7
            @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
            /* renamed from: e0 */
            public void mo3397e0(Bundle bundle3, int i) {
                Bundle bundle4;
                CompressHelper compressHelper2;
                EPUBChaptersActivityFragment.this.m4330Y2();
                String string = bundle3.getString("type");
                String string2 = bundle3.getString("contentId");
                bundle3.getString(HTML.Tag.f65890V);
                if (string.equals(IcyHeaders.f35463C2)) {
                    bundle4 = new Bundle();
                    bundle4.putBundle("DB", EPUBChaptersActivityFragment.this.f75212I3);
                    bundle4.putString("ParentId", string2);
                    compressHelper2 = new CompressHelper(EPUBChaptersActivityFragment.this.m44716w());
                } else if (string.equals("5")) {
                    CompressHelper compressHelper3 = new CompressHelper(EPUBChaptersActivityFragment.this.m44716w());
                    EPUBChaptersActivityFragment ePUBChaptersActivityFragment = EPUBChaptersActivityFragment.this;
                    compressHelper3.m4883q1(ePUBChaptersActivityFragment.f75212I3, string2, ePUBChaptersActivityFragment.m4332W2(bundle3.getString("subText")), null);
                    return;
                } else if (!string.equals("0")) {
                    return;
                } else {
                    EPUBChaptersActivityFragment ePUBChaptersActivityFragment2 = EPUBChaptersActivityFragment.this;
                    CompressHelper compressHelper4 = ePUBChaptersActivityFragment2.f75215L3;
                    Bundle bundle5 = ePUBChaptersActivityFragment2.f75212I3;
                    Bundle m4907i1 = compressHelper4.m4907i1(compressHelper4.m4955V(bundle5, "Select * from toc where id=" + string2));
                    if (m4907i1 == null) {
                        return;
                    }
                    String string3 = m4907i1.getString("leaf");
                    String string4 = m4907i1.getString("docId");
                    String string5 = m4907i1.getString(HTML.Tag.f65890V);
                    if (string3.equals("0")) {
                        new CompressHelper(EPUBChaptersActivityFragment.this.m44716w()).m4883q1(EPUBChaptersActivityFragment.this.f75212I3, string4, null, string5);
                        return;
                    }
                    bundle4 = new Bundle();
                    bundle4.putBundle("DB", EPUBChaptersActivityFragment.this.f75212I3);
                    bundle4.putString("ParentId", m4907i1.getString("id"));
                    compressHelper2 = new CompressHelper(EPUBChaptersActivityFragment.this.m44716w());
                }
                compressHelper2.m4979N(EPUBChaptersActivity.class, EPUBChaptersActivityFragment.class, bundle4);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return inflate;
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: V0 */
    public void mo3638V0() {
        super.mo3638V0();
        LocalBroadcastManager.m43863b(m44716w()).m43859f(this.f74384g4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id, Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    /* renamed from: t3 */
    public String m4629t3(ArrayList<String> arrayList) {
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            arrayList2.add("'" + it2.next() + "'");
        }
        return StringUtils.join(arrayList2, ",");
    }

    /* renamed from: u3 */
    public void m4628u3() {
        m4340O2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = EPUBChaptersActivityFragment.this.f74379b4;
                if (EPUBChaptersActivityFragment.this.f74380c4.booleanValue() && str.equals("0")) {
                    str = IcyHeaders.f35463C2;
                }
                if (EPUBChaptersActivityFragment.this.f74381d4 == null) {
                    EPUBChaptersActivityFragment.this.f74381d4 = new ArrayList();
                    EPUBChaptersActivityFragment ePUBChaptersActivityFragment = EPUBChaptersActivityFragment.this;
                    ePUBChaptersActivityFragment.m4627v3(str, ePUBChaptersActivityFragment.f74381d4);
                }
                EPUBChaptersActivityFragment.this.f74382e4 = new ArrayList();
                EPUBChaptersActivityFragment ePUBChaptersActivityFragment2 = EPUBChaptersActivityFragment.this;
                CompressHelper compressHelper = ePUBChaptersActivityFragment2.f75215L3;
                String m4971P1 = compressHelper.m4971P1();
                StringBuilder sb = new StringBuilder();
                sb.append("Select dbAddress from recent where dbName ='");
                sb.append(EPUBChaptersActivityFragment.this.f75212I3.getString("Name"));
                sb.append("' AND dbAddress in (");
                EPUBChaptersActivityFragment ePUBChaptersActivityFragment3 = EPUBChaptersActivityFragment.this;
                sb.append(ePUBChaptersActivityFragment3.m4629t3(ePUBChaptersActivityFragment3.f74381d4));
                sb.append(")");
                ePUBChaptersActivityFragment2.f74382e4 = compressHelper.m4943Z(m4971P1, sb.toString(), "dbAddress");
                EPUBChaptersActivityFragment.this.f74383f4 = new ArrayList(EPUBChaptersActivityFragment.this.f74381d4);
                if (EPUBChaptersActivityFragment.this.f74382e4 != null) {
                    EPUBChaptersActivityFragment.this.f74383f4.removeAll(EPUBChaptersActivityFragment.this.f74382e4);
                    return;
                }
                EPUBChaptersActivityFragment.this.f74382e4 = new ArrayList();
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBChaptersActivityFragment.3
            @Override // java.lang.Runnable
            public void run() {
                if (EPUBChaptersActivityFragment.this.f74383f4.size() == 0) {
                    CompressHelper.m4921e2(EPUBChaptersActivityFragment.this.m44716w(), "All are reviewed", 1);
                    return;
                }
                FragmentActivity m44716w = EPUBChaptersActivityFragment.this.m44716w();
                CompressHelper.m4921e2(m44716w, EPUBChaptersActivityFragment.this.f74383f4.size() + " Remaining (" + EPUBChaptersActivityFragment.this.f74382e4.size() + " Reviewed)", 1);
                int nextInt = new Random().nextInt(EPUBChaptersActivityFragment.this.f74383f4.size());
                new CompressHelper(EPUBChaptersActivityFragment.this.m44716w()).m4883q1(EPUBChaptersActivityFragment.this.f75212I3, (String) EPUBChaptersActivityFragment.this.f74383f4.get(nextInt), null, null);
            }
        });
    }

    /* renamed from: v3 */
    public void m4627v3(String str, ArrayList<String> arrayList) {
        Log.d("readChildTOCS", "parentId = " + str);
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select * from TOC where parentId = " + str);
        if (m4955V == null) {
            m4955V = new ArrayList<>();
        }
        Iterator<Bundle> it2 = m4955V.iterator();
        while (it2.hasNext()) {
            Bundle next = it2.next();
            if (next.getString("leaf").equals("0")) {
                arrayList.add(next.getString("docId"));
            } else {
                m4627v3(next.getString("id"), arrayList);
            }
        }
    }
}
