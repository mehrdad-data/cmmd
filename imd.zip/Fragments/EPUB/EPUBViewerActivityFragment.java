package net.imedicaldoctor.imd.Fragments.EPUB;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.WebView;
import androidx.appcompat.app.AlertDialog;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMD;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class EPUBViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public String f74414A4;

    /* renamed from: B4 */
    public String f74415B4;

    /* renamed from: C4 */
    public boolean f74416C4;

    /* renamed from: D4 */
    public long f74417D4;

    /* renamed from: w4 */
    private String f74418w4;

    /* renamed from: x4 */
    private MenuItem f74419x4;

    /* renamed from: y4 */
    public ArrayList<String> f74420y4;

    /* renamed from: z4 */
    public Bundle f74421z4;

    /* renamed from: y4 */
    private void m4620y4(String str) {
        ArrayList<String> arrayList = this.f74420y4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f74420y4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", next);
            try {
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(next, "/");
                String str2 = splitByWholeSeparator[splitByWholeSeparator.length - 1];
                bundle.putString("Description", this.f74421z4.containsKey(str2) ? this.f74421z4.getString(str2) : "");
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
            }
            bundle.putString("id", next);
            if (new File(next).length() > 5000) {
                arrayList2.add(bundle);
            }
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: C3 */
    public void mo4144C3(String str) {
        WebView webView = this.f75853f4;
        webView.loadUrl("javascript:document.getElementById(\"" + str + "\").scrollIntoView(true);");
        WebView webView2 = this.f75853f4;
        webView2.loadUrl("javascript:document.getElementsByName(\"" + str + "\")[0].scrollIntoView(true);");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: J3 */
    public boolean mo4136J3(Context context) {
        if (this.f75850c4.getString("Name").equals("utdpathways.db")) {
            return false;
        }
        return super.mo4136J3(context);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String[] split = consoleMessage.message().split(",,,,,");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str : splitByWholeSeparator) {
                String replace = this.f74414A4.replace("file://", "");
                if (replace.endsWith("/")) {
                    replace = replace.substring(0, replace.length() - 1);
                }
                String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str, "/");
                for (String str2 : splitByWholeSeparator2) {
                    replace = str2.equals("..") ? m4621x4(replace) : replace + "/" + str2;
                }
                try {
                    if (this.f74416C4 && splitByWholeSeparator2.length > 0) {
                        String str3 = splitByWholeSeparator2[splitByWholeSeparator2.length - 1];
                        CompressHelper compressHelper = this.f75863p4;
                        Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(this.f75850c4, "Select * from images where imageName='" + str3 + "'"));
                        if (m4858z != null) {
                            String string = m4858z.getString("desc");
                            if (!this.f74421z4.containsKey(str3)) {
                                this.f74421z4.putString(str3, string);
                            }
                        }
                    }
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                }
                File file = new File(replace);
                file.length();
                if (file.length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(replace);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + replace);
            }
            this.f74420y4 = arrayList;
            mo3978f4();
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: Q3 */
    public boolean mo4126Q3(WebView webView, String str, String str2, JsResult jsResult) {
        if (System.currentTimeMillis() - this.f74417D4 > 1000) {
            this.f74417D4 = System.currentTimeMillis();
            new AlertDialog.Builder(m44716w()).mo26292l(str2).mo26278s("OK", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBViewerActivityFragment.3
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }).m52864I();
        } else {
            Log.e("e-Anatomy", "too many alerts");
        }
        jsResult.cancel();
        return true;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<String> arrayList = this.f74420y4;
        if (arrayList == null || arrayList.size() <= 0) {
            return null;
        }
        return m4071w3(this.f74420y4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        super.mo3569S3(webView, str);
        this.f75853f4.loadUrl("javascript:IgnoreSmallImages();");
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:fixAllImages2();");
        if (!this.f75850c4.getString("Name").contains("auntminni") && !this.f75850c4.getString("Name").contains("student-")) {
            this.f75853f4.loadUrl("javascript:fixAllTables();");
        }
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: T0 */
    public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(C4804R.C4811menu.f87357menu_epubviewer, menu);
        m4096h4(menu);
        mo3568e3(menu);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        this.f74421z4 = new Bundle();
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        m4094i4(inflate, bundle);
        if (bundle != null) {
            this.f74420y4 = bundle.getStringArrayList("mImages");
            this.f74414A4 = bundle.getString("mBasePath");
            this.f74415B4 = bundle.getString("mPath");
        }
        if (m44859B() == null) {
            return inflate;
        }
        iMDLogger.m3290j("AMViewer", "Loading EPUB Document with mDocAddress = " + this.f75851d4);
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBViewerActivityFragment.1
            /* JADX WARN: Removed duplicated region for block: B:36:0x014d  */
            /* JADX WARN: Removed duplicated region for block: B:39:0x01ab A[Catch: Exception -> 0x01c5, TryCatch #4 {Exception -> 0x01c5, blocks: (B:3:0x000c, B:14:0x0044, B:16:0x004a, B:41:0x01b7, B:43:0x01bd, B:18:0x0050, B:20:0x006f, B:22:0x0076, B:34:0x011f, B:37:0x014e, B:39:0x01ab, B:40:0x01af, B:33:0x00fd, B:13:0x003d, B:5:0x0018, B:8:0x002a, B:9:0x0031, B:10:0x0035), top: B:56:0x000c, inners: #0 }] */
            /* JADX WARN: Removed duplicated region for block: B:43:0x01bd A[Catch: Exception -> 0x01c5, TRY_LEAVE, TryCatch #4 {Exception -> 0x01c5, blocks: (B:3:0x000c, B:14:0x0044, B:16:0x004a, B:41:0x01b7, B:43:0x01bd, B:18:0x0050, B:20:0x006f, B:22:0x0076, B:34:0x011f, B:37:0x014e, B:39:0x01ab, B:40:0x01af, B:33:0x00fd, B:13:0x003d, B:5:0x0018, B:8:0x002a, B:9:0x0031, B:10:0x0035), top: B:56:0x000c, inners: #0 }] */
            /* JADX WARN: Removed duplicated region for block: B:57:? A[RETURN, SYNTHETIC] */
            @Override // java.lang.Runnable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public void run() {
                /*
                    Method dump skipped, instructions count: 473
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.EPUB.EPUBViewerActivityFragment.RunnableC38221.run():void");
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = EPUBViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    EPUBViewerActivityFragment ePUBViewerActivityFragment = EPUBViewerActivityFragment.this;
                    ePUBViewerActivityFragment.m4078s4(ePUBViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(EPUBViewerActivityFragment.this.f74414A4);
                String str2 = "file://" + file.getAbsolutePath() + "/";
                EPUBViewerActivityFragment ePUBViewerActivityFragment2 = EPUBViewerActivityFragment.this;
                ePUBViewerActivityFragment2.f75853f4.loadDataWithBaseURL(str2, ePUBViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                EPUBViewerActivityFragment.this.m4092j4();
                EPUBViewerActivityFragment.this.m4098g4();
                EPUBViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87357menu_epubviewer);
                EPUBViewerActivityFragment.this.m44735q2(false);
                EPUBViewerActivityFragment.this.m4140G3();
            }
        });
        return inflate;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86774action_gallery) {
            m4620y4("soheilvb");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        this.f74419x4 = menu.findItem(C4804R.C4808id.f86774action_gallery);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: m1 */
    public void mo3501m1(Bundle bundle) {
        super.mo3501m1(bundle);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        String str4;
        String str5 = str3;
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str5);
        if (str2.equals("image")) {
            m4620y4(str5);
            return true;
        }
        if (str2.equals("utdpathway")) {
            ArrayList arrayList = new ArrayList(Collections2.m23110e(((iMD) m44716w().getApplicationContext()).f83461s, new Predicate<Bundle>() { // from class: net.imedicaldoctor.imd.Fragments.EPUB.EPUBViewerActivityFragment.4
                @Override // com.google.common.base.Predicate
                /* renamed from: a */
                public boolean apply(Bundle bundle) {
                    return bundle.getString("Name").equals("uptodate");
                }
            }));
            if (arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "you must install Uptodate", 1);
                return false;
            }
            Bundle bundle = (Bundle) arrayList.get(0);
            str5 = str5.replace(".html", "");
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str5, "-");
            if (splitByWholeSeparator.length < 3) {
                return false;
            }
            if (splitByWholeSeparator[1].equals("MED") || splitByWholeSeparator[1].equals("PAT") || splitByWholeSeparator[1].equals("Society_Guidelines") || splitByWholeSeparator[1].equals("DRG")) {
                String str6 = splitByWholeSeparator[3];
                if (str6.contains("#")) {
                    str6 = StringUtils.splitByWholeSeparator(str6, "#")[0];
                }
                this.f75863p4.m4883q1(bundle, "Topic-" + splitByWholeSeparator[2], null, str6);
            } else if (splitByWholeSeparator[1].equals("Graphic")) {
                this.f75863p4.m4883q1(bundle, "Graphic-" + splitByWholeSeparator[2], null, "");
            }
        }
        if (str2.equals("svv")) {
            m4619z4(this.f75850c4.getString("Path") + str5.replace("//", ""));
            return true;
        }
        if (str2.equals(Annotation.f59806M2)) {
            CompressHelper compressHelper = new CompressHelper(m44716w());
            String str7 = "//" + this.f75850c4.getString("Path") + "/";
            if (this.f75850c4.getString("Name").contains("student-")) {
                str5 = str5.replace("///student/content/book", "base");
            }
            if (str.contains("#")) {
                str4 = StringUtils.splitByWholeSeparator(str, "#")[1];
                iMDLogger.m3294f("Testing", "BasePath : " + str7 + ", Resource : " + str5 + ", mPath : " + this.f74415B4);
                str5 = str5.replace(str7, "");
                if (this.f75850c4.getString("Name").contains("student-")) {
                    str5 = str5 + ".html";
                }
                if (this.f74415B4.equalsIgnoreCase(str5)) {
                    mo4144C3(str4);
                    return true;
                }
            } else {
                if (this.f75850c4.getString("Name").contains("student-")) {
                    str5 = str5 + ".html";
                }
                str4 = "";
            }
            iMDLogger.m3294f("Testing", "BasePath : " + str7 + ", Resource : " + str5 + ", mPath : " + this.f74415B4);
            String replace = str5.replace(str7, "");
            Bundle bundle2 = this.f75850c4;
            StringBuilder sb = new StringBuilder();
            sb.append("Select * from docs where path = '");
            sb.append(replace);
            sb.append("'");
            ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, sb.toString());
            if (m4955V == null || m4955V.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "Sorry, Document not available", 1);
                return true;
            }
            compressHelper.m4883q1(this.f75850c4, m4955V.get(0).getString("id"), null, str4);
        }
        return true;
    }

    /* renamed from: x4 */
    public String m4621x4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }

    /* renamed from: z4 */
    public void m4619z4(String str) {
        ArrayList arrayList = new ArrayList();
        Bundle bundle = new Bundle();
        bundle.putString("ImagePath", str);
        bundle.putString("isVideo", IcyHeaders.f35463C2);
        arrayList.add(bundle);
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList);
        intent.putExtra("Start", 0);
        mo4139H2(intent);
    }
}
