package net.imedicaldoctor.imd.Fragments.Statdx;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class SDListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f75399b4;

    /* renamed from: c4 */
    public String f75400c4;

    /* renamed from: d4 */
    public ArrayList<Bundle> f75401d4;

    /* renamed from: e4 */
    public ArrayList<Bundle> f75402e4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            this.f75400c4 = "0";
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDListActivityFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            this.f75400c4 = m44859B().getString("ParentId");
        }
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle2 = this.f75212I3;
        this.f75401d4 = compressHelper.m4955V(bundle2, "select * from categories where parent='" + this.f75400c4 + "'");
        CompressHelper compressHelper2 = this.f75215L3;
        Bundle bundle3 = this.f75212I3;
        this.f75402e4 = compressHelper2.m4955V(bundle3, "select * from docs where id in (Select docId from cats_docs where catId='" + this.f75400c4 + "')");
        if (this.f75401d4 == null) {
            this.f75401d4 = new ArrayList<>();
        }
        if (this.f75402e4 == null) {
            this.f75402e4 = new ArrayList<>();
        }
        this.f75216M3 = new ChaptersAdapter(m44716w(), null, "title", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDListActivityFragment.2
            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                return i < SDListActivityFragment.this.f75401d4.size() ? 0 : 1;
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter, androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
                MaterialRippleLayout materialRippleLayout;
                View.OnClickListener onClickListener;
                if (viewHolder.m42556F() == 0) {
                    RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                    final Bundle bundle4 = SDListActivityFragment.this.f75401d4.get(i);
                    rippleTextViewHolder.f83300I.setText(bundle4.getString("title"));
                    materialRippleLayout = rippleTextViewHolder.f83301J;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDListActivityFragment.2.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            Bundle bundle5 = new Bundle();
                            bundle5.putBundle("DB", SDListActivityFragment.this.f75212I3);
                            bundle5.putString("ParentId", bundle4.getString("id"));
                            SDListActivityFragment.this.f75215L3.m4979N(SDListActivity.class, SDListActivityFragment.class, bundle5);
                        }
                    };
                } else {
                    RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                    SDListActivityFragment sDListActivityFragment = SDListActivityFragment.this;
                    final Bundle bundle5 = sDListActivityFragment.f75402e4.get(i - sDListActivityFragment.f75401d4.size());
                    rippleTextFullViewHolder.f83284I.setText(bundle5.getString("title"));
                    if (SDListActivityFragment.this.f75212I3.getString("Name").equals("expertpath.db")) {
                        rippleTextFullViewHolder.f83286K.setVisibility(8);
                    } else {
                        rippleTextFullViewHolder.f83286K.setVisibility(0);
                        rippleTextFullViewHolder.f83286K.setImageDrawable(SDListActivityFragment.this.m44716w().getResources().getDrawable(SDListActivityFragment.this.m4292l3(bundle5.getString("type"))));
                    }
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDListActivityFragment.2.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDListActivityFragment sDListActivityFragment2 = SDListActivityFragment.this;
                            CompressHelper compressHelper3 = sDListActivityFragment2.f75215L3;
                            Bundle bundle6 = sDListActivityFragment2.f75212I3;
                            compressHelper3.m4883q1(bundle6, "menu,,," + bundle5.getString("id"), null, null);
                        }
                    };
                }
                materialRippleLayout.setOnClickListener(onClickListener);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter, androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup2, int i) {
                if (i == 0) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f83215d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup2, false));
                }
                if (i == 1) {
                    RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(LayoutInflater.from(this.f83215d).inflate(C4804R.C4810layout.f87265list_view_item_ripple_text_full, viewGroup2, false));
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                    return rippleTextFullViewHolder;
                }
                return null;
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter, androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                return SDListActivityFragment.this.f75401d4.size() + SDListActivityFragment.this.f75402e4.size();
            }
        };
        this.f75399b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", "content", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle4, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                if (SDListActivityFragment.this.f75212I3.getString("Name").equals("expertpath.db")) {
                    rippleTextFullViewHolder.f83286K.setVisibility(8);
                } else {
                    rippleTextFullViewHolder.f83286K.setVisibility(0);
                    rippleTextFullViewHolder.f83286K.setImageDrawable(SDListActivityFragment.this.m44716w().getResources().getDrawable(SDListActivityFragment.this.m4292l3(bundle4.getString("typeText"))));
                }
                rippleTextFullViewHolder.f83284I.setText(bundle4.getString("text"));
                if (bundle4.getString("type").equals(ExifInterface.f14411T4)) {
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                } else {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    rippleTextFullViewHolder.f83285J.setText(bundle4.getString("content"));
                }
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDListActivityFragment.3.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CompressHelper compressHelper3;
                        Bundle bundle5;
                        StringBuilder sb;
                        String str;
                        if (bundle4.getString("type").equals(ExifInterface.f14411T4)) {
                            SDListActivityFragment sDListActivityFragment = SDListActivityFragment.this;
                            compressHelper3 = sDListActivityFragment.f75215L3;
                            bundle5 = sDListActivityFragment.f75212I3;
                            sb = new StringBuilder();
                            str = "case,,,";
                        } else {
                            SDListActivityFragment sDListActivityFragment2 = SDListActivityFragment.this;
                            compressHelper3 = sDListActivityFragment2.f75215L3;
                            bundle5 = sDListActivityFragment2.f75212I3;
                            sb = new StringBuilder();
                            str = "menu,,,";
                        }
                        sb.append(str);
                        sb.append(bundle4.getString("contentId"));
                        compressHelper3.m4883q1(bundle5, sb.toString(), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle4) {
                SDListActivityFragment.this.m4330Y2();
                SDListActivityFragment.this.f75223T3.m51655i0(bundle4.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                return new RippleTextFullViewHolder(view);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75399b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f75399b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match '(text:" + str + "*) AND (type:1 OR type:3)' order by type asc");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    /* renamed from: l3 */
    public int m4292l3(String str) {
        return (str.equals("di3-dx") || str.equals("dx")) ? C4804R.C4807drawable.f86715statdx_dx : str.equals("expert-ddx") ? C4804R.C4807drawable.f86714statdx_ddx : str.equals("anatomymodule") ? C4804R.C4807drawable.f86716statdx_person : str.equals("tsm") ? C4804R.C4807drawable.f86719statdx_tnm : str.equals("procedure") ? C4804R.C4807drawable.f86717statdx_syringe : str.equals("di3-generic") ? C4804R.C4807drawable.f86715statdx_dx : str.equals("di3-tsm") ? C4804R.C4807drawable.f86719statdx_tnm : str.equals("di3-procedure") ? C4804R.C4807drawable.f86717statdx_syringe : str.equals("ia2-module") ? C4804R.C4807drawable.f86716statdx_person : str.equals("di3-expert-ddx") ? C4804R.C4807drawable.f86714statdx_ddx : str.equals("table") ? C4804R.C4807drawable.f86718statdx_table : str.equals("Case") ? C4804R.C4807drawable.f86713statdx_case : C4804R.C4807drawable.f86715statdx_dx;
    }
}
