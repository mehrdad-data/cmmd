package net.imedicaldoctor.imd.Fragments.Statdx;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.GridAutoFitLayoutManager;
import net.imedicaldoctor.imd.ViewHolders.ImageViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class SDCaseActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public Bundle f75350A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f75351B4;

    /* renamed from: C4 */
    public String f75352C4;

    /* renamed from: D4 */
    public ArrayList<String> f75353D4;

    /* renamed from: E4 */
    public ChaptersAdapter f75354E4;

    /* renamed from: F4 */
    public ArrayList<Bundle> f75355F4;

    /* renamed from: G4 */
    public String f75356G4;

    /* renamed from: H4 */
    private Bundle f75357H4;

    /* renamed from: w4 */
    public RecyclerView f75358w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f75359x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75360y4;

    /* renamed from: z4 */
    public DiagnosisAdapter f75361z4;

    /* renamed from: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment$1 */
    /* loaded from: classes2.dex */
    class RunnableC41491 implements Runnable {
        RunnableC41491() {
        }

        @Override // java.lang.Runnable
        public void run() {
            SDCaseActivityFragment.this.f75351B4 = new ArrayList<>();
            Bundle bundle = new Bundle();
            bundle.putString("fieldTitle", "Description");
            bundle.putString("fieldId", "");
            SDCaseActivityFragment.this.f75351B4.add(bundle);
            SDCaseActivityFragment sDCaseActivityFragment = SDCaseActivityFragment.this;
            CompressHelper compressHelper = sDCaseActivityFragment.f75863p4;
            Bundle bundle2 = sDCaseActivityFragment.f75850c4;
            sDCaseActivityFragment.f75359x4 = compressHelper.m4955V(bundle2, "Select * from cases_images where caseId='" + SDCaseActivityFragment.this.f75352C4 + "'");
            SDCaseActivityFragment sDCaseActivityFragment2 = SDCaseActivityFragment.this;
            if (sDCaseActivityFragment2.f75359x4 == null) {
                sDCaseActivityFragment2.f75359x4 = new ArrayList<>();
            }
            if (SDCaseActivityFragment.this.f75359x4.size() > 0) {
                SDCaseActivityFragment.this.f75353D4.add("Images");
                Iterator<Bundle> it2 = SDCaseActivityFragment.this.f75359x4.iterator();
                while (it2.hasNext()) {
                    Bundle next = it2.next();
                    Bundle bundle3 = new Bundle();
                    Bundle bundle4 = SDCaseActivityFragment.this.f75850c4;
                    String m4942Z0 = CompressHelper.m4942Z0(bundle4, next.getString("imageId") + ".jpg", "images-E");
                    SDCaseActivityFragment.this.m4133M3(next.getString("imageId"), "images-E");
                    bundle3.putString("ImagePath", m4942Z0);
                    bundle3.putString("id", next.getString("imageId"));
                    bundle3.putString("Encrypted", IcyHeaders.f35463C2);
                    bundle3.putBundle("db", SDCaseActivityFragment.this.f75850c4);
                    SDCaseActivityFragment.this.f75360y4.add(bundle3);
                }
                SDCaseActivityFragment sDCaseActivityFragment3 = SDCaseActivityFragment.this;
                sDCaseActivityFragment3.f75354E4 = new ChaptersAdapter(sDCaseActivityFragment3.m44716w(), SDCaseActivityFragment.this.f75359x4, "title", C4804R.C4810layout.f87246list_view_item_image) { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.1.1
                    @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                    /* renamed from: e0 */
                    public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle5, int i) {
                        final ImageViewHolder imageViewHolder = (ImageViewHolder) viewHolder;
                        Bundle bundle6 = SDCaseActivityFragment.this.f75850c4;
                        final String m4942Z02 = CompressHelper.m4942Z0(bundle6, bundle5.getString("imageId") + ".jpg", "small");
                        SDCaseActivityFragment.this.m4133M3(bundle5.getString("imageId"), "small");
                        Glide.m40315G(SDCaseActivityFragment.this.m44716w()).mo40150i(new File(m4942Z02)).m40191t2(imageViewHolder.f83246I);
                        if (SDCaseActivityFragment.this.f75357H4.containsKey(m4942Z02)) {
                            imageViewHolder.f83247J.setRippleColor(SDCaseActivityFragment.this.f75357H4.getInt(m4942Z02));
                        } else {
                            SDCaseActivityFragment.this.m4083q3(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.1.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    Palette.Swatch m43631C = Palette.m43628b(BitmapFactory.decodeFile(m4942Z02)).m43594g().m43631C();
                                    if (m43631C == null) {
                                        return;
                                    }
                                    int m43579e = m43631C.m43579e();
                                    if (SDCaseActivityFragment.this.f75357H4.containsKey(m4942Z02)) {
                                        return;
                                    }
                                    SDCaseActivityFragment.this.f75357H4.putInt(m4942Z02, m43579e);
                                }
                            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.1.1.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    imageViewHolder.f83247J.setRippleColor(SDCaseActivityFragment.this.f75357H4.getInt(m4942Z02));
                                }
                            });
                        }
                        imageViewHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.1.1.3
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                SDCaseActivityFragment.this.m4300D4(bundle5.getString("imageId"));
                            }
                        });
                    }

                    @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                    /* renamed from: h0 */
                    public RecyclerView.ViewHolder mo3403h0(View view) {
                        return new ImageViewHolder(view);
                    }
                };
            }
            SDCaseActivityFragment sDCaseActivityFragment4 = SDCaseActivityFragment.this;
            CompressHelper compressHelper2 = sDCaseActivityFragment4.f75863p4;
            Bundle bundle5 = sDCaseActivityFragment4.f75850c4;
            sDCaseActivityFragment4.f75355F4 = compressHelper2.m4955V(bundle5, "Select * from cases_docs where caseId='" + SDCaseActivityFragment.this.f75352C4 + "'");
            ArrayList<Bundle> arrayList = SDCaseActivityFragment.this.f75355F4;
            if (arrayList != null && arrayList.size() > 0) {
                SDCaseActivityFragment.this.f75353D4.add("ddx");
            }
            SDCaseActivityFragment.this.f75353D4.add("Document");
        }
    }

    /* loaded from: classes2.dex */
    public class DiagnosisAdapter extends RecyclerView.Adapter {

        /* renamed from: f */
        private static final int f75378f = 0;

        /* renamed from: g */
        private static final int f75379g = 1;

        /* renamed from: h */
        private static final int f75380h = 2;

        /* renamed from: d */
        public Context f75381d;

        public DiagnosisAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            SDCaseActivityFragment sDCaseActivityFragment = SDCaseActivityFragment.this;
            Bundle m4298x4 = sDCaseActivityFragment.m4298x4(i, sDCaseActivityFragment.f75353D4);
            String string = m4298x4.getString("Type");
            if (string.equals("Header")) {
                return 0;
            }
            if (string.equals("Item")) {
                return m4298x4.getString("Section").equals("Images") ? 2 : 1;
            }
            return -1;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            MaterialRippleLayout materialRippleLayout;
            View.OnClickListener onClickListener;
            SDCaseActivityFragment sDCaseActivityFragment = SDCaseActivityFragment.this;
            Bundle m4298x4 = sDCaseActivityFragment.m4298x4(i, sDCaseActivityFragment.f75353D4);
            int m42556F = viewHolder.m42556F();
            if (m42556F == 0) {
                ((HeaderCellViewHolder) viewHolder).f75387I.setText(SDCaseActivityFragment.this.m4302B4(m4298x4.getString("Text")));
            } else if (m42556F == 2) {
                RecyclerViewViewHolder recyclerViewViewHolder = (RecyclerViewViewHolder) viewHolder;
                recyclerViewViewHolder.f75388I.setAdapter(SDCaseActivityFragment.this.f75354E4);
                recyclerViewViewHolder.f75388I.setLayoutManager(new GridAutoFitLayoutManager(SDCaseActivityFragment.this.m44716w(), (int) (SDCaseActivityFragment.this.m44782a0().getDisplayMetrics().density * 100.0f)));
            } else if (m42556F == 1) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                String string = m4298x4.getString("Section");
                int i2 = m4298x4.getInt("Index");
                rippleTextFullViewHolder.f83285J.setVisibility(8);
                if (string.equals("Images")) {
                    return;
                }
                if (string.equals("Document")) {
                    final Bundle bundle = SDCaseActivityFragment.this.f75351B4.get(i2);
                    rippleTextFullViewHolder.f83284I.setText(bundle.getString("fieldTitle"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.DiagnosisAdapter.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDCaseActivityFragment sDCaseActivityFragment2 = SDCaseActivityFragment.this;
                            CompressHelper compressHelper = sDCaseActivityFragment2.f75863p4;
                            Bundle bundle2 = sDCaseActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle2, "doc,,,case,,," + SDCaseActivityFragment.this.f75352C4, null, bundle.getString("fieldId"));
                        }
                    };
                } else if (!string.equals("ddx")) {
                    return;
                } else {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    final Bundle bundle2 = SDCaseActivityFragment.this.f75355F4.get(i2);
                    rippleTextFullViewHolder.f83284I.setText(bundle2.getString("docTitle"));
                    rippleTextFullViewHolder.f83285J.setText(bundle2.getString("docSection"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.DiagnosisAdapter.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDCaseActivityFragment sDCaseActivityFragment2 = SDCaseActivityFragment.this;
                            CompressHelper compressHelper = sDCaseActivityFragment2.f75863p4;
                            Bundle bundle3 = sDCaseActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle3, "menu,,," + bundle2.getString("docId"), null, null);
                        }
                    };
                }
                materialRippleLayout.setOnClickListener(onClickListener);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new HeaderCellViewHolder(LayoutInflater.from(SDCaseActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false));
            }
            if (i == 2) {
                return new RecyclerViewViewHolder(LayoutInflater.from(SDCaseActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87253list_view_item_recyclerview, viewGroup, false));
            }
            if (i == 1) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(LayoutInflater.from(SDCaseActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87265list_view_item_ripple_text_full, viewGroup, false));
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
            return null;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            SDCaseActivityFragment sDCaseActivityFragment = SDCaseActivityFragment.this;
            return sDCaseActivityFragment.m4299E4(sDCaseActivityFragment.f75353D4);
        }
    }

    /* loaded from: classes2.dex */
    public static class HeaderCellViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f75387I;

        public HeaderCellViewHolder(View view) {
            super(view);
            this.f75387I = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
        }
    }

    /* loaded from: classes2.dex */
    public static class RecyclerViewViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public RecyclerView f75388I;

        public RecyclerViewViewHolder(View view) {
            super(view);
            this.f75388I = (RecyclerView) view.findViewById(C4804R.C4808id.f87001recycler_view);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: D4 */
    public void m4300D4(String str) {
        int i = 0;
        int i2 = 0;
        while (true) {
            if (i2 >= this.f75360y4.size() - 1) {
                break;
            } else if (this.f75360y4.get(i2).getString("id").equals(str)) {
                i = i2;
                break;
            } else {
                i2++;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", this.f75360y4);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public void m4303A4() {
        this.f75358w4.setItemAnimator(new DefaultItemAnimator());
        this.f75358w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f75358w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }

    /* renamed from: B4 */
    public String m4302B4(String str) {
        if (!str.equals("Images")) {
            return str.equals("Document") ? "Document" : str.equals("ddx") ? "Related Dx" : "";
        }
        return this.f75359x4.size() + " Images";
    }

    /* renamed from: C4 */
    public int m4301C4(String str) {
        ArrayList<Bundle> arrayList;
        if (str.equals("Images")) {
            return 1;
        }
        if (str.equals("Document")) {
            arrayList = this.f75351B4;
        } else if (!str.equals("ddx")) {
            return 0;
        } else {
            arrayList = this.f75355F4;
        }
        return arrayList.size();
    }

    /* renamed from: E4 */
    public int m4299E4(ArrayList<String> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return 0;
        }
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            i = i + m4301C4(it2.next()) + 1;
        }
        return i;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList = this.f75359x4;
        if (arrayList == null || arrayList.size() <= 0) {
            return null;
        }
        Bundle m4073v3 = m4073v3(this.f75359x4);
        Bundle bundle = this.f75850c4;
        String m4942Z0 = CompressHelper.m4942Z0(bundle, m4073v3.getString("imageId") + ".jpg", "images-E");
        m4133M3(m4073v3.getString("imageId"), "images-E");
        return m4942Z0;
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f75358w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        this.f75357H4 = new Bundle();
        String[] split = this.f75851d4.split(",,,");
        if (split.length == 2) {
            this.f75352C4 = split[1];
        } else if (split.length == 3) {
            this.f75352C4 = split[1];
            this.f75356G4 = split[2];
            this.f75851d4 = split[0] + ",,," + split[1];
        }
        this.f75353D4 = new ArrayList<>();
        this.f75360y4 = new ArrayList<>();
        CompressHelper compressHelper = this.f75863p4;
        Bundle bundle2 = this.f75850c4;
        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from cases where id='" + this.f75352C4 + "'");
        if (m4955V == null || m4955V.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "Can't find the document, sorry", 1);
        } else {
            Bundle bundle3 = m4955V.get(0);
            this.f75350A4 = bundle3;
            this.f75852e4 = bundle3.getString("title");
            m4081r3(new RunnableC41491(), new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    SDCaseActivityFragment sDCaseActivityFragment = SDCaseActivityFragment.this;
                    if (sDCaseActivityFragment.f75359x4 == null) {
                        sDCaseActivityFragment.f75359x4 = new ArrayList<>();
                    }
                    SDCaseActivityFragment sDCaseActivityFragment2 = SDCaseActivityFragment.this;
                    final String str = sDCaseActivityFragment2.f75356G4;
                    if (str != null) {
                        sDCaseActivityFragment2.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                SDCaseActivityFragment.this.m4300D4(str);
                            }
                        }, 1000L);
                    }
                    if (SDCaseActivityFragment.this.m44859B().containsKey("SEARCH") && SDCaseActivityFragment.this.m44859B().getStringArray("SEARCH") != null) {
                        new Timer().schedule(new TimerTask() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.2.2
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                SDCaseActivityFragment sDCaseActivityFragment3 = SDCaseActivityFragment.this;
                                CompressHelper compressHelper2 = sDCaseActivityFragment3.f75863p4;
                                Bundle bundle4 = sDCaseActivityFragment3.f75850c4;
                                compressHelper2.m4883q1(bundle4, "doc,,,case,,," + SDCaseActivityFragment.this.f75352C4, SDCaseActivityFragment.this.m44859B().getStringArray("SEARCH"), null);
                                SDCaseActivityFragment.this.m44859B().remove("SEARCH");
                            }
                        }, SimpleExoPlayer.f32068s1);
                    }
                    SDCaseActivityFragment sDCaseActivityFragment3 = SDCaseActivityFragment.this;
                    sDCaseActivityFragment3.f75361z4 = new DiagnosisAdapter();
                    SDCaseActivityFragment sDCaseActivityFragment4 = SDCaseActivityFragment.this;
                    sDCaseActivityFragment4.f75358w4.setAdapter(sDCaseActivityFragment4.f75361z4);
                    SDCaseActivityFragment.this.m4303A4();
                    SDCaseActivityFragment.this.m4100f3(C4804R.C4811menu.f87326favorite);
                    SDCaseActivityFragment.this.m44735q2(false);
                    SDCaseActivityFragment.this.m4140G3();
                }
            });
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        super.mo3568e3(menu);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.4

            /* renamed from: a */
            byte[] f75376a;

            @Override // android.os.AsyncTask
            protected Object doInBackground(Object[] objArr) {
                try {
                    File file = new File(SDCaseActivityFragment.this.mo3979S2());
                    this.f75376a = new CompressHelper(SDCaseActivityFragment.this.m44716w()).m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127");
                    return null;
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    iMDLogger.m3294f("ImageGallery", "Error in decrypting image");
                    return null;
                }
            }

            @Override // android.os.AsyncTask
            protected void onPostExecute(Object obj) {
                super.onPostExecute(obj);
                Glide.m40315G(SDCaseActivityFragment.this.m44716w()).mo40151h(this.f75376a).m40191t2(SDCaseActivityFragment.this.f75859l4);
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
    }

    @Override // androidx.fragment.app.Fragment, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDCaseActivityFragment.3
            @Override // java.lang.Runnable
            public void run() {
                SDCaseActivityFragment.this.f75361z4.m42860G();
            }
        }, 500L);
    }

    /* renamed from: x4 */
    public Bundle m4298x4(int i, ArrayList<String> arrayList) {
        Iterator<String> it2 = arrayList.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            String next = it2.next();
            if (i == i2) {
                Bundle bundle = new Bundle();
                bundle.putString("Text", next);
                bundle.putString("Type", "Header");
                return bundle;
            }
            int m4301C4 = i2 + m4301C4(next);
            if (i <= m4301C4) {
                Bundle bundle2 = new Bundle();
                bundle2.putString("Section", next);
                bundle2.putInt("Index", (i - (m4301C4 - m4301C4(next))) - 1);
                bundle2.putString("Type", "Item");
                return bundle2;
            }
            i2 = m4301C4 + 1;
        }
        return null;
    }
}
