package net.imedicaldoctor.imd.Fragments.Statdx;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.GridAutoFitLayoutManager;
import net.imedicaldoctor.imd.ViewHolders.ImageViewHolder;
import net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class SDMenuActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public DiagnosisAdapter f75413A4;

    /* renamed from: B4 */
    public Bundle f75414B4;

    /* renamed from: C4 */
    public ArrayList<Bundle> f75415C4;

    /* renamed from: D4 */
    public String f75416D4;

    /* renamed from: E4 */
    public ArrayList<String> f75417E4;

    /* renamed from: F4 */
    public NotStickySectionAdapter f75418F4;

    /* renamed from: G4 */
    public ArrayList<Bundle> f75419G4;

    /* renamed from: H4 */
    public ArrayList<Bundle> f75420H4;

    /* renamed from: I4 */
    public ArrayList<Bundle> f75421I4;

    /* renamed from: J4 */
    public ArrayList<Bundle> f75422J4;

    /* renamed from: K4 */
    public ArrayList<Bundle> f75423K4;

    /* renamed from: L4 */
    public ArrayList<Bundle> f75424L4;

    /* renamed from: M4 */
    public String f75425M4;

    /* renamed from: N4 */
    private Bundle f75426N4;

    /* renamed from: w4 */
    public RecyclerView f75427w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f75428x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75429y4;

    /* renamed from: z4 */
    public ArrayList<Bundle> f75430z4;

    /* renamed from: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment$1 */
    /* loaded from: classes2.dex */
    class RunnableC41711 implements Runnable {
        RunnableC41711() {
        }

        @Override // java.lang.Runnable
        public void run() {
            SDMenuActivityFragment sDMenuActivityFragment = SDMenuActivityFragment.this;
            CompressHelper compressHelper = sDMenuActivityFragment.f75863p4;
            Bundle bundle = sDMenuActivityFragment.f75850c4;
            sDMenuActivityFragment.f75415C4 = compressHelper.m4955V(bundle, "Select * from fields where topicId='" + SDMenuActivityFragment.this.f75416D4 + "'");
            SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
            CompressHelper compressHelper2 = sDMenuActivityFragment2.f75863p4;
            Bundle bundle2 = sDMenuActivityFragment2.f75850c4;
            sDMenuActivityFragment2.f75428x4 = compressHelper2.m4955V(bundle2, "Select * from images where docId='" + SDMenuActivityFragment.this.f75416D4 + "'");
            SDMenuActivityFragment sDMenuActivityFragment3 = SDMenuActivityFragment.this;
            if (sDMenuActivityFragment3.f75428x4 == null) {
                sDMenuActivityFragment3.f75428x4 = new ArrayList<>();
            }
            if (SDMenuActivityFragment.this.f75428x4.size() > 0) {
                SDMenuActivityFragment sDMenuActivityFragment4 = SDMenuActivityFragment.this;
                sDMenuActivityFragment4.f75429y4 = sDMenuActivityFragment4.f75863p4.m4941Z1(sDMenuActivityFragment4.f75428x4, "category");
                SDMenuActivityFragment.this.f75417E4.add("Images");
                Iterator<Bundle> it2 = SDMenuActivityFragment.this.f75428x4.iterator();
                while (it2.hasNext()) {
                    Bundle next = it2.next();
                    Bundle bundle3 = new Bundle();
                    Bundle bundle4 = SDMenuActivityFragment.this.f75850c4;
                    String m4942Z0 = CompressHelper.m4942Z0(bundle4, next.getString("id") + ".jpg", "images-E");
                    SDMenuActivityFragment.this.m4133M3(next.getString("id"), "images-E");
                    bundle3.putString("ImagePath", m4942Z0);
                    bundle3.putString("id", next.getString("id"));
                    bundle3.putString("Encrypted", IcyHeaders.f35463C2);
                    bundle3.putString("DescriptionHTML2", SDMenuActivityFragment.this.f75863p4.m5015B(next.getString(HTML.Tag.f65910g), next.getString("id"), "127"));
                    bundle3.putBundle("db", SDMenuActivityFragment.this.f75850c4);
                    SDMenuActivityFragment.this.f75430z4.add(bundle3);
                }
                SDMenuActivityFragment sDMenuActivityFragment5 = SDMenuActivityFragment.this;
                sDMenuActivityFragment5.f75418F4 = new NotStickySectionAdapter(sDMenuActivityFragment5.m44716w(), SDMenuActivityFragment.this.f75429y4, "title", C4804R.C4810layout.f87246list_view_item_image, C4804R.C4810layout.f87247list_view_item_image_header) { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.1.1
                    @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                    /* renamed from: f0 */
                    public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle5, int i) {
                        final ImageViewHolder imageViewHolder = (ImageViewHolder) viewHolder;
                        Bundle bundle6 = SDMenuActivityFragment.this.f75850c4;
                        final String m4942Z02 = CompressHelper.m4942Z0(bundle6, bundle5.getString("id") + ".jpg", "small");
                        SDMenuActivityFragment.this.m4133M3(bundle5.getString("id"), "small");
                        Glide.m40315G(SDMenuActivityFragment.this.m44716w()).mo40150i(new File(m4942Z02)).m40191t2(imageViewHolder.f83246I);
                        if (SDMenuActivityFragment.this.f75426N4.containsKey(m4942Z02)) {
                            imageViewHolder.f83247J.setRippleColor(SDMenuActivityFragment.this.f75426N4.getInt(m4942Z02));
                        } else {
                            SDMenuActivityFragment.this.m4083q3(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.1.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    Palette.Swatch m43631C = Palette.m43628b(BitmapFactory.decodeFile(m4942Z02)).m43594g().m43631C();
                                    if (m43631C == null) {
                                        return;
                                    }
                                    int m43579e = m43631C.m43579e();
                                    if (SDMenuActivityFragment.this.f75426N4.containsKey(m4942Z02)) {
                                        return;
                                    }
                                    SDMenuActivityFragment.this.f75426N4.putInt(m4942Z02, m43579e);
                                }
                            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.1.1.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    imageViewHolder.f83247J.setRippleColor(SDMenuActivityFragment.this.f75426N4.getInt(m4942Z02));
                                }
                            });
                        }
                        imageViewHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.1.1.3
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                SDMenuActivityFragment.this.m4288D4(bundle5.getString("id"));
                            }
                        });
                    }

                    @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                    /* renamed from: k0 */
                    public RecyclerView.ViewHolder mo3385k0(View view) {
                        return new ImageViewHolder(view);
                    }
                };
            }
            if (!SDMenuActivityFragment.this.f75850c4.getString("Name").equals("expertpath.d")) {
                SDMenuActivityFragment sDMenuActivityFragment6 = SDMenuActivityFragment.this;
                CompressHelper compressHelper3 = sDMenuActivityFragment6.f75863p4;
                Bundle bundle5 = sDMenuActivityFragment6.f75850c4;
                sDMenuActivityFragment6.f75419G4 = compressHelper3.m4955V(bundle5, "Select * from ddx where docId='" + SDMenuActivityFragment.this.f75416D4 + "'");
                ArrayList<Bundle> arrayList = SDMenuActivityFragment.this.f75419G4;
                if (arrayList != null && arrayList.size() > 0) {
                    SDMenuActivityFragment.this.f75417E4.add("ddx");
                }
                SDMenuActivityFragment sDMenuActivityFragment7 = SDMenuActivityFragment.this;
                CompressHelper compressHelper4 = sDMenuActivityFragment7.f75863p4;
                Bundle bundle6 = sDMenuActivityFragment7.f75850c4;
                sDMenuActivityFragment7.f75420H4 = compressHelper4.m4955V(bundle6, "Select * from docs_cases where docId='" + SDMenuActivityFragment.this.f75416D4 + "'");
                ArrayList<Bundle> arrayList2 = SDMenuActivityFragment.this.f75420H4;
                if (arrayList2 != null && arrayList2.size() > 0) {
                    SDMenuActivityFragment sDMenuActivityFragment8 = SDMenuActivityFragment.this;
                    sDMenuActivityFragment8.f75421I4 = sDMenuActivityFragment8.f75863p4.m4941Z1(sDMenuActivityFragment8.f75420H4, "caseGroup");
                    Iterator<Bundle> it3 = SDMenuActivityFragment.this.f75421I4.iterator();
                    while (it3.hasNext()) {
                        ArrayList<String> arrayList3 = SDMenuActivityFragment.this.f75417E4;
                        arrayList3.add("case-" + SDMenuActivityFragment.this.f75421I4.indexOf(it3.next()));
                    }
                }
                SDMenuActivityFragment sDMenuActivityFragment9 = SDMenuActivityFragment.this;
                CompressHelper compressHelper5 = sDMenuActivityFragment9.f75863p4;
                Bundle bundle7 = sDMenuActivityFragment9.f75850c4;
                sDMenuActivityFragment9.f75422J4 = compressHelper5.m4955V(bundle7, "Select * from anatomy where docId='" + SDMenuActivityFragment.this.f75416D4 + "'");
                ArrayList<Bundle> arrayList4 = SDMenuActivityFragment.this.f75422J4;
                if (arrayList4 != null && arrayList4.size() > 0) {
                    SDMenuActivityFragment.this.f75417E4.add("anatomy");
                }
                SDMenuActivityFragment sDMenuActivityFragment10 = SDMenuActivityFragment.this;
                CompressHelper compressHelper6 = sDMenuActivityFragment10.f75863p4;
                Bundle bundle8 = sDMenuActivityFragment10.f75850c4;
                sDMenuActivityFragment10.f75423K4 = compressHelper6.m4955V(bundle8, "Select * from ddx where id='" + SDMenuActivityFragment.this.f75416D4 + "'");
                ArrayList<Bundle> arrayList5 = SDMenuActivityFragment.this.f75423K4;
                if (arrayList5 != null && arrayList5.size() > 0) {
                    SDMenuActivityFragment.this.f75417E4.add("relatedxddx");
                }
                SDMenuActivityFragment sDMenuActivityFragment11 = SDMenuActivityFragment.this;
                CompressHelper compressHelper7 = sDMenuActivityFragment11.f75863p4;
                Bundle bundle9 = sDMenuActivityFragment11.f75850c4;
                sDMenuActivityFragment11.f75424L4 = compressHelper7.m4955V(bundle9, "Select * from anatomy where id='" + SDMenuActivityFragment.this.f75416D4 + "'");
                ArrayList<Bundle> arrayList6 = SDMenuActivityFragment.this.f75424L4;
                if (arrayList6 != null && arrayList6.size() > 0) {
                    SDMenuActivityFragment.this.f75417E4.add("relatedxanatomy");
                }
            }
            SDMenuActivityFragment.this.f75417E4.add("Document");
        }
    }

    /* loaded from: classes2.dex */
    public class DiagnosisAdapter extends RecyclerView.Adapter {

        /* renamed from: f */
        private static final int f75447f = 0;

        /* renamed from: g */
        private static final int f75448g = 1;

        /* renamed from: h */
        private static final int f75449h = 2;

        /* renamed from: d */
        public Context f75450d;

        public DiagnosisAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            SDMenuActivityFragment sDMenuActivityFragment = SDMenuActivityFragment.this;
            Bundle m4286x4 = sDMenuActivityFragment.m4286x4(i, sDMenuActivityFragment.f75417E4);
            String string = m4286x4.getString("Type");
            if (string.equals("Header")) {
                return 0;
            }
            if (string.equals("Item")) {
                return m4286x4.getString("Section").equals("Images") ? 2 : 1;
            }
            return -1;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            MaterialRippleLayout materialRippleLayout;
            View.OnClickListener onClickListener;
            SDMenuActivityFragment sDMenuActivityFragment = SDMenuActivityFragment.this;
            Bundle m4286x4 = sDMenuActivityFragment.m4286x4(i, sDMenuActivityFragment.f75417E4);
            int m42556F = viewHolder.m42556F();
            if (m42556F == 0) {
                ((HeaderCellViewHolder) viewHolder).f75466I.setText(SDMenuActivityFragment.this.m4290B4(m4286x4.getString("Text")));
            } else if (m42556F == 2) {
                RecyclerViewViewHolder recyclerViewViewHolder = (RecyclerViewViewHolder) viewHolder;
                recyclerViewViewHolder.f75467I.setAdapter(SDMenuActivityFragment.this.f75418F4);
                final GridAutoFitLayoutManager gridAutoFitLayoutManager = new GridAutoFitLayoutManager(SDMenuActivityFragment.this.m44716w(), (int) (SDMenuActivityFragment.this.m44782a0().getDisplayMetrics().density * 100.0f));
                gridAutoFitLayoutManager.m43287N3(new GridLayoutManager.SpanSizeLookup() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.DiagnosisAdapter.1
                    @Override // androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup
                    /* renamed from: f */
                    public int mo3768f(int i2) {
                        if (SDMenuActivityFragment.this.f75418F4.mo3384C(i2) == 1) {
                            return gridAutoFitLayoutManager.f83243b0;
                        }
                        return 1;
                    }
                });
                recyclerViewViewHolder.f75467I.setLayoutManager(gridAutoFitLayoutManager);
            } else if (m42556F == 1) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                String string = m4286x4.getString("Section");
                int i2 = m4286x4.getInt("Index");
                rippleTextFullViewHolder.f83285J.setVisibility(8);
                if (string.equals("Images")) {
                    return;
                }
                if (string.equals("Document")) {
                    final Bundle bundle = SDMenuActivityFragment.this.f75415C4.get(i2);
                    rippleTextFullViewHolder.f83284I.setText(bundle.getString("fieldTitle"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.DiagnosisAdapter.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
                            CompressHelper compressHelper = sDMenuActivityFragment2.f75863p4;
                            Bundle bundle2 = sDMenuActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle2, "doc,,," + SDMenuActivityFragment.this.f75416D4, null, bundle.getString("fieldId"));
                        }
                    };
                } else if (string.equals("ddx")) {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    final Bundle bundle2 = SDMenuActivityFragment.this.f75419G4.get(i2);
                    rippleTextFullViewHolder.f83284I.setText(bundle2.getString("docTitle"));
                    rippleTextFullViewHolder.f83285J.setText(bundle2.getString("docSection"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.DiagnosisAdapter.3
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
                            CompressHelper compressHelper = sDMenuActivityFragment2.f75863p4;
                            Bundle bundle3 = sDMenuActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle3, "menu,,," + bundle2.getString("id"), null, null);
                        }
                    };
                } else if (string.startsWith("case-")) {
                    final Bundle bundle3 = (Bundle) SDMenuActivityFragment.this.f75421I4.get(Integer.valueOf(string.split("-")[1]).intValue()).getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).get(i2);
                    rippleTextFullViewHolder.f83284I.setText(bundle3.getString("caseTitle"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.DiagnosisAdapter.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
                            CompressHelper compressHelper = sDMenuActivityFragment2.f75863p4;
                            Bundle bundle4 = sDMenuActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle4, "case,,," + bundle3.getString("caseId"), null, null);
                        }
                    };
                } else if (string.equals("anatomy")) {
                    final Bundle bundle4 = SDMenuActivityFragment.this.f75422J4.get(i2);
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    rippleTextFullViewHolder.f83284I.setText(bundle4.getString("docTitle"));
                    rippleTextFullViewHolder.f83285J.setText(bundle4.getString("docSection"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.DiagnosisAdapter.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
                            CompressHelper compressHelper = sDMenuActivityFragment2.f75863p4;
                            Bundle bundle5 = sDMenuActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle5, "menu,,," + bundle4.getString("id"), null, null);
                        }
                    };
                } else if (string.equals("relatedxddx")) {
                    final Bundle bundle5 = SDMenuActivityFragment.this.f75423K4.get(i2);
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    rippleTextFullViewHolder.f83284I.setText(bundle5.getString("topicTitle"));
                    rippleTextFullViewHolder.f83285J.setText(bundle5.getString("topicCategory"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.DiagnosisAdapter.6
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
                            CompressHelper compressHelper = sDMenuActivityFragment2.f75863p4;
                            Bundle bundle6 = sDMenuActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle6, "menu,,," + bundle5.getString("docId"), null, null);
                        }
                    };
                } else if (!string.equals("relatedxanatomy")) {
                    return;
                } else {
                    final Bundle bundle6 = SDMenuActivityFragment.this.f75424L4.get(i2);
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    rippleTextFullViewHolder.f83284I.setText(bundle6.getString("topicTitle"));
                    rippleTextFullViewHolder.f83285J.setText(bundle6.getString("topicCategory"));
                    materialRippleLayout = rippleTextFullViewHolder.f83288M;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.DiagnosisAdapter.7
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
                            CompressHelper compressHelper = sDMenuActivityFragment2.f75863p4;
                            Bundle bundle7 = sDMenuActivityFragment2.f75850c4;
                            compressHelper.m4883q1(bundle7, "menu,,," + bundle6.getString("docId"), null, null);
                        }
                    };
                }
                materialRippleLayout.setOnClickListener(onClickListener);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 0) {
                return new HeaderCellViewHolder(LayoutInflater.from(SDMenuActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false));
            }
            if (i == 2) {
                return new RecyclerViewViewHolder(LayoutInflater.from(SDMenuActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87253list_view_item_recyclerview, viewGroup, false));
            }
            if (i == 1) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(LayoutInflater.from(SDMenuActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87265list_view_item_ripple_text_full, viewGroup, false));
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
            return null;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            SDMenuActivityFragment sDMenuActivityFragment = SDMenuActivityFragment.this;
            return sDMenuActivityFragment.m4287E4(sDMenuActivityFragment.f75417E4);
        }
    }

    /* loaded from: classes2.dex */
    public static class HeaderCellViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f75466I;

        public HeaderCellViewHolder(View view) {
            super(view);
            this.f75466I = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
        }
    }

    /* loaded from: classes2.dex */
    public static class RecyclerViewViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public RecyclerView f75467I;

        public RecyclerViewViewHolder(View view) {
            super(view);
            this.f75467I = (RecyclerView) view.findViewById(C4804R.C4808id.f87001recycler_view);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: D4 */
    public void m4288D4(String str) {
        int i = 0;
        int i2 = 0;
        while (true) {
            if (i2 >= this.f75430z4.size()) {
                break;
            } else if (this.f75430z4.get(i2).getString("id").equals(str)) {
                i = i2;
                break;
            } else {
                i2++;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", this.f75430z4);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public void m4291A4() {
        this.f75427w4.setItemAnimator(new DefaultItemAnimator());
        this.f75427w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f75427w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }

    /* renamed from: B4 */
    public String m4290B4(String str) {
        if (str.equals("Images")) {
            return this.f75428x4.size() + " Images";
        } else if (str.equals("Document")) {
            return "Document";
        } else {
            if (str.equals("ddx")) {
                return "Differential Diagnosis";
            }
            if (str.startsWith("case-")) {
                return this.f75421I4.get(Integer.valueOf(str.split("-")[1]).intValue()).getString("title");
            } else if (str.equals("anatomy")) {
                return "Related Anatomy";
            } else {
                if (str.equals("relatedxddx") || str.equals("relatedxanatomy")) {
                    return "Related Dx";
                }
                iMDLogger.m3294f("numberOfRowsInSection", "Where is title for : " + str);
                return str;
            }
        }
    }

    /* renamed from: C4 */
    public int m4289C4(String str) {
        if (str.equals("Images")) {
            return 1;
        }
        if (str.equals("Document")) {
            return this.f75415C4.size();
        }
        if (str.equals("ddx")) {
            return this.f75419G4.size();
        }
        if (str.startsWith("case-")) {
            return this.f75421I4.get(Integer.valueOf(str.split("-")[1]).intValue()).getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
        } else if (str.equals("anatomy")) {
            return this.f75422J4.size();
        } else {
            if (str.equals("relatedxddx")) {
                return this.f75423K4.size();
            }
            if (str.equals("relatedxanatomy")) {
                return this.f75424L4.size();
            }
            iMDLogger.m3294f("numberOfRowsInSection", "Where is row count for : " + str);
            return -1;
        }
    }

    /* renamed from: E4 */
    public int m4287E4(ArrayList<String> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return 0;
        }
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            i = i + m4289C4(it2.next()) + 1;
        }
        return i;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList = this.f75428x4;
        if (arrayList == null || arrayList.size() <= 0) {
            return null;
        }
        Bundle m4073v3 = m4073v3(this.f75428x4);
        Bundle bundle = this.f75850c4;
        String m4942Z0 = CompressHelper.m4942Z0(bundle, m4073v3.getString("id") + ".jpg", "images-E");
        m4133M3(m4073v3.getString("id"), "images-E");
        return m4942Z0;
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f75427w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        this.f75426N4 = new Bundle();
        String[] split = this.f75851d4.split(",,,");
        if (split.length == 2) {
            this.f75416D4 = split[1];
        } else if (split.length == 3) {
            this.f75416D4 = split[1];
            this.f75425M4 = split[2];
            this.f75851d4 = split[0] + ",,," + split[1];
        }
        if (!new File(CompressHelper.m4945Y0(this.f75850c4, "base")).exists()) {
            new File(CompressHelper.m4945Y0(this.f75850c4, "base")).mkdirs();
        }
        this.f75417E4 = new ArrayList<>();
        this.f75430z4 = new ArrayList<>();
        CompressHelper compressHelper = this.f75863p4;
        Bundle bundle2 = this.f75850c4;
        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from docs where id='" + this.f75416D4 + "'");
        if (m4955V == null || m4955V.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "Can't find the document, sorry", 1);
        } else {
            this.f75414B4 = m4955V.get(0);
            this.f75852e4 = this.f75414B4.getString("title") + " - " + this.f75414B4.getString("category");
            m4081r3(new RunnableC41711(), new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    SDMenuActivityFragment sDMenuActivityFragment = SDMenuActivityFragment.this;
                    if (sDMenuActivityFragment.f75428x4 == null) {
                        sDMenuActivityFragment.f75428x4 = new ArrayList<>();
                    }
                    SDMenuActivityFragment sDMenuActivityFragment2 = SDMenuActivityFragment.this;
                    final String str = sDMenuActivityFragment2.f75425M4;
                    if (str != null) {
                        sDMenuActivityFragment2.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                SDMenuActivityFragment.this.m4288D4(str);
                            }
                        }, 1000L);
                    }
                    if (SDMenuActivityFragment.this.m44859B().containsKey("SEARCH") && SDMenuActivityFragment.this.m44859B().getStringArray("SEARCH") != null) {
                        new Timer().schedule(new TimerTask() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.2.2
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                SDMenuActivityFragment sDMenuActivityFragment3 = SDMenuActivityFragment.this;
                                CompressHelper compressHelper2 = sDMenuActivityFragment3.f75863p4;
                                Bundle bundle3 = sDMenuActivityFragment3.f75850c4;
                                compressHelper2.m4883q1(bundle3, "doc,,," + SDMenuActivityFragment.this.f75416D4, SDMenuActivityFragment.this.m44859B().getStringArray("SEARCH"), null);
                                SDMenuActivityFragment.this.m44859B().remove("SEARCH");
                            }
                        }, SimpleExoPlayer.f32068s1);
                    }
                    SDMenuActivityFragment sDMenuActivityFragment3 = SDMenuActivityFragment.this;
                    sDMenuActivityFragment3.f75413A4 = new DiagnosisAdapter();
                    SDMenuActivityFragment sDMenuActivityFragment4 = SDMenuActivityFragment.this;
                    sDMenuActivityFragment4.f75427w4.setAdapter(sDMenuActivityFragment4.f75413A4);
                    SDMenuActivityFragment.this.m4291A4();
                    SDMenuActivityFragment.this.m4100f3(C4804R.C4811menu.f87326favorite);
                    SDMenuActivityFragment.this.m44735q2(false);
                    SDMenuActivityFragment.this.m4140G3();
                }
            });
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        super.mo3568e3(menu);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.4

            /* renamed from: a */
            byte[] f75445a;

            @Override // android.os.AsyncTask
            protected Object doInBackground(Object[] objArr) {
                try {
                    File file = new File(SDMenuActivityFragment.this.mo3979S2());
                    this.f75445a = new CompressHelper(SDMenuActivityFragment.this.m44716w()).m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127");
                    return null;
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    iMDLogger.m3294f("ImageGallery", "Error in decrypting image");
                    return null;
                }
            }

            @Override // android.os.AsyncTask
            protected void onPostExecute(Object obj) {
                super.onPostExecute(obj);
                Glide.m40315G(SDMenuActivityFragment.this.m44716w()).mo40151h(this.f75445a).m40191t2(SDMenuActivityFragment.this.f75859l4);
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
    }

    @Override // androidx.fragment.app.Fragment, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f75849b4.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDMenuActivityFragment.3
            @Override // java.lang.Runnable
            public void run() {
                SDMenuActivityFragment.this.f75413A4.m42860G();
            }
        }, 500L);
    }

    /* renamed from: x4 */
    public Bundle m4286x4(int i, ArrayList<String> arrayList) {
        Iterator<String> it2 = arrayList.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            String next = it2.next();
            if (i == i2) {
                Bundle bundle = new Bundle();
                bundle.putString("Text", next);
                bundle.putString("Type", "Header");
                return bundle;
            }
            int m4289C4 = i2 + m4289C4(next);
            if (i <= m4289C4) {
                Bundle bundle2 = new Bundle();
                bundle2.putString("Section", next);
                bundle2.putInt("Index", (i - (m4289C4 - m4289C4(next))) - 1);
                bundle2.putString("Type", "Item");
                return bundle2;
            }
            i2 = m4289C4 + 1;
        }
        return null;
    }
}
