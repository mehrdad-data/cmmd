package net.imedicaldoctor.imd.Fragments.Statdx;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class SDDocActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public String f75389A4;

    /* renamed from: B4 */
    public String f75390B4;

    /* renamed from: w4 */
    public Bundle f75391w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f75392x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75393y4;

    /* renamed from: z4 */
    public ArrayList<Bundle> f75394z4;

    /* renamed from: x4 */
    private void m4295x4(String str) {
        if (this.f75393y4.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
            return;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(this.f75393y4);
        int i = 0;
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            if (((Bundle) arrayList.get(i2)).getString("id").startsWith(str)) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList = this.f75392x4;
        if (arrayList == null || arrayList.size() <= 0) {
            return null;
        }
        Bundle m4073v3 = m4073v3(this.f75392x4);
        Bundle bundle = this.f75850c4;
        String m4942Z0 = CompressHelper.m4942Z0(bundle, m4073v3.getString("id") + ".jpg", "images-E");
        m4133M3(m4073v3.getString("id"), "images-E");
        return m4942Z0;
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDDocActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                String str;
                try {
                    String str2 = SDDocActivityFragment.this.f75847Z3;
                    if (str2 == null || str2.length() == 0) {
                        SDDocActivityFragment.this.f75393y4 = new ArrayList<>();
                        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(SDDocActivityFragment.this.f75851d4, ",,,");
                        String str3 = "127";
                        if (splitByWholeSeparator.length == 3) {
                            SDDocActivityFragment sDDocActivityFragment = SDDocActivityFragment.this;
                            sDDocActivityFragment.f75390B4 = splitByWholeSeparator[2];
                            CompressHelper compressHelper = sDDocActivityFragment.f75863p4;
                            Bundle bundle2 = sDDocActivityFragment.f75850c4;
                            ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select id,title,description as content from cases where id='" + SDDocActivityFragment.this.f75390B4 + "'");
                            if (m4955V != null && m4955V.size() != 0) {
                                SDDocActivityFragment.this.f75391w4 = m4955V.get(0);
                                SDDocActivityFragment sDDocActivityFragment2 = SDDocActivityFragment.this;
                                sDDocActivityFragment2.f75852e4 = sDDocActivityFragment2.f75391w4.getString("title");
                                SDDocActivityFragment sDDocActivityFragment3 = SDDocActivityFragment.this;
                                CompressHelper compressHelper2 = sDDocActivityFragment3.f75863p4;
                                Bundle bundle3 = sDDocActivityFragment3.f75850c4;
                                sDDocActivityFragment3.f75392x4 = compressHelper2.m4955V(bundle3, "Select imageId as id, * from cases_images where caseId='" + SDDocActivityFragment.this.f75390B4 + "'");
                                SDDocActivityFragment sDDocActivityFragment4 = SDDocActivityFragment.this;
                                if (sDDocActivityFragment4.f75392x4 == null) {
                                    sDDocActivityFragment4.f75392x4 = new ArrayList<>();
                                }
                                if (SDDocActivityFragment.this.f75392x4.size() > 0) {
                                    Iterator<Bundle> it2 = SDDocActivityFragment.this.f75392x4.iterator();
                                    while (it2.hasNext()) {
                                        Bundle next = it2.next();
                                        Bundle bundle4 = new Bundle();
                                        Bundle bundle5 = SDDocActivityFragment.this.f75850c4;
                                        bundle4.putString("ImagePath", CompressHelper.m4942Z0(bundle5, next.getString("imageId") + ".jpg", "images-E"));
                                        bundle4.putString("id", next.getString("imageId"));
                                        bundle4.putString("Encrypted", IcyHeaders.f35463C2);
                                        bundle4.putBundle("db", SDDocActivityFragment.this.f75850c4);
                                        SDDocActivityFragment.this.f75393y4.add(bundle4);
                                    }
                                }
                                SDDocActivityFragment.this.f75394z4 = new ArrayList<>();
                                Bundle bundle6 = new Bundle();
                                bundle6.putString("fieldTitle", "Description");
                                bundle6.putString("fieldId", "");
                                SDDocActivityFragment.this.f75394z4.add(bundle6);
                                str = str3;
                            }
                            SDDocActivityFragment.this.f75837P3 = "Document doesn't exist";
                            return;
                        }
                        SDDocActivityFragment sDDocActivityFragment5 = SDDocActivityFragment.this;
                        sDDocActivityFragment5.f75389A4 = splitByWholeSeparator[1];
                        CompressHelper compressHelper3 = sDDocActivityFragment5.f75863p4;
                        Bundle bundle7 = sDDocActivityFragment5.f75850c4;
                        ArrayList<Bundle> m4955V2 = compressHelper3.m4955V(bundle7, "Select * from docs where id='" + SDDocActivityFragment.this.f75389A4 + "'");
                        if (m4955V2 != null && m4955V2.size() != 0) {
                            SDDocActivityFragment.this.f75391w4 = m4955V2.get(0);
                            SDDocActivityFragment sDDocActivityFragment6 = SDDocActivityFragment.this;
                            sDDocActivityFragment6.f75852e4 = SDDocActivityFragment.this.f75391w4.getString("title") + " - " + SDDocActivityFragment.this.f75391w4.getString("category");
                            SDDocActivityFragment sDDocActivityFragment7 = SDDocActivityFragment.this;
                            CompressHelper compressHelper4 = sDDocActivityFragment7.f75863p4;
                            Bundle bundle8 = sDDocActivityFragment7.f75850c4;
                            sDDocActivityFragment7.f75392x4 = compressHelper4.m4955V(bundle8, "Select * from images where docId='" + SDDocActivityFragment.this.f75389A4 + "'");
                            SDDocActivityFragment sDDocActivityFragment8 = SDDocActivityFragment.this;
                            if (sDDocActivityFragment8.f75392x4 == null) {
                                sDDocActivityFragment8.f75392x4 = new ArrayList<>();
                            }
                            if (SDDocActivityFragment.this.f75392x4.size() > 0) {
                                Iterator<Bundle> it3 = SDDocActivityFragment.this.f75392x4.iterator();
                                while (it3.hasNext()) {
                                    Bundle next2 = it3.next();
                                    Bundle bundle9 = new Bundle();
                                    Bundle bundle10 = SDDocActivityFragment.this.f75850c4;
                                    bundle9.putString("ImagePath", CompressHelper.m4942Z0(bundle10, next2.getString("id") + ".jpg", "images-E"));
                                    bundle9.putString("id", next2.getString("id"));
                                    bundle9.putString("Encrypted", IcyHeaders.f35463C2);
                                    String str4 = str3;
                                    bundle9.putString("DescriptionHTML2", SDDocActivityFragment.this.f75863p4.m5015B(next2.getString(HTML.Tag.f65910g), next2.getString("id"), str4));
                                    bundle9.putBundle("db", SDDocActivityFragment.this.f75850c4);
                                    SDDocActivityFragment.this.f75393y4.add(bundle9);
                                    str3 = str4;
                                }
                            }
                            str = str3;
                            SDDocActivityFragment sDDocActivityFragment9 = SDDocActivityFragment.this;
                            CompressHelper compressHelper5 = sDDocActivityFragment9.f75863p4;
                            Bundle bundle11 = sDDocActivityFragment9.f75850c4;
                            sDDocActivityFragment9.f75394z4 = compressHelper5.m4955V(bundle11, "Select * from fields where topicId='" + SDDocActivityFragment.this.f75389A4 + "'");
                            SDDocActivityFragment sDDocActivityFragment10 = SDDocActivityFragment.this;
                            if (sDDocActivityFragment10.f75394z4 == null) {
                                sDDocActivityFragment10.f75394z4 = new ArrayList<>();
                            }
                        }
                        SDDocActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                        SDDocActivityFragment sDDocActivityFragment11 = SDDocActivityFragment.this;
                        String m4117W3 = sDDocActivityFragment11.m4117W3(sDDocActivityFragment11.m44716w(), "ASHeader.css");
                        SDDocActivityFragment sDDocActivityFragment12 = SDDocActivityFragment.this;
                        String m4117W32 = sDDocActivityFragment12.m4117W3(sDDocActivityFragment12.m44716w(), "ASFooter.css");
                        String replace = m4117W3.replace("[size]", "200").replace("[title]", SDDocActivityFragment.this.f75852e4).replace("[include]", "");
                        SDDocActivityFragment sDDocActivityFragment13 = SDDocActivityFragment.this;
                        String m5015B = sDDocActivityFragment13.f75863p4.m5015B(sDDocActivityFragment13.f75391w4.getString("content"), SDDocActivityFragment.this.f75391w4.getString("id"), str);
                        SDDocActivityFragment sDDocActivityFragment14 = SDDocActivityFragment.this;
                        sDDocActivityFragment14.f75847Z3 = replace + m5015B + m4117W32;
                    }
                    SDDocActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    SDDocActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDDocActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = SDDocActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    SDDocActivityFragment sDDocActivityFragment = SDDocActivityFragment.this;
                    sDDocActivityFragment.m4078s4(sDDocActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4945Y0(SDDocActivityFragment.this.f75850c4, "base"));
                SDDocActivityFragment sDDocActivityFragment2 = SDDocActivityFragment.this;
                sDDocActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", sDDocActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                SDDocActivityFragment.this.m4092j4();
                SDDocActivityFragment.this.m4098g4();
                SDDocActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                SDDocActivityFragment.this.m44735q2(false);
                SDDocActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4295x4("soheilvb");
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f75394z4);
            bundle.putString("TitleProperty", "fieldTitle");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        m4124T2().m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7329f6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDDocActivityFragment.3
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(String str) throws Throwable {
                if (str != null) {
                    File file = new File(str);
                    if (file.exists()) {
                        try {
                            Glide.m40315G(SDDocActivityFragment.this.m44716w()).mo40151h(new CompressHelper(SDDocActivityFragment.this.m44716w()).m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127")).m40191t2(SDDocActivityFragment.this.f75859l4);
                        } catch (Exception e) {
                            FirebaseCrashlytics.m18030d().m18027g(e);
                            iMDLogger.m3294f("ImageGallery", "Error in decrypting image");
                        }
                    }
                }
            }
        }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.Statdx.SDDocActivityFragment.4
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(Throwable th) throws Throwable {
            }
        });
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }
}
