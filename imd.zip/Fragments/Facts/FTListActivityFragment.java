package net.imedicaldoctor.imd.Fragments.Facts;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleInfoTextViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class FTListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74666b4;

    /* renamed from: c4 */
    public String f74667c4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            this.f74667c4 = "0";
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTListActivityFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            this.f74667c4 = m44859B().getString("ParentId");
        }
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle2 = this.f75212I3;
        this.f75218O3 = compressHelper.m4955V(bundle2, "Select * from toc where parentId=" + this.f74667c4);
        this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87259list_view_item_ripple_goto_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTListActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle3, final int i) {
                RippleInfoTextViewHolder rippleInfoTextViewHolder = (RippleInfoTextViewHolder) viewHolder;
                rippleInfoTextViewHolder.f83260I.setText(bundle3.getString("title"));
                rippleInfoTextViewHolder.f83263L.setVisibility(8);
                rippleInfoTextViewHolder.f83261J.setVisibility(8);
                if (!bundle3.getString("leaf").equals(IcyHeaders.f35463C2)) {
                    if (bundle3.getString("docName").length() > 0) {
                        rippleInfoTextViewHolder.f83263L.setVisibility(0);
                        rippleInfoTextViewHolder.f83261J.setVisibility(0);
                        rippleInfoTextViewHolder.f83261J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTListActivityFragment.2.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                FTListActivityFragment fTListActivityFragment = FTListActivityFragment.this;
                                fTListActivityFragment.f75215L3.m4883q1(fTListActivityFragment.f75212I3, bundle3.getString("docName"), null, null);
                            }
                        });
                    } else {
                        rippleInfoTextViewHolder.f83263L.setVisibility(0);
                    }
                }
                rippleInfoTextViewHolder.f83262K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTListActivityFragment.2.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        FTListActivityFragment.this.m4537l3(bundle3, i);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new RippleInfoTextViewHolder(view);
            }
        };
        this.f74666b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle3, int i) {
                TextView textView;
                int i2;
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle3.getString("text"));
                rippleTextFullViewHolder.f83285J.setText(bundle3.getString("content"));
                if (bundle3.getString("content").length() == 0) {
                    textView = rippleTextFullViewHolder.f83285J;
                    i2 = 8;
                } else {
                    textView = rippleTextFullViewHolder.f83285J;
                    i2 = 0;
                }
                textView.setVisibility(i2);
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTListActivityFragment.3.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        FTListActivityFragment.this.m4330Y2();
                        FTListActivityFragment fTListActivityFragment = FTListActivityFragment.this;
                        fTListActivityFragment.f75215L3.m4883q1(fTListActivityFragment.f75212I3, bundle3.getString("contentId"), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle3) {
                FTListActivityFragment.this.m4330Y2();
                FTListActivityFragment.this.f75223T3.m51655i0(bundle3.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74666b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74666b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select distinct(text),* from search where search match '(text:" + str + "*) AND (type:1)' order by type asc");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    /* renamed from: l3 */
    public void m4537l3(Bundle bundle, int i) {
        m4330Y2();
        if (!bundle.getString("leaf").equals("0")) {
            this.f75215L3.m4883q1(this.f75212I3, bundle.getString("docName"), null, null);
            return;
        }
        Bundle bundle2 = new Bundle();
        bundle2.putBundle("DB", this.f75212I3);
        bundle2.putString("ParentId", bundle.getString("id"));
        this.f75215L3.m4979N(FTListActivity.class, FTListActivityFragment.class, bundle2);
    }
}
