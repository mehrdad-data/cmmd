package net.imedicaldoctor.imd.Fragments.Facts;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class FTViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f74679w4;

    /* renamed from: x4 */
    public ArrayList<String> f74680x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f74681y4;

    /* renamed from: z4 */
    public boolean f74682z4;

    /* renamed from: z4 */
    private void m4534z4(String str) {
        ArrayList<String> arrayList = this.f74680x4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f74680x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", next);
            bundle.putString("Description", "");
            bundle.putString("id", next);
            if (new File(next).length() > 5000) {
                arrayList2.add(bundle);
            }
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4535y4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f74680x4 = arrayList;
            mo3978f4();
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return m4071w3(this.f74680x4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        if (this.f74682z4) {
            this.f74682z4 = false;
            m4536x4();
            this.f75853f4.loadUrl("javascript:ConvertAllImages();");
            this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
            this.f75853f4.loadUrl("javascript:onBodyLoad();");
            super.mo3569S3(webView, str);
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        this.f74682z4 = true;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    String str = FTViewerActivityFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        iMDLogger.m3294f("Loading Document", FTViewerActivityFragment.this.f75851d4);
                        FTViewerActivityFragment fTViewerActivityFragment = FTViewerActivityFragment.this;
                        CompressHelper compressHelper = fTViewerActivityFragment.f75863p4;
                        Bundle bundle2 = fTViewerActivityFragment.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from docs where docName='" + FTViewerActivityFragment.this.f75851d4 + "'");
                        if (m4955V != null && m4955V.size() != 0) {
                            FTViewerActivityFragment.this.f74679w4 = m4955V.get(0);
                            FTViewerActivityFragment fTViewerActivityFragment2 = FTViewerActivityFragment.this;
                            CompressHelper compressHelper2 = fTViewerActivityFragment2.f75863p4;
                            Bundle bundle3 = fTViewerActivityFragment2.f75850c4;
                            fTViewerActivityFragment2.f74681y4 = compressHelper2.m4955V(bundle3, "select * from fields where docId='" + FTViewerActivityFragment.this.f75851d4 + "'");
                            FTViewerActivityFragment fTViewerActivityFragment3 = FTViewerActivityFragment.this;
                            fTViewerActivityFragment3.f75852e4 = fTViewerActivityFragment3.f74679w4.getString("title");
                            FTViewerActivityFragment fTViewerActivityFragment4 = FTViewerActivityFragment.this;
                            String m5015B = fTViewerActivityFragment4.f75863p4.m5015B(fTViewerActivityFragment4.f74679w4.getString("content"), FTViewerActivityFragment.this.f75851d4, "127");
                            FTViewerActivityFragment fTViewerActivityFragment5 = FTViewerActivityFragment.this;
                            String m5015B2 = fTViewerActivityFragment5.f75863p4.m5015B(fTViewerActivityFragment5.f74679w4.getString("java"), FTViewerActivityFragment.this.f75851d4, "127");
                            FTViewerActivityFragment fTViewerActivityFragment6 = FTViewerActivityFragment.this;
                            String m4117W3 = fTViewerActivityFragment6.m4117W3(fTViewerActivityFragment6.m44716w(), "FTHeader.css");
                            FTViewerActivityFragment fTViewerActivityFragment7 = FTViewerActivityFragment.this;
                            String m4117W32 = fTViewerActivityFragment7.m4117W3(fTViewerActivityFragment7.m44716w(), "FTFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", FTViewerActivityFragment.this.f75852e4).replace("[include]", "").replace("[javascript]", m5015B2);
                            FTViewerActivityFragment fTViewerActivityFragment8 = FTViewerActivityFragment.this;
                            fTViewerActivityFragment8.f75847Z3 = replace + m5015B + m4117W32;
                        }
                        FTViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                    }
                    FTViewerActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    FTViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Facts.FTViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = FTViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    FTViewerActivityFragment fTViewerActivityFragment = FTViewerActivityFragment.this;
                    fTViewerActivityFragment.m4078s4(fTViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(FTViewerActivityFragment.this.f75850c4.getString("Path") + "/base");
                FTViewerActivityFragment fTViewerActivityFragment2 = FTViewerActivityFragment.this;
                fTViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", fTViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                FTViewerActivityFragment.this.m4092j4();
                FTViewerActivityFragment.this.m4098g4();
                FTViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                FTViewerActivityFragment.this.m44735q2(false);
                FTViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4534z4("asdfafdsaf");
            return true;
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f74681y4);
            bundle.putString("TitleProperty", "title");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        String str4;
        if (str2.equals("image")) {
            m4534z4(str3);
            return true;
        }
        if (str2.equals(Annotation.f59806M2)) {
            String str5 = "//" + CompressHelper.m4945Y0(this.f75850c4, "base") + "/";
            if (str3.contains("#")) {
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "#");
                String str6 = splitByWholeSeparator[0];
                String str7 = splitByWholeSeparator[1];
                String replace = str6.replace(str5, "").replace(".html", "");
                if (this.f74679w4.getString("docName").toLowerCase().equals(replace.toLowerCase())) {
                    this.f75853f4.loadUrl("javascript:window.location.href = \"#" + str7 + "\"");
                    return true;
                } else if (replace.length() == 0) {
                    this.f75853f4.loadUrl("javascript:window.location.href = \"#" + str7 + "\"");
                    return true;
                } else if (replace.substring(replace.length() - 1).equals("/")) {
                    this.f75853f4.loadUrl("javascript:window.location.href = \"#" + str7 + "\"");
                    return true;
                } else {
                    str4 = str7;
                    str3 = replace;
                }
            } else {
                str4 = "";
            }
            String replace2 = str3.replace(str5, "");
            if (replace2.length() == 0) {
                return true;
            }
            str3 = replace2.replace(".html", "").toLowerCase();
            if (str3.contains("/monodisp.aspx?")) {
                String m4920f = CompressHelper.m4920f(str3, "monoid=", "&");
                if (m4920f == null || m4920f.length() == 0) {
                    m4920f = this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(str3, "&monoid="));
                }
                CompressHelper compressHelper = this.f75863p4;
                if (compressHelper.m4907i1(compressHelper.m4955V(this.f75850c4, "select * from docs where docName='" + m4920f + "'")) == null) {
                    CompressHelper.m4921e2(m44716w(), "Sorry, not in this book", 1);
                } else {
                    this.f75863p4.m4883q1(this.f75850c4, m4920f, null, str4);
                }
            }
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public void m4536x4() {
        Iterator<Bundle> it2 = this.f74681y4.iterator();
        while (it2.hasNext()) {
            String string = it2.next().getString("fId");
            if (!string.equals("prodlist_DIV") && this.f75850c4.getString("Name").equals("facts.db")) {
                WebView webView = this.f75853f4;
                webView.loadUrl("javascript:showSingleSection('" + string + "');");
            }
        }
    }

    /* renamed from: y4 */
    public String m4535y4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }
}
