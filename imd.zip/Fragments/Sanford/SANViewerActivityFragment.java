package net.imedicaldoctor.imd.Fragments.Sanford;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class SANViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f75159w4;

    /* renamed from: x4 */
    public ArrayList<String> f75160x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75161y4;

    /* renamed from: z4 */
    public boolean f75162z4;

    /* renamed from: y4 */
    private void m4363y4(String str) {
        ArrayList<String> arrayList = this.f75160x4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f75160x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", next);
            bundle.putString("Description", "");
            bundle.putString("id", next);
            if (new File(next).length() > 5000) {
                arrayList2.add(bundle);
            }
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String string = this.f75850c4.getString("Path");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = string.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4364x4(str) : str + "/" + str3;
                    }
                } else {
                    str = string + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f75160x4 = arrayList;
            mo3978f4();
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return m4071w3(this.f75160x4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:fixAllImages2();");
        this.f75853f4.loadUrl("javascript:fixAllTables();");
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        this.f75162z4 = true;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Sanford.SANViewerActivityFragment.1
            /* JADX WARN: Removed duplicated region for block: B:23:0x00c4  */
            @Override // java.lang.Runnable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public void run() {
                /*
                    Method dump skipped, instructions count: 272
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Sanford.SANViewerActivityFragment.RunnableC40791.run():void");
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Sanford.SANViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = SANViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    SANViewerActivityFragment sANViewerActivityFragment = SANViewerActivityFragment.this;
                    sANViewerActivityFragment.m4078s4(sANViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(SANViewerActivityFragment.this.f75850c4.getString("Path"));
                SANViewerActivityFragment sANViewerActivityFragment2 = SANViewerActivityFragment.this;
                sANViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", sANViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                SANViewerActivityFragment.this.m4092j4();
                SANViewerActivityFragment.this.m4098g4();
                SANViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                SANViewerActivityFragment.this.m44735q2(false);
                SANViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86774action_gallery) {
            m4363y4("asdfafdsaf");
            return true;
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86776action_menu);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        String str4;
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        if (str2.equals("image")) {
            m4363y4(str3);
            return true;
        } else if (!str2.equals(Annotation.f59806M2)) {
            if (str2.equals("http")) {
                m4123T3(str);
            }
            return true;
        } else {
            CompressHelper compressHelper = new CompressHelper(m44716w());
            String str5 = "//" + this.f75850c4.getString("Path") + "/";
            if (str.contains("#")) {
                str4 = StringUtils.splitByWholeSeparator(str, "#")[1];
                iMDLogger.m3294f("Testing", "BasePath : " + str5 + ", Resource : " + str3 + ", mPath : " + this.f75851d4);
                str3 = str3.replace(str5, "");
                if (this.f75851d4.equalsIgnoreCase(str3)) {
                    mo4144C3(str4);
                    return true;
                }
            } else {
                str4 = "";
            }
            iMDLogger.m3294f("Testing", "BasePath : " + str5 + ", Resource : " + str3 + ", mPath : " + this.f75851d4);
            String replace = str3.replace(str5, "");
            if (!new File(CompressHelper.m4945Y0(this.f75850c4, replace)).exists()) {
                replace = compressHelper.m4904j1(StringUtils.splitByWholeSeparator(replace, "/"));
                if (!replace.endsWith(".html")) {
                    replace = replace + ".html";
                }
                if (!new File(CompressHelper.m4945Y0(this.f75850c4, replace)).exists()) {
                    CompressHelper.m4921e2(m44716w(), "Sorry, Document not available", 1);
                    return true;
                }
            }
            compressHelper.m4883q1(this.f75850c4, replace, null, str4);
            return true;
        }
    }

    /* renamed from: x4 */
    public String m4364x4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }
}
