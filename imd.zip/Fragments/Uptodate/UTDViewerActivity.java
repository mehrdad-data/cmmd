package net.imedicaldoctor.imd.Fragments.Uptodate;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.appcompat.app.AlertDialog;
import androidx.exifinterface.media.ExifInterface;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMD;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class UTDViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class UTDViewerFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        private String f75785A4;

        /* renamed from: B4 */
        private String f75786B4;

        /* renamed from: C4 */
        private String f75787C4;

        /* renamed from: D4 */
        private String f75788D4;

        /* renamed from: w4 */
        private String f75789w4;

        /* renamed from: x4 */
        private String f75790x4 = null;

        /* renamed from: y4 */
        private String f75791y4 = null;

        /* renamed from: z4 */
        private String f75792z4 = null;

        /* renamed from: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity$UTDViewerFragment$2 */
        /* loaded from: classes2.dex */
        class RunnableC42992 implements Runnable {
            RunnableC42992() {
            }

            @Override // java.lang.Runnable
            public void run() {
                AlertDialog.Builder mo26278s;
                DialogInterface.OnClickListener onClickListener;
                String str = UTDViewerFragment.this.f75837P3;
                if (str == null || str.length() <= 0) {
                    UTDViewerFragment.this.f75863p4.m4892n1();
                    UTDViewerFragment.this.m4102d4("Topic");
                    new File(CompressHelper.m4945Y0(UTDViewerFragment.this.f75850c4, "base"));
                    UTDViewerFragment uTDViewerFragment = UTDViewerFragment.this;
                    uTDViewerFragment.f75853f4.loadDataWithBaseURL("file:///android_asset/", uTDViewerFragment.f75847Z3, "text/html", "utf-8", null);
                    UTDViewerFragment.this.m4092j4();
                    UTDViewerFragment.this.m4098g4();
                    UTDViewerFragment.this.m4100f3(C4804R.C4811menu.f87396menu_utdviewer);
                    UTDViewerFragment.this.m44735q2(false);
                    UTDViewerFragment.this.m4140G3();
                    return;
                }
                if (UTDViewerFragment.this.f75837P3.equals(IcyHeaders.f35463C2)) {
                    mo26278s = new AlertDialog.Builder(UTDViewerFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("The database is corrupt . it may happen after delta update or as a result of bad installation or a cleaner app in your device . you must delete and redownload this database. what do you want to do ?").mo26284p("Delete", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.3
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            new AlertDialog.Builder(UTDViewerFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Are you sure ? this will delete uptodate database ...").mo26266y("Yes", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.3.2
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                    UTDViewerFragment.this.m4125R2(new File(UTDViewerFragment.this.f75850c4.getString("Path")));
                                    LocalBroadcastManager.m43863b(UTDViewerFragment.this.m44716w()).m43861d(new Intent("reload"));
                                    UTDViewerFragment.this.f75863p4.m4989J1(false);
                                    UTDViewerFragment.this.f75863p4.m4989J1(true);
                                }
                            }).mo26284p("No", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.3.1
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                }
                            }).m52864I();
                        }
                    }).mo26278s("More Info", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.2
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            UTDViewerFragment.this.m4123T3("http://imedicaldoctor.net/faq#null");
                            UTDViewerFragment.this.f75863p4.m4998G1(false);
                        }
                    });
                    onClickListener = new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    };
                } else if (!UTDViewerFragment.this.f75837P3.equals(ExifInterface.f14403S4)) {
                    UTDViewerFragment uTDViewerFragment2 = UTDViewerFragment.this;
                    uTDViewerFragment2.m4078s4(uTDViewerFragment2.f75837P3);
                    return;
                } else {
                    mo26278s = new AlertDialog.Builder(UTDViewerFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Document can't be found . if this happens a lot your database is corrupted . it may happen after delta update . you must delete and redownload this database. what do you want to do ?").mo26284p("Delete", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.6
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            new AlertDialog.Builder(UTDViewerFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Are you sure ? this will delete uptodate database ...").mo26266y("Yes", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.6.2
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                    UTDViewerFragment.this.m4125R2(new File(UTDViewerFragment.this.f75850c4.getString("Path")));
                                    LocalBroadcastManager.m43863b(UTDViewerFragment.this.m44716w()).m43861d(new Intent("reload"));
                                    UTDViewerFragment.this.f75863p4.m4989J1(true);
                                    UTDViewerFragment.this.f75863p4.m4989J1(false);
                                }
                            }).mo26284p("No", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.6.1
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                }
                            }).m52864I();
                        }
                    }).mo26278s("More Info", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.5
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            UTDViewerFragment.this.m4123T3("http://imedicaldoctor.net/faq#null");
                            UTDViewerFragment.this.f75863p4.m4998G1(false);
                        }
                    });
                    onClickListener = new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.2.4
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    };
                }
                mo26278s.mo26266y("OK", onClickListener).m52864I();
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: A3 */
        public void mo4146A3(int i) {
            if (this.f75854g4.length() > 0) {
                try {
                    WebView webView = this.f75853f4;
                    webView.loadUrl("javascript:setHighlightClass(\"" + this.f75854g4.getString(this.f75835N3) + "\")");
                    WebView webView2 = this.f75853f4;
                    webView2.loadUrl("javascript:var obj = document.getElementById(\"" + this.f75854g4.getString(i) + "\");obj.className = \"highlightedCurrent\";obj.scrollIntoView(true);");
                    this.f75835N3 = i;
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                }
            }
            m4120V2();
        }

        /* renamed from: G4 */
        public void m4165G4(String str) {
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            compressHelper.m4883q1(bundle, "Graphic-" + str, null, null);
        }

        /* renamed from: H4 */
        public void m4164H4(String str) {
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            compressHelper.m4883q1(bundle, "Topic-" + str, null, null);
        }

        /* renamed from: I4 */
        public void m4163I4(String str) {
            String string;
            String str2;
            String str3;
            try {
                JSONObject jSONObject = new JSONObject(Uri.decode(str.substring(21)));
                if (jSONObject.getJSONObject(HTML.Tag.f65854D).getString("assetType").equals("graphic")) {
                    JSONArray jSONArray = jSONObject.getJSONArray("data");
                    ArrayList arrayList = new ArrayList();
                    for (int i = 0; i < jSONArray.length(); i++) {
                        arrayList.add(jSONArray.getJSONObject(i).getString("id"));
                    }
                    this.f75863p4.m4883q1(this.f75850c4, "Graphic-" + TextUtils.join(",,,,", arrayList), null, null);
                    return;
                }
                try {
                    string = jSONObject.getJSONObject(HTML.Tag.f65854D).getString("topicId");
                } catch (Exception unused) {
                    string = jSONObject.getJSONArray("data").getJSONObject(0).getString("id");
                }
                try {
                    str2 = jSONObject.getJSONArray("data").getJSONObject(0).getString("subtype");
                } catch (Exception unused2) {
                    str2 = "";
                }
                if (!str2.equals("narrative_icg")) {
                    try {
                        try {
                            str3 = jSONObject.getJSONObject(HTML.Tag.f65854D).getString(HTML.Tag.f65890V);
                        } catch (Exception unused3) {
                            str3 = null;
                        }
                    } catch (Exception unused4) {
                        str3 = jSONObject.getJSONArray("data").getJSONObject(0).getString(HTML.Tag.f65890V);
                    }
                    if (this.f75788D4.equals(string)) {
                        mo4144C3(str3);
                        return;
                    }
                    iMDLogger.m3290j("Activity Type", m44716w().getClass().toString());
                    this.f75863p4.m4883q1(this.f75850c4, "Topic-" + string, null, str3);
                    return;
                }
                ArrayList arrayList2 = new ArrayList(Collections2.m23110e(((iMD) m44716w().getApplicationContext()).f83461s, new Predicate<Bundle>() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.6
                    @Override // com.google.common.base.Predicate
                    /* renamed from: a */
                    public boolean apply(Bundle bundle) {
                        return bundle.getString("Name").equals("utdpathways.db");
                    }
                }));
                if (arrayList2.size() == 0) {
                    CompressHelper.m4921e2(m44716w(), "You must install Uptodate Pathways Database", 1);
                    return;
                }
                Bundle bundle = (Bundle) arrayList2.get(0);
                CompressHelper compressHelper = this.f75863p4;
                ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select * from docs where path = '" + ("base/" + string + ".html") + "'");
                if (m4955V != null && m4955V.size() != 0) {
                    this.f75863p4.m4883q1(bundle, m4955V.get(0).getString("id"), null, "");
                    return;
                }
                CompressHelper.m4921e2(m44716w(), "Sorry, Document not available", 1);
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                iMDLogger.m3294f("ViewerActivity , onMenuURLClicked", e.toString());
            }
        }

        /* renamed from: J4 */
        public void m4162J4() {
            if (this.f75786B4 == null) {
                return;
            }
            try {
                JSONArray jSONArray = new JSONArray(this.f75786B4);
                String str = "";
                for (int i = 0; i < jSONArray.length(); i++) {
                    JSONObject jSONObject = jSONArray.getJSONObject(i);
                    ArrayList arrayList = new ArrayList();
                    for (int i2 = 0; i2 < jSONObject.getJSONArray("contributorList").length(); i2++) {
                        ArrayList arrayList2 = new ArrayList();
                        JSONObject jSONObject2 = jSONObject.getJSONArray("contributorList").getJSONObject(i2);
                        for (int i3 = 0; i3 < jSONObject2.getJSONArray("associations").length(); i3++) {
                            arrayList2.add(jSONObject2.getJSONArray("associations").getString(i3));
                        }
                        arrayList.add("<i>" + jSONObject2.getString("name") + "</i><br>" + TextUtils.join("<br>", arrayList2));
                    }
                    String str2 = "<b>" + jSONObject.getString("headingTitle") + "</b><br>" + TextUtils.join("\n", arrayList);
                    str = str.length() == 0 ? str2 : str + "<br>" + str2;
                }
                new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l(Html.fromHtml(str)).mo26266y("OK", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i4) {
                    }
                }).m52864I();
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
            }
        }

        /* renamed from: K4 */
        public void m4161K4() {
            if (this.f75786B4 == null) {
                return;
            }
            try {
                JSONArray jSONArray = new JSONArray(this.f75786B4);
                String str = "";
                for (int i = 0; i < jSONArray.length(); i++) {
                    JSONObject jSONObject = jSONArray.getJSONObject(i);
                    ArrayList arrayList = new ArrayList();
                    for (int i2 = 0; i2 < jSONObject.getJSONArray("contributorList").length(); i2++) {
                        JSONObject jSONObject2 = jSONObject.getJSONArray("contributorList").getJSONObject(i2);
                        arrayList.add("<b>" + jSONObject2.getString("name") + "</b><br>" + jSONObject2.getString("disclosure"));
                    }
                    String join = TextUtils.join("<br>", arrayList);
                    str = str.length() == 0 ? join : str + "<br>" + join;
                }
                new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l(Html.fromHtml(str)).mo26266y("OK", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.4
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i3) {
                    }
                }).m52864I();
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            JSONArray jSONArray;
            CompressHelper compressHelper;
            Bundle bundle;
            String str;
            String str2;
            if (this.f75792z4 == null) {
                return null;
            }
            try {
                jSONArray = new JSONArray(this.f75792z4);
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                jSONArray = null;
            }
            if (jSONArray == null || jSONArray.length() == 0) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    JSONArray jSONArray2 = jSONArray.getJSONObject(i).getJSONArray("graphics");
                    for (int i2 = 0; i2 < jSONArray2.length(); i2++) {
                        JSONObject jSONObject = jSONArray2.getJSONObject(i2);
                        jSONObject.getJSONObject("graphicInfo").getString("displayName");
                        arrayList.add(jSONObject.getJSONObject("graphicInfo").getString("id"));
                    }
                } catch (Exception e2) {
                    FirebaseCrashlytics.m18030d().m18027g(e2);
                }
            }
            Random random = new Random();
            int i3 = 0;
            while (true) {
                int nextInt = random.nextInt(arrayList.size());
                if (i3 > arrayList.size() - 1) {
                    return null;
                }
                i3++;
                String str3 = (String) arrayList.get(nextInt);
                if (this.f75850c4.getString("Name").equals("utdadvanced")) {
                    compressHelper = this.f75863p4;
                    bundle = this.f75850c4;
                    str = "select * from graphic_asset where id =" + str3;
                    str2 = "lab.db";
                } else {
                    compressHelper = this.f75863p4;
                    bundle = this.f75850c4;
                    str = "select * from graphic_asset where id =" + str3;
                    str2 = "utdasset.sqlite";
                }
                Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4952W(bundle, str, str2));
                if (m4907i1 != null) {
                    try {
                        JSONObject jSONObject2 = new JSONObject(new String(this.f75863p4.m4870v(m4907i1.getString("payload"), m4907i1.getString("id"), "127")));
                        if (jSONObject2.has("base64Image")) {
                            String string = jSONObject2.getString("base64Image");
                            String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "background.png");
                            File file = new File(m4945Y0);
                            if (file.exists() && !file.delete()) {
                                iMDLogger.m3294f("ImagePathForToolbar", "Not Deleted");
                            }
                            FileOutputStream fileOutputStream = new FileOutputStream(file);
                            IOUtils.write(Base64.decode(string, 0), fileOutputStream);
                            fileOutputStream.close();
                            return m4945Y0;
                        }
                        continue;
                    } catch (Exception e3) {
                        FirebaseCrashlytics.m18030d().m18027g(e3);
                    }
                }
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87396menu_utdviewer, menu);
            m4096h4(menu);
            MenuItem findItem = menu.findItem(C4804R.C4808id.f86784action_relatedTopics);
            MenuItem findItem2 = menu.findItem(C4804R.C4808id.f86783action_relatedGraphics);
            MenuItem findItem3 = menu.findItem(C4804R.C4808id.f86782action_relatedCalcs);
            MenuItem findItem4 = menu.findItem(C4804R.C4808id.f86776action_menu);
            MenuItem findItem5 = menu.findItem(C4804R.C4808id.f86781action_references);
            if (this.f75790x4 == null) {
                findItem.setVisible(false);
            }
            if (this.f75792z4 == null) {
                findItem2.setVisible(false);
            }
            if (this.f75791y4 == null) {
                findItem3.setVisible(false);
            }
            if (this.f75789w4 == null) {
                findItem4.setVisible(false);
            }
            if (this.f75785A4 == null) {
                findItem5.setVisible(false);
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (m44859B() == null) {
                return inflate;
            }
            if (bundle != null) {
                this.f75787C4 = bundle.getString("mLastMajorUpdates");
                this.f75786B4 = bundle.getString("mContributers");
                this.f75792z4 = bundle.getString("mRelatedGraphics");
                this.f75791y4 = bundle.getString("mRelatedCalcs");
                this.f75790x4 = bundle.getString("mRelatedTopics");
                this.f75785A4 = bundle.getString("mReferences");
                this.f75789w4 = bundle.getString("mMenuHTML");
            }
            this.f75788D4 = this.f75851d4.split("-")[1];
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    String str;
                    Bundle m4919f0;
                    try {
                        String str2 = UTDViewerFragment.this.f75847Z3;
                        if (str2 == null || str2.length() == 0) {
                            if (UTDViewerFragment.this.f75850c4.getString("Name").equals("uptodateonline")) {
                                try {
                                    str = UTDViewerFragment.this.f75863p4.m4918f1(UTDViewerFragment.this.f75863p4.m4991J() + "/utdonline/topic/" + UTDViewerFragment.this.f75788D4 + ".txt", "topic-" + UTDViewerFragment.this.f75788D4 + UTDViewerFragment.this.f75850c4.getString("Version"));
                                } catch (Exception unused) {
                                    str = null;
                                }
                                if (str == null) {
                                    UTDViewerFragment.this.f75837P3 = "Error in retrieving data from server";
                                    return;
                                }
                            } else if (!new File(CompressHelper.m4945Y0(UTDViewerFragment.this.f75850c4, "utdasset.sqlite")).exists()) {
                                UTDViewerFragment.this.f75837P3 = IcyHeaders.f35463C2;
                                return;
                            } else {
                                UTDViewerFragment uTDViewerFragment = UTDViewerFragment.this;
                                uTDViewerFragment.f75788D4 = uTDViewerFragment.f75788D4.replace(StringUtils.SPACE, "");
                                if (UTDViewerFragment.this.f75850c4.getString("Name").equals("utdadvanced")) {
                                    UTDViewerFragment uTDViewerFragment2 = UTDViewerFragment.this;
                                    m4919f0 = uTDViewerFragment2.f75863p4.m4919f0(uTDViewerFragment2.f75850c4, "select * from topic_asset where id = " + UTDViewerFragment.this.f75788D4, "lab.db");
                                } else {
                                    UTDViewerFragment uTDViewerFragment3 = UTDViewerFragment.this;
                                    m4919f0 = uTDViewerFragment3.f75863p4.m4919f0(uTDViewerFragment3.f75850c4, "select * from topic_asset where id = " + UTDViewerFragment.this.f75788D4, "utdasset.sqlite");
                                }
                                if (m4919f0 == null) {
                                    UTDViewerFragment.this.f75837P3 = ExifInterface.f14403S4;
                                    return;
                                }
                                str = m4919f0.getString("payload");
                            }
                            UTDViewerFragment uTDViewerFragment4 = UTDViewerFragment.this;
                            JSONObject jSONObject = new JSONObject(new String(uTDViewerFragment4.f75863p4.m4870v(str, uTDViewerFragment4.f75788D4, "127")));
                            if (jSONObject.has("outlineHtml")) {
                                UTDViewerFragment.this.f75789w4 = jSONObject.getString("outlineHtml");
                            }
                            if (jSONObject.has("referenceHtml")) {
                                UTDViewerFragment.this.f75785A4 = jSONObject.getString("referenceHtml");
                            }
                            String string = jSONObject.getString("bodyHtml");
                            if (jSONObject.has("relatedTopics")) {
                                UTDViewerFragment.this.f75790x4 = jSONObject.getJSONObject("relatedTopics").getString("topics");
                            }
                            if (jSONObject.has("relatedCalculators")) {
                                UTDViewerFragment.this.f75791y4 = jSONObject.getJSONObject("relatedCalculators").getString("topics");
                            }
                            if (jSONObject.has("relatedGraphics")) {
                                UTDViewerFragment.this.f75792z4 = jSONObject.getString("relatedGraphics");
                            }
                            if (jSONObject.has("contributors")) {
                                UTDViewerFragment.this.f75786B4 = jSONObject.getString("contributors");
                            }
                            UTDViewerFragment.this.f75787C4 = jSONObject.getJSONObject("topicInfo").getString("lastMajorUpdateMs");
                            UTDViewerFragment.this.f75852e4 = jSONObject.getJSONObject("topicInfo").getString("title");
                            UTDViewerFragment uTDViewerFragment5 = UTDViewerFragment.this;
                            String m4117W3 = uTDViewerFragment5.m4117W3(uTDViewerFragment5.m44716w(), "UTDHeader.css");
                            UTDViewerFragment uTDViewerFragment6 = UTDViewerFragment.this;
                            String replace = uTDViewerFragment6.m4117W3(uTDViewerFragment6.m44716w(), "UTDFooter.css").replace("[year]", String.valueOf(new SimpleDateFormat("yyyy").format(new Date())));
                            String replace2 = m4117W3.replace("[Title]", UTDViewerFragment.this.f75852e4).replace("[size]", "200");
                            UTDViewerFragment.this.f75847Z3 = replace2 + string + replace;
                        }
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        e.printStackTrace();
                        UTDViewerFragment.this.f75837P3 = e.getLocalizedMessage();
                    }
                }
            }, new RunnableC42992());
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86776action_menu) {
                UTDMenuFragment uTDMenuFragment = new UTDMenuFragment();
                Bundle bundle = new Bundle();
                bundle.putString(HTML.Tag.f65946y, this.f75789w4);
                bundle.putString("title", this.f75852e4);
                uTDMenuFragment.m44751k2(bundle);
                uTDMenuFragment.m44844E2(this, 0);
                uTDMenuFragment.mo29915h3(m44820L(), HTML.Tag.f65943w0);
                return true;
            } else if (itemId == C4804R.C4808id.f86781action_references) {
                UTDMenuFragment uTDMenuFragment2 = new UTDMenuFragment();
                Bundle bundle2 = new Bundle();
                bundle2.putString(HTML.Tag.f65946y, this.f75785A4);
                bundle2.putString("title", this.f75852e4);
                uTDMenuFragment2.m44751k2(bundle2);
                uTDMenuFragment2.m44844E2(this, 0);
                uTDMenuFragment2.mo29915h3(m44820L(), "references");
                return true;
            } else if (itemId == C4804R.C4808id.f86784action_relatedTopics) {
                UTDRelatedTopicsFragment uTDRelatedTopicsFragment = new UTDRelatedTopicsFragment();
                Bundle bundle3 = new Bundle();
                bundle3.putString("RELATED", this.f75790x4);
                uTDRelatedTopicsFragment.m44751k2(bundle3);
                uTDRelatedTopicsFragment.m44844E2(this, 0);
                uTDRelatedTopicsFragment.mo29915h3(m44820L(), "related");
                return true;
            } else if (itemId == C4804R.C4808id.f86782action_relatedCalcs) {
                UTDRelatedTopicsFragment uTDRelatedTopicsFragment2 = new UTDRelatedTopicsFragment();
                Bundle bundle4 = new Bundle();
                bundle4.putString("RELATED", this.f75791y4);
                bundle4.putString("CALC", "");
                uTDRelatedTopicsFragment2.m44751k2(bundle4);
                uTDRelatedTopicsFragment2.m44844E2(this, 0);
                uTDRelatedTopicsFragment2.mo29915h3(m44820L(), "relatedcalc");
                return true;
            } else if (itemId == C4804R.C4808id.f86783action_relatedGraphics) {
                UTDRelatedGraphicsFragment uTDRelatedGraphicsFragment = new UTDRelatedGraphicsFragment();
                Bundle bundle5 = new Bundle();
                bundle5.putString("RELATED", this.f75792z4);
                uTDRelatedGraphicsFragment.m44751k2(bundle5);
                uTDRelatedGraphicsFragment.m44844E2(this, 0);
                uTDRelatedGraphicsFragment.mo29915h3(m44820L(), "related");
                return true;
            } else {
                return super.mo3709e1(menuItem);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            MenuItem findItem = menu.findItem(C4804R.C4808id.f86784action_relatedTopics);
            MenuItem findItem2 = menu.findItem(C4804R.C4808id.f86783action_relatedGraphics);
            MenuItem findItem3 = menu.findItem(C4804R.C4808id.f86782action_relatedCalcs);
            MenuItem findItem4 = menu.findItem(C4804R.C4808id.f86776action_menu);
            MenuItem findItem5 = menu.findItem(C4804R.C4808id.f86781action_references);
            if (this.f75790x4 == null) {
                findItem.setVisible(false);
            }
            if (this.f75792z4 == null) {
                findItem2.setVisible(false);
            }
            if (this.f75791y4 == null) {
                findItem3.setVisible(false);
            }
            if (this.f75789w4 == null) {
                findItem4.setVisible(false);
            }
            if (this.f75785A4 == null) {
                findItem5.setVisible(false);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            String string;
            String string2;
            String str4;
            String str5;
            if (str2.equals("uptodatewebaction")) {
                if (!str3.equals("//zoomOut") && !str3.equals("//zoomIn") && !str3.equals("//zoomFinished")) {
                    if (str3.equals("//contributors")) {
                        m4162J4();
                    } else if (str3.equals("//contributorsDisclosure")) {
                        m4161K4();
                    } else if (str3.startsWith("//lastUpdated")) {
                        String string3 = this.f75850c4.getString("Version");
                        Date date = new Date(Long.valueOf(Long.parseLong(this.f75787C4)).longValue());
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        CompressHelper.m4921e2(m44716w(), "All topics are updated as new evidence becomes available and our peer review process is complete. Literature review current through " + string3.split(StringUtils.SPACE)[0] + ". This topic was last updated: " + simpleDateFormat.format(date), 1);
                    }
                }
            } else if (str2.equals("uptodateappaction")) {
                try {
                    JSONObject jSONObject = new JSONObject(Uri.decode(Uri.parse(str).toString().substring(21)));
                    try {
                        string = jSONObject.getJSONObject(HTML.Tag.f65854D).getString("assetType");
                    } catch (Exception unused) {
                        string = jSONObject.getJSONArray("data").getJSONObject(0).getString("type");
                    }
                    if (string.equals("graphic")) {
                        JSONArray jSONArray = jSONObject.getJSONArray("data");
                        ArrayList arrayList = new ArrayList();
                        for (int i = 0; i < jSONArray.length(); i++) {
                            arrayList.add(jSONArray.getJSONObject(i).getString("id"));
                        }
                        this.f75863p4.m4883q1(this.f75850c4, "Graphic-" + TextUtils.join(",,,,", arrayList), null, null);
                        return true;
                    } else if (string.equals("topic")) {
                        try {
                            string2 = jSONObject.getJSONObject(HTML.Tag.f65854D).getString("topicId");
                        } catch (Exception unused2) {
                            string2 = jSONObject.getJSONArray("data").getJSONObject(0).getString("id");
                        }
                        try {
                            str4 = jSONObject.getJSONArray("data").getJSONObject(0).getString("subtype");
                        } catch (Exception unused3) {
                            str4 = "";
                        }
                        if (str4.equals("narrative_icg")) {
                            ArrayList arrayList2 = new ArrayList(Collections2.m23110e(((iMD) m44716w().getApplicationContext()).f83461s, new Predicate<Bundle>() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity.UTDViewerFragment.5
                                @Override // com.google.common.base.Predicate
                                /* renamed from: a */
                                public boolean apply(Bundle bundle) {
                                    return bundle.getString("Name").equals("utdpathways.db");
                                }
                            }));
                            if (arrayList2.size() == 0) {
                                CompressHelper.m4921e2(m44716w(), "You must install Uptodate Pathways Database", 1);
                                return true;
                            }
                            Bundle bundle = (Bundle) arrayList2.get(0);
                            CompressHelper compressHelper = this.f75863p4;
                            ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select * from docs where path = '" + ("base/" + string2 + ".html") + "'");
                            if (m4955V != null && m4955V.size() != 0) {
                                this.f75863p4.m4883q1(bundle, m4955V.get(0).getString("id"), null, "");
                            }
                            CompressHelper.m4921e2(m44716w(), "Sorry, Document not available", 1);
                        } else {
                            try {
                                try {
                                    str5 = jSONObject.getJSONObject(HTML.Tag.f65854D).getString(HTML.Tag.f65890V);
                                } catch (Exception unused4) {
                                    str5 = null;
                                }
                            } catch (Exception unused5) {
                                str5 = jSONObject.getJSONArray("data").getJSONObject(0).getString(HTML.Tag.f65890V);
                            }
                            if (this.f75788D4.equals(string2)) {
                                mo4144C3(str5);
                                return true;
                            }
                            iMDLogger.m3290j("Activity Type", m44716w().getClass().toString());
                            this.f75863p4.m4883q1(this.f75850c4, "Topic-" + string2, null, str5);
                        }
                    } else if (string.equals("external")) {
                        mo4139H2(new Intent("android.intent.action.VIEW", Uri.parse(StringUtils.splitByWholeSeparator(this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(URLDecoder.decode(jSONObject.getJSONArray("data").getJSONObject(0).getString("url")), "?target_url=")), "&token=")[0])));
                    }
                } catch (Exception unused6) {
                }
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new UTDViewerFragment(), bundle);
    }
}
