package net.imedicaldoctor.imd.Fragments.Uptodate;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity;
import net.imedicaldoctor.imd.iMDLogger;

/* loaded from: classes2.dex */
public class UTDMenuFragment extends DialogFragment {
    /* renamed from: j3 */
    private static String m4183j3(Context context, String str) throws Exception {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(context.getAssets().open(str), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine == null) {
                bufferedReader.close();
                return sb.toString();
            }
            sb.append(readLine + "\n");
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87194fragment_utdmenu, (ViewGroup) null);
        WebView webView = (WebView) inflate.findViewById(C4804R.C4808id.f87083webview);
        try {
            String string = m44859B().getString(HTML.Tag.f65946y);
            String m4183j3 = m4183j3(m44716w(), "UTDHeader.css");
            String m4183j32 = m4183j3(m44716w(), "UTDFooter.css");
            webView.setWebViewClient(new WebViewClient() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDMenuFragment.1
                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView webView2, String str) {
                    iMDLogger.m3290j("MenuFragment", str);
                    ((UTDViewerActivity.UTDViewerFragment) UTDMenuFragment.this.m44753k0()).m4163I4(str);
                    UTDMenuFragment.this.mo27003Q2();
                    return true;
                }
            });
            webView.getSettings().setAllowFileAccess(true);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.loadDataWithBaseURL("file:///android_asset/", m4183j3.replace("[size]", "200").replace("[Title]", m44859B().getString("title")) + string + m4183j32, "text/html", "utf-8", null);
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            iMDLogger.m3294f("Error in MenuFragment", e.toString());
        }
        builder.setView(inflate);
        return builder.create();
    }
}
