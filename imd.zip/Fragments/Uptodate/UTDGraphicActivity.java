package net.imedicaldoctor.imd.Fragments.Uptodate;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.appcompat.app.AlertDialog;
import androidx.exifinterface.media.ExifInterface;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;
import org.apache.commons.p024io.IOUtils;

/* loaded from: classes2.dex */
public class UTDGraphicActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class UTDGraphicFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        private ArrayList<Bundle> f75739A4;

        /* renamed from: B4 */
        private float f75740B4;

        /* renamed from: C4 */
        private boolean f75741C4;

        /* renamed from: D4 */
        private String f75742D4;

        /* renamed from: E4 */
        private String f75743E4;

        /* renamed from: F4 */
        private String f75744F4;

        /* renamed from: w4 */
        private String[] f75745w4;

        /* renamed from: x4 */
        private ArrayList<String> f75746x4;

        /* renamed from: y4 */
        private ArrayList<String> f75747y4;

        /* renamed from: z4 */
        private ArrayList<String> f75748z4;

        /* renamed from: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity$UTDGraphicFragment$3 */
        /* loaded from: classes2.dex */
        class RunnableC42713 implements Runnable {
            RunnableC42713() {
            }

            @Override // java.lang.Runnable
            public void run() {
                AlertDialog.Builder mo26278s;
                DialogInterface.OnClickListener onClickListener;
                String str = UTDGraphicFragment.this.f75837P3;
                if (str == null || str.length() <= 0) {
                    UTDGraphicFragment uTDGraphicFragment = UTDGraphicFragment.this;
                    uTDGraphicFragment.f75853f4.loadDataWithBaseURL("file:///android_asset/", uTDGraphicFragment.f75847Z3, "text/html", "utf-8", null);
                    UTDGraphicFragment.this.m4092j4();
                    UTDGraphicFragment.this.m4098g4();
                    UTDGraphicFragment.this.m4100f3(C4804R.C4811menu.f87395menu_utdgraphic);
                    UTDGraphicFragment.this.m44735q2(false);
                    UTDGraphicFragment.this.m4140G3();
                    return;
                }
                if (UTDGraphicFragment.this.f75837P3.equals(IcyHeaders.f35463C2)) {
                    mo26278s = new AlertDialog.Builder(UTDGraphicFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("The database is corrupt . it may happen after delta update or as a result of bad installation or a cleaner app in your device . you must delete and redownload this database. what do you want to do ?").mo26284p("Delete", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.3
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            new AlertDialog.Builder(UTDGraphicFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Are you sure ? this will delete uptodate database ...").mo26266y("Yes", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.3.2
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                    UTDGraphicFragment.this.m4125R2(new File(UTDGraphicFragment.this.f75850c4.getString("Path")));
                                    LocalBroadcastManager.m43863b(UTDGraphicFragment.this.m44716w()).m43861d(new Intent("reload"));
                                    UTDGraphicFragment.this.f75863p4.m4989J1(false);
                                    UTDGraphicFragment.this.f75863p4.m4989J1(true);
                                }
                            }).mo26284p("No", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.3.1
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                }
                            }).m52864I();
                        }
                    }).mo26278s("More Info", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.2
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            UTDGraphicFragment.this.m4123T3("http://imedicaldoctor.net/faq#null");
                            UTDGraphicFragment.this.f75863p4.m4998G1(false);
                        }
                    });
                    onClickListener = new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    };
                } else if (!UTDGraphicFragment.this.f75837P3.equals(ExifInterface.f14403S4)) {
                    UTDGraphicFragment uTDGraphicFragment2 = UTDGraphicFragment.this;
                    uTDGraphicFragment2.m4078s4(uTDGraphicFragment2.f75837P3);
                    return;
                } else {
                    mo26278s = new AlertDialog.Builder(UTDGraphicFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Document can't be found . if this happens a lot your database is corrupted . it may happen after delta update . you must delete and redownload this database. what do you want to do ?").mo26284p("Delete", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.6
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            new AlertDialog.Builder(UTDGraphicFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Are you sure ? this will delete uptodate database ...").mo26266y("Yes", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.6.2
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                    UTDGraphicFragment.this.m4125R2(new File(UTDGraphicFragment.this.f75850c4.getString("Path")));
                                    LocalBroadcastManager.m43863b(UTDGraphicFragment.this.m44716w()).m43861d(new Intent("reload"));
                                    UTDGraphicFragment.this.f75863p4.m4989J1(true);
                                    UTDGraphicFragment.this.f75863p4.m4989J1(false);
                                }
                            }).mo26284p("No", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.6.1
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface2, int i2) {
                                }
                            }).m52864I();
                        }
                    }).mo26278s("More Info", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.5
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                            UTDGraphicFragment.this.m4123T3("http://imedicaldoctor.net/faq#null");
                            UTDGraphicFragment.this.f75863p4.m4998G1(false);
                        }
                    });
                    onClickListener = new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.3.4
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    };
                }
                mo26278s.mo26266y("OK", onClickListener).m52864I();
            }
        }

        /* renamed from: M4 */
        public static void m4191M4(String str, Context context) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("datetaken", Long.valueOf(System.currentTimeMillis()));
            contentValues.put("mime_type", MimeTypes.f40519G0);
            contentValues.put("_data", str);
            context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        }

        /* renamed from: N4 */
        public static void m4190N4(String str, Context context) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("datetaken", Long.valueOf(System.currentTimeMillis()));
            contentValues.put("mime_type", MimeTypes.f40551f);
            contentValues.put("_data", str);
            context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        }

        /* renamed from: P4 */
        private void m4188P4(String str) {
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", str);
            bundle.putString("isVideo", IcyHeaders.f35463C2);
            ArrayList arrayList = new ArrayList();
            arrayList.add(bundle);
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", arrayList);
            intent.putExtra("Start", 0);
            mo4139H2(intent);
        }

        /* renamed from: Q4 */
        private void m4187Q4(String str) {
            ArrayList<Bundle> arrayList = this.f75739A4;
            if (arrayList == null || arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
                return;
            }
            int i = 0;
            for (int i2 = 0; i2 < this.f75739A4.size(); i2++) {
                if (this.f75739A4.get(i2).getString("name").equals(str)) {
                    i = i2;
                }
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", this.f75739A4);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* renamed from: O4 */
        public void m4189O4(String str) {
            CompressHelper compressHelper = new CompressHelper(m44716w());
            Bundle bundle = this.f75850c4;
            compressHelper.m4883q1(bundle, "Topic-" + str, null, null);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            try {
                ArrayList<String> arrayList = this.f75747y4;
                if (arrayList != null && arrayList.size() != 0) {
                    int nextInt = new Random().nextInt(this.f75747y4.size());
                    if (this.f75747y4.size() - 1 < 0) {
                        return null;
                    }
                    String str = this.f75747y4.get(nextInt);
                    String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "background.png");
                    File file = new File(m4945Y0);
                    if (file.exists()) {
                        file.delete();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    IOUtils.write(Base64.decode(str, 0), fileOutputStream);
                    fileOutputStream.close();
                    return m4945Y0;
                }
                return null;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                return null;
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87395menu_utdgraphic, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            this.f75739A4 = new ArrayList<>();
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            this.f75849b4 = inflate;
            m4094i4(inflate, bundle);
            this.f75866s4 = new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    CompressHelper.m4921e2(UTDGraphicFragment.this.m44716w(), "Download Completed", 1);
                    try {
                        if (new File(UTDGraphicFragment.this.f75744F4).exists()) {
                            byte[] readFileToByteArray = FileUtils.readFileToByteArray(new File(UTDGraphicFragment.this.f75744F4));
                            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(UTDGraphicFragment.this.f75743E4, "/");
                            FileUtils.writeByteArrayToFile(new File(UTDGraphicFragment.this.f75743E4), UTDGraphicFragment.this.f75863p4.m4864x(readFileToByteArray, splitByWholeSeparator[splitByWholeSeparator.length - 1], "127"));
                            new File(UTDGraphicFragment.this.f75743E4).deleteOnExit();
                            UTDGraphicFragment.this.f75741C4 = true;
                            UTDGraphicFragment uTDGraphicFragment = UTDGraphicFragment.this;
                            uTDGraphicFragment.f75742D4 = uTDGraphicFragment.f75743E4;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    UTDGraphicFragment.this.m4141F3();
                }
            };
            if (m44859B() == null) {
                return this.f75849b4;
            }
            if (bundle != null) {
                this.f75747y4 = bundle.getStringArrayList("mBase64Images");
                this.f75748z4 = bundle.getStringArrayList("mBase64ImageNames");
                this.f75746x4 = bundle.getStringArrayList("mRelatedTopics");
                this.f75741C4 = bundle.getBoolean("mIsVideo");
                this.f75742D4 = bundle.getString("mVideoPath");
                this.f75743E4 = bundle.getString("mVideoSavePath");
            }
            String[] stringArray = m44859B().getStringArray("IDS");
            this.f75745w4 = stringArray;
            String join = TextUtils.join(";", stringArray);
            this.f75851d4 = "Graphic-" + join;
            m4105c3();
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.2
                /* JADX WARN: Removed duplicated region for block: B:125:0x03e9  */
                /* JADX WARN: Removed duplicated region for block: B:126:0x03ec A[Catch: Exception -> 0x0412, TRY_LEAVE, TryCatch #9 {Exception -> 0x0412, blocks: (B:123:0x03e3, B:126:0x03ec), top: B:191:0x03e3 }] */
                /* JADX WARN: Removed duplicated region for block: B:193:0x01cd A[EXC_TOP_SPLITTER, SYNTHETIC] */
                /* JADX WARN: Removed duplicated region for block: B:201:0x0225 A[EXC_TOP_SPLITTER, SYNTHETIC] */
                /* JADX WARN: Removed duplicated region for block: B:219:0x0162 A[SYNTHETIC] */
                /* JADX WARN: Removed duplicated region for block: B:64:0x0202  */
                /* JADX WARN: Removed duplicated region for block: B:95:0x02e6  */
                @Override // java.lang.Runnable
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                public void run() {
                    /*
                        Method dump skipped, instructions count: 1378
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity.UTDGraphicFragment.RunnableC42702.run():void");
                }
            }, new RunnableC42713());
            return this.f75849b4;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86788action_save_gallery) {
                if (this.f75741C4) {
                    new File(this.f75742D4);
                    try {
                        FileUtils.copyFile(new File(this.f75742D4), new File(this.f75743E4));
                    } catch (IOException e) {
                        String cls = getClass().toString();
                        iMDLogger.m3294f(cls, "Error in copying " + this.f75742D4 + " to " + this.f75743E4);
                        e.printStackTrace();
                    }
                    MediaScannerConnection.scanFile(m44716w(), new String[]{this.f75743E4}, null, null);
                    m4190N4(this.f75743E4, m44716w());
                } else {
                    for (int i = 0; i < this.f75747y4.size(); i++) {
                        String str = this.f75747y4.get(i);
                        String[] split = this.f75748z4.get(i).split("/");
                        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, split[split.length - 1]);
                        try {
                            FileOutputStream fileOutputStream = new FileOutputStream(m4945Y0);
                            IOUtils.write(Base64.decode(str, 0), fileOutputStream);
                            fileOutputStream.close();
                        } catch (IOException e2) {
                            String cls2 = getClass().toString();
                            iMDLogger.m3294f(cls2, "Error in writing to " + m4945Y0);
                            e2.printStackTrace();
                        }
                        MediaScannerConnection.scanFile(m44716w(), new String[]{m4945Y0}, null, null);
                        m4191M4(m4945Y0, m44716w());
                    }
                }
            }
            if (itemId == C4804R.C4808id.f86785action_related_topics) {
                String join = TextUtils.join(",", this.f75746x4);
                UTDRelatedTopics2Fragment uTDRelatedTopics2Fragment = new UTDRelatedTopics2Fragment();
                Bundle bundle = new Bundle();
                bundle.putString("RELATED", join);
                bundle.putBundle("db", this.f75850c4);
                uTDRelatedTopics2Fragment.m44751k2(bundle);
                uTDRelatedTopics2Fragment.m44844E2(this, 0);
                uTDRelatedTopics2Fragment.mo29915h3(m44820L(), "related");
                return true;
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            MenuItem findItem = menu.findItem(C4804R.C4808id.f86785action_related_topics);
            if (this.f75746x4.size() == 0) {
                findItem.setVisible(false);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            iMDLogger.m3290j("URL Requested", str);
            Uri.parse(str);
            if (str2.equals("image")) {
                m4187Q4(str3.substring(2));
                return true;
            }
            if (str2.equals("video")) {
                if (this.f75742D4.equals("")) {
                    String[] split = StringUtils.split(this.f75743E4, "/");
                    String str4 = split[split.length - 1];
                    m4111Z2(this.f75863p4.m4991J() + "/videos-E/" + str4, this.f75850c4.getString("Path") + "/videos-E/" + str4);
                } else {
                    iMDLogger.m3294f("Video Path ", this.f75742D4);
                    m4188P4(this.f75742D4);
                }
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new UTDGraphicFragment(), bundle);
    }
}
