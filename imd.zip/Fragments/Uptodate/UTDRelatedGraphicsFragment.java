package net.imedicaldoctor.imd.Fragments.Uptodate;

import android.app.Dialog;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class UTDRelatedGraphicsFragment extends DialogFragment {
    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87195fragment_utdrelated_graphics, (ViewGroup) null);
        ExpandableListView expandableListView = (ExpandableListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        try {
            final JSONArray jSONArray = new JSONArray(m44859B().getString("RELATED"));
            expandableListView.setAdapter(new ExpandableListAdapter() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDRelatedGraphicsFragment.1
                @Override // android.widget.ExpandableListAdapter
                public boolean areAllItemsEnabled() {
                    return true;
                }

                @Override // android.widget.ExpandableListAdapter
                public Object getChild(int i, int i2) {
                    try {
                        return jSONArray.getJSONObject(i).getJSONArray("graphics").getJSONObject(i2);
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        String cls = getClass().toString();
                        iMDLogger.m3294f(cls, "Error in getChild : " + e.toString());
                        return null;
                    }
                }

                @Override // android.widget.ExpandableListAdapter
                public long getChildId(int i, int i2) {
                    return (i * 1000) + i2;
                }

                @Override // android.widget.ExpandableListAdapter
                public View getChildView(int i, int i2, boolean z, View view, ViewGroup viewGroup) {
                    View inflate2 = LayoutInflater.from(UTDRelatedGraphicsFragment.this.m44716w()).inflate(C4804R.C4810layout.f87255list_view_item_related_graphic, viewGroup, false);
                    try {
                        ((TextView) inflate2.findViewById(C4804R.C4808id.f87060title_text)).setText(((JSONObject) getChild(i, i2)).getJSONObject("graphicInfo").getString("displayName"));
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        String cls = getClass().toString();
                        iMDLogger.m3294f(cls, "Error in getChildView Title : " + e.toString());
                    }
                    return inflate2;
                }

                @Override // android.widget.ExpandableListAdapter
                public int getChildrenCount(int i) {
                    try {
                        return jSONArray.getJSONObject(i).getJSONArray("graphics").length();
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        String cls = getClass().toString();
                        iMDLogger.m3294f(cls, "Error in getting ChildrenCount from json : " + e.toString());
                        return 0;
                    }
                }

                @Override // android.widget.ExpandableListAdapter
                public long getCombinedChildId(long j, long j2) {
                    return 0L;
                }

                @Override // android.widget.ExpandableListAdapter
                public long getCombinedGroupId(long j) {
                    return 0L;
                }

                @Override // android.widget.ExpandableListAdapter
                public Object getGroup(int i) {
                    try {
                        return jSONArray.getJSONObject(i);
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        String cls = getClass().toString();
                        iMDLogger.m3294f(cls, "Error in getGroup : " + e.toString());
                        return null;
                    }
                }

                @Override // android.widget.ExpandableListAdapter
                public int getGroupCount() {
                    return jSONArray.length();
                }

                @Override // android.widget.ExpandableListAdapter
                public long getGroupId(int i) {
                    return i;
                }

                @Override // android.widget.ExpandableListAdapter
                public View getGroupView(int i, boolean z, View view, ViewGroup viewGroup) {
                    View inflate2 = LayoutInflater.from(UTDRelatedGraphicsFragment.this.m44716w()).inflate(C4804R.C4810layout.f87256list_view_item_related_graphic_header, viewGroup, false);
                    try {
                        ((TextView) inflate2.findViewById(C4804R.C4808id.f87060title_text)).setText(((JSONObject) getGroup(i)).getString("headingTitle"));
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        String cls = getClass().toString();
                        iMDLogger.m3294f(cls, "Error in getGroupView Title : " + e.toString());
                    }
                    return inflate2;
                }

                @Override // android.widget.ExpandableListAdapter
                public boolean hasStableIds() {
                    return true;
                }

                @Override // android.widget.ExpandableListAdapter
                public boolean isChildSelectable(int i, int i2) {
                    return true;
                }

                @Override // android.widget.ExpandableListAdapter
                public boolean isEmpty() {
                    return false;
                }

                @Override // android.widget.ExpandableListAdapter
                public void onGroupCollapsed(int i) {
                }

                @Override // android.widget.ExpandableListAdapter
                public void onGroupExpanded(int i) {
                }

                @Override // android.widget.ExpandableListAdapter
                public void registerDataSetObserver(DataSetObserver dataSetObserver) {
                }

                @Override // android.widget.ExpandableListAdapter
                public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
                }
            });
            expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDRelatedGraphicsFragment.2
                @Override // android.widget.ExpandableListView.OnChildClickListener
                public boolean onChildClick(ExpandableListView expandableListView2, View view, int i, int i2, long j) {
                    try {
                        JSONObject jSONObject = (JSONObject) expandableListView2.getExpandableListAdapter().getChild(i, i2);
                        String cls = getClass().toString();
                        iMDLogger.m3290j(cls, "graph clicked " + jSONObject);
                        ((UTDViewerActivity.UTDViewerFragment) UTDRelatedGraphicsFragment.this.m44753k0()).m4165G4(jSONObject.getJSONObject("graphicInfo").getString("id"));
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        String cls2 = getClass().toString();
                        iMDLogger.m3294f(cls2, "Error in onChildClick : " + e.toString());
                    }
                    UTDRelatedGraphicsFragment.this.mo27003Q2();
                    return true;
                }
            });
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            iMDLogger.m3294f(getClass().toString(), "Error in parsing related Graphics " + e);
        }
        for (int groupCount = expandableListView.getExpandableListAdapter().getGroupCount(); groupCount >= 0; groupCount--) {
            expandableListView.expandGroup(groupCount, true);
        }
        builder.setView(inflate);
        return builder.create();
    }
}
