package net.imedicaldoctor.imd.Fragments.Uptodate;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Uptodate.UTDGraphicActivity;
import net.imedicaldoctor.imd.iMDLogger;

/* loaded from: classes2.dex */
public class UTDRelatedTopics2Fragment extends DialogFragment {
    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87197fragment_utdrelated_topics2, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        m44716w().setFinishOnTouchOutside(true);
        try {
            String string = m44859B().getString("RELATED");
            CompressHelper compressHelper = new CompressHelper(m44716w());
            Bundle bundle2 = m44859B().getBundle("db");
            listView.setAdapter((ListAdapter) new CursorAdapter(m44716w(), compressHelper.m4912h(compressHelper.m4952W(bundle2, "select topic_id as _id, title from topic where topic_id in (" + string + ")", "unidex.en.sqlite"))) { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDRelatedTopics2Fragment.1
                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: d */
                public void mo3522d(View view, Context context, Cursor cursor) {
                    ((TextView) view.findViewById(C4804R.C4808id.f87060title_text)).setText(cursor.getString(cursor.getColumnIndex("title")));
                }

                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: i */
                public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                    UTDRelatedTopics2Fragment.this.m44716w().getLayoutInflater();
                    return LayoutInflater.from(UTDRelatedTopics2Fragment.this.m44716w()).inflate(C4804R.C4810layout.f87257list_view_item_related_topics, viewGroup, false);
                }
            });
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDRelatedTopics2Fragment.2
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                    iMDLogger.m3290j("relatedTopicsFragment", "clicked : " + mo45341b.getString(mo45341b.getColumnIndex("title")));
                    ((UTDGraphicActivity.UTDGraphicFragment) UTDRelatedTopics2Fragment.this.m44753k0()).m4189O4(mo45341b.getString(mo45341b.getColumnIndex("_id")));
                    UTDRelatedTopics2Fragment.this.mo27003Q2();
                }
            });
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            String cls = getClass().toString();
            iMDLogger.m3294f(cls, "Error in parsing related Topics " + e);
        }
        builder.setView(inflate);
        return builder.create();
    }
}
