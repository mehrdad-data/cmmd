package net.imedicaldoctor.imd.Fragments.Uptodate;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.itextpdf.tool.xml.html.HTML;
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter;
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersDecoration;
import java.io.File;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.VBHelper;
import net.imedicaldoctor.imd.ViewHolders.ChaptersSectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.UTDSearchAdapter;
import net.imedicaldoctor.imd.iMDActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class UTDSearchActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class UTDSearchFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        public AsyncTask f75771b4;

        /* renamed from: c4 */
        public TabLayout f75772c4;

        /* renamed from: d4 */
        public UTDSearchAdapter f75773d4;

        /* renamed from: e4 */
        private StickyRecyclerHeadersDecoration f75774e4;

        /* renamed from: q3 */
        private boolean m4176q3() {
            return new File(CompressHelper.m4945Y0(this.f75212I3, "unidex.en.sqlite")).exists();
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4334U2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            ArrayList<Bundle> m4952W;
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87198fragment_utdsearch, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4334U2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            this.f75772c4 = (TabLayout) this.f75221R3.findViewById(C4804R.C4808id.f87042tabs);
            if (m4176q3()) {
                this.f75772c4.setVisibility(0);
            } else {
                this.f75772c4.setVisibility(8);
            }
            this.f75772c4.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.1
                @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                /* renamed from: a */
                public void mo4174a(TabLayout.Tab tab) {
                }

                @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                /* renamed from: b */
                public void mo4173b(TabLayout.Tab tab) {
                    if (UTDSearchFragment.this.f75223T3.getQuery().length() > 0) {
                        SearchView searchView = UTDSearchFragment.this.f75223T3;
                        searchView.m51655i0(searchView.getQuery(), true);
                    }
                }

                @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                /* renamed from: c */
                public void mo4172c(TabLayout.Tab tab) {
                }
            });
            String[] strArr = {"All", "Adult", "Pediatric", "Patient"};
            for (int i = 0; i < 4; i++) {
                TabLayout.Tab m24950D = this.f75772c4.m24950D();
                m24950D.m24890D(strArr[i]);
                this.f75772c4.m24926e(m24950D);
            }
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            if (m44859B().containsKey("Parent")) {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.2
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
                String string = m44859B().getString("Parent");
                if (string.equals("99999")) {
                    m4952W = this.f75215L3.m4952W(this.f75212I3, "SELECT Text as title,URL as id,1 as leaf ,'Video Index' as section  FROM search where search.'table' match 'movie'", "fsearch.db");
                } else {
                    CompressHelper compressHelper = this.f75215L3;
                    Bundle bundle2 = this.f75212I3;
                    m4952W = compressHelper.m4952W(bundle2, "SELECT * FROM toc where parentId=" + string, "utdtoc.db");
                }
            } else {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
                m4952W = this.f75215L3.m4952W(this.f75212I3, "select 99999 as id, 'Video Index' as title, 0 as parentId, 0 as leaf,'' as section union SELECT * FROM toc where parentId=0", "utdtoc.db");
            }
            this.f75218O3 = m4952W;
            ArrayList<Bundle> arrayList = new ArrayList<>();
            ((TextView) this.f75221R3.findViewById(C4804R.C4808id.f87065toolbar_subtext_view)).setText(m4177p3());
            if (this.f75218O3 == null) {
                this.f75218O3 = new ArrayList<>();
                new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("The database is corrupt as the result of low disk space, corrupted download or cleaner apps. please delete uptodate database and download it again from the downloads page").mo26284p("Delete", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.4
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        new AlertDialog.Builder(UTDSearchFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Are you sure ?").mo26266y("Yes", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.4.2
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(DialogInterface dialogInterface2, int i3) {
                                UTDSearchFragment.this.m4181l3(new File(UTDSearchFragment.this.f75212I3.getString("Path")));
                                LocalBroadcastManager.m43863b(UTDSearchFragment.this.m44716w()).m43861d(new Intent("reload"));
                                UTDSearchFragment.this.f75215L3.m4989J1(false);
                                UTDSearchFragment.this.f75215L3.m4989J1(true);
                            }
                        }).mo26284p("No", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.4.1
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(DialogInterface dialogInterface2, int i3) {
                            }
                        }).m52864I();
                    }
                }).mo26278s("More Info", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        UTDSearchFragment.this.m4175r3("http://imedicaldoctor.net/faq#null");
                        UTDSearchFragment.this.f75215L3.m4998G1(false);
                    }
                }).m52864I();
            }
            Iterator<Bundle> it2 = this.f75218O3.iterator();
            while (it2.hasNext()) {
                Bundle next = it2.next();
                if (next.getString(HTML.Tag.f65890V).equals("")) {
                    next.remove(HTML.Tag.f65890V);
                    next.putString(HTML.Tag.f65890V, "Table of Contents");
                }
                arrayList.add(next);
            }
            this.f75215L3.m4941Z1(arrayList, HTML.Tag.f65890V);
            this.f75216M3 = new ChaptersSectionAdapter(m44716w(), this.f75218O3, "title", HTML.Tag.f65890V) { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.5
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersSectionAdapter
                /* renamed from: f0 */
                public void mo3400f0(Bundle bundle3, int i2) {
                    CompressHelper compressHelper2;
                    Bundle bundle4;
                    StringBuilder sb;
                    String str;
                    UTDSearchFragment.this.m4330Y2();
                    if (!bundle3.getString("leaf").equals(IcyHeaders.f35463C2)) {
                        Bundle bundle5 = new Bundle();
                        bundle5.putBundle("DB", UTDSearchFragment.this.f75212I3);
                        bundle5.putString("Parent", bundle3.getString("id"));
                        UTDSearchFragment.this.f75215L3.m4979N(UTDSearchActivity.class, UTDSearchFragment.class, bundle5);
                    } else if (bundle3.getString("id").contains("Graphic-")) {
                        new CompressHelper(UTDSearchFragment.this.m44716w()).m4883q1(UTDSearchFragment.this.f75212I3, bundle3.getString("id"), null, null);
                    } else {
                        String string2 = bundle3.getString("title");
                        UTDSearchFragment uTDSearchFragment = UTDSearchFragment.this;
                        CompressHelper compressHelper3 = uTDSearchFragment.f75215L3;
                        Bundle bundle6 = uTDSearchFragment.f75212I3;
                        Bundle m4907i1 = compressHelper3.m4907i1(compressHelper3.m4952W(bundle6, "Select * from tocmap where tocId=" + bundle3.getString("id"), "utdtoc.db"));
                        if (m4907i1 != null) {
                            compressHelper2 = new CompressHelper(UTDSearchFragment.this.m44716w());
                            bundle4 = UTDSearchFragment.this.f75212I3;
                            sb = new StringBuilder();
                            sb.append("Topic-");
                            str = "topicId";
                        } else {
                            UTDSearchFragment uTDSearchFragment2 = UTDSearchFragment.this;
                            CompressHelper compressHelper4 = uTDSearchFragment2.f75215L3;
                            Bundle bundle7 = uTDSearchFragment2.f75212I3;
                            m4907i1 = compressHelper4.m4907i1(compressHelper4.m4952W(bundle7, "Select * from topic where title='" + string2.replace("'", "''") + "'", "unidex.en.sqlite"));
                            if (m4907i1 == null) {
                                CompressHelper.m4921e2(UTDSearchFragment.this.m44716w(), "Sorry, Can't find it. use search to find similar topics", 1);
                                return;
                            }
                            compressHelper2 = new CompressHelper(UTDSearchFragment.this.m44716w());
                            bundle4 = UTDSearchFragment.this.f75212I3;
                            sb = new StringBuilder();
                            sb.append("Topic-");
                            str = "topic_id";
                        }
                        sb.append(m4907i1.getString(str));
                        compressHelper2.m4883q1(bundle4, sb.toString(), null, null);
                    }
                }
            };
            this.f75773d4 = new UTDSearchAdapter(m44716w(), this.f75219P3, "title", null) { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.6
                @Override // net.imedicaldoctor.imd.ViewHolders.UTDSearchAdapter
                /* renamed from: d0 */
                public void mo3361d0(Bundle bundle3, int i2) {
                    UTDSearchFragment.this.m4330Y2();
                    String string2 = bundle3.getString("_id");
                    CompressHelper compressHelper2 = new CompressHelper(UTDSearchFragment.this.m44716w());
                    Bundle bundle4 = UTDSearchFragment.this.f75212I3;
                    compressHelper2.m4883q1(bundle4, "Topic-" + string2, null, null);
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            StickyRecyclerHeadersDecoration stickyRecyclerHeadersDecoration = new StickyRecyclerHeadersDecoration((StickyRecyclerHeadersAdapter) this.f75216M3);
            this.f75774e4 = stickyRecyclerHeadersDecoration;
            this.f75227X3.m42923n(stickyRecyclerHeadersDecoration);
            this.f75227X3.setLayoutManager(new LinearLayoutManager(m44716w()));
            this.f75227X3.setItemAnimator(new DefaultItemAnimator());
            this.f75227X3.m42923n(new DividerItemDecoration(m44716w(), 1));
            this.f75216M3.m42849Z(new RecyclerView.AdapterDataObserver() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.7
                @Override // androidx.recyclerview.widget.RecyclerView.AdapterDataObserver
                /* renamed from: a */
                public void mo3511a() {
                    UTDSearchFragment.this.f75774e4.m8633n();
                }
            });
            m44735q2(true);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: a3 */
        public void mo3982a3() {
            this.f75773d4.m3360e0(this.f75219P3);
            this.f75227X3.setAdapter(this.f75773d4);
            this.f75774e4.m8633n();
            this.f75227X3.m42906s1(this.f75774e4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: c3 */
        public void mo4182c3() {
            this.f75227X3.m42923n(this.f75774e4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            int parseInt;
            int i = 0;
            if (!m4176q3()) {
                String[] split = str.split(StringUtils.SPACE);
                String str2 = "";
                while (i < split.length) {
                    if (str2.length() == 0) {
                        str2 = "'" + split[i] + "'";
                    } else {
                        str2 = str2 + " , '" + split[i] + "'";
                    }
                    i++;
                }
                return this.f75215L3.m4952W(this.f75212I3, "select topic.topic_id _id, topic.title, sum( prof  ) * count( * ) * min(count(*),2)  weight , count(*) c from kw2topic_xref, topic, kw where kw.pk =kw2topic_xref.kw_fk and topic.topic_id =kw2topic_xref.topic_id and kw in (" + str2 + ") group by topic.topic_id, topic.title order by weight desc, c desc, topic.title asc limit 50", "utdkw.sqlite");
            }
            ArrayList<Bundle> m4952W = this.f75215L3.m4952W(this.f75212I3, "SELECT q.qbtype, x.topic_hits hits FROM query q, query_topic x WHERE q.disp = '" + str + "'  AND x.nqid = q.nqid AND x.pref = '" + m4178o3() + "'", "unidex.en.sqlite");
            if (m4952W == null || m4952W.size() == 0) {
                return null;
            }
            String m3428e = new VBHelper(m44716w()).m3428e(m4952W.get(0).getByteArray("hits"));
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int i2 = 4;
            while (i2 < m3428e.length()) {
                int i3 = i2 + 8;
                arrayList.add(String.valueOf(Integer.parseInt(m3428e.substring(i2, i3), 16)));
                arrayList2.add("WHEN " + String.valueOf(parseInt) + " THEN " + i);
                i++;
                i2 = i3;
            }
            String str3 = "order by case topic_id " + TextUtils.join(StringUtils.SPACE, arrayList2) + " end";
            return this.f75215L3.m4952W(this.f75212I3, "SELECT topic_id as _id, title FROM topic WHERE topic_id IN (" + TextUtils.join(",", arrayList) + ") " + str3, "unidex.en.sqlite");
        }

        /* JADX WARN: Removed duplicated region for block: B:16:0x006b  */
        /* JADX WARN: Removed duplicated region for block: B:17:0x007a  */
        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public java.util.ArrayList<android.os.Bundle> mo3980j3(java.lang.String r4) {
            /*
                r3 = this;
                int r0 = r4.length()
                r1 = 1
                java.lang.String r2 = "'"
                if (r0 != r1) goto L1e
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "q1='"
            L10:
                r0.append(r1)
                r0.append(r4)
                r0.append(r2)
            L19:
                java.lang.String r0 = r0.toString()
                goto L4f
            L1e:
                int r0 = r4.length()
                r1 = 2
                if (r0 != r1) goto L2d
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "q2='"
                goto L10
            L2d:
                int r0 = r4.length()
                r1 = 3
                if (r0 != r1) goto L3c
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "q3='"
                goto L10
            L3c:
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "q like '"
                r0.append(r1)
                r0.append(r4)
                java.lang.String r1 = "%'"
                r0.append(r1)
                goto L19
            L4f:
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                r1.<init>()
                java.lang.String r2 = "select q _id, u as word, case c when 0 then '' else 'c' || c || ' ' end || case c2 when 0 then '' else ' c_' || c2 || ' ' end u2, p, f from qf where "
                r1.append(r2)
                r1.append(r0)
                java.lang.String r0 = " order by f desc, q asc limit 30"
                r1.append(r0)
                java.lang.String r0 = r1.toString()
                boolean r1 = r3.m4176q3()
                if (r1 == 0) goto L7a
                java.lang.String r4 = r3.m4180m3(r4)
                net.imedicaldoctor.imd.Data.CompressHelper r0 = r3.f75215L3
                android.os.Bundle r1 = r3.f75212I3
                java.lang.String r2 = "unidex.en.sqlite"
                java.util.ArrayList r4 = r0.m4952W(r1, r4, r2)
                goto L84
            L7a:
                net.imedicaldoctor.imd.Data.CompressHelper r4 = r3.f75215L3
                android.os.Bundle r1 = r3.f75212I3
                java.lang.String r2 = "utdqf.sqlite"
                java.util.ArrayList r4 = r4.m4952W(r1, r0, r2)
            L84:
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Uptodate.UTDSearchActivity.UTDSearchFragment.mo3980j3(java.lang.String):java.util.ArrayList");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: l1 */
        public void mo3541l1() {
            super.mo3541l1();
            m4330Y2();
        }

        /* renamed from: l3 */
        public void m4181l3(File file) {
            if (file.isDirectory()) {
                for (File file2 : file.listFiles()) {
                    m4181l3(file2);
                }
            }
            file.delete();
        }

        /* renamed from: m3 */
        public String m4180m3(String str) {
            StringBuilder sb;
            String str2;
            String replace = str.replace("'", "''");
            if (replace.length() == 1) {
                sb = new StringBuilder();
                str2 = "d1 = '";
            } else if (replace.length() == 2) {
                sb = new StringBuilder();
                str2 = "d2 = '";
            } else if (replace.length() != 3) {
                sb = new StringBuilder();
                sb.append("disp like '");
                sb.append(replace);
                sb.append("%'");
                String str3 = "SELECT rowid _id,disp as word, IFNULL(engl, disp) AS useq, weight, qbtype, trprov FROM query WHERE hide IS NULL AND " + sb.toString() + " ORDER BY weight DESC, disp ASC LIMIT 30";
                iMDLogger.m3294f("Query:", str3);
                return str3;
            } else {
                sb = new StringBuilder();
                str2 = "d3 = '";
            }
            sb.append(str2);
            sb.append(replace);
            sb.append("'");
            String str32 = "SELECT rowid _id,disp as word, IFNULL(engl, disp) AS useq, weight, qbtype, trprov FROM query WHERE hide IS NULL AND " + sb.toString() + " ORDER BY weight DESC, disp ASC LIMIT 30";
            iMDLogger.m3294f("Query:", str32);
            return str32;
        }

        /* renamed from: o3 */
        public String m4178o3() {
            int selectedTabPosition = this.f75772c4.getSelectedTabPosition();
            return selectedTabPosition == 0 ? "X" : selectedTabPosition == 1 ? ExifInterface.f14387Q4 : selectedTabPosition == 2 ? "P" : selectedTabPosition == 3 ? "I" : "X";
        }

        /* renamed from: p3 */
        public String m4177p3() {
            return new SimpleDateFormat("d MMM yyyy").format(new SimpleDateFormat("yyyyMMdd").parse(this.f75212I3.getString("Version"), new ParsePosition(0)));
        }

        /* renamed from: r3 */
        public void m4175r3(String str) {
            mo4139H2(new Intent("android.intent.action.VIEW", Uri.parse(str)));
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87115activity_utdsearch);
        if (bundle == null) {
            UTDSearchFragment uTDSearchFragment = new UTDSearchFragment();
            uTDSearchFragment.m44751k2(getIntent().getExtras());
            m44690E().m44464r().m44301b(C4804R.C4808id.container, uTDSearchFragment).mo44289n();
        }
    }
}
