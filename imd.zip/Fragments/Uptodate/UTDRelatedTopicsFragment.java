package net.imedicaldoctor.imd.Fragments.Uptodate;

import android.app.Dialog;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Fragments.Uptodate.UTDViewerActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class UTDRelatedTopicsFragment extends DialogFragment {
    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87196fragment_utdrelated_topics, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        m44716w().setFinishOnTouchOutside(true);
        try {
            final JSONArray jSONArray = new JSONArray(m44859B().getString("RELATED"));
            listView.setAdapter(new ListAdapter() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDRelatedTopicsFragment.1
                @Override // android.widget.ListAdapter
                public boolean areAllItemsEnabled() {
                    return true;
                }

                @Override // android.widget.Adapter
                public int getCount() {
                    return jSONArray.length();
                }

                @Override // android.widget.Adapter
                public Object getItem(int i) {
                    try {
                        return jSONArray.getJSONObject(i);
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        return null;
                    }
                }

                @Override // android.widget.Adapter
                public long getItemId(int i) {
                    return i;
                }

                @Override // android.widget.Adapter
                public int getItemViewType(int i) {
                    return 1;
                }

                @Override // android.widget.Adapter
                public View getView(int i, View view, ViewGroup viewGroup) {
                    UTDRelatedTopicsFragment.this.m44716w().getLayoutInflater();
                    View inflate2 = LayoutInflater.from(UTDRelatedTopicsFragment.this.m44716w()).inflate(C4804R.C4810layout.f87257list_view_item_related_topics, viewGroup, false);
                    try {
                        ((TextView) inflate2.findViewById(C4804R.C4808id.f87060title_text)).setText((UTDRelatedTopicsFragment.this.m44859B().containsKey("CALC") ? ((JSONObject) getItem(i)).getJSONObject("topicInfo") : (JSONObject) getItem(i)).getString("title"));
                    } catch (Exception unused) {
                    }
                    return inflate2;
                }

                @Override // android.widget.Adapter
                public int getViewTypeCount() {
                    return 1;
                }

                @Override // android.widget.Adapter
                public boolean hasStableIds() {
                    return true;
                }

                @Override // android.widget.Adapter
                public boolean isEmpty() {
                    return false;
                }

                @Override // android.widget.ListAdapter
                public boolean isEnabled(int i) {
                    return true;
                }

                @Override // android.widget.Adapter
                public void registerDataSetObserver(DataSetObserver dataSetObserver) {
                }

                @Override // android.widget.Adapter
                public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
                }
            });
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Uptodate.UTDRelatedTopicsFragment.2
                /* JADX WARN: Type inference failed for: r1v1, types: [android.widget.Adapter] */
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    UTDViewerActivity.UTDViewerFragment uTDViewerFragment;
                    String string;
                    JSONObject jSONObject = (JSONObject) adapterView.getAdapter().getItem(i);
                    iMDLogger.m3290j("relatedTopicsFragment", "clicked : " + jSONObject.toString());
                    try {
                        if (UTDRelatedTopicsFragment.this.m44859B().containsKey("CALC")) {
                            uTDViewerFragment = (UTDViewerActivity.UTDViewerFragment) UTDRelatedTopicsFragment.this.m44753k0();
                            string = jSONObject.getJSONObject("topicInfo").getString("id");
                        } else {
                            uTDViewerFragment = (UTDViewerActivity.UTDViewerFragment) UTDRelatedTopicsFragment.this.m44753k0();
                            string = jSONObject.getString("id");
                        }
                        uTDViewerFragment.m4164H4(string);
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        String cls = getClass().toString();
                        iMDLogger.m3294f(cls, "Error in getting id of topic " + e.toString());
                    }
                    UTDRelatedTopicsFragment.this.mo27003Q2();
                }
            });
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            String cls = getClass().toString();
            iMDLogger.m3294f(cls, "Error in parsing related Topics " + e);
        }
        builder.setView(inflate);
        return builder.create();
    }
}
