package net.imedicaldoctor.imd.Fragments.Stockley;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class STViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f75481w4;

    /* renamed from: x4 */
    public ArrayList<String> f75482x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75483y4;

    /* renamed from: y4 */
    private void m4281y4(String str) {
        ArrayList<String> arrayList = this.f75482x4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f75482x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", next);
            bundle.putString("Description", "");
            bundle.putString("id", next);
            if (new File(next).length() > 5000) {
                arrayList2.add(bundle);
            }
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4282x4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f75482x4 = arrayList;
            mo3978f4();
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return m4071w3(this.f75482x4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        this.f75853f4.loadUrl("javascript:onBodyLoad();");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Stockley.STViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    String str = STViewerActivityFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        iMDLogger.m3294f("Loading Document", STViewerActivityFragment.this.f75851d4);
                        STViewerActivityFragment sTViewerActivityFragment = STViewerActivityFragment.this;
                        CompressHelper compressHelper = sTViewerActivityFragment.f75863p4;
                        Bundle bundle2 = sTViewerActivityFragment.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from docs where docName='" + STViewerActivityFragment.this.f75851d4 + "'");
                        if (m4955V != null && m4955V.size() != 0) {
                            STViewerActivityFragment.this.f75481w4 = m4955V.get(0);
                            STViewerActivityFragment sTViewerActivityFragment2 = STViewerActivityFragment.this;
                            sTViewerActivityFragment2.f75852e4 = sTViewerActivityFragment2.f75481w4.getString("title");
                            STViewerActivityFragment sTViewerActivityFragment3 = STViewerActivityFragment.this;
                            String m5015B = sTViewerActivityFragment3.f75863p4.m5015B(sTViewerActivityFragment3.f75481w4.getString("content"), STViewerActivityFragment.this.f75851d4, "127");
                            STViewerActivityFragment sTViewerActivityFragment4 = STViewerActivityFragment.this;
                            String m4117W3 = sTViewerActivityFragment4.m4117W3(sTViewerActivityFragment4.m44716w(), "STHeader.css");
                            STViewerActivityFragment sTViewerActivityFragment5 = STViewerActivityFragment.this;
                            String m4117W32 = sTViewerActivityFragment5.m4117W3(sTViewerActivityFragment5.m44716w(), "STFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", STViewerActivityFragment.this.f75852e4).replace("[include]", "");
                            STViewerActivityFragment sTViewerActivityFragment6 = STViewerActivityFragment.this;
                            sTViewerActivityFragment6.f75847Z3 = replace + m5015B + m4117W32;
                        }
                        STViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                    }
                    STViewerActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    STViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Stockley.STViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = STViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    STViewerActivityFragment sTViewerActivityFragment = STViewerActivityFragment.this;
                    sTViewerActivityFragment.m4078s4(sTViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(STViewerActivityFragment.this.f75850c4.getString("Path") + "/base");
                STViewerActivityFragment sTViewerActivityFragment2 = STViewerActivityFragment.this;
                sTViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", sTViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                STViewerActivityFragment.this.m4092j4();
                STViewerActivityFragment.this.m4098g4();
                STViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                STViewerActivityFragment.this.m44735q2(false);
                STViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86774action_gallery) {
            m4281y4("asdfafdsaf");
            return true;
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86776action_menu);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        String str4;
        if (str2.equals("image")) {
            m4281y4(str3);
            return true;
        }
        if (str2.equals(Annotation.f59806M2)) {
            String str5 = "//" + CompressHelper.m4945Y0(this.f75850c4, "base") + "/";
            if (str3.contains("#")) {
                String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "#");
                String str6 = splitByWholeSeparator[0];
                String str7 = splitByWholeSeparator[1];
                String replace = str6.replace(str5, "").replace(".html", "");
                if (this.f75481w4.getString("docName").toLowerCase().equals(replace.toLowerCase())) {
                    this.f75853f4.loadUrl("javascript:window.location.href = \"#" + str7 + "\"");
                    return true;
                } else if (replace.length() == 0) {
                    this.f75853f4.loadUrl("javascript:window.location.href = \"#" + str7 + "\"");
                    return true;
                } else if (replace.substring(replace.length() - 1).equals("/")) {
                    this.f75853f4.loadUrl("javascript:window.location.href = \"#" + str7 + "\"");
                    return true;
                } else {
                    str4 = str7;
                    str3 = replace;
                }
            } else {
                str4 = "";
            }
            String replace2 = str3.replace(str5, "");
            if (replace2.length() == 0) {
                return true;
            }
            str3 = replace2.toLowerCase();
            CompressHelper compressHelper = this.f75863p4;
            if (compressHelper.m4907i1(compressHelper.m4955V(this.f75850c4, "select * from docs where docName='" + str3 + "'")) == null) {
                CompressHelper.m4921e2(m44716w(), "Sorry, not in this book", 1);
            } else {
                this.f75863p4.m4883q1(this.f75850c4, str3, null, str4);
            }
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public String m4282x4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }
}
