package net.imedicaldoctor.imd.Fragments.UWorld;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.css.CSS;
import com.itextpdf.tool.xml.html.HTML;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.HeaderCellViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;

/* loaded from: classes2.dex */
public class UWTestResultActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public UWTestResultAdapter f75654A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f75655B4;

    /* renamed from: C4 */
    public Bundle f75656C4;

    /* renamed from: D4 */
    public int f75657D4 = 0;

    /* renamed from: E4 */
    public int f75658E4 = 0;

    /* renamed from: F4 */
    public int f75659F4 = 0;

    /* renamed from: G4 */
    public final int f75660G4 = 0;

    /* renamed from: H4 */
    public final int f75661H4 = 1;

    /* renamed from: I4 */
    public final int f75662I4 = 2;

    /* renamed from: J4 */
    public final int f75663J4 = 3;

    /* renamed from: w4 */
    public RecyclerView f75664w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f75665x4;

    /* renamed from: y4 */
    public Bundle f75666y4;

    /* renamed from: z4 */
    public ArrayList<String> f75667z4;

    /* loaded from: classes2.dex */
    public class QuestionViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f75668I;

        /* renamed from: J */
        public TextView f75669J;

        /* renamed from: K */
        public TextView f75670K;

        /* renamed from: L */
        public TextView f75671L;

        /* renamed from: M */
        public ImageView f75672M;

        /* renamed from: N */
        public MaterialRippleLayout f75673N;

        public QuestionViewHolder(View view) {
            super(view);
            this.f75668I = (TextView) view.findViewById(C4804R.C4808id.f87053text_number);
            this.f75669J = (TextView) view.findViewById(C4804R.C4808id.f87057text_title);
            this.f75670K = (TextView) view.findViewById(C4804R.C4808id.f87048text_correct);
            this.f75673N = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            this.f75671L = (TextView) view.findViewById(C4804R.C4808id.f87056text_time);
            this.f75672M = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        }
    }

    /* loaded from: classes2.dex */
    public class TestScoreViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f75675I;

        /* renamed from: J */
        public TextView f75676J;

        /* renamed from: K */
        public TextView f75677K;

        /* renamed from: L */
        public TextView f75678L;

        /* renamed from: M */
        public ImageView f75679M;

        /* renamed from: N */
        public TextView f75680N;

        /* renamed from: O */
        public MaterialRippleLayout f75681O;

        public TestScoreViewHolder(View view) {
            super(view);
            this.f75675I = (TextView) view.findViewById(C4804R.C4808id.f87049text_date);
            this.f75676J = (TextView) view.findViewById(C4804R.C4808id.f87051text_info1);
            this.f75677K = (TextView) view.findViewById(C4804R.C4808id.f87052text_info2);
            this.f75681O = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            this.f75678L = (TextView) view.findViewById(C4804R.C4808id.f87055text_score);
            this.f75679M = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
            this.f75680N = (TextView) view.findViewById(C4804R.C4808id.f87054text_resume);
        }
    }

    /* loaded from: classes2.dex */
    public class UWTestResultAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        public String f75683d;

        public UWTestResultAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            if (i == 0) {
                return 0;
            }
            if (i == 1) {
                return 1;
            }
            return i == UWTestResultActivityFragment.this.f75655B4.size() + 2 ? 3 : 2;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            TextView textView;
            StringBuilder sb;
            ImageView imageView;
            Resources m44782a0;
            int i2;
            String str;
            int m42556F = viewHolder.m42556F();
            if (m42556F == 3) {
                textView = ((HeaderCellViewHolder) viewHolder).f83245I;
                sb = new StringBuilder();
                sb.append(UWTestResultActivityFragment.this.f75657D4);
                sb.append(" Correct . ");
                sb.append(UWTestResultActivityFragment.this.f75658E4);
                sb.append(" Incorrect . ");
                sb.append(UWTestResultActivityFragment.this.f75659F4);
                sb.append(" Omitted");
            } else if (m42556F == 1) {
                textView = ((HeaderCellViewHolder) viewHolder).f83245I;
                str = "Questions";
                textView.setText(str);
            } else if (m42556F == 2) {
                final int i3 = i - 2;
                Bundle bundle = UWTestResultActivityFragment.this.f75655B4.get(i3);
                QuestionViewHolder questionViewHolder = (QuestionViewHolder) viewHolder;
                questionViewHolder.f75668I.setText(String.valueOf(i3 + 1));
                questionViewHolder.f75669J.setText(bundle.getString("title"));
                TextView textView2 = questionViewHolder.f75670K;
                textView2.setText(((int) ((Float.valueOf(bundle.getString("corrTaken")).floatValue() / Float.valueOf(bundle.getString("pplTaken")).floatValue()) * 100.0f)) + CSS.Value.f65657n0);
                TextView textView3 = questionViewHolder.f75671L;
                textView3.setText(bundle.getString(HTML.Tag.f65879P0) + " sec");
                String string = bundle.getString("selectedAnswer");
                String string2 = bundle.getString("corrAnswer");
                if (string.length() == 0) {
                    imageView = questionViewHolder.f75672M;
                    m44782a0 = UWTestResultActivityFragment.this.m44782a0();
                    i2 = C4804R.C4807drawable.f86669omitted_icon;
                } else if (string.equals(string2)) {
                    imageView = questionViewHolder.f75672M;
                    m44782a0 = UWTestResultActivityFragment.this.m44782a0();
                    i2 = C4804R.C4807drawable.f86561correct_icon;
                } else {
                    imageView = questionViewHolder.f75672M;
                    m44782a0 = UWTestResultActivityFragment.this.m44782a0();
                    i2 = C4804R.C4807drawable.f86611incorrect_icon;
                }
                imageView.setImageDrawable(m44782a0.getDrawable(i2));
                questionViewHolder.f75673N.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestResultActivityFragment.UWTestResultAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        Bundle bundle2 = new Bundle();
                        bundle2.putInt("gotoQIndex", i3);
                        UWTestResultActivityFragment uWTestResultActivityFragment = UWTestResultActivityFragment.this;
                        CompressHelper compressHelper = uWTestResultActivityFragment.f75863p4;
                        Bundle bundle3 = uWTestResultActivityFragment.f75850c4;
                        compressHelper.m4880r1(bundle3, "test-" + UWTestResultActivityFragment.this.f75656C4.getString("id"), null, null, bundle2);
                    }
                });
                return;
            } else if (m42556F != 0) {
                return;
            } else {
                TestScoreViewHolder testScoreViewHolder = (TestScoreViewHolder) viewHolder;
                TextView textView4 = testScoreViewHolder.f75675I;
                UWTestResultActivityFragment uWTestResultActivityFragment = UWTestResultActivityFragment.this;
                textView4.setText(uWTestResultActivityFragment.m4230y4(uWTestResultActivityFragment.f75656C4.getString("createdDate")));
                TextView textView5 = testScoreViewHolder.f75676J;
                textView5.setText(UWTestResultActivityFragment.this.f75655B4.size() + " Questions. Mode: " + UWTestResultActivityFragment.this.f75656C4.getString("mode"));
                TextView textView6 = testScoreViewHolder.f75677K;
                textView6.setText(UWTestResultActivityFragment.this.f75656C4.getString("subject") + " , " + UWTestResultActivityFragment.this.f75656C4.getString("system"));
                testScoreViewHolder.f75679M.setImageDrawable(UWTestResultActivityFragment.this.m44782a0().getDrawable(C4804R.C4807drawable.f86555circle_green));
                testScoreViewHolder.f75680N.setText("Score");
                testScoreViewHolder.f75678L.setVisibility(0);
                textView = testScoreViewHolder.f75678L;
                sb = new StringBuilder();
                sb.append(UWTestResultActivityFragment.this.f75656C4.getString(FirebaseAnalytics.Param.f55169D));
                sb.append(CSS.Value.f65657n0);
            }
            str = sb.toString();
            textView.setText(str);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 3) {
                return new HeaderCellViewHolder(LayoutInflater.from(UWTestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87241list_view_item_footer, viewGroup, false));
            }
            if (i == 1) {
                return new HeaderCellViewHolder(LayoutInflater.from(UWTestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false));
            }
            if (i == 2) {
                return new QuestionViewHolder(LayoutInflater.from(UWTestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87301list_view_item_uworld_quetion, viewGroup, false));
            } else if (i == 0) {
                return new TestScoreViewHolder(LayoutInflater.from(UWTestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87302list_view_item_uworld_test, viewGroup, false));
            } else {
                return null;
            }
        }

        /* renamed from: d0 */
        public String m4229d0(String str) {
            return str;
        }

        /* renamed from: e0 */
        public void m4228e0(RecyclerView.ViewHolder viewHolder, Bundle bundle, int i) {
        }

        /* renamed from: f0 */
        public void m4227f0(Bundle bundle, int i) {
        }

        /* renamed from: g0 */
        public RecyclerView.ViewHolder m4226g0(View view) {
            return new RippleTextViewHolder(view);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return UWTestResultActivityFragment.this.f75655B4.size() + 2 + 1;
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f75664w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        String str = this.f75851d4.split("-")[1];
        CompressHelper compressHelper = this.f75863p4;
        this.f75656C4 = compressHelper.m4907i1(compressHelper.m4955V(this.f75850c4, "select * from tests where id=" + str));
        ArrayList<Bundle> m4955V = this.f75863p4.m4955V(this.f75850c4, "Select questions.id,pplTaken,corrTaken,title,selectedAnswer,corrAnswer,time  from Questions left outer join (select * from logs where testId=" + str + ") as logs2 on questions.id=logs2.qid where questions.id in (" + this.f75656C4.getString("qIds") + ")");
        this.f75655B4 = m4955V;
        this.f75852e4 = "Test Result";
        Iterator<Bundle> it2 = m4955V.iterator();
        while (it2.hasNext()) {
            Bundle next = it2.next();
            if (next.getString("selectedAnswer").length() == 0) {
                this.f75659F4++;
            } else if (next.getString("selectedAnswer").equals(next.getString("corrAnswer"))) {
                this.f75657D4++;
            } else {
                this.f75658E4++;
            }
        }
        UWTestResultAdapter uWTestResultAdapter = new UWTestResultAdapter();
        this.f75654A4 = uWTestResultAdapter;
        this.f75664w4.setAdapter(uWTestResultAdapter);
        m4231x4();
        m4100f3(C4804R.C4811menu.f87324empty);
        m44735q2(false);
        m4140G3();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f75665x4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f75665x4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    /* renamed from: x4 */
    public void m4231x4() {
        this.f75664w4.setItemAnimator(new DefaultItemAnimator());
        this.f75664w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f75664w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }

    /* renamed from: y4 */
    public String m4230y4(String str) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ");
        try {
            return new SimpleDateFormat("MM dd,yyyy HH:mm:ss").format(simpleDateFormat.parse(str));
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            return str;
        }
    }
}
