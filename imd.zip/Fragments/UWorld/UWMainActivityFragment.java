package net.imedicaldoctor.imd.Fragments.UWorld;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.timepicker.TimeModel;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import io.requery.android.database.sqlite.SQLiteDatabase;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.HeaderCellViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleSearchContentViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class UWMainActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public ArrayList<String> f75584b4;

    /* renamed from: c4 */
    public ArrayList<Bundle> f75585c4;

    /* renamed from: d4 */
    public ArrayList<Bundle> f75586d4;

    /* renamed from: e4 */
    public ArrayList<Bundle> f75587e4;

    /* renamed from: f4 */
    public ArrayList<Bundle> f75588f4;

    /* renamed from: g4 */
    public ArrayList<Bundle> f75589g4;

    /* renamed from: h4 */
    public ArrayList<Bundle> f75590h4;

    /* renamed from: j4 */
    public String f75592j4;

    /* renamed from: n4 */
    public ArrayList<Integer> f75596n4;

    /* renamed from: o4 */
    public ArrayList<Integer> f75597o4;

    /* renamed from: p4 */
    public ArrayList<Integer> f75598p4;

    /* renamed from: i4 */
    public int f75591i4 = 0;

    /* renamed from: k4 */
    public int f75593k4 = 40;

    /* renamed from: l4 */
    public int f75594l4 = 0;

    /* renamed from: m4 */
    public int f75595m4 = 0;

    /* renamed from: q4 */
    private final String f75599q4 = "Questions";

    /* renamed from: r4 */
    private final String f75600r4 = "Create A Test";

    /* renamed from: s4 */
    private final String f75601s4 = "Previous Tests";

    /* renamed from: t4 */
    private final String f75602t4 = "Settings";

    /* renamed from: u4 */
    private final String f75603u4 = "subject";

    /* renamed from: v4 */
    private final String f75604v4 = "system";

    /* renamed from: w4 */
    private final String f75605w4 = "numberquestion";

    /* renamed from: x4 */
    private final String f75606x4 = "testMode";

    /* renamed from: y4 */
    private final String f75607y4 = "filter";

    /* renamed from: z4 */
    private final String f75608z4 = "hardness";

    /* loaded from: classes2.dex */
    public class AccountTextViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        private TextView f75616I;

        /* renamed from: J */
        private MaterialRippleLayout f75617J;

        public AccountTextViewHolder(View view) {
            super(view);
            this.f75616I = (TextView) view.findViewById(C4804R.C4808id.text);
            this.f75617J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        }
    }

    /* loaded from: classes2.dex */
    public class UWAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        private final int f75619d = 0;

        /* renamed from: e */
        private final int f75620e = 4;

        /* renamed from: f */
        private final int f75621f = 1;

        /* renamed from: g */
        private final int f75622g = 2;

        /* renamed from: h */
        private final int f75623h = 3;

        /* JADX INFO: Access modifiers changed from: package-private */
        /* renamed from: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment$UWAdapter$13 */
        /* loaded from: classes2.dex */
        public class View$OnClickListenerC423413 implements View.OnClickListener {
            View$OnClickListenerC423413() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (UWMainActivityFragment.this.f75592j4.length() > 0) {
                    return;
                }
                new AlertDialog.Builder(UWMainActivityFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("This will backup your test history, favorites and highlights to the iMD Server and will give you a identifier to restore it later.").mo26266y("OK", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.13.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
                        String m4878s0 = uWMainActivityFragment.f75215L3.m4878s0(CompressHelper.m4948X0(uWMainActivityFragment.f75212I3), "select qid, selectedAnswer, corrAnswer, answerDate, time, testId from logs", "qid,selectedAnswer,corrAnswer,answerDate,time,testId", null);
                        UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                        String m4878s02 = uWMainActivityFragment2.f75215L3.m4878s0(CompressHelper.m4948X0(uWMainActivityFragment2.f75212I3), "select id,qIds, createdDate, qIndex, done, mode, right, wrong, subject, system, hard from tests", "id,qIds,createdDate,qIndex,done,mode,right,wrong,subject,system,hard", null);
                        CompressHelper compressHelper = UWMainActivityFragment.this.f75215L3;
                        String m4878s03 = compressHelper.m4878s0(compressHelper.m4972P0(), "select dbName,dbTitle,dbAddress,dbDate,dbDocName from favorites where dbName='" + UWMainActivityFragment.this.f75212I3.getString("Name").replace("'", "''") + "'", "dbName,dbTitle,dbAddress,dbDate,dbDocName", null);
                        Bundle bundle = new Bundle();
                        bundle.putString("text", "");
                        UWMainActivityFragment uWMainActivityFragment3 = UWMainActivityFragment.this;
                        final ProgressDialog show = ProgressDialog.show(UWMainActivityFragment.this.m44716w(), "Backing up", "Please wait...", true);
                        UWMainActivityFragment.this.f75215L3.m4890o0("SaveToFile|||||" + (m4878s0 + "###" + m4878s02 + "###" + m4878s03 + "###" + uWMainActivityFragment3.f75215L3.m4878s0(uWMainActivityFragment3.m4244u3(), "select dbName,dbTitle,dbAddress,dbDate,dbDocName,type,text,note,save from highlight where dbName = '" + UWMainActivityFragment.this.f75212I3.getString("Name").replace("'", "''") + "'", "dbName,dbTitle,dbAddress,dbDate,dbDocName,type,text,note,save", bundle))).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7329f6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.13.2.1
                            @Override // io.reactivex.rxjava3.functions.Consumer
                            /* renamed from: a */
                            public void accept(String str) throws Throwable {
                                show.dismiss();
                                UWMainActivityFragment uWMainActivityFragment4 = UWMainActivityFragment.this;
                                uWMainActivityFragment4.f75592j4 = "Backup identifier : " + str;
                                UWMainActivityFragment.this.f75216M3.m42860G();
                            }
                        }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.13.2.2
                            @Override // io.reactivex.rxjava3.functions.Consumer
                            /* renamed from: a */
                            public void accept(Throwable th) throws Throwable {
                                show.dismiss();
                                CompressHelper.m4921e2(UWMainActivityFragment.this.m44716w(), "Error in contacting server", 1);
                            }
                        });
                    }
                }).mo26284p("Cancel", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.13.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                }).m52864I();
            }
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* renamed from: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment$UWAdapter$14 */
        /* loaded from: classes2.dex */
        public class View$OnClickListenerC423914 implements View.OnClickListener {
            View$OnClickListenerC423914() {
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final EditText editText = new EditText(UWMainActivityFragment.this.m44716w());
                editText.setTextColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.f86093black));
                new AlertDialog.Builder(UWMainActivityFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Enter Backup Identifier. This will delete test history, favorites and highlights of this database from this device").setView(editText).mo26266y("OK", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.14.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String obj = editText.getText().toString();
                        if (obj.length() == 0) {
                            CompressHelper.m4921e2(UWMainActivityFragment.this.m44716w(), "You must enter a backup identifier", 1);
                            return;
                        }
                        final ProgressDialog show = ProgressDialog.show(UWMainActivityFragment.this.m44716w(), "Restoring", "Please wait...", true);
                        UWMainActivityFragment.this.f75215L3.m4890o0("LoadFromFile|||||" + obj).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7329f6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.14.2.1
                            @Override // io.reactivex.rxjava3.functions.Consumer
                            /* renamed from: a */
                            public void accept(String str) throws Throwable {
                                CompressHelper compressHelper;
                                String str2;
                                String m4948X0;
                                String str3;
                                String str4;
                                if (str.length() == 0) {
                                    show.dismiss();
                                    CompressHelper.m4921e2(UWMainActivityFragment.this.m44716w(), "Identifier not found", 1);
                                    return;
                                }
                                String[] splitByWholeSeparatorPreserveAllTokens = StringUtils.splitByWholeSeparatorPreserveAllTokens(str, "###");
                                UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
                                uWMainActivityFragment.f75215L3.m4897m(uWMainActivityFragment.f75212I3, "Delete from logs");
                                UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                                uWMainActivityFragment2.f75215L3.m4897m(uWMainActivityFragment2.f75212I3, "Delete from tests");
                                CompressHelper compressHelper2 = UWMainActivityFragment.this.f75215L3;
                                String m4972P0 = compressHelper2.m4972P0();
                                compressHelper2.m4885q(m4972P0, "delete from favorites where dbName='" + UWMainActivityFragment.this.f75212I3.getString("Name").replace("'", "''") + "'");
                                UWMainActivityFragment uWMainActivityFragment3 = UWMainActivityFragment.this;
                                CompressHelper compressHelper3 = uWMainActivityFragment3.f75215L3;
                                String m4244u3 = uWMainActivityFragment3.m4244u3();
                                compressHelper3.m4885q(m4244u3, "delete from highlight where dbName='" + UWMainActivityFragment.this.f75212I3.getString("Name").replace("'", "''") + "'");
                                UWMainActivityFragment uWMainActivityFragment4 = UWMainActivityFragment.this;
                                uWMainActivityFragment4.f75215L3.m4896m0(splitByWholeSeparatorPreserveAllTokens[0], CompressHelper.m4948X0(uWMainActivityFragment4.f75212I3), "logs", "qid,selectedAnswer,corrAnswer,answerDate,time,testId", null);
                                int m4876t = UWMainActivityFragment.this.f75215L3.m4876t(splitByWholeSeparatorPreserveAllTokens[1]);
                                if (m4876t != 11) {
                                    if (m4876t == 10) {
                                        UWMainActivityFragment uWMainActivityFragment5 = UWMainActivityFragment.this;
                                        compressHelper = uWMainActivityFragment5.f75215L3;
                                        str2 = splitByWholeSeparatorPreserveAllTokens[1];
                                        m4948X0 = CompressHelper.m4948X0(uWMainActivityFragment5.f75212I3);
                                        str3 = "tests";
                                        str4 = "qIds,createdDate,qIndex,done,mode,right,wrong,subject,system,hard";
                                    }
                                    Bundle bundle = new Bundle();
                                    bundle.putString("dbName", UWMainActivityFragment.this.f75212I3.getString("Name"));
                                    bundle.putString("dbTitle", UWMainActivityFragment.this.f75212I3.getString("Title"));
                                    CompressHelper compressHelper4 = UWMainActivityFragment.this.f75215L3;
                                    compressHelper4.m4896m0(splitByWholeSeparatorPreserveAllTokens[2], compressHelper4.m4972P0(), "favorites", "dbName,dbTitle,dbAddress,dbDate,dbDocName", bundle);
                                    UWMainActivityFragment uWMainActivityFragment6 = UWMainActivityFragment.this;
                                    uWMainActivityFragment6.f75215L3.m4896m0(splitByWholeSeparatorPreserveAllTokens[3], uWMainActivityFragment6.m4244u3(), "highlight", "dbName,dbTitle,dbAddress,dbDate,dbDocName,type,text,note,save", bundle);
                                    UWMainActivityFragment.this.m4250o3();
                                    show.dismiss();
                                    CompressHelper.m4921e2(UWMainActivityFragment.this.m44716w(), "Restore was successful", 1);
                                    UWMainActivityFragment.this.m4252m3();
                                    UWMainActivityFragment.this.f75216M3.m42860G();
                                    UWMainActivityFragment.this.m4240y3();
                                }
                                UWMainActivityFragment uWMainActivityFragment7 = UWMainActivityFragment.this;
                                compressHelper = uWMainActivityFragment7.f75215L3;
                                str2 = splitByWholeSeparatorPreserveAllTokens[1];
                                m4948X0 = CompressHelper.m4948X0(uWMainActivityFragment7.f75212I3);
                                str3 = "tests";
                                str4 = "id,qIds,createdDate,qIndex,done,mode,right,wrong,subject,system,hard";
                                compressHelper.m4896m0(str2, m4948X0, str3, str4, null);
                                Bundle bundle2 = new Bundle();
                                bundle2.putString("dbName", UWMainActivityFragment.this.f75212I3.getString("Name"));
                                bundle2.putString("dbTitle", UWMainActivityFragment.this.f75212I3.getString("Title"));
                                CompressHelper compressHelper42 = UWMainActivityFragment.this.f75215L3;
                                compressHelper42.m4896m0(splitByWholeSeparatorPreserveAllTokens[2], compressHelper42.m4972P0(), "favorites", "dbName,dbTitle,dbAddress,dbDate,dbDocName", bundle2);
                                UWMainActivityFragment uWMainActivityFragment62 = UWMainActivityFragment.this;
                                uWMainActivityFragment62.f75215L3.m4896m0(splitByWholeSeparatorPreserveAllTokens[3], uWMainActivityFragment62.m4244u3(), "highlight", "dbName,dbTitle,dbAddress,dbDate,dbDocName,type,text,note,save", bundle2);
                                UWMainActivityFragment.this.m4250o3();
                                show.dismiss();
                                CompressHelper.m4921e2(UWMainActivityFragment.this.m44716w(), "Restore was successful", 1);
                                UWMainActivityFragment.this.m4252m3();
                                UWMainActivityFragment.this.f75216M3.m42860G();
                                UWMainActivityFragment.this.m4240y3();
                            }
                        }, new Consumer<Throwable>() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.14.2.2
                            @Override // io.reactivex.rxjava3.functions.Consumer
                            /* renamed from: a */
                            public void accept(Throwable th) throws Throwable {
                                show.dismiss();
                                CompressHelper.m4921e2(UWMainActivityFragment.this.m44716w(), "Error in contacting server", 1);
                            }
                        });
                    }
                }).mo26284p("Cancel", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.14.1
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                }).m52864I();
            }
        }

        public UWAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
            Bundle m4253l3 = uWMainActivityFragment.m4253l3(i, uWMainActivityFragment.f75584b4);
            if (!m4253l3.getString("Type").equals("Header") && m4253l3.getString("Type").equals("Item")) {
                String string = m4253l3.getString("Section");
                int i2 = m4253l3.getInt("Index");
                if (string.equals("Questions")) {
                    return 1;
                }
                if (string.equals("Create A Test")) {
                    if (i2 == 7) {
                        return 4;
                    }
                    return i2 == 6 ? 3 : 2;
                } else if (string.equals("Previous Tests")) {
                    return 1;
                } else {
                    if (string.equals("Settings")) {
                        return 3;
                    }
                }
            }
            return 0;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            MaterialRippleLayout materialRippleLayout;
            View.OnClickListener view$OnClickListenerC423914;
            TextView textView;
            TextView textView2;
            String str;
            UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
            Bundle m4253l3 = uWMainActivityFragment.m4253l3(i, uWMainActivityFragment.f75584b4);
            if (m4253l3.getString("Type").equals("Header")) {
                ((HeaderCellViewHolder) viewHolder).f83245I.setText(m4253l3.getString("Text"));
            }
            if (m4253l3.getString("Type").equals("Item")) {
                String string = m4253l3.getString("Section");
                int i2 = m4253l3.getInt("Index");
                if (string.equals("Questions")) {
                    RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                    if (i2 == 0) {
                        rippleTextViewHolder.f83300I.setText("Browse Questions");
                        materialRippleLayout = rippleTextViewHolder.f83301J;
                        view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                                uWMainActivityFragment2.f75215L3.m4979N(UWTocActivity.class, UWTocActivityFragment.class, uWMainActivityFragment2.m4249p3("0"));
                            }
                        };
                    } else if (i2 != 1) {
                        return;
                    } else {
                        rippleTextViewHolder.f83300I.setText("Favorite Questions");
                        materialRippleLayout = rippleTextViewHolder.f83301J;
                        view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.2
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                                uWMainActivityFragment2.f75215L3.m4979N(UWTocActivity.class, UWTocActivityFragment.class, uWMainActivityFragment2.m4249p3(ExifInterface.f14411T4));
                            }
                        };
                    }
                } else if (string.equals("Create A Test")) {
                    if (i2 == 7) {
                        textView2 = ((HeaderCellViewHolder) viewHolder).f83245I;
                        str = UWMainActivityFragment.this.f75591i4 + " Questions Found";
                    } else if (i2 == 6) {
                        AccountTextViewHolder accountTextViewHolder = (AccountTextViewHolder) viewHolder;
                        accountTextViewHolder.f75616I.setTextColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
                        if (UWMainActivityFragment.this.f75591i4 > 0) {
                            accountTextViewHolder.f75617J.setBackgroundColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.green_dark));
                            accountTextViewHolder.f75616I.setText("Let's Go");
                            materialRippleLayout = accountTextViewHolder.f75617J;
                            view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.3
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                                    String str2 = StringUtils.splitByWholeSeparator(uWMainActivityFragment2.f75587e4.get(uWMainActivityFragment2.f75593k4).getString("title"), StringUtils.SPACE)[0];
                                    String m4251n3 = UWMainActivityFragment.this.m4251n3(new Date());
                                    UWAdapter uWAdapter = UWAdapter.this;
                                    UWMainActivityFragment uWMainActivityFragment3 = UWMainActivityFragment.this;
                                    String m4236d0 = uWAdapter.m4236d0(uWMainActivityFragment3.f75585c4, uWMainActivityFragment3.f75596n4, "name");
                                    UWAdapter uWAdapter2 = UWAdapter.this;
                                    UWMainActivityFragment uWMainActivityFragment4 = UWMainActivityFragment.this;
                                    String m4236d02 = uWAdapter2.m4236d0(uWMainActivityFragment4.f75586d4, uWMainActivityFragment4.f75597o4, "name");
                                    UWMainActivityFragment uWMainActivityFragment5 = UWMainActivityFragment.this;
                                    String string2 = uWMainActivityFragment5.f75590h4.get(uWMainActivityFragment5.f75595m4).getString("title");
                                    String m4245t3 = UWMainActivityFragment.this.m4245t3();
                                    UWMainActivityFragment uWMainActivityFragment6 = UWMainActivityFragment.this;
                                    ArrayList<Bundle> m4955V = uWMainActivityFragment6.f75215L3.m4955V(uWMainActivityFragment6.f75212I3, "Select id, parentqid from questions where " + m4245t3 + " order by random() limit " + str2);
                                    ArrayList arrayList = new ArrayList();
                                    ArrayList arrayList2 = new ArrayList();
                                    Iterator<Bundle> it2 = m4955V.iterator();
                                    while (it2.hasNext()) {
                                        Bundle next = it2.next();
                                        String string3 = next.getString("parentQId");
                                        if (string3 == null) {
                                            string3 = "0";
                                        }
                                        if (string3.equals("0")) {
                                            arrayList.add(next.getString("id"));
                                        } else if (!arrayList2.contains(string3)) {
                                            arrayList2.add(string3);
                                        }
                                    }
                                    Iterator it3 = arrayList2.iterator();
                                    while (it3.hasNext()) {
                                        UWMainActivityFragment uWMainActivityFragment7 = UWMainActivityFragment.this;
                                        ArrayList<Bundle> m4955V2 = uWMainActivityFragment7.f75215L3.m4955V(uWMainActivityFragment7.f75212I3, "Select id from questions where parentQId = " + ((String) it3.next()) + " order by id");
                                        if (m4955V2 == null) {
                                            m4955V2 = new ArrayList<>();
                                        }
                                        for (int size = m4955V2.size() - 1; size >= 0; size--) {
                                            String string4 = m4955V2.get(size).getString("id");
                                            if (arrayList.size() == Integer.parseInt(str2)) {
                                                arrayList.remove(arrayList.size() - 1);
                                            }
                                            arrayList.add(0, string4);
                                        }
                                    }
                                    String join = StringUtils.join(arrayList, ",");
                                    UWMainActivityFragment uWMainActivityFragment8 = UWMainActivityFragment.this;
                                    CompressHelper compressHelper = uWMainActivityFragment8.f75215L3;
                                    Bundle bundle = uWMainActivityFragment8.f75212I3;
                                    StringBuilder sb = new StringBuilder();
                                    sb.append("Insert into Tests (id, qIds, createdDate, qIndex, done, mode, right, wrong, subject, system, hard) values (null, '");
                                    sb.append(join);
                                    sb.append("', '");
                                    sb.append(m4251n3);
                                    sb.append("', 0, 0, '");
                                    UWMainActivityFragment uWMainActivityFragment9 = UWMainActivityFragment.this;
                                    sb.append(uWMainActivityFragment9.f75588f4.get(uWMainActivityFragment9.f75594l4).getString("title"));
                                    sb.append("', 0, 0, '");
                                    sb.append(m4236d0);
                                    sb.append("', '");
                                    sb.append(m4236d02);
                                    sb.append("', '");
                                    sb.append(string2);
                                    sb.append("')");
                                    compressHelper.m4897m(bundle, sb.toString());
                                    UWMainActivityFragment uWMainActivityFragment10 = UWMainActivityFragment.this;
                                    CompressHelper compressHelper2 = uWMainActivityFragment10.f75215L3;
                                    String string5 = compressHelper2.m4907i1(compressHelper2.m4955V(uWMainActivityFragment10.f75212I3, "SELECT id FROM Tests ORDER BY id DESC LIMIT 1")).getString("id");
                                    UWMainActivityFragment uWMainActivityFragment11 = UWMainActivityFragment.this;
                                    uWMainActivityFragment11.f75215L3.m4883q1(uWMainActivityFragment11.f75212I3, "test-" + string5, null, null);
                                }
                            };
                        } else {
                            accountTextViewHolder.f75617J.setBackgroundColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.f86225material_grey_700));
                            textView2 = accountTextViewHolder.f75616I;
                            str = "No Question Available";
                        }
                    } else {
                        RippleTextViewHolder rippleTextViewHolder2 = (RippleTextViewHolder) viewHolder;
                        if (i2 == 0) {
                            TextView textView3 = rippleTextViewHolder2.f83300I;
                            UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                            textView3.setText(uWMainActivityFragment2.f75587e4.get(uWMainActivityFragment2.f75593k4).getString("title"));
                            materialRippleLayout = rippleTextViewHolder2.f83301J;
                            view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.4
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    UWMainActivityFragment uWMainActivityFragment3 = UWMainActivityFragment.this;
                                    uWMainActivityFragment3.m4255A3("numberquestion", uWMainActivityFragment3.f75587e4, "title", uWMainActivityFragment3.f75593k4);
                                }
                            };
                        } else if (i2 == 1) {
                            TextView textView4 = rippleTextViewHolder2.f83300I;
                            StringBuilder sb = new StringBuilder();
                            sb.append("Test Mode : ");
                            UWMainActivityFragment uWMainActivityFragment3 = UWMainActivityFragment.this;
                            sb.append(uWMainActivityFragment3.f75588f4.get(uWMainActivityFragment3.f75594l4).getString("title"));
                            textView4.setText(sb.toString());
                            materialRippleLayout = rippleTextViewHolder2.f83301J;
                            view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.5
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    UWMainActivityFragment uWMainActivityFragment4 = UWMainActivityFragment.this;
                                    uWMainActivityFragment4.m4255A3("testMode", uWMainActivityFragment4.f75588f4, "title", uWMainActivityFragment4.f75594l4);
                                }
                            };
                        } else if (i2 == 2) {
                            TextView textView5 = rippleTextViewHolder2.f83300I;
                            UWMainActivityFragment uWMainActivityFragment4 = UWMainActivityFragment.this;
                            textView5.setText(m4236d0(uWMainActivityFragment4.f75585c4, uWMainActivityFragment4.f75596n4, "name"));
                            materialRippleLayout = rippleTextViewHolder2.f83301J;
                            view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.6
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    UWMainActivityFragment uWMainActivityFragment5 = UWMainActivityFragment.this;
                                    uWMainActivityFragment5.m4239z3("subject", uWMainActivityFragment5.f75585c4, "name", uWMainActivityFragment5.f75596n4);
                                }
                            };
                        } else if (i2 == 3) {
                            TextView textView6 = rippleTextViewHolder2.f83300I;
                            UWMainActivityFragment uWMainActivityFragment5 = UWMainActivityFragment.this;
                            textView6.setText(m4236d0(uWMainActivityFragment5.f75586d4, uWMainActivityFragment5.f75597o4, "name"));
                            materialRippleLayout = rippleTextViewHolder2.f83301J;
                            view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.7
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    UWMainActivityFragment uWMainActivityFragment6 = UWMainActivityFragment.this;
                                    uWMainActivityFragment6.m4239z3("system", uWMainActivityFragment6.f75586d4, "name", uWMainActivityFragment6.f75597o4);
                                }
                            };
                        } else if (i2 == 4) {
                            TextView textView7 = rippleTextViewHolder2.f83300I;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Filter : ");
                            UWMainActivityFragment uWMainActivityFragment6 = UWMainActivityFragment.this;
                            sb2.append(m4236d0(uWMainActivityFragment6.f75589g4, uWMainActivityFragment6.f75598p4, "title"));
                            textView7.setText(sb2.toString());
                            materialRippleLayout = rippleTextViewHolder2.f83301J;
                            view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.8
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    UWMainActivityFragment uWMainActivityFragment7 = UWMainActivityFragment.this;
                                    uWMainActivityFragment7.m4239z3("filter", uWMainActivityFragment7.f75589g4, "title", uWMainActivityFragment7.f75598p4);
                                }
                            };
                        } else if (i2 != 5) {
                            return;
                        } else {
                            TextView textView8 = rippleTextViewHolder2.f83300I;
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append("Difficulty : ");
                            UWMainActivityFragment uWMainActivityFragment7 = UWMainActivityFragment.this;
                            sb3.append(uWMainActivityFragment7.f75590h4.get(uWMainActivityFragment7.f75595m4).getString("title"));
                            textView8.setText(sb3.toString());
                            materialRippleLayout = rippleTextViewHolder2.f83301J;
                            view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.9
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    UWMainActivityFragment uWMainActivityFragment8 = UWMainActivityFragment.this;
                                    uWMainActivityFragment8.m4255A3("hardness", uWMainActivityFragment8.f75590h4, "title", uWMainActivityFragment8.f75595m4);
                                }
                            };
                        }
                    }
                    textView2.setText(str);
                    return;
                } else if (string.equals("Previous Tests")) {
                    RippleTextViewHolder rippleTextViewHolder3 = (RippleTextViewHolder) viewHolder;
                    if (i2 == 0) {
                        rippleTextViewHolder3.f83300I.setText("Last Test");
                        materialRippleLayout = rippleTextViewHolder3.f83301J;
                        view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.10
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                CompressHelper compressHelper;
                                Bundle bundle;
                                StringBuilder sb4;
                                String str2;
                                UWMainActivityFragment uWMainActivityFragment8 = UWMainActivityFragment.this;
                                CompressHelper compressHelper2 = uWMainActivityFragment8.f75215L3;
                                Bundle m4907i1 = compressHelper2.m4907i1(compressHelper2.m4955V(uWMainActivityFragment8.f75212I3, "Select * from tests order by id desc limit 1"));
                                if (m4907i1 == null) {
                                    CompressHelper.m4921e2(UWMainActivityFragment.this.m44716w(), "You haven't created any test yet", 0);
                                    return;
                                }
                                if (m4907i1.getString("done").equals(IcyHeaders.f35463C2)) {
                                    UWMainActivityFragment uWMainActivityFragment9 = UWMainActivityFragment.this;
                                    compressHelper = uWMainActivityFragment9.f75215L3;
                                    bundle = uWMainActivityFragment9.f75212I3;
                                    sb4 = new StringBuilder();
                                    str2 = "testresult-";
                                } else {
                                    UWMainActivityFragment uWMainActivityFragment10 = UWMainActivityFragment.this;
                                    compressHelper = uWMainActivityFragment10.f75215L3;
                                    bundle = uWMainActivityFragment10.f75212I3;
                                    sb4 = new StringBuilder();
                                    str2 = "test-";
                                }
                                sb4.append(str2);
                                sb4.append(m4907i1.getString("id"));
                                compressHelper.m4883q1(bundle, sb4.toString(), null, null);
                            }
                        };
                    } else if (i2 != 1) {
                        return;
                    } else {
                        rippleTextViewHolder3.f83300I.setText("Previous Tests");
                        materialRippleLayout = rippleTextViewHolder3.f83301J;
                        view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.11
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                UWMainActivityFragment uWMainActivityFragment8 = UWMainActivityFragment.this;
                                uWMainActivityFragment8.f75215L3.m4979N(UWTestsListActivity.class, UWTestsListActivityFragment.class, uWMainActivityFragment8.m4249p3("0"));
                            }
                        };
                    }
                } else if (!string.equals("Settings")) {
                    return;
                } else {
                    if (i2 == 0) {
                        AccountTextViewHolder accountTextViewHolder2 = (AccountTextViewHolder) viewHolder;
                        accountTextViewHolder2.f75616I.setTextColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
                        accountTextViewHolder2.f75616I.setText("Reset History");
                        accountTextViewHolder2.f75617J.setBackgroundColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.red));
                        materialRippleLayout = accountTextViewHolder2.f75617J;
                        view$OnClickListenerC423914 = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.12
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                new AlertDialog.Builder(UWMainActivityFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("This will delete all tests and history").mo26266y("OK", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.12.2
                                    @Override // android.content.DialogInterface.OnClickListener
                                    public void onClick(DialogInterface dialogInterface, int i3) {
                                        UWMainActivityFragment uWMainActivityFragment8 = UWMainActivityFragment.this;
                                        uWMainActivityFragment8.f75215L3.m4897m(uWMainActivityFragment8.f75212I3, "delete from logs");
                                        UWMainActivityFragment uWMainActivityFragment9 = UWMainActivityFragment.this;
                                        uWMainActivityFragment9.f75215L3.m4897m(uWMainActivityFragment9.f75212I3, "delete from tests");
                                        UWMainActivityFragment uWMainActivityFragment10 = UWMainActivityFragment.this;
                                        uWMainActivityFragment10.f75215L3.m4897m(uWMainActivityFragment10.f75212I3, "delete from flags");
                                        UWMainActivityFragment.this.m4252m3();
                                        UWMainActivityFragment.this.f75216M3.m42860G();
                                    }
                                }).mo26284p("Cancel", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.UWAdapter.12.1
                                    @Override // android.content.DialogInterface.OnClickListener
                                    public void onClick(DialogInterface dialogInterface, int i3) {
                                    }
                                }).m52864I();
                            }
                        };
                    } else if (i2 == 1) {
                        AccountTextViewHolder accountTextViewHolder3 = (AccountTextViewHolder) viewHolder;
                        accountTextViewHolder3.f75616I.setTextColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
                        accountTextViewHolder3.f75617J.setBackgroundColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.green));
                        String str2 = "Backup Data";
                        accountTextViewHolder3.f75616I.setText("Backup Data");
                        if (UWMainActivityFragment.this.f75592j4.length() == 0) {
                            textView = accountTextViewHolder3.f75616I;
                        } else {
                            textView = accountTextViewHolder3.f75616I;
                            str2 = UWMainActivityFragment.this.f75592j4;
                        }
                        textView.setText(str2);
                        materialRippleLayout = accountTextViewHolder3.f75617J;
                        view$OnClickListenerC423914 = new View$OnClickListenerC423413();
                    } else if (i2 != 2) {
                        return;
                    } else {
                        AccountTextViewHolder accountTextViewHolder4 = (AccountTextViewHolder) viewHolder;
                        accountTextViewHolder4.f75616I.setTextColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
                        accountTextViewHolder4.f75616I.setText("Restore Data");
                        accountTextViewHolder4.f75617J.setBackgroundColor(UWMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.f86110dark_blue));
                        materialRippleLayout = accountTextViewHolder4.f75617J;
                        view$OnClickListenerC423914 = new View$OnClickListenerC423914();
                    }
                }
                materialRippleLayout.setOnClickListener(view$OnClickListenerC423914);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i != 0) {
                if (i != 1) {
                    if (i != 2) {
                        if (i == 3) {
                            return new AccountTextViewHolder(LayoutInflater.from(UWMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87218list_view_item_account_text, viewGroup, false));
                        } else if (i != 4) {
                            return null;
                        } else {
                            return new HeaderCellViewHolder(LayoutInflater.from(UWMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87241list_view_item_footer, viewGroup, false));
                        }
                    }
                    return new RippleTextViewHolder(LayoutInflater.from(UWMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87270list_view_item_ripple_text_list, viewGroup, false));
                }
                return new RippleTextViewHolder(LayoutInflater.from(UWMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
            }
            return new HeaderCellViewHolder(LayoutInflater.from(UWMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false));
        }

        /* renamed from: d0 */
        public String m4236d0(ArrayList<Bundle> arrayList, ArrayList<Integer> arrayList2, String str) {
            ArrayList arrayList3 = new ArrayList();
            Iterator<Integer> it2 = arrayList2.iterator();
            while (it2.hasNext()) {
                arrayList3.add(arrayList.get(it2.next().intValue()).getString(str));
            }
            return StringUtils.join(arrayList3, " | ");
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
            return uWMainActivityFragment.m4254B3(uWMainActivityFragment.f75584b4);
        }
    }

    /* renamed from: A3 */
    public void m4255A3(String str, ArrayList<Bundle> arrayList, String str2, int i) {
        SelectDialog selectDialog = new SelectDialog();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("Items", arrayList);
        bundle.putString("TitleProperty", str2);
        bundle.putInt("Position", i);
        bundle.putString("Type", str);
        selectDialog.m44844E2(this, 0);
        selectDialog.m44751k2(bundle);
        selectDialog.m44870c3(true);
        selectDialog.mo29915h3(m44820L(), "asdfasdfasdf");
    }

    /* renamed from: B3 */
    public int m4254B3(ArrayList<String> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return 0;
        }
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            i = i + m4243v3(it2.next()) + 1;
        }
        return i;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        this.f75592j4 = "";
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        m4337R2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f75596n4 = new ArrayList<>();
        this.f75597o4 = new ArrayList<>();
        this.f75598p4 = new ArrayList<>();
        this.f75596n4.add(0);
        this.f75597o4.add(0);
        this.f75598p4.add(0);
        ((AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar)).m27445s(true, false);
        ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
        this.f75585c4 = this.f75215L3.m4955V(this.f75212I3, "select 0 as id,'All Subjects' as name , sum(count) as count from subjects union select id, name,count from subjects");
        this.f75586d4 = this.f75215L3.m4955V(this.f75212I3, "select 0 as id, 'All Systems' as name , sum(count) as count from systems union select id, name,count from systems");
        this.f75587e4 = new ArrayList<>();
        for (int i = 0; i < 1001; i++) {
            this.f75587e4.add(m4248q3(i + " Questions"));
        }
        ArrayList<Bundle> arrayList = new ArrayList<>();
        this.f75588f4 = arrayList;
        arrayList.add(m4248q3("Reading"));
        this.f75588f4.add(m4248q3("Testing"));
        ArrayList<Bundle> arrayList2 = new ArrayList<>();
        this.f75590h4 = arrayList2;
        arrayList2.add(m4246s3("All", "0", "100"));
        this.f75590h4.add(m4246s3("Easy", "75", "100"));
        this.f75590h4.add(m4246s3("Fair", "50", "75"));
        this.f75590h4.add(m4246s3("Hard", "25", "50"));
        this.f75590h4.add(m4246s3("Extreme !", "0", "25"));
        ArrayList<Bundle> arrayList3 = new ArrayList<>();
        this.f75589g4 = arrayList3;
        arrayList3.add(m4247r3("All Questions", ""));
        this.f75589g4.add(m4247r3("Unused", "not (id in (select distinct qid from logs))"));
        this.f75589g4.add(m4247r3("Incorrect", "id in (select qid from (select qid,max(rowid),selectedanswer<>corrAnswer as res from logs group by qid) where res=1) "));
        this.f75589g4.add(m4247r3("Favorites", "id in (" + this.f75215L3.m4905j0("select group_concat(dbAddress) as s from favorites where dbName = '" + this.f75212I3.getString("Name") + "'").get(0).getString("s").replace("question-", "").replace("answer-", "") + ")"));
        String string = this.f75212I3.getString("Version");
        int intValue = Integer.valueOf(string.substring(0, 4)).intValue();
        int intValue2 = Integer.valueOf(string.substring(4, 6)).intValue();
        ArrayList arrayList4 = new ArrayList();
        ArrayList arrayList5 = new ArrayList();
        do {
            if (intValue2 > 1) {
                intValue2--;
            } else {
                intValue--;
                intValue2 = 12;
            }
            arrayList5.add("(lastUpdated like '" + String.format(TimeModel.f50792C2, Integer.valueOf(intValue2)) + "/%/" + intValue + "')");
            StringBuilder sb = new StringBuilder();
            sb.append("");
            sb.append(intValue);
            sb.append("-");
            sb.append(intValue2);
            String sb2 = sb.toString();
            this.f75589g4.add(m4247r3("Updated Since " + sb2, TextUtils.join(" OR ", arrayList5)));
            arrayList4.add(sb2);
        } while (arrayList4.size() < 12);
        m44735q2(false);
        ArrayList<String> arrayList6 = new ArrayList<>();
        this.f75584b4 = arrayList6;
        arrayList6.add("Questions");
        this.f75584b4.add("Create A Test");
        this.f75584b4.add("Previous Tests");
        this.f75584b4.add("Settings");
        this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
            /* renamed from: d0 */
            public void mo3398d0(RecyclerView.ViewHolder viewHolder, int i2, Bundle bundle2) {
                String str;
                StringBuilder sb3;
                String str2;
                RippleSearchContentViewHolder rippleSearchContentViewHolder = (RippleSearchContentViewHolder) viewHolder;
                rippleSearchContentViewHolder.f83264I.setText(bundle2.getString("text"));
                final String string2 = bundle2.getString("type");
                final String string3 = bundle2.getString("contentId");
                if (string2.equals("0")) {
                    rippleSearchContentViewHolder.f83265J.setVisibility(8);
                    rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.1.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
                            CompressHelper compressHelper = uWMainActivityFragment.f75215L3;
                            Bundle bundle3 = uWMainActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "question-" + string3, null, null);
                        }
                    });
                    return;
                }
                if (string2.equals(IcyHeaders.f35463C2)) {
                    sb3 = new StringBuilder();
                    sb3.append("<font color=\"red\">");
                    str2 = "Question";
                } else if (string2.equals(ExifInterface.f14403S4)) {
                    sb3 = new StringBuilder();
                    sb3.append("<font color=\"red\">");
                    str2 = "Explanation";
                } else if (!string2.equals(ExifInterface.f14411T4)) {
                    str = "";
                    final String str3 = str + StringUtils.SPACE + bundle2.getString("subText");
                    rippleSearchContentViewHolder.f83265J.setText(Html.fromHtml(str3));
                    rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.1.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            if (string2.equals(ExifInterface.f14403S4)) {
                                UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
                                CompressHelper compressHelper = uWMainActivityFragment.f75215L3;
                                Bundle bundle3 = uWMainActivityFragment.f75212I3;
                                compressHelper.m4883q1(bundle3, "answer-" + string3, UWMainActivityFragment.this.m4332W2(str3), null);
                                return;
                            }
                            UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                            CompressHelper compressHelper2 = uWMainActivityFragment2.f75215L3;
                            Bundle bundle4 = uWMainActivityFragment2.f75212I3;
                            compressHelper2.m4883q1(bundle4, "question-" + string3, UWMainActivityFragment.this.m4332W2(str3), null);
                        }
                    });
                } else {
                    sb3 = new StringBuilder();
                    sb3.append("<font color=\"red\">");
                    str2 = "Answer";
                }
                sb3.append(str2);
                sb3.append("</font>");
                str = sb3.toString();
                final String str32 = str + StringUtils.SPACE + bundle2.getString("subText");
                rippleSearchContentViewHolder.f83265J.setText(Html.fromHtml(str32));
                rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWMainActivityFragment.1.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (string2.equals(ExifInterface.f14403S4)) {
                            UWMainActivityFragment uWMainActivityFragment = UWMainActivityFragment.this;
                            CompressHelper compressHelper = uWMainActivityFragment.f75215L3;
                            Bundle bundle3 = uWMainActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "answer-" + string3, UWMainActivityFragment.this.m4332W2(str32), null);
                            return;
                        }
                        UWMainActivityFragment uWMainActivityFragment2 = UWMainActivityFragment.this;
                        CompressHelper compressHelper2 = uWMainActivityFragment2.f75215L3;
                        Bundle bundle4 = uWMainActivityFragment2.f75212I3;
                        compressHelper2.m4883q1(bundle4, "question-" + string3, UWMainActivityFragment.this.m4332W2(str32), null);
                    }
                });
            }
        };
        m4252m3();
        UWAdapter uWAdapter = new UWAdapter();
        this.f75216M3 = uWAdapter;
        this.f75227X3.setAdapter(uWAdapter);
        m4338Q2();
        m4250o3();
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75217N3.m3396f0(this.f75219P3);
        this.f75227X3.setAdapter(this.f75217N3);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    /* renamed from: l3 */
    public Bundle m4253l3(int i, ArrayList<String> arrayList) {
        Iterator<String> it2 = arrayList.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            String next = it2.next();
            if (i == i2) {
                Bundle bundle = new Bundle();
                bundle.putString("Text", next);
                bundle.putString("Type", "Header");
                return bundle;
            }
            int m4243v3 = i2 + m4243v3(next);
            if (i <= m4243v3) {
                Bundle bundle2 = new Bundle();
                bundle2.putString("Section", next);
                bundle2.putInt("Index", (i - (m4243v3 - m4243v3(next))) - 1);
                bundle2.putString("Type", "Item");
                return bundle2;
            }
            i2 = m4243v3 + 1;
        }
        return null;
    }

    /* renamed from: m3 */
    public void m4252m3() {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(bundle, "select count(*) as c from questions where " + m4245t3()));
        this.f75591i4 = m4907i1 == null ? 0 : Integer.valueOf(m4907i1.getString("c")).intValue();
    }

    /* renamed from: n3 */
    public String m4251n3(Date date) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ").format(date);
    }

    /* renamed from: o3 */
    public void m4250o3() {
        ArrayList<Bundle> m4955V = this.f75215L3.m4955V(this.f75212I3, "select id,qIds from tests where score is null");
        if (m4955V == null) {
            return;
        }
        Iterator<Bundle> it2 = m4955V.iterator();
        while (it2.hasNext()) {
            Bundle next = it2.next();
            String string = next.getString("id");
            String string2 = next.getString("qIds");
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            int doubleValue = (int) ((Double.valueOf(compressHelper.m4907i1(compressHelper.m4955V(bundle, "select count(*) as c from logs where testId='" + string + "' and selectedAnswer=corrAnswer")).getString("c")).doubleValue() / StringUtils.splitByWholeSeparatorPreserveAllTokens(string2, ",").length) * 100.0d);
            CompressHelper compressHelper2 = this.f75215L3;
            Bundle bundle2 = this.f75212I3;
            compressHelper2.m4897m(bundle2, "Update tests set score='" + doubleValue + "' where id=" + string);
        }
    }

    /* renamed from: p3 */
    public Bundle m4249p3(String str) {
        Bundle bundle = new Bundle();
        bundle.putBundle("DB", this.f75212I3);
        bundle.putString("ParentId", str);
        return bundle;
    }

    /* renamed from: q3 */
    public Bundle m4248q3(String str) {
        Bundle bundle = new Bundle();
        bundle.putString("title", str);
        return bundle;
    }

    /* renamed from: r3 */
    public Bundle m4247r3(String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putString("title", str);
        bundle.putString("sql", str2);
        return bundle;
    }

    /* renamed from: s3 */
    public Bundle m4246s3(String str, String str2, String str3) {
        Bundle bundle = new Bundle();
        bundle.putString("title", str);
        bundle.putString("Min", str2);
        bundle.putString("Max", str3);
        return bundle;
    }

    /* renamed from: t3 */
    public String m4245t3() {
        String string = this.f75590h4.get(this.f75595m4).getString("Min");
        String string2 = this.f75590h4.get(this.f75595m4).getString("Max");
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        Iterator<Integer> it2 = this.f75596n4.iterator();
        while (it2.hasNext()) {
            String string3 = this.f75585c4.get(it2.next().intValue()).getString("id");
            if (!string3.equals("0")) {
                arrayList2.add("(subId = " + string3 + ")");
            }
        }
        if (arrayList2.size() > 0) {
            arrayList.add("(" + StringUtils.join(arrayList2, " OR ") + ")");
        }
        ArrayList arrayList3 = new ArrayList();
        Iterator<Integer> it3 = this.f75597o4.iterator();
        while (it3.hasNext()) {
            String string4 = this.f75586d4.get(it3.next().intValue()).getString("id");
            if (!string4.equals("0")) {
                arrayList3.add("(sysId = " + string4 + ")");
            }
        }
        if (arrayList3.size() > 0) {
            arrayList.add("(" + StringUtils.join(arrayList3, " OR ") + ")");
        }
        ArrayList arrayList4 = new ArrayList();
        Iterator<Integer> it4 = this.f75598p4.iterator();
        while (it4.hasNext()) {
            String string5 = this.f75589g4.get(it4.next().intValue()).getString("sql");
            if (string5.length() > 0) {
                arrayList4.add("(" + string5 + ")");
            }
        }
        if (arrayList4.size() > 0) {
            arrayList.add("(" + StringUtils.join(arrayList4, " AND ") + ")");
        }
        arrayList.add("(corrTaken / pplTaken)*100 > " + string);
        arrayList.add("(corrTaken / pplTaken)*100 < " + string2);
        String join = StringUtils.join(arrayList, " AND ");
        Log.d("UW", "Final Query : " + join);
        return join;
    }

    /* renamed from: u3 */
    public String m4244u3() {
        String str = this.f75215L3.m4856z1() + "/highlights.db";
        if (!new File(str).exists()) {
            SQLiteDatabase.openOrCreateDatabase(str, (SQLiteDatabase.CursorFactory) null).execSQL("create virtual table highlight using fts4 (dbName, dbTitle, dbAddress, dbDate, dbDocName, type, text, note, save)");
        }
        return str;
    }

    /* renamed from: v3 */
    public int m4243v3(String str) {
        if (str.equals("Questions")) {
            return 2;
        }
        if (str.equals("Create A Test")) {
            return 8;
        }
        if (str.equals("Previous Tests")) {
            return 2;
        }
        return str.equals("Settings") ? 3 : 0;
    }

    /* renamed from: w3 */
    public void m4242w3(String str, ArrayList<Integer> arrayList) {
        if (str.equals("filter")) {
            this.f75598p4 = arrayList;
        } else if (!str.equals("hardness") && !str.equals("testMode") && !str.equals("numberquestion")) {
            if (str.equals("system")) {
                this.f75597o4 = arrayList;
            } else if (str.equals("subject")) {
                this.f75596n4 = arrayList;
            }
        }
        m4252m3();
        this.f75216M3.m42860G();
    }

    /* renamed from: x3 */
    public void m4241x3(String str, Bundle bundle, int i) {
        if (!str.equals("filter")) {
            if (str.equals("hardness")) {
                this.f75595m4 = i;
            } else if (str.equals("testMode")) {
                this.f75594l4 = i;
            } else if (str.equals("numberquestion")) {
                this.f75593k4 = i;
            } else if (!str.equals("system")) {
                str.equals("subject");
            }
        }
        m4252m3();
        this.f75216M3.m42860G();
    }

    /* renamed from: y3 */
    public void m4240y3() {
        iMDLogger.m3296d("sendFavorite", "Sending FavoriteChanged message");
        Intent intent = new Intent("net.imedicaldoctor.imd.favorite");
        intent.putExtra("Test", "Random data for test");
        LocalBroadcastManager.m43863b(m44716w()).m43861d(intent);
    }

    /* renamed from: z3 */
    public void m4239z3(String str, ArrayList<Bundle> arrayList, String str2, ArrayList<Integer> arrayList2) {
        CheckDialog checkDialog = new CheckDialog();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("Items", arrayList);
        bundle.putString("TitleProperty", str2);
        bundle.putIntegerArrayList("Positions", arrayList2);
        bundle.putString("Type", str);
        checkDialog.m44844E2(this, 0);
        checkDialog.m44751k2(bundle);
        checkDialog.m44870c3(true);
        checkDialog.mo29915h3(m44820L(), "asdfasdfasdf");
    }
}
