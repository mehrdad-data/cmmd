package net.imedicaldoctor.imd.Fragments.UWorld;

import android.os.Bundle;
import java.util.ArrayList;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Martindale.MDListActivity;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;

/* loaded from: classes2.dex */
public class UWTocActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public String f75720b4;

    /* renamed from: c4 */
    public String f75721c4 = "";

    /* renamed from: d4 */
    public ArrayList<String> f75722d4;

    /* renamed from: e4 */
    public String f75723e4;

    /* JADX WARN: Removed duplicated region for block: B:41:0x0201  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0215  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0224 A[LOOP:0: B:47:0x021e->B:49:0x0224, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x023e  */
    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View mo3277U0(android.view.LayoutInflater r15, android.view.ViewGroup r16, android.os.Bundle r17) {
        /*
            Method dump skipped, instructions count: 665
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.UWorld.UWTocActivityFragment.mo3277U0(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75217N3.m3396f0(this.f75219P3);
        this.f75227X3.setAdapter(this.f75217N3);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return this.f75721c4;
    }

    /* renamed from: l3 */
    public void m4204l3(Bundle bundle, int i) {
        m4330Y2();
        if (!bundle.getString("docId").equals("0")) {
            this.f75215L3.m4883q1(this.f75212I3, bundle.getString("docId"), null, null);
            return;
        }
        Bundle bundle2 = new Bundle();
        bundle2.putBundle("DB", this.f75212I3);
        bundle2.putString("ParentId", bundle.getString("id"));
        this.f75215L3.m4979N(MDListActivity.class, UWTocActivityFragment.class, bundle2);
    }
}
