package net.imedicaldoctor.imd.Fragments.UWorld;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.css.CSS;
import java.text.SimpleDateFormat;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class UWTestsListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f75703b4;

    /* renamed from: c4 */
    public String f75704c4;

    /* loaded from: classes2.dex */
    public class TestScoreViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f75712I;

        /* renamed from: J */
        public TextView f75713J;

        /* renamed from: K */
        public TextView f75714K;

        /* renamed from: L */
        public TextView f75715L;

        /* renamed from: M */
        public ImageView f75716M;

        /* renamed from: N */
        public TextView f75717N;

        /* renamed from: O */
        public MaterialRippleLayout f75718O;

        public TestScoreViewHolder(View view) {
            super(view);
            this.f75712I = (TextView) view.findViewById(C4804R.C4808id.f87049text_date);
            this.f75713J = (TextView) view.findViewById(C4804R.C4808id.f87051text_info1);
            this.f75714K = (TextView) view.findViewById(C4804R.C4808id.f87052text_info2);
            this.f75718O = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            this.f75715L = (TextView) view.findViewById(C4804R.C4808id.f87055text_score);
            this.f75716M = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
            this.f75717N = (TextView) view.findViewById(C4804R.C4808id.f87054text_resume);
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        appBarLayout.m27445s(false, false);
        appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestsListActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                relativeLayout.setVisibility(0);
            }
        }, 800L);
        this.f75218O3 = this.f75215L3.m4955V(this.f75212I3, "Select * from tests order by id desc");
        ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87302list_view_item_uworld_test) { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestsListActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                MaterialRippleLayout materialRippleLayout;
                View.OnClickListener onClickListener;
                TestScoreViewHolder testScoreViewHolder = (TestScoreViewHolder) viewHolder;
                testScoreViewHolder.f75712I.setText(UWTestsListActivityFragment.this.m4206l3(bundle2.getString("createdDate")));
                int length = StringUtils.splitByWholeSeparator(bundle2.getString("qIds"), ",").length;
                TextView textView = testScoreViewHolder.f75713J;
                textView.setText(length + " Questions. Mode: " + bundle2.getString("mode"));
                TextView textView2 = testScoreViewHolder.f75714K;
                textView2.setText(bundle2.getString("subject") + " , " + bundle2.getString("system"));
                if (bundle2.getString("done").equals(IcyHeaders.f35463C2)) {
                    testScoreViewHolder.f75716M.setImageDrawable(UWTestsListActivityFragment.this.m44782a0().getDrawable(C4804R.C4807drawable.f86555circle_green));
                    testScoreViewHolder.f75717N.setText("Score");
                    testScoreViewHolder.f75715L.setVisibility(0);
                    TextView textView3 = testScoreViewHolder.f75715L;
                    textView3.setText(bundle2.getString(FirebaseAnalytics.Param.f55169D) + CSS.Value.f65657n0);
                    materialRippleLayout = testScoreViewHolder.f75718O;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestsListActivityFragment.2.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            UWTestsListActivityFragment uWTestsListActivityFragment = UWTestsListActivityFragment.this;
                            CompressHelper compressHelper = uWTestsListActivityFragment.f75215L3;
                            Bundle bundle3 = uWTestsListActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "testresult-" + bundle2.getString("id"), null, null);
                        }
                    };
                } else {
                    testScoreViewHolder.f75716M.setImageDrawable(UWTestsListActivityFragment.this.m44782a0().getDrawable(C4804R.C4807drawable.f86554circle_blue));
                    testScoreViewHolder.f75717N.setText("Resume");
                    testScoreViewHolder.f75715L.setVisibility(8);
                    materialRippleLayout = testScoreViewHolder.f75718O;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestsListActivityFragment.2.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            UWTestsListActivityFragment uWTestsListActivityFragment = UWTestsListActivityFragment.this;
                            CompressHelper compressHelper = uWTestsListActivityFragment.f75215L3;
                            Bundle bundle3 = uWTestsListActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "test-" + bundle2.getString("id"), null, null);
                        }
                    };
                }
                materialRippleLayout.setOnClickListener(onClickListener);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new TestScoreViewHolder(view);
            }
        };
        this.f75216M3 = chaptersAdapter;
        chaptersAdapter.f83219h = "No Test Available";
        this.f75227X3.setAdapter(chaptersAdapter);
        m4338Q2();
        m44735q2(false);
        this.f75223T3.setVisibility(8);
        this.f75222S3.setTitle("Previous Tests");
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75703b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f75703b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "";
    }

    /* renamed from: l3 */
    public String m4206l3(String str) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ");
        try {
            return new SimpleDateFormat("MM dd,yyyy HH:mm:ss").format(simpleDateFormat.parse(str));
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            return str;
        }
    }
}
