package net.imedicaldoctor.imd.Fragments.UWorld;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import androidx.appcompat.app.AlertDialog;
import androidx.exifinterface.media.ExifInterface;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.AccessMedicine.AMHTMLViewerFragment;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.GeneralDialogFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class UWTestViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public ArrayList<Bundle> f75687A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f75688B4;

    /* renamed from: C4 */
    public int f75689C4;

    /* renamed from: D4 */
    public Bundle f75690D4;

    /* renamed from: E4 */
    public Date f75691E4;

    /* renamed from: F4 */
    public String f75692F4;

    /* renamed from: w4 */
    public Bundle f75693w4;

    /* renamed from: x4 */
    public ArrayList<String> f75694x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75695y4;

    /* renamed from: z4 */
    private GeneralDialogFragment f75696z4;

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: B4 */
    public void m4224B4() {
        CompressHelper compressHelper = this.f75863p4;
        Bundle bundle = this.f75850c4;
        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select * from images where questionId = " + this.f75688B4.get(this.f75689C4).getString("id"));
        if (m4955V == null) {
            m4955V = new ArrayList<>();
        }
        Iterator<Bundle> it2 = m4955V.iterator();
        while (it2.hasNext()) {
            String string = it2.next().getString("filename");
            String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, string, "media-E");
            if (new File(m4942Z0).exists()) {
                try {
                    byte[] m4867w = this.f75863p4.m4867w(FileUtils.readFileToByteArray(new File(m4942Z0)), string, "127");
                    String m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, string, "base");
                    if (new File(m4942Z02).exists()) {
                        new File(m4942Z02).delete();
                    }
                    FileUtils.writeByteArrayToFile(new File(m4942Z02), m4867w, false);
                    new File(m4942Z02).deleteOnExit();
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    e.printStackTrace();
                }
            }
        }
        this.f75695y4 = m4955V;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: C4 */
    public void m4223C4(ArrayList<String> arrayList) {
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            String replace = next.replace(".JPG", ".jpg");
            Log.e("UW", "Media2 : " + replace);
            String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, replace, "media-E");
            if (new File(m4942Z0).exists()) {
                File file = new File(m4942Z0);
                try {
                    String replace2 = CompressHelper.m4942Z0(this.f75850c4, next, "base").replace(".mov", ".mp4");
                    if (!new File(replace2).exists()) {
                        byte[] readFileToByteArray = FileUtils.readFileToByteArray(file);
                        Log.e("UW", "GET DATA " + replace);
                        byte[] m4867w = this.f75863p4.m4867w(readFileToByteArray, replace, "127");
                        Log.e("UW", "New Image Path : " + replace2);
                        FileUtils.writeByteArrayToFile(new File(replace2), m4867w, false);
                    }
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    e.printStackTrace();
                }
            }
        }
        this.f75694x4 = arrayList;
    }

    /* renamed from: H4 */
    private String m4218H4(String str, String str2, String str3) {
        return "<a name=\"f" + str3 + "\"><div id=\"h" + str3 + "\" class=\"headerExpanded\"  DIR=\"LTR\" onclick=\"collapse(f" + str3 + ");toggleHeaderExpanded(h" + str3 + ");\"><span class=\"fieldname\">" + str + "</span></div></a><div class=\"content\" DIR=\"LTR\" id=\"f" + str3 + "\">" + str2 + "</div>";
    }

    /* renamed from: N4 */
    private void m4212N4(String str) {
        ArrayList<String> arrayList = this.f75694x4;
        if ((arrayList == null && this.f75695y4 == null) || arrayList.size() + this.f75695y4.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f75694x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", CompressHelper.m4942Z0(this.f75850c4, next, "base"));
            bundle.putString("Description", "");
            bundle.putString("id", next);
            if (next.endsWith(".mov") || next.endsWith(".mp4") || next.endsWith(".mp3")) {
                bundle.putString("isVideo", IcyHeaders.f35463C2);
            }
            arrayList2.add(bundle);
        }
        Iterator<Bundle> it3 = this.f75695y4.iterator();
        while (it3.hasNext()) {
            Bundle next2 = it3.next();
            Bundle bundle2 = new Bundle();
            Iterator<Bundle> it4 = it3;
            bundle2.putString("ImagePath", CompressHelper.m4942Z0(this.f75850c4, next2.getString("filename"), "base"));
            bundle2.putString("Description", next2.getString("title"));
            bundle2.putString("id", next2.getString("mediaId"));
            if (next2.getString("filename").endsWith(".mov")) {
                bundle2.putString("isVideo", IcyHeaders.f35463C2);
            }
            if (next2.getString("filename").endsWith(".mp4")) {
                bundle2.putString("isVideo", IcyHeaders.f35463C2);
            }
            if (next2.getString("filename").endsWith(".mp3")) {
                bundle2.putString("isVideo", IcyHeaders.f35463C2);
            }
            arrayList2.add(bundle2);
            it3 = it4;
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public void m4225A4() {
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setEnabled(true);
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setIcon(C4804R.C4807drawable.f86585ic_action_next_item);
    }

    /* renamed from: F4 */
    public String m4220F4(Date date) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ").format(date);
    }

    /* renamed from: G4 */
    public String m4219G4(String str) {
        return str.equals(IcyHeaders.f35463C2) ? ExifInterface.f14387Q4 : str.equals(ExifInterface.f14403S4) ? "B" : str.equals(ExifInterface.f14411T4) ? "C" : str.equals("4") ? "D" : str.equals("5") ? ExifInterface.f14355M4 : str.equals("6") ? "F" : str.equals("7") ? "G" : str.equals("8") ? "H" : str;
    }

    /* renamed from: I4 */
    public void m4217I4(final String str, final boolean z) {
        m4083q3(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestViewerActivityFragment.1
            /* JADX WARN: Removed duplicated region for block: B:48:0x0324  */
            /* JADX WARN: Removed duplicated region for block: B:49:0x0327  */
            @Override // java.lang.Runnable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public void run() {
                /*
                    Method dump skipped, instructions count: 913
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.UWorld.UWTestViewerActivityFragment.RunnableC42531.run():void");
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                UWTestViewerActivityFragment.this.m4215K4();
                if (z) {
                    UWTestViewerActivityFragment.this.f75692F4 = "answerSectionsa";
                }
            }
        });
    }

    /* renamed from: J4 */
    public void m4216J4() {
        this.f75691E4 = new Date();
        this.f75852e4 = "Question " + String.valueOf(this.f75689C4 + 1) + " Of " + this.f75688B4.size();
        StringBuilder sb = new StringBuilder();
        sb.append("question-");
        sb.append(this.f75688B4.get(this.f75689C4).getString("id"));
        this.f75851d4 = sb.toString();
        Bundle bundle = this.f75688B4.get(this.f75689C4);
        String string = bundle.getString("id");
        Bundle bundle2 = this.f75690D4;
        String str = "100";
        if (bundle2 != null) {
            ArrayList<Bundle> m4955V = this.f75863p4.m4955V(this.f75850c4, "Select * from logs where testId=" + bundle2.getString("id") + " AND qid = " + string);
            if (m4955V == null || m4955V.size() <= 0) {
                if (this.f75690D4.getString("done").equals(IcyHeaders.f35463C2)) {
                    m4217I4("100", false);
                    return;
                }
            } else if (!this.f75690D4.getString("mode").equals("Testing")) {
                m4217I4(m4955V.get(0).getString("selectedAnswer"), false);
                return;
            } else if (!this.f75690D4.getString("done").equals("0")) {
                m4217I4(m4955V.get(0).getString("selectedAnswer"), false);
                return;
            } else {
                str = m4955V.get(0).getString("selectedAnswer");
            }
        }
        String m5015B = this.f75863p4.m5015B(bundle.getString("question"), string, "127");
        this.f75863p4.m5015B(bundle.getString("explanation"), string, "127");
        String m4108a4 = ViewerHelperFragment.m4108a4(m4117W3(m44716w(), "UWHeader.css") + m4117W3(m44716w(), "UWQuestion.css"), "[size]", "200");
        ArrayList<String> arrayList = new ArrayList<>();
        String string2 = bundle.getString("mediaName");
        String string3 = bundle.getString("otherMedias");
        if (string2.length() > 0) {
            for (String str2 : StringUtils.splitByWholeSeparator(string2, ";")) {
                arrayList.add(str2);
            }
        }
        if (string3.length() > 0) {
            for (String str3 : StringUtils.splitByWholeSeparator(string3, ",")) {
                arrayList.add(str3.replace("/", "_"));
            }
        }
        m4223C4(arrayList);
        m4224B4();
        ArrayList<Bundle> m4955V2 = this.f75863p4.m4955V(this.f75850c4, "select * from answers where qId = " + string);
        if (m4955V2 == null) {
            m4955V2 = new ArrayList<>();
        }
        String m4108a42 = ViewerHelperFragment.m4108a4(ViewerHelperFragment.m4108a4(m4108a4, "[correctID]", bundle.getString("corrAns")), "[Question]", m5015B);
        StringBuilder sb2 = new StringBuilder();
        Iterator<Bundle> it2 = m4955V2.iterator();
        while (it2.hasNext()) {
            Bundle next = it2.next();
            String m5015B2 = this.f75863p4.m5015B(next.getString("answerText"), string, "127");
            String string4 = next.getString("answerId");
            sb2.append("<tr><td width=\"16\" id=\"Qbank-Answer-Row-Image-" + string4 + "\"></td><td><input type=\"radio\" name=\"Qbank-Answer-Button-Group\" onclick=\"answerChanged(" + string4 + ")\" " + (string4.equals(str) ? "checked=\"checked\"" : "") + "></td><td class=\"answerOptionNumber\"><span>" + m4219G4(string4) + ". </span></td><td><span id=\"AnswerText" + string4 + "\" onclick=\"answerClickedForStrikeout(" + string4 + ");\">" + m5015B2 + "</span></td></tr>");
        }
        this.f75847Z3 = ViewerHelperFragment.m4108a4(ViewerHelperFragment.m4108a4(m4108a42, "[Answers]", sb2.toString()), "highresdefault/", "highresdefault_");
        m4215K4();
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: K3 */
    public Boolean mo4135K3(String str) {
        CompressHelper compressHelper = this.f75863p4;
        String m4972P0 = compressHelper.m4972P0();
        StringBuilder sb = new StringBuilder();
        sb.append("select * from favorites where dbName='");
        sb.append(this.f75863p4.m4963S0(this.f75850c4.getString("Name")));
        sb.append("' AND (dbAddress='");
        sb.append(this.f75863p4.m4963S0(str));
        sb.append("' OR dbAddress='question-");
        sb.append(this.f75863p4.m4963S0(str));
        sb.append("' OR dbAddress='answer-");
        sb.append(this.f75863p4.m4963S0(str));
        sb.append("')");
        return compressHelper.m4907i1(compressHelper.m4946Y(m4972P0, sb.toString())) == null ? Boolean.FALSE : Boolean.TRUE;
    }

    /* renamed from: K4 */
    public void m4215K4() {
        File file = new File(CompressHelper.m4945Y0(this.f75850c4, "base"));
        this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
        String str = this.f75852e4;
        if (str != null) {
            this.f75858k4.setTitle(str);
            m4101e4(this.f75852e4);
            m4130O2();
        }
        mo3978f4();
        m4096h4(this.f75858k4.getMenu());
        m4210P4();
    }

    /* renamed from: L4 */
    public void m4214L4(String str) {
        String str2;
        String string = this.f75688B4.get(this.f75689C4).getString("id");
        String string2 = this.f75688B4.get(this.f75689C4).getString("corrAns");
        Date date = new Date();
        String m4220F4 = m4220F4(date);
        long time = (date.getTime() - this.f75691E4.getTime()) / 1000;
        Bundle bundle = this.f75690D4;
        String string3 = bundle != null ? bundle.getString("id") : "null";
        ArrayList<Bundle> m4955V = this.f75863p4.m4955V(this.f75850c4, "Select * from logs where testId=" + string3 + " AND qid = " + string);
        if (m4955V == null || m4955V.size() <= 0) {
            str2 = "Insert into logs (id, qid, selectedAnswer, corrAnswer, answerDate, time, testId) values (null, " + string + ", " + str + ", " + string2 + ", '" + str + "', " + time + ", " + string3 + ")";
        } else {
            str2 = "Update logs set selectedAnswer = " + str + ", answerDate='" + m4220F4 + "', time=" + time + " where id=" + m4955V.get(0).getString("id");
        }
        this.f75863p4.m4897m(this.f75850c4, str2);
    }

    /* renamed from: M4 */
    public String m4213M4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }

    /* renamed from: O4 */
    public void m4211O4() {
        try {
            String m4117W3 = m4117W3(m44716w(), "LXHeader.css");
            String m4117W32 = m4117W3(m44716w(), "LXFooter.css");
            String replace = m4117W3.replace("[size]", "200").replace("[title]", this.f75852e4).replace("[include]", "");
            Iterator it2 = this.f75863p4.m5000G(new JSONObject(m4117W3(m44716w(), "l.json"))).getParcelableArrayList("USMLE").iterator();
            String str = "";
            int i = 0;
            while (it2.hasNext()) {
                Bundle bundle = (Bundle) it2.next();
                i++;
                str = str + m4218H4(bundle.getString("name"), bundle.getString("content").replace("display:none", ""), i + "");
            }
            String str2 = replace + str + m4117W32;
            Bundle bundle2 = new Bundle();
            bundle2.putBundle("DB", this.f75850c4);
            bundle2.putString("URL", "html-Lab Values,,,,," + str2);
            bundle2.putString("Dialog", IcyHeaders.f35463C2);
            AMHTMLViewerFragment aMHTMLViewerFragment = new AMHTMLViewerFragment();
            aMHTMLViewerFragment.m44751k2(bundle2);
            GeneralDialogFragment generalDialogFragment = new GeneralDialogFragment(aMHTMLViewerFragment);
            this.f75696z4 = generalDialogFragment;
            generalDialogFragment.m44870c3(true);
            this.f75696z4.m44844E2(this, 0);
            this.f75696z4.mo29915h3(m44820L(), "AMSectionsViewer");
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            iMDLogger.m3294f("LXViewer", "Error in reading LXHeader and LXFooter : " + e.getLocalizedMessage());
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4213M4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f75694x4 = arrayList;
            mo3978f4();
        } else if (split[0].equals("answer")) {
            String str4 = split[1];
            m4214L4(str4);
            Bundle bundle = this.f75690D4;
            if (bundle == null || !bundle.getString("mode").equals("Testing")) {
                m4217I4(str4, true);
            }
        }
        return super.mo3571P3(consoleMessage);
    }

    /* renamed from: P4 */
    public void m4210P4() {
        this.f75839R3.findItem(C4804R.C4808id.f86795action_stop).setVisible(false);
        if (this.f75690D4 != null) {
            this.f75839R3.findItem(C4804R.C4808id.f86795action_stop).setVisible(true);
        }
        m4207z4();
        m4225A4();
        if (this.f75689C4 <= 0) {
            m4209x4();
        }
        if (this.f75689C4 >= this.f75688B4.size() - 1) {
            m4208y4();
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return null;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:onBodyLoad();");
        String str2 = this.f75692F4;
        if (str2 != null) {
            mo4144C3(str2);
            this.f75692F4 = null;
        }
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        try {
            String str = this.f75847Z3;
            if (str == null || str.length() == 0) {
                m4098g4();
                m44735q2(false);
                if (this.f75850c4.getString("Name").toLowerCase(Locale.ROOT).contains("uworld")) {
                    m4100f3(C4804R.C4811menu.f87407uworld_test_uworld);
                } else {
                    m4100f3(C4804R.C4811menu.f87406uworld_test);
                }
                m4140G3();
                iMDLogger.m3294f("Loading Document", this.f75851d4);
                if (this.f75851d4.contains("-")) {
                    String[] split = this.f75851d4.split("-");
                    if (split[0].equals("test")) {
                        CompressHelper compressHelper = this.f75863p4;
                        Bundle bundle2 = this.f75850c4;
                        this.f75690D4 = compressHelper.m4907i1(compressHelper.m4955V(bundle2, "Select * from tests where id =" + split[1]));
                        CompressHelper compressHelper2 = this.f75863p4;
                        Bundle bundle3 = this.f75850c4;
                        this.f75688B4 = compressHelper2.m4955V(bundle3, "Select * from Questions where id in (" + this.f75690D4.getString("qIds") + ")");
                        this.f75689C4 = Integer.valueOf(this.f75690D4.getString("qIndex")).intValue();
                        if (m44859B().containsKey("gotoQIndex")) {
                            this.f75689C4 = m44859B().getInt("gotoQIndex");
                        }
                    } else if (split[0].equals("question")) {
                        CompressHelper compressHelper3 = this.f75863p4;
                        Bundle bundle4 = this.f75850c4;
                        this.f75688B4 = compressHelper3.m4955V(bundle4, "Select * from Questions where id=" + split[1]);
                        this.f75689C4 = 0;
                    } else if (split[0].equals("answer")) {
                        CompressHelper compressHelper4 = this.f75863p4;
                        Bundle bundle5 = this.f75850c4;
                        this.f75688B4 = compressHelper4.m4955V(bundle5, "Select * from Questions where id=" + split[1]);
                        this.f75689C4 = 0;
                        m4217I4(null, false);
                    }
                } else {
                    this.f75688B4 = this.f75863p4.m4955V(this.f75850c4, m44859B().getString("Query"));
                    this.f75689C4 = m44859B().getInt("QuestionIndex");
                }
                m4216J4();
            }
            m4087m3();
            m4092j4();
        } catch (Exception e) {
            m4080r4(e);
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int i;
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86771action_favorites) {
            new Bundle();
            String str = "Question " + this.f75688B4.get(this.f75689C4).getString("id") + " - " + this.f75688B4.get(this.f75689C4).getString("title");
            if (menuItem.getTitle().equals("Add Favorite")) {
                m4132N2(str, mo4079s3());
                menuItem.setTitle("Remove Favorite");
                i = C4804R.C4807drawable.f86584ic_action_favorite_yellow;
            } else {
                mo4084p3(mo4079s3());
                menuItem.setTitle("Add Favorite");
                i = C4804R.C4807drawable.f86582ic_action_favorite;
            }
            menuItem.setIcon(i);
            return true;
        } else if (itemId == C4804R.C4808id.f86944lab_values) {
            m4211O4();
            return true;
        } else if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4212N4("asdfafdsaf");
            return true;
        } else {
            if (itemId == C4804R.C4808id.f86780action_previous) {
                this.f75689C4--;
                m4216J4();
                m4210P4();
            }
            if (itemId == C4804R.C4808id.f86778action_next) {
                this.f75689C4++;
                m4216J4();
                m4210P4();
                if (this.f75690D4 != null) {
                    this.f75863p4.m4897m(this.f75850c4, "Update tests set qIndex=" + this.f75689C4 + " where id=" + this.f75690D4.getString("id"));
                }
            }
            if (itemId == C4804R.C4808id.f86795action_stop) {
                new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Do you want to END this test ?").mo26266y("Yes", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestViewerActivityFragment.4
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        UWTestViewerActivityFragment uWTestViewerActivityFragment = UWTestViewerActivityFragment.this;
                        if (uWTestViewerActivityFragment.f75690D4 == null) {
                            return;
                        }
                        CompressHelper compressHelper = uWTestViewerActivityFragment.f75863p4;
                        Bundle bundle = uWTestViewerActivityFragment.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select questions.id,pplTaken,corrTaken,title,selectedAnswer,corrAnswer,time  from Questions left outer join (select * from logs where testId=" + UWTestViewerActivityFragment.this.f75690D4.getString("id") + ") as logs2 on questions.id=logs2.qid where questions.id in (" + UWTestViewerActivityFragment.this.f75690D4.getString("qIds") + ")");
                        Iterator<Bundle> it2 = m4955V.iterator();
                        float f = 0.0f;
                        while (it2.hasNext()) {
                            Bundle next = it2.next();
                            if (next.getString("selectedAnswer").length() != 0 && next.getString("selectedAnswer").equals(next.getString("corrAnswer"))) {
                                f += 1.0f;
                            }
                        }
                        int size = (int) ((f / m4955V.size()) * 100.0f);
                        UWTestViewerActivityFragment uWTestViewerActivityFragment2 = UWTestViewerActivityFragment.this;
                        CompressHelper compressHelper2 = uWTestViewerActivityFragment2.f75863p4;
                        Bundle bundle2 = uWTestViewerActivityFragment2.f75850c4;
                        compressHelper2.m4897m(bundle2, "Update tests set score='" + size + "', done=1 where id=" + UWTestViewerActivityFragment.this.f75690D4.getString("id"));
                        UWTestViewerActivityFragment uWTestViewerActivityFragment3 = UWTestViewerActivityFragment.this;
                        CompressHelper compressHelper3 = uWTestViewerActivityFragment3.f75863p4;
                        Bundle bundle3 = uWTestViewerActivityFragment3.f75850c4;
                        compressHelper3.m4883q1(bundle3, "testresult-" + UWTestViewerActivityFragment.this.f75690D4.getString("id"), null, null);
                    }
                }).mo26284p("No", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.UWTestViewerActivityFragment.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                    }
                }).m52864I();
            }
            return super.mo3709e1(menuItem);
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: m4 */
    public boolean mo3567m4() {
        return false;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p3 */
    public void mo4084p3(String str) {
        CompressHelper compressHelper = this.f75863p4;
        String m4972P0 = compressHelper.m4972P0();
        compressHelper.m4885q(m4972P0, "delete from favorites where dbName='" + this.f75863p4.m4963S0(this.f75850c4.getString("Name")) + "' AND (dbAddress='" + this.f75863p4.m4963S0(str) + "' OR dbAddress='question-" + this.f75863p4.m4963S0(str) + "' OR dbAddress='answer-" + this.f75863p4.m4963S0(str) + "')");
        m4104c4();
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        String str4;
        if (str2.equals("image")) {
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "/");
            m4212N4(splitByWholeSeparator[splitByWholeSeparator.length - 1]);
            return true;
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        if (str3.contains("USMLEWorld-Question-Answer-Changed")) {
            this.f75853f4.loadUrl("javascript:console.log(\"answer,,,,,\" + prevAnswerID);");
            return true;
        } else if (str3.contains("/2323")) {
            m4212N4("soheilvb");
            return true;
        } else {
            if (str2.equals(Annotation.f59806M2)) {
                String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str3, "/");
                String str5 = splitByWholeSeparator2[splitByWholeSeparator2.length - 1];
                if (str5.endsWith(".html")) {
                    try {
                        str4 = FileUtils.readFileToString(new File(CompressHelper.m4942Z0(this.f75850c4, str5, "base")));
                    } catch (Exception unused) {
                        str4 = "";
                    }
                    Bundle bundle = new Bundle();
                    bundle.putBundle("DB", this.f75850c4);
                    bundle.putString("URL", "html-UWORLD,,,,," + str4);
                    bundle.putString("Dialog", IcyHeaders.f35463C2);
                    AMHTMLViewerFragment aMHTMLViewerFragment = new AMHTMLViewerFragment();
                    aMHTMLViewerFragment.m44751k2(bundle);
                    GeneralDialogFragment generalDialogFragment = new GeneralDialogFragment(aMHTMLViewerFragment);
                    this.f75696z4 = generalDialogFragment;
                    generalDialogFragment.m44870c3(true);
                    this.f75696z4.m44844E2(this, 0);
                    this.f75696z4.mo29915h3(m44820L(), "AMSectionsViewer");
                    return true;
                }
                m4212N4(str5);
            }
            return true;
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: s3 */
    public String mo4079s3() {
        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(this.f75851d4, "-");
        return splitByWholeSeparator.length > 1 ? splitByWholeSeparator[1] : this.f75851d4;
    }

    /* renamed from: x4 */
    public void m4209x4() {
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setEnabled(false);
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setIcon(C4804R.C4807drawable.f86590ic_action_previous_item_disabled);
    }

    /* renamed from: y4 */
    public void m4208y4() {
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setEnabled(false);
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setIcon(C4804R.C4807drawable.f86587ic_action_next_item_disabled);
    }

    /* renamed from: z4 */
    public void m4207z4() {
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setEnabled(true);
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setIcon(C4804R.C4807drawable.f86588ic_action_previous_item);
    }
}
