package net.imedicaldoctor.imd.Fragments.UWorld;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextCheckViewHolder;

/* loaded from: classes2.dex */
public class CheckDialog extends DialogFragment {

    /* renamed from: g4 */
    ArrayList<Integer> f75572g4;

    /* renamed from: h4 */
    RecyclerView f75573h4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87167fragment_new_check_viewer, (ViewGroup) null);
        this.f75573h4 = (RecyclerView) inflate.findViewById(C4804R.C4808id.f87001recycler_view);
        ArrayList parcelableArrayList = m44859B().getParcelableArrayList("Items");
        String string = m44859B().getString("TitleProperty");
        this.f75572g4 = m44859B().containsKey("Positions") ? m44859B().getIntegerArrayList("Positions") : new ArrayList<>();
        this.f75573h4.setAdapter(new ChaptersAdapter(m44716w(), parcelableArrayList, string, C4804R.C4810layout.f87263list_view_item_ripple_text_check) { // from class: net.imedicaldoctor.imd.Fragments.UWorld.CheckDialog.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, final int i) {
                ImageView imageView;
                int i2;
                RippleTextCheckViewHolder rippleTextCheckViewHolder = (RippleTextCheckViewHolder) viewHolder;
                if (CheckDialog.this.f75572g4.contains(Integer.valueOf(i))) {
                    imageView = rippleTextCheckViewHolder.f83272K;
                    i2 = 0;
                } else {
                    imageView = rippleTextCheckViewHolder.f83272K;
                    i2 = 8;
                }
                imageView.setVisibility(i2);
                rippleTextCheckViewHolder.f83270I.setText(bundle2.getString(this.f83217f));
                rippleTextCheckViewHolder.f83271J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.CheckDialog.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CheckDialog.this.m4257j3(bundle2, i);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new RippleTextCheckViewHolder(view);
            }
        });
        this.f75573h4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
        this.f75573h4.m42923n(new DividerItemDecoration(m44716w(), 1));
        ((Button) inflate.findViewById(C4804R.C4808id.f86876done_button)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UWorld.CheckDialog.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CheckDialog.this.mo27002R2();
                if (CheckDialog.this.m44753k0() instanceof UWMainActivityFragment) {
                    ((UWMainActivityFragment) CheckDialog.this.m44753k0()).m4242w3(CheckDialog.this.m44859B().getString("Type"), CheckDialog.this.f75572g4);
                }
            }
        });
        builder.setView(inflate);
        return builder.create();
    }

    /* renamed from: j3 */
    public void m4257j3(Bundle bundle, int i) {
        if (this.f75572g4.contains(Integer.valueOf(i))) {
            this.f75572g4.remove(Integer.valueOf(i));
            if (this.f75572g4.size() == 0) {
                this.f75572g4.add(0);
                this.f75573h4.getAdapter().m42859H(0);
            }
        } else {
            if (i == 0) {
                this.f75572g4 = new ArrayList<>();
                this.f75573h4.getAdapter().m42860G();
            } else if (this.f75572g4.contains(0)) {
                this.f75572g4.remove((Object) 0);
                this.f75573h4.getAdapter().m42859H(0);
            }
            this.f75572g4.add(Integer.valueOf(i));
        }
        this.f75573h4.getAdapter().m42859H(i);
    }
}
