package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class MMNeoListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f75025b4;

    /* renamed from: c4 */
    public String f75026c4;

    /* renamed from: d4 */
    public TabLayout f75027d4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87169fragment_new_list_tab, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f75027d4 = (TabLayout) this.f75221R3.findViewById(C4804R.C4808id.f87042tabs);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            str = null;
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoListActivityFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            str = m44859B().getString("ParentId");
        }
        this.f75026c4 = str;
        if (this.f75026c4 == null) {
            this.f75218O3 = this.f75215L3.m4955V(this.f75212I3, "SELECT * FROM drug_class_idx order by title collate nocase asc");
            this.f75027d4.setVisibility(0);
        } else {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle2 = this.f75212I3;
            this.f75218O3 = compressHelper.m4955V(bundle2, "select drug_class_int.name as title, drug_class_int.drug_Id as drug_id ,genericTitle as subtitle from drug_class_int inner join (select drug_id as generic_id, name as genericTitle from drug_idx where has_generic=0) on drug_class_int.drug_id =generic_id where class_id=" + this.f75026c4 + " order by drug_class_int.name collate nocase asc");
            this.f75027d4.setVisibility(8);
            CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) this.f75227X3.getLayoutParams();
            layoutParams.setMargins(0, 0, 0, 0);
            this.f75227X3.setLayoutParams(layoutParams);
        }
        String[] strArr = {"Drugs", "Enteral Formulas"};
        for (int i = 0; i < 2; i++) {
            TabLayout.Tab m24950D = this.f75027d4.m24950D();
            m24950D.m24890D(strArr[i]);
            this.f75027d4.m24926e(m24950D);
        }
        this.f75027d4.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoListActivityFragment.2
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: a */
            public void mo4174a(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: b */
            public void mo4173b(TabLayout.Tab tab) {
                MMNeoListActivityFragment mMNeoListActivityFragment;
                CompressHelper compressHelper2;
                Bundle bundle3;
                String str2;
                if (tab.m24878k() == 0) {
                    mMNeoListActivityFragment = MMNeoListActivityFragment.this;
                    compressHelper2 = mMNeoListActivityFragment.f75215L3;
                    bundle3 = mMNeoListActivityFragment.f75212I3;
                    str2 = "SELECT * FROM drug_class_idx order by title collate nocase asc";
                } else {
                    mMNeoListActivityFragment = MMNeoListActivityFragment.this;
                    compressHelper2 = mMNeoListActivityFragment.f75215L3;
                    bundle3 = mMNeoListActivityFragment.f75212I3;
                    str2 = "SELECT * FROM formula_idx order by title collate nocase asc";
                }
                mMNeoListActivityFragment.f75218O3 = compressHelper2.m4955V(bundle3, str2);
                if (MMNeoListActivityFragment.this.f75223T3.getQuery().toString().length() > 0) {
                    MMNeoListActivityFragment mMNeoListActivityFragment2 = MMNeoListActivityFragment.this;
                    mMNeoListActivityFragment2.f75219P3 = mMNeoListActivityFragment2.mo3981d3(mMNeoListActivityFragment2.f75223T3.getQuery().toString());
                    MMNeoListActivityFragment.this.mo3982a3();
                    return;
                }
                MMNeoListActivityFragment mMNeoListActivityFragment3 = MMNeoListActivityFragment.this;
                ((ChaptersAdapter) mMNeoListActivityFragment3.f75216M3).m3404g0(mMNeoListActivityFragment3.f75218O3);
                MMNeoListActivityFragment mMNeoListActivityFragment4 = MMNeoListActivityFragment.this;
                mMNeoListActivityFragment4.f75227X3.setAdapter(mMNeoListActivityFragment4.f75216M3);
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: c */
            public void mo4172c(TabLayout.Tab tab) {
            }
        });
        this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle3, final int i2) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle3.getString("title"));
                String string = bundle3.getString("subtitle");
                if (bundle3.getString("title").equals(string) || string == null || string.length() == 0) {
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                } else {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                    rippleTextFullViewHolder.f83285J.setText(string);
                }
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoListActivityFragment.3.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        MMNeoListActivityFragment.this.m4404l3(bundle3, i2);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f75025b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoListActivityFragment.4
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle3, int i2) {
                TextView textView;
                int i3;
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle3.getString("text"));
                rippleTextFullViewHolder.f83285J.setText(bundle3.getString("content"));
                if (bundle3.getString("content").equals(bundle3.getString("text")) || bundle3.getString("content").length() == 0) {
                    textView = rippleTextFullViewHolder.f83285J;
                    i3 = 8;
                } else {
                    textView = rippleTextFullViewHolder.f83285J;
                    i3 = 0;
                }
                textView.setVisibility(i3);
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoListActivityFragment.4.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CompressHelper compressHelper2;
                        Bundle bundle4;
                        StringBuilder sb;
                        String str2;
                        MMNeoListActivityFragment.this.m4330Y2();
                        if (bundle3.getString("typeText").equals("Drug")) {
                            MMNeoListActivityFragment mMNeoListActivityFragment = MMNeoListActivityFragment.this;
                            compressHelper2 = mMNeoListActivityFragment.f75215L3;
                            bundle4 = mMNeoListActivityFragment.f75212I3;
                            sb = new StringBuilder();
                            str2 = "drug-";
                        } else {
                            MMNeoListActivityFragment mMNeoListActivityFragment2 = MMNeoListActivityFragment.this;
                            compressHelper2 = mMNeoListActivityFragment2.f75215L3;
                            bundle4 = mMNeoListActivityFragment2.f75212I3;
                            sb = new StringBuilder();
                            str2 = "formula-";
                        }
                        sb.append(str2);
                        sb.append(bundle3.getString("contentId"));
                        compressHelper2.m4883q1(bundle4, sb.toString(), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle3) {
                MMNeoListActivityFragment.this.m4330Y2();
                MMNeoListActivityFragment.this.f75223T3.m51655i0(bundle3.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75025b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f75025b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper;
        Bundle bundle;
        StringBuilder sb;
        String str2;
        if (this.f75027d4.getSelectedTabPosition() == 0) {
            compressHelper = this.f75215L3;
            bundle = this.f75212I3;
            sb = new StringBuilder();
            sb.append("Select * from search where search match '(text:");
            sb.append(str);
            sb.append("* OR content:");
            sb.append(str);
            str2 = "*) AND type:1 AND typeText:Drug'";
        } else {
            compressHelper = this.f75215L3;
            bundle = this.f75212I3;
            sb = new StringBuilder();
            sb.append("Select * from search where search match '(text:");
            sb.append(str);
            sb.append("* OR content:");
            sb.append(str);
            str2 = "*) AND type:1 AND typeText:Formula'";
        }
        sb.append(str2);
        return compressHelper.m4952W(bundle, sb.toString(), "fsearch.sqlite");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4952W(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'", "fsearch.sqlite");
    }

    /* renamed from: l3 */
    public void m4404l3(Bundle bundle, int i) {
        CompressHelper compressHelper;
        Bundle bundle2;
        StringBuilder sb;
        String str;
        m4330Y2();
        if (this.f75026c4 != null) {
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            sb = new StringBuilder();
            sb.append("drug-");
            str = "drug_id";
        } else if (this.f75027d4.getSelectedTabPosition() == 0) {
            Bundle bundle3 = new Bundle();
            bundle3.putBundle("DB", this.f75212I3);
            bundle3.putString("ParentId", bundle.getString("class_id"));
            this.f75215L3.m4979N(MMNeoListActivity.class, MMNeoListActivityFragment.class, bundle3);
            return;
        } else {
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            sb = new StringBuilder();
            sb.append("formula-");
            str = "formula_id";
        }
        sb.append(bundle.getString(str));
        compressHelper.m4883q1(bundle2, sb.toString(), null, null);
    }
}
