package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MMNeoViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f75038w4;

    /* renamed from: x4 */
    public ArrayList<String> f75039x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75040y4;

    /* renamed from: z4 */
    public int f75041z4;

    /* renamed from: D4 */
    private void m4400D4(String str) {
        ArrayList<String> arrayList = this.f75039x4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f75039x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", next);
            bundle.putString("Description", "");
            bundle.putString("id", next);
            if (new File(next).length() > 5000) {
                arrayList2.add(bundle);
            }
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public String m4403A4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75041z4 + 1;
        this.f75041z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: B4 */
    public String m4402B4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75041z4 + 1;
        this.f75041z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded2\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded2(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: C4 */
    public String m4401C4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4401C4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f75039x4 = arrayList;
            mo3978f4();
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return m4071w3(this.f75039x4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                String str;
                Iterator<Bundle> it2;
                Bundle next;
                try {
                    String str2 = MMNeoViewerActivityFragment.this.f75847Z3;
                    if (str2 == null || str2.length() == 0) {
                        iMDLogger.m3294f("Loading Document", MMNeoViewerActivityFragment.this.f75851d4);
                        String[] split = MMNeoViewerActivityFragment.this.f75851d4.split("-");
                        MMNeoViewerActivityFragment.this.f75040y4 = new ArrayList<>();
                        MMNeoViewerActivityFragment.this.f75041z4 = 0;
                        if (split[0].equals("drug")) {
                            MMNeoViewerActivityFragment mMNeoViewerActivityFragment = MMNeoViewerActivityFragment.this;
                            ArrayList<Bundle> m4955V = mMNeoViewerActivityFragment.f75863p4.m4955V(mMNeoViewerActivityFragment.f75850c4, "Select * from drug_idx where drug_id=" + split[1] + " and has_generic=0");
                            if (m4955V != null && m4955V.size() != 0) {
                                MMNeoViewerActivityFragment.this.f75038w4 = m4955V.get(0);
                                MMNeoViewerActivityFragment mMNeoViewerActivityFragment2 = MMNeoViewerActivityFragment.this;
                                mMNeoViewerActivityFragment2.f75852e4 = mMNeoViewerActivityFragment2.f75038w4.getString("name");
                                MMNeoViewerActivityFragment mMNeoViewerActivityFragment3 = MMNeoViewerActivityFragment.this;
                                ArrayList<Bundle> m4955V2 = mMNeoViewerActivityFragment3.f75863p4.m4955V(mMNeoViewerActivityFragment3.f75850c4, "select drug_section.title as sectionTitle, drug_sub_section.title as subSectionTitle, monograph from (drug_mono inner join drug_sub_section on drug_sub_section.sub_section_id=drug_mono.sub_section_id) inner join drug_section on drug_section.section_id=drug_sub_section.section_id where drug_id=" + split[1] + " AND monograph<>'' AND drug_section.section_id<>0 order by drug_section.section_id, drug_sub_section.sub_section_id");
                                if (m4955V2 == null) {
                                    m4955V2 = new ArrayList<>();
                                }
                                Iterator<Bundle> it3 = m4955V2.iterator();
                                str = "";
                                while (it3.hasNext()) {
                                    str = str + MMNeoViewerActivityFragment.this.m4403A4(next.getString("sectionTitle"), "", "LTR", next.getString("monograph"), "", "margin-left:10px;margin-top:5px", "");
                                    MMNeoViewerActivityFragment.this.m4399x4(it3.next().getString("sectionTitle"), MMNeoViewerActivityFragment.this.f75041z4);
                                }
                            }
                            MMNeoViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                            return;
                        } else if (split[0].equals("formula")) {
                            MMNeoViewerActivityFragment mMNeoViewerActivityFragment4 = MMNeoViewerActivityFragment.this;
                            ArrayList<Bundle> m4955V3 = mMNeoViewerActivityFragment4.f75863p4.m4955V(mMNeoViewerActivityFragment4.f75850c4, "Select * from formula_idx where formula_id=" + split[1]);
                            if (m4955V3 != null && m4955V3.size() != 0) {
                                MMNeoViewerActivityFragment.this.f75038w4 = m4955V3.get(0);
                                MMNeoViewerActivityFragment mMNeoViewerActivityFragment5 = MMNeoViewerActivityFragment.this;
                                mMNeoViewerActivityFragment5.f75852e4 = mMNeoViewerActivityFragment5.f75038w4.getString("title");
                                MMNeoViewerActivityFragment mMNeoViewerActivityFragment6 = MMNeoViewerActivityFragment.this;
                                ArrayList<Bundle> m4955V4 = mMNeoViewerActivityFragment6.f75863p4.m4955V(mMNeoViewerActivityFragment6.f75850c4, "SELECT (  CASE WHEN (fs.sorter = 0) THEN '<th>'  WHEN (fs.sorter % 2 != 0) THEN '<tr class=\"\"odd\"\"><td>'   ELSE '<tr><td>' END ||   fs.value ||   CASE WHEN (fs.sorter = 0) THEN '</th><th>' ELSE '</td><td>' END || (CASE WHEN (ft.per_100_cal_value = '') THEN '&nbsp;' ELSE ft.per_100_cal_value END) || CASE WHEN (fs.sorter = 0) THEN '</th><th>' ELSE '</td><td>' END || (CASE WHEN (ft.per_liter_value = '') THEN '&nbsp;' ELSE ft.per_liter_value END) || CASE WHEN (fs.sorter = 0) THEN '</th>'  ELSE '</td></tr>' END  ) formatted_formula_data FROM formula_table ft, formula_section fs WHERE formula_id = " + split[1] + " AND ft.section_id = fs.section_id ORDER BY fs.sorter");
                                MMNeoViewerActivityFragment mMNeoViewerActivityFragment7 = MMNeoViewerActivityFragment.this;
                                ArrayList<Bundle> m4955V5 = mMNeoViewerActivityFragment7.f75863p4.m4955V(mMNeoViewerActivityFragment7.f75850c4, "SELECT ((CASE note_id WHEN 5 THEN X'e280a0' || ' Protein Source: ' WHEN 6 THEN X'e280a1' || ' Fat Source: ' WHEN 7 THEN X'c2a7' || ' Carbohydrate Source: ' ELSE '' END) || value) as formatted_product_note FROM product_notes WHERE formula_id = " + split[1] + "  AND note_id != 1 ORDER BY note_id");
                                String str3 = "";
                                while (m4955V4.iterator().hasNext()) {
                                    str3 = str3 + it2.next().getString("formatted_formula_data");
                                }
                                String str4 = "<table>" + str3 + "</table>";
                                Iterator<Bundle> it4 = m4955V5.iterator();
                                String str5 = "";
                                while (it4.hasNext()) {
                                    str5 = str5 + it4.next().getString("formatted_product_note");
                                }
                                MMNeoViewerActivityFragment mMNeoViewerActivityFragment8 = MMNeoViewerActivityFragment.this;
                                mMNeoViewerActivityFragment8.m4399x4("Table", mMNeoViewerActivityFragment8.f75041z4);
                                str = ("" + MMNeoViewerActivityFragment.this.m4403A4("Table", "", "LTR", str4, "", "margin-left:10px;margin-top:5px", "")) + MMNeoViewerActivityFragment.this.m4403A4("Product Notes", "", "LTR", str5, "", "margin-left:10px;margin-top:5px", "");
                                MMNeoViewerActivityFragment mMNeoViewerActivityFragment9 = MMNeoViewerActivityFragment.this;
                                mMNeoViewerActivityFragment9.m4399x4("Product Notes", mMNeoViewerActivityFragment9.f75041z4);
                            }
                            MMNeoViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                            return;
                        } else {
                            str = "";
                        }
                        MMNeoViewerActivityFragment mMNeoViewerActivityFragment10 = MMNeoViewerActivityFragment.this;
                        String m4117W3 = mMNeoViewerActivityFragment10.m4117W3(mMNeoViewerActivityFragment10.m44716w(), "MMHeader.css");
                        MMNeoViewerActivityFragment mMNeoViewerActivityFragment11 = MMNeoViewerActivityFragment.this;
                        String m4117W32 = mMNeoViewerActivityFragment11.m4117W3(mMNeoViewerActivityFragment11.m44716w(), "MMFooter.css");
                        String replace = m4117W3.replace("[size]", "200").replace("[title]", MMNeoViewerActivityFragment.this.f75852e4).replace("[include]", "");
                        MMNeoViewerActivityFragment.this.f75847Z3 = replace + str + m4117W32;
                    }
                    MMNeoViewerActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    MMNeoViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = MMNeoViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    MMNeoViewerActivityFragment mMNeoViewerActivityFragment = MMNeoViewerActivityFragment.this;
                    mMNeoViewerActivityFragment.m4078s4(mMNeoViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4945Y0(MMNeoViewerActivityFragment.this.f75850c4, "base"));
                MMNeoViewerActivityFragment mMNeoViewerActivityFragment2 = MMNeoViewerActivityFragment.this;
                mMNeoViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", mMNeoViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                MMNeoViewerActivityFragment.this.m4092j4();
                MMNeoViewerActivityFragment.this.m4098g4();
                MMNeoViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                MMNeoViewerActivityFragment.this.m44735q2(false);
                MMNeoViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4400D4("asdfafdsaf");
            return true;
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f75040y4);
            bundle.putString("TitleProperty", "label");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        if (str2.equals("image")) {
            m4400D4(str3);
            return true;
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public void m4399x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f75040y4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4398y4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75041z4 + 1;
        this.f75041z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded3\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded3(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: z4 */
    public String m4397z4(String str, String str2, String str3, String str4) {
        int i = this.f75041z4 + 1;
        this.f75041z4 = i;
        String valueOf = String.valueOf(i);
        return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
    }
}
