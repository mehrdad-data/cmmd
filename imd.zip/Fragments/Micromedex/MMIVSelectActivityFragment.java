package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.extractor.p010ts.TsExtractor;
import com.google.android.material.appbar.AppBarLayout;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.ObservableEmitter;
import io.reactivex.rxjava3.core.ObservableOnSubscribe;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullDeleteViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MMIVSelectActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74954b4;

    /* renamed from: c4 */
    public ArrayList<Bundle> f74955c4;

    /* renamed from: d4 */
    public Button f74956d4;

    /* renamed from: e4 */
    public ArrayList<String> f74957e4;

    /* renamed from: f4 */
    public ArrayList<Bundle> f74958f4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87149fragment_epointeract, viewGroup, false);
        this.f74955c4 = new ArrayList<>();
        this.f74957e4 = new ArrayList<>();
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        appBarLayout.m27445s(false, false);
        appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                relativeLayout.setVisibility(0);
            }
        }, 800L);
        Button button = (Button) this.f75221R3.findViewById(C4804R.C4808id.f87006result_button);
        this.f74956d4 = button;
        button.setText("Please Add Drug");
        this.f74956d4.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (MMIVSelectActivityFragment.this.f74955c4.size() > 0) {
                    new Bundle().putParcelableArrayList("Items", MMIVSelectActivityFragment.this.f74955c4);
                    ArrayList arrayList = new ArrayList();
                    Iterator<Bundle> it2 = MMIVSelectActivityFragment.this.f74955c4.iterator();
                    while (it2.hasNext()) {
                        Bundle next = it2.next();
                        String string = next.getString("text");
                        String m4424m3 = MMIVSelectActivityFragment.this.m4424m3(next.getString("contentId"));
                        arrayList.add(m4424m3 + ",,,,," + string + ",,,,," + next.getString("typeText"));
                    }
                    new Bundle();
                    MMIVSelectActivityFragment mMIVSelectActivityFragment = MMIVSelectActivityFragment.this;
                    CompressHelper compressHelper = mMIVSelectActivityFragment.f75215L3;
                    Bundle bundle2 = mMIVSelectActivityFragment.f75212I3;
                    compressHelper.m4883q1(bundle2, "interactresult-" + StringUtils.join(arrayList, ";;;;;"), null, null);
                }
            }
        });
        ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f74955c4, "title", C4804R.C4810layout.f87266list_view_item_ripple_text_full_delete) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullDeleteViewHolder rippleTextFullDeleteViewHolder = (RippleTextFullDeleteViewHolder) viewHolder;
                rippleTextFullDeleteViewHolder.f83278I.setText(bundle2.getString("text"));
                rippleTextFullDeleteViewHolder.f83279J.setText(bundle2.getString("content"));
                rippleTextFullDeleteViewHolder.f83283N.setVisibility(0);
                rippleTextFullDeleteViewHolder.f83281L.setVisibility(0);
                if (bundle2.getString("content").length() == 0) {
                    rippleTextFullDeleteViewHolder.f83279J.setVisibility(8);
                } else {
                    rippleTextFullDeleteViewHolder.f83279J.setVisibility(0);
                }
                final String m4424m3 = MMIVSelectActivityFragment.this.m4424m3(bundle2.getString("contentId"));
                rippleTextFullDeleteViewHolder.f83282M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.3.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        MMIVSelectActivityFragment.this.m4330Y2();
                        ArrayList arrayList = new ArrayList();
                        String string = bundle2.getString("text");
                        String m4424m32 = MMIVSelectActivityFragment.this.m4424m3(bundle2.getString("contentId"));
                        arrayList.add(m4424m32 + ",,,,," + string + ",,,,," + bundle2.getString("typeText"));
                        new Bundle();
                        MMIVSelectActivityFragment mMIVSelectActivityFragment = MMIVSelectActivityFragment.this;
                        CompressHelper compressHelper = mMIVSelectActivityFragment.f75215L3;
                        Bundle bundle3 = mMIVSelectActivityFragment.f75212I3;
                        compressHelper.m4883q1(bundle3, "interactresult-" + StringUtils.join(arrayList, ";;;;;"), null, null);
                    }
                });
                rippleTextFullDeleteViewHolder.f83283N.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.3.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        MMIVSelectActivityFragment.this.f74955c4.remove(bundle2);
                        MMIVSelectActivityFragment.this.f74957e4.remove(m4424m3);
                        MMIVSelectActivityFragment mMIVSelectActivityFragment = MMIVSelectActivityFragment.this;
                        ((ChaptersAdapter) mMIVSelectActivityFragment.f75216M3).m3404g0(mMIVSelectActivityFragment.f74955c4);
                        MMIVSelectActivityFragment.this.m4425l3();
                        MMIVSelectActivityFragment.this.f75216M3.m42860G();
                        MMIVSelectActivityFragment mMIVSelectActivityFragment2 = MMIVSelectActivityFragment.this;
                        mMIVSelectActivityFragment2.f75227X3.setAdapter(mMIVSelectActivityFragment2.f75216M3);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                RippleTextFullDeleteViewHolder rippleTextFullDeleteViewHolder = new RippleTextFullDeleteViewHolder(view);
                rippleTextFullDeleteViewHolder.f83280K.setVisibility(8);
                return rippleTextFullDeleteViewHolder;
            }
        };
        this.f75216M3 = chaptersAdapter;
        chaptersAdapter.f83219h = "Search To Add Drug";
        this.f74954b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.4
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle2.getString("text"));
                rippleTextFullViewHolder.f83285J.setText(bundle2.getString("content"));
                rippleTextFullViewHolder.f83287L.setVisibility(8);
                if (bundle2.getString("content").length() == 0) {
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                } else {
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                }
                final String m4424m3 = MMIVSelectActivityFragment.this.m4424m3(bundle2.getString("contentId"));
                if (MMIVSelectActivityFragment.this.f74957e4.contains(m4424m3)) {
                    rippleTextFullViewHolder.f83284I.setTextColor(Color.rgb((int) TsExtractor.f35065I, (int) TsExtractor.f35065I, (int) TsExtractor.f35065I));
                    return;
                }
                rippleTextFullViewHolder.f83284I.setTextColor(Color.rgb(0, 0, 0));
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.4.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        MMIVSelectActivityFragment.this.m4330Y2();
                        MMIVSelectActivityFragment.this.f74955c4.add(bundle2);
                        MMIVSelectActivityFragment.this.f74957e4.add(m4424m3);
                        MMIVSelectActivityFragment.this.m4425l3();
                        MMIVSelectActivityFragment.this.f75223T3.m51655i0("", false);
                        MMIVSelectActivityFragment mMIVSelectActivityFragment = MMIVSelectActivityFragment.this;
                        ((ChaptersAdapter) mMIVSelectActivityFragment.f75216M3).m3404g0(mMIVSelectActivityFragment.f74955c4);
                        MMIVSelectActivityFragment.this.f75216M3.m42860G();
                        MMIVSelectActivityFragment mMIVSelectActivityFragment2 = MMIVSelectActivityFragment.this;
                        mMIVSelectActivityFragment2.f75227X3.setAdapter(mMIVSelectActivityFragment2.f75216M3);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle2) {
                MMIVSelectActivityFragment.this.m4330Y2();
                MMIVSelectActivityFragment.this.f75223T3.m51655i0(bundle2.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74954b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74954b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4952W(bundle, "Select * from search where search match 'text:" + str + "* NOT (type:5)'", "fsearch.sqlite");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4952W(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'", "fsearch.sqlite");
    }

    /* renamed from: l3 */
    public void m4425l3() {
        Observable.m7156x1(new ObservableOnSubscribe<String>() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.5
            @Override // io.reactivex.rxjava3.core.ObservableOnSubscribe
            /* renamed from: a */
            public void mo3518a(@NonNull ObservableEmitter<String> observableEmitter) throws Throwable {
                observableEmitter.onNext("asdf");
            }
        }).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7339e6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVSelectActivityFragment.6
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(String str) throws Throwable {
                ArrayList<Bundle> arrayList = MMIVSelectActivityFragment.this.f74955c4;
                if (arrayList == null || arrayList.size() == 0) {
                    MMIVSelectActivityFragment.this.f74956d4.setEnabled(false);
                    MMIVSelectActivityFragment.this.f74956d4.setBackgroundColor(Color.rgb(100, 100, 100));
                    MMIVSelectActivityFragment.this.f74956d4.setText("Please Add Drug");
                    return;
                }
                MMIVSelectActivityFragment.this.f74956d4.setText("Check Compatibility");
                MMIVSelectActivityFragment.this.f74956d4.setEnabled(true);
                MMIVSelectActivityFragment.this.f74956d4.setBackgroundColor(Color.rgb(64, 140, 83));
            }
        });
    }

    /* renamed from: m3 */
    public String m4424m3(String str) {
        return str.contains("-") ? str.split("-")[1] : str;
    }
}
