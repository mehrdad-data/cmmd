package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.exifinterface.media.ExifInterface;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MMIVViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f74974w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f74975x4;

    /* renamed from: y4 */
    public int f74976y4;

    /* renamed from: A4 */
    public String m4422A4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74976y4 + 1;
        this.f74976y4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: B4 */
    public String m4421B4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74976y4 + 1;
        this.f74976y4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded2\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded2(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: C4 */
    public String m4420C4(String str) {
        return str.equals("C") ? "iv_compat_compatible" : str.equals("I") ? "iv_compat_incompatible" : str.equals("U") ? "iv_compat_uncertain" : str.equals("N") ? "iv_compat_nottested" : str.equals(ExifInterface.f14395R4) ? "iv_compat_cautionvariable" : "";
    }

    /* renamed from: D4 */
    public String m4419D4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        String str = this.f75847Z3;
        if (str == null || str.length() == 0) {
            this.f74976y4 = 0;
            this.f74975x4 = new ArrayList<>();
            m4081r3(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVViewerActivityFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    String str2;
                    String str3;
                    MMIVViewerActivityFragment mMIVViewerActivityFragment = MMIVViewerActivityFragment.this;
                    String str4 = "";
                    mMIVViewerActivityFragment.f75847Z3 = "";
                    String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(mMIVViewerActivityFragment.f75851d4.replace("doc-", ""), ",,,");
                    if (splitByWholeSeparator[0].equals("solution")) {
                        String str5 = splitByWholeSeparator[1];
                        String str6 = splitByWholeSeparator[2];
                        String str7 = splitByWholeSeparator[3];
                        String str8 = splitByWholeSeparator[4];
                        MMIVViewerActivityFragment mMIVViewerActivityFragment2 = MMIVViewerActivityFragment.this;
                        mMIVViewerActivityFragment2.f75863p4.m4897m(mMIVViewerActivityFragment2.f75850c4, "Update app_state set value=" + str7 + ", title='" + str8 + "' where key='current_solution_id'");
                        String str9 = "margin-left:15px;";
                        MMIVViewerActivityFragment.this.f75852e4 = str6 + " - " + str8;
                        MMIVViewerActivityFragment mMIVViewerActivityFragment3 = MMIVViewerActivityFragment.this;
                        ArrayList<Bundle> m4955V = mMIVViewerActivityFragment3.f75863p4.m4955V(mMIVViewerActivityFragment3.f75850c4, "Select * from v_solution_intermediate");
                        if (m4955V == null) {
                            m4955V = new ArrayList<>();
                        }
                        Iterator<Bundle> it2 = m4955V.iterator();
                        while (it2.hasNext()) {
                            Bundle next = it2.next();
                            String str10 = next.getString("name") + " - " + next.getString("concentration");
                            if (next.getString("storage").length() > 0) {
                                str3 = "" + MMIVViewerActivityFragment.this.m4421B4("Storage", "", "LTR", next.getString("storage"), "", str9, "");
                            } else {
                                str3 = "";
                            }
                            if (next.getString("study_period").length() > 0) {
                                str3 = str3 + MMIVViewerActivityFragment.this.m4421B4("Study Period", "", "LTR", next.getString("study_period"), "", str9, "");
                            }
                            if (next.getString(TtmlNode.f38102W).length() > 0) {
                                str3 = str3 + MMIVViewerActivityFragment.this.m4421B4("Container", "", "LTR", next.getString(TtmlNode.f38102W), "", str9, "");
                            }
                            if (next.getString(CookiePolicy.BROWSER_COMPATIBILITY).length() > 0) {
                                str3 = str3 + MMIVViewerActivityFragment.this.m4421B4("Physical Compatibility", "", "LTR", next.getString(CookiePolicy.BROWSER_COMPATIBILITY), "", str9, "");
                            }
                            if (next.getString("stability").length() > 0) {
                                str3 = str3 + MMIVViewerActivityFragment.this.m4421B4("Chemical Stability", "", "LTR", next.getString("stability"), "", str9, "");
                            }
                            String str11 = str3;
                            String str12 = "<div style=\"display: flex; align-items: center\"><img src=\"" + ("file:///android_asset/" + MMIVViewerActivityFragment.this.m4420C4(next.getString("result")) + ".png") + "\" style=\"margin:2px;width: 100%%;max-width:25px\"/>" + str10 + "</div>";
                            Iterator<Bundle> it3 = it2;
                            MMIVViewerActivityFragment.this.f75847Z3 = MMIVViewerActivityFragment.this.f75847Z3 + MMIVViewerActivityFragment.this.m4422A4(str12, "", "LTR", str11, "", "margin-left:10px;margin-top:5px", "");
                            MMIVViewerActivityFragment mMIVViewerActivityFragment4 = MMIVViewerActivityFragment.this;
                            mMIVViewerActivityFragment4.m4418x4(str10, mMIVViewerActivityFragment4.f74976y4);
                            str9 = str9;
                            it2 = it3;
                        }
                        return;
                    }
                    String str13 = splitByWholeSeparator[1];
                    String str14 = splitByWholeSeparator[2];
                    String str15 = splitByWholeSeparator[3];
                    String str16 = splitByWholeSeparator[4];
                    MMIVViewerActivityFragment mMIVViewerActivityFragment5 = MMIVViewerActivityFragment.this;
                    String str17 = "stability";
                    mMIVViewerActivityFragment5.f75863p4.m4897m(mMIVViewerActivityFragment5.f75850c4, "Update app_state set value=" + str13 + ", title='" + str14 + "' where key='current_agent_id'");
                    MMIVViewerActivityFragment mMIVViewerActivityFragment6 = MMIVViewerActivityFragment.this;
                    mMIVViewerActivityFragment6.f75863p4.m4897m(mMIVViewerActivityFragment6.f75850c4, "Update app_state set value=" + str15 + ", title='" + str16 + "' where key='current_drug2_id'");
                    MMIVViewerActivityFragment mMIVViewerActivityFragment7 = MMIVViewerActivityFragment.this;
                    StringBuilder sb = new StringBuilder();
                    sb.append(str14);
                    sb.append(" - ");
                    sb.append(str16);
                    mMIVViewerActivityFragment7.f75852e4 = sb.toString();
                    MMIVViewerActivityFragment mMIVViewerActivityFragment8 = MMIVViewerActivityFragment.this;
                    ArrayList<Bundle> m4955V2 = mMIVViewerActivityFragment8.f75863p4.m4955V(mMIVViewerActivityFragment8.f75850c4, "Select * from v_drug_drug_intermediate");
                    if (m4955V2 == null) {
                        m4955V2 = new ArrayList<>();
                    }
                    Iterator<Bundle> it4 = m4955V2.iterator();
                    while (it4.hasNext()) {
                        Bundle next2 = it4.next();
                        String str18 = next2.getString("drug1_title") + StringUtils.SPACE + next2.getString("drug1_concentration") + " : " + next2.getString("drug1_vehicle") + " <br/> " + next2.getString("drug2_title") + StringUtils.SPACE + next2.getString("drug2_concentration") + " :";
                        if (next2.getString("storage").length() > 0) {
                            str2 = str4 + MMIVViewerActivityFragment.this.m4421B4("Storage", "", "LTR", next2.getString("storage"), "", "margin-left:15px;", "");
                        } else {
                            str2 = str4;
                        }
                        if (next2.getString("study_period").length() > 0) {
                            str2 = str2 + MMIVViewerActivityFragment.this.m4421B4("Study Period", "", "LTR", next2.getString("study_period"), "", "margin-left:15px;", "");
                        }
                        if (next2.getString(TtmlNode.f38102W).length() > 0) {
                            str2 = str2 + MMIVViewerActivityFragment.this.m4421B4("Container", "", "LTR", next2.getString(TtmlNode.f38102W), "", "margin-left:15px;", "");
                        }
                        if (next2.getString(CookiePolicy.BROWSER_COMPATIBILITY).length() > 0) {
                            str2 = str2 + MMIVViewerActivityFragment.this.m4421B4("Physical Compatibility", "", "LTR", next2.getString(CookiePolicy.BROWSER_COMPATIBILITY), "", "margin-left:15px;", "");
                        }
                        String str19 = str17;
                        if (next2.getString(str19).length() > 0) {
                            str2 = str2 + MMIVViewerActivityFragment.this.m4421B4("Chemical Stability", "", "LTR", next2.getString(str19), "", "margin-left:15px;", "");
                        }
                        String str20 = str2;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("<div style=\"display: flex; align-items: center\"><img src=\"");
                        sb2.append("file:///android_asset/" + MMIVViewerActivityFragment.this.m4420C4(next2.getString("result")) + ".png");
                        sb2.append("\" style=\"margin:2px;width: 100%%;max-width:25px\"/>");
                        sb2.append(str18);
                        Iterator<Bundle> it5 = it4;
                        sb2.append("</div>");
                        String sb3 = sb2.toString();
                        MMIVViewerActivityFragment.this.f75847Z3 = MMIVViewerActivityFragment.this.f75847Z3 + MMIVViewerActivityFragment.this.m4422A4(sb3, "", "LTR", str20, "", "margin-left:10px;margin-top:5px", "");
                        MMIVViewerActivityFragment mMIVViewerActivityFragment9 = MMIVViewerActivityFragment.this;
                        mMIVViewerActivityFragment9.m4418x4(str18, mMIVViewerActivityFragment9.f74976y4);
                        it4 = it5;
                        str4 = str4;
                        str17 = str19;
                    }
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVViewerActivityFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    MMIVViewerActivityFragment mMIVViewerActivityFragment = MMIVViewerActivityFragment.this;
                    String m4117W3 = mMIVViewerActivityFragment.m4117W3(mMIVViewerActivityFragment.m44716w(), "MMHeader.css");
                    MMIVViewerActivityFragment mMIVViewerActivityFragment2 = MMIVViewerActivityFragment.this;
                    String m4117W32 = mMIVViewerActivityFragment2.m4117W3(mMIVViewerActivityFragment2.m44716w(), "MMFooter.css");
                    String replace = m4117W3.replace("[size]", "200").replace("[title]", MMIVViewerActivityFragment.this.f75852e4).replace("[include]", "");
                    File file = new File(CompressHelper.m4945Y0(MMIVViewerActivityFragment.this.f75850c4, "base"));
                    MMIVViewerActivityFragment.this.f75847Z3 = replace + MMIVViewerActivityFragment.this.f75847Z3 + m4117W32;
                    MMIVViewerActivityFragment.this.m4087m3();
                    MMIVViewerActivityFragment mMIVViewerActivityFragment3 = MMIVViewerActivityFragment.this;
                    mMIVViewerActivityFragment3.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", mMIVViewerActivityFragment3.f75847Z3, "text/html", "utf-8", null);
                    MMIVViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                }
            });
            m4092j4();
        }
        m4098g4();
        m44735q2(false);
        m4140G3();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f74975x4);
            bundle.putString("TitleProperty", "label");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public void m4418x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f74975x4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4417y4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f74976y4 + 1;
        this.f74976y4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded3\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded3(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: z4 */
    public String m4416z4(String str, String str2, String str3, String str4) {
        int i = this.f74976y4 + 1;
        this.f74976y4 = i;
        String valueOf = String.valueOf(i);
        return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
    }
}
