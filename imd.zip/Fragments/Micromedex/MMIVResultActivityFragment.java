package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.tabs.TabLayout;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.ObservableEmitter;
import io.reactivex.rxjava3.core.ObservableOnSubscribe;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextImageArrowViewHolder;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MMIVResultActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public NotStickySectionAdapter f74910A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f74911B4;

    /* renamed from: C4 */
    public ArrayList<Bundle> f74912C4;

    /* renamed from: D4 */
    public ArrayList<Bundle> f74913D4;

    /* renamed from: E4 */
    public ArrayList<Bundle> f74914E4;

    /* renamed from: F4 */
    public ArrayList<Bundle> f74915F4;

    /* renamed from: G4 */
    public ArrayList<Bundle> f74916G4;

    /* renamed from: H4 */
    public TabLayout f74917H4;

    /* renamed from: I4 */
    public String f74918I4;

    /* renamed from: J4 */
    public String f74919J4;

    /* renamed from: K4 */
    public NotStickySectionAdapter f74920K4;

    /* renamed from: L4 */
    public ChaptersAdapter f74921L4;

    /* renamed from: M4 */
    public ChaptersAdapter f74922M4;

    /* renamed from: w4 */
    public RecyclerView f74923w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f74924x4;

    /* renamed from: y4 */
    public Bundle f74925y4;

    /* renamed from: z4 */
    public ArrayList<String> f74926z4;

    /* renamed from: A4 */
    public void m4432A4() {
        final ProgressDialog progressDialog = new ProgressDialog(m44716w());
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Loading");
        progressDialog.show();
        Observable.m7156x1(new ObservableOnSubscribe<String>() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.3
            @Override // io.reactivex.rxjava3.core.ObservableOnSubscribe
            /* renamed from: a */
            public void mo3518a(@NonNull ObservableEmitter<String> observableEmitter) throws Throwable {
                MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment.f74915F4 = mMIVResultActivityFragment.f75863p4.m4955V(mMIVResultActivityFragment.f75850c4, "SELECT * from v_multi_ysite_summary");
                MMIVResultActivityFragment mMIVResultActivityFragment2 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment2.f74916G4 = mMIVResultActivityFragment2.f75863p4.m4955V(mMIVResultActivityFragment2.f75850c4, "Select * from v_multi_admix_summary");
                observableEmitter.onNext("Completed");
            }
        }).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7339e6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.4
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(String str) throws Throwable {
                progressDialog.hide();
                MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment.f74921L4.m3404g0(mMIVResultActivityFragment.f74915F4);
                MMIVResultActivityFragment mMIVResultActivityFragment2 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment2.f74922M4.m3404g0(mMIVResultActivityFragment2.f74916G4);
                MMIVResultActivityFragment mMIVResultActivityFragment3 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment3.f74923w4.setAdapter(mMIVResultActivityFragment3.f74921L4);
            }
        });
    }

    /* renamed from: B4 */
    public void m4431B4() {
        final ProgressDialog progressDialog = new ProgressDialog(m44716w());
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Loading");
        progressDialog.show();
        Observable.m7156x1(new ObservableOnSubscribe<String>() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.1
            @Override // io.reactivex.rxjava3.core.ObservableOnSubscribe
            /* renamed from: a */
            public void mo3518a(@NonNull ObservableEmitter<String> observableEmitter) throws Throwable {
                MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment.f74913D4 = mMIVResultActivityFragment.f75863p4.m4955V(mMIVResultActivityFragment.f75850c4, "SELECT sol.solution_id solution_id, CASE WHEN commSol.display_name IS NULL THEN sol.title ELSE commSol.display_name END title, res.result, CASE WHEN commSol.display_name IS NULL THEN 1 ELSE 0 END grouper, CASE WHEN commSol.sorter IS NULL THEN UPPER(sol.title) ELSE commSol.sorter END sorter, 1 show_view_button FROM iv_drug_solution_idx sol LEFT JOIN lookup_common_solutions commSol ON sol.solution_id = commSol.id, sv_solution_result res, iv_mono_solution_idx msi, iv_mono_agent_int mai WHERE sol.solution_id = res.solution_id AND msi.iv_id = mai.iv_id AND sol.solution_id = mai.agent_id GROUP BY sol.solution_id UNION ALL SELECT id solution_id, display_name title, 'N' result, 0 grouper, sorter sorter, 0 show_view_button FROM lookup_common_solutions WHERE id NOT IN (SELECT solution_id FROM sv_solution_result) ORDER BY grouper, sorter");
                MMIVResultActivityFragment mMIVResultActivityFragment2 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment2.f74914E4 = mMIVResultActivityFragment2.f75863p4.m4941Z1(mMIVResultActivityFragment2.f74913D4, "grouper");
                MMIVResultActivityFragment mMIVResultActivityFragment3 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment3.f74915F4 = mMIVResultActivityFragment3.f75863p4.m4955V(mMIVResultActivityFragment3.f75850c4, "Select * from v_ysite_summary");
                MMIVResultActivityFragment mMIVResultActivityFragment4 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment4.f74916G4 = mMIVResultActivityFragment4.f75863p4.m4955V(mMIVResultActivityFragment4.f75850c4, "Select * from v_admix_summary");
                observableEmitter.onNext("Completed");
            }
        }).m7300i6(Schedulers.m5370e()).m7193t4(AndroidSchedulers.m8490e()).m7339e6(new Consumer<String>() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.2
            @Override // io.reactivex.rxjava3.functions.Consumer
            /* renamed from: a */
            public void accept(String str) throws Throwable {
                progressDialog.hide();
                MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment.f74920K4.m3388h0(mMIVResultActivityFragment.f74914E4);
                MMIVResultActivityFragment mMIVResultActivityFragment2 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment2.f74921L4.m3404g0(mMIVResultActivityFragment2.f74915F4);
                MMIVResultActivityFragment mMIVResultActivityFragment3 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment3.f74922M4.m3404g0(mMIVResultActivityFragment3.f74916G4);
                MMIVResultActivityFragment mMIVResultActivityFragment4 = MMIVResultActivityFragment.this;
                mMIVResultActivityFragment4.f74923w4.setAdapter(mMIVResultActivityFragment4.f74920K4);
            }
        });
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87171fragment_new_list_viewer_tab, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74923w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(this.f75851d4.replace("interactresult-", ""), ";;;;;");
        TabLayout tabLayout = (TabLayout) this.f75849b4.findViewById(C4804R.C4808id.f87042tabs);
        this.f74917H4 = tabLayout;
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.5
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: a */
            public void mo4174a(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: b */
            public void mo4173b(TabLayout.Tab tab) {
                RecyclerView recyclerView;
                RecyclerView.Adapter adapter;
                String charSequence = tab.m24875n().toString();
                if (charSequence.equals("Solutions")) {
                    MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                    recyclerView = mMIVResultActivityFragment.f74923w4;
                    adapter = mMIVResultActivityFragment.f74920K4;
                } else if (charSequence.equals("Y-Site")) {
                    MMIVResultActivityFragment mMIVResultActivityFragment2 = MMIVResultActivityFragment.this;
                    recyclerView = mMIVResultActivityFragment2.f74923w4;
                    adapter = mMIVResultActivityFragment2.f74921L4;
                } else if (!charSequence.equals("Admix")) {
                    return;
                } else {
                    MMIVResultActivityFragment mMIVResultActivityFragment3 = MMIVResultActivityFragment.this;
                    recyclerView = mMIVResultActivityFragment3.f74923w4;
                    adapter = mMIVResultActivityFragment3.f74922M4;
                }
                recyclerView.setAdapter(adapter);
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            /* renamed from: c */
            public void mo4172c(TabLayout.Tab tab) {
            }
        });
        if (splitByWholeSeparator.length == 1) {
            m4430x4("Solutions");
            m4430x4("Y-Site");
            m4430x4("Admix");
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(splitByWholeSeparator[0], ",,,,,");
            this.f74918I4 = splitByWholeSeparator2[0];
            this.f74919J4 = splitByWholeSeparator2[1];
            this.f75863p4.m4897m(this.f75850c4, "Update app_state set value=" + splitByWholeSeparator2[0] + ", title='" + splitByWholeSeparator2[1] + "' where key='current_agent_id'");
            this.f75852e4 = splitByWholeSeparator2[1];
            m4431B4();
            NotStickySectionAdapter notStickySectionAdapter = new NotStickySectionAdapter(m44716w(), this.f74914E4, "title", C4804R.C4810layout.f87269list_view_item_ripple_text_image_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.6
                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: f0 */
                public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                    RippleTextImageArrowViewHolder rippleTextImageArrowViewHolder = (RippleTextImageArrowViewHolder) viewHolder;
                    rippleTextImageArrowViewHolder.f83293I.setText(bundle2.getString("title"));
                    rippleTextImageArrowViewHolder.f83294J.setImageDrawable(MMIVResultActivityFragment.this.m44782a0().getDrawable(MMIVResultActivityFragment.this.m4428z4(bundle2.getString("res.result"))));
                    if (bundle2.getString("res.result").equals("N")) {
                        rippleTextImageArrowViewHolder.f83295K.setVisibility(8);
                        rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.6.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view2) {
                                CompressHelper.m4921e2(MMIVResultActivityFragment.this.m44716w(), "Not Tested", 1);
                            }
                        });
                        return;
                    }
                    rippleTextImageArrowViewHolder.f83295K.setVisibility(0);
                    rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.6.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                            mMIVResultActivityFragment.f75863p4.m4883q1(mMIVResultActivityFragment.f75850c4, "doc-solution,,," + MMIVResultActivityFragment.this.f74918I4 + ",,," + MMIVResultActivityFragment.this.f74919J4 + ",,," + bundle2.getString("solution_id") + ",,," + bundle2.getString("title"), null, null);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: i0 */
                public String mo3387i0(String str) {
                    return str.equals("0") ? "Common Solutions" : str.equals(IcyHeaders.f35463C2) ? "Other Solutions" : "";
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: k0 */
                public RecyclerView.ViewHolder mo3385k0(View view2) {
                    return new RippleTextImageArrowViewHolder(view2);
                }
            };
            this.f74920K4 = notStickySectionAdapter;
            notStickySectionAdapter.f83255i = "No Drug-Solution Combination Have Been Tested";
            ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f74915F4, "adfs", C4804R.C4810layout.f87269list_view_item_ripple_text_image_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.7
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: e0 */
                public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                    RippleTextImageArrowViewHolder rippleTextImageArrowViewHolder = (RippleTextImageArrowViewHolder) viewHolder;
                    rippleTextImageArrowViewHolder.f83293I.setText(bundle2.getString("title"));
                    rippleTextImageArrowViewHolder.f83294J.setImageDrawable(MMIVResultActivityFragment.this.m44782a0().getDrawable(MMIVResultActivityFragment.this.m4428z4(bundle2.getString("result"))));
                    if (bundle2.getString("result").equals("N")) {
                        rippleTextImageArrowViewHolder.f83295K.setVisibility(8);
                        rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.7.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view2) {
                                CompressHelper.m4921e2(MMIVResultActivityFragment.this.m44716w(), "Not Tested", 1);
                            }
                        });
                        return;
                    }
                    rippleTextImageArrowViewHolder.f83295K.setVisibility(0);
                    rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.7.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                            mMIVResultActivityFragment.f75863p4.m4883q1(mMIVResultActivityFragment.f75850c4, "doc-ysite,,," + MMIVResultActivityFragment.this.f74918I4 + ",,," + MMIVResultActivityFragment.this.f74919J4 + ",,," + bundle2.getString("value_id") + ",,," + bundle2.getString("title"), null, null);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: h0 */
                public RecyclerView.ViewHolder mo3403h0(View view2) {
                    return new RippleTextImageArrowViewHolder(view2);
                }
            };
            this.f74921L4 = chaptersAdapter;
            chaptersAdapter.f83219h = "No Drug-Drug Combination Have Been Tested";
            ChaptersAdapter chaptersAdapter2 = new ChaptersAdapter(m44716w(), this.f74916G4, "adfs", C4804R.C4810layout.f87269list_view_item_ripple_text_image_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.8
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: e0 */
                public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                    RippleTextImageArrowViewHolder rippleTextImageArrowViewHolder = (RippleTextImageArrowViewHolder) viewHolder;
                    rippleTextImageArrowViewHolder.f83293I.setText(bundle2.getString("title"));
                    rippleTextImageArrowViewHolder.f83294J.setImageDrawable(MMIVResultActivityFragment.this.m44782a0().getDrawable(MMIVResultActivityFragment.this.m4428z4(bundle2.getString("result"))));
                    if (bundle2.getString("result").equals("N")) {
                        rippleTextImageArrowViewHolder.f83295K.setVisibility(8);
                        rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.8.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view2) {
                                CompressHelper.m4921e2(MMIVResultActivityFragment.this.m44716w(), "Not Tested", 1);
                            }
                        });
                        return;
                    }
                    rippleTextImageArrowViewHolder.f83295K.setVisibility(0);
                    rippleTextImageArrowViewHolder.f83296L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.8.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                            mMIVResultActivityFragment.f75863p4.m4883q1(mMIVResultActivityFragment.f75850c4, "doc-admix,,," + MMIVResultActivityFragment.this.f74918I4 + ",,," + MMIVResultActivityFragment.this.f74919J4 + ",,," + bundle2.getString("value_id") + ",,," + bundle2.getString("title"), null, null);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: h0 */
                public RecyclerView.ViewHolder mo3403h0(View view2) {
                    return new RippleTextImageArrowViewHolder(view2);
                }
            };
            this.f74922M4 = chaptersAdapter2;
            chaptersAdapter2.f83219h = "No Drug-Drug Combination Have Been Tested";
            this.f74923w4.setAdapter(this.f74920K4);
        } else {
            m4430x4("Y-Site");
            m4430x4("Admix");
            this.f75863p4.m4897m(this.f75850c4, "Delete from selected_agents");
            for (String str : splitByWholeSeparator) {
                String[] splitByWholeSeparator3 = StringUtils.splitByWholeSeparator(str, ",,,,,");
                String str2 = splitByWholeSeparator3[0];
                String str3 = splitByWholeSeparator3[1];
                String[] splitByWholeSeparator4 = StringUtils.splitByWholeSeparator(splitByWholeSeparator3[2], "-");
                this.f75863p4.m4897m(this.f75850c4, "Insert into selected_agents values (" + str2 + "," + splitByWholeSeparator4[0] + ", '" + str3 + "', 0, " + splitByWholeSeparator4[1] + ")");
            }
            this.f75852e4 = "Interaction Result";
            m4432A4();
            ChaptersAdapter chaptersAdapter3 = new ChaptersAdapter(m44716w(), this.f74915F4, "title", C4804R.C4810layout.f87267list_view_item_ripple_text_full_interact) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.9
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: e0 */
                public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                    RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                    final String[] splitByWholeSeparator5 = StringUtils.splitByWholeSeparator(bundle2.getString("title"), " - ");
                    rippleTextFullViewHolder.f83284I.setText(splitByWholeSeparator5[0]);
                    rippleTextFullViewHolder.f83285J.setText(splitByWholeSeparator5[1]);
                    rippleTextFullViewHolder.f83286K.setImageDrawable(MMIVResultActivityFragment.this.m44782a0().getDrawable(MMIVResultActivityFragment.this.m4428z4(bundle2.getString("result"))));
                    rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.9.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                            mMIVResultActivityFragment.f75863p4.m4883q1(mMIVResultActivityFragment.f75850c4, "doc-ysite,,," + bundle2.getString("agent_id") + ",,," + splitByWholeSeparator5[0] + ",,," + bundle2.getString("drug2_id") + ",,," + splitByWholeSeparator5[1], null, null);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: h0 */
                public RecyclerView.ViewHolder mo3403h0(View view2) {
                    return new RippleTextFullViewHolder(view2);
                }
            };
            this.f74921L4 = chaptersAdapter3;
            chaptersAdapter3.f83219h = "No Drug-Drug Combination Have Been Tested";
            ChaptersAdapter chaptersAdapter4 = new ChaptersAdapter(m44716w(), this.f74915F4, "title", C4804R.C4810layout.f87267list_view_item_ripple_text_full_interact) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.10
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: e0 */
                public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                    RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                    final String[] splitByWholeSeparator5 = StringUtils.splitByWholeSeparator(bundle2.getString("title"), " - ");
                    rippleTextFullViewHolder.f83284I.setText(splitByWholeSeparator5[0]);
                    rippleTextFullViewHolder.f83285J.setText(splitByWholeSeparator5[1]);
                    rippleTextFullViewHolder.f83286K.setImageDrawable(MMIVResultActivityFragment.this.m44782a0().getDrawable(MMIVResultActivityFragment.this.m4428z4(bundle2.getString("result"))));
                    rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMIVResultActivityFragment.10.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            MMIVResultActivityFragment mMIVResultActivityFragment = MMIVResultActivityFragment.this;
                            mMIVResultActivityFragment.f75863p4.m4883q1(mMIVResultActivityFragment.f75850c4, "doc-admix,,," + bundle2.getString("agent_id") + ",,," + splitByWholeSeparator5[0] + ",,," + bundle2.getString("drug2_id") + ",,," + splitByWholeSeparator5[1], null, null);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: h0 */
                public RecyclerView.ViewHolder mo3403h0(View view2) {
                    return new RippleTextFullViewHolder(view2);
                }
            };
            this.f74922M4 = chaptersAdapter4;
            chaptersAdapter4.f83219h = "No Drug-Drug Combination Have Been Tested";
        }
        m4429y4();
        m4100f3(C4804R.C4811menu.f87326favorite);
        m44735q2(false);
        m4140G3();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f74924x4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f74924x4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    /* renamed from: x4 */
    public void m4430x4(String str) {
        TabLayout.Tab m24950D = this.f74917H4.m24950D();
        m24950D.m24890D(str);
        this.f74917H4.m24926e(m24950D);
    }

    /* renamed from: y4 */
    public void m4429y4() {
        this.f74923w4.setItemAnimator(new DefaultItemAnimator());
        this.f74923w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f74923w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }

    /* renamed from: z4 */
    public int m4428z4(String str) {
        return str.equals("C") ? C4804R.C4807drawable.f86618iv_compat_compatible : str.equals("I") ? C4804R.C4807drawable.f86619iv_compat_incompatible : str.equals("U") ? C4804R.C4807drawable.f86621iv_compat_uncertain : str.equals("N") ? C4804R.C4807drawable.f86620iv_compat_nottested : str.equals(ExifInterface.f14395R4) ? C4804R.C4807drawable.f86617iv_compat_cautionvariable : C4804R.C4807drawable.f86674placeholder;
    }
}
