package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MMViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public boolean f75044A4;

    /* renamed from: w4 */
    public Bundle f75045w4;

    /* renamed from: x4 */
    public ArrayList<String> f75046x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75047y4;

    /* renamed from: z4 */
    public int f75048z4;

    /* renamed from: D4 */
    private void m4393D4(String str) {
        ArrayList<String> arrayList = this.f75046x4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f75046x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", next);
            bundle.putString("Description", "");
            bundle.putString("id", next);
            if (new File(next).length() > 5000) {
                arrayList2.add(bundle);
            }
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public String m4396A4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75048z4 + 1;
        this.f75048z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: B4 */
    public String m4395B4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75048z4 + 1;
        this.f75048z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded2\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded2(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: C4 */
    public String m4394C4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4394C4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f75046x4 = arrayList;
            mo3978f4();
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return m4071w3(this.f75046x4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        this.f75044A4 = true;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    String str = MMViewerActivityFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        iMDLogger.m3294f("Loading Document", MMViewerActivityFragment.this.f75851d4);
                        MMViewerActivityFragment mMViewerActivityFragment = MMViewerActivityFragment.this;
                        ArrayList<Bundle> m4955V = mMViewerActivityFragment.f75863p4.m4955V(mMViewerActivityFragment.f75850c4, "Select * from drug_idx where drug_id=" + MMViewerActivityFragment.this.f75851d4 + " and has_generic=0");
                        if (m4955V != null && m4955V.size() != 0) {
                            MMViewerActivityFragment.this.f75047y4 = new ArrayList<>();
                            MMViewerActivityFragment mMViewerActivityFragment2 = MMViewerActivityFragment.this;
                            mMViewerActivityFragment2.f75048z4 = 0;
                            mMViewerActivityFragment2.f75045w4 = m4955V.get(0);
                            MMViewerActivityFragment mMViewerActivityFragment3 = MMViewerActivityFragment.this;
                            mMViewerActivityFragment3.f75852e4 = mMViewerActivityFragment3.f75045w4.getString("title");
                            MMViewerActivityFragment mMViewerActivityFragment4 = MMViewerActivityFragment.this;
                            ArrayList<Bundle> m4955V2 = mMViewerActivityFragment4.f75863p4.m4955V(mMViewerActivityFragment4.f75850c4, "select drug_section.title as sectionTitle, drug_sub_section.title as subSectionTitle, monograph from (drug_mono inner join drug_sub_section on drug_sub_section.sub_section_id=drug_mono.sub_section_id) inner join drug_section on drug_section.section_id=drug_sub_section.section_id where drug_id=" + MMViewerActivityFragment.this.f75851d4 + " AND monograph<>'' AND drug_section.section_id<>0 order by drug_section.section_id, drug_sub_section.sub_section_id");
                            if (m4955V2 == null) {
                                m4955V2 = new ArrayList<>();
                            }
                            Iterator<Bundle> it2 = m4955V2.iterator();
                            String str2 = "";
                            String str3 = str2;
                            String str4 = str3;
                            while (it2.hasNext()) {
                                Bundle next = it2.next();
                                String string = next.getString("sectionTitle");
                                String string2 = next.getString("subSectionTitle");
                                String string3 = next.getString("monograph");
                                if (!string.equals(str4)) {
                                    if (str3.length() > 0) {
                                        str2 = str2 + MMViewerActivityFragment.this.m4396A4(str4, "", "LTR", str3, "", "", "");
                                        MMViewerActivityFragment mMViewerActivityFragment5 = MMViewerActivityFragment.this;
                                        mMViewerActivityFragment5.m4392x4(str4, mMViewerActivityFragment5.f75048z4);
                                    }
                                    str3 = "";
                                    str4 = string;
                                }
                                str3 = str3 + MMViewerActivityFragment.this.m4395B4(string2, "", "", string3, "", "margin-left:15px", "");
                            }
                            if (str3.length() > 0) {
                                str2 = str2 + MMViewerActivityFragment.this.m4396A4(str4, "", "LTR", str3, "", "", "");
                                MMViewerActivityFragment mMViewerActivityFragment6 = MMViewerActivityFragment.this;
                                mMViewerActivityFragment6.m4392x4(str4, mMViewerActivityFragment6.f75048z4);
                            }
                            MMViewerActivityFragment mMViewerActivityFragment7 = MMViewerActivityFragment.this;
                            String m4117W3 = mMViewerActivityFragment7.m4117W3(mMViewerActivityFragment7.m44716w(), "MMHeader.css");
                            MMViewerActivityFragment mMViewerActivityFragment8 = MMViewerActivityFragment.this;
                            String m4117W32 = mMViewerActivityFragment8.m4117W3(mMViewerActivityFragment8.m44716w(), "MMFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", MMViewerActivityFragment.this.f75852e4).replace("[include]", "");
                            MMViewerActivityFragment.this.f75847Z3 = replace + str2 + m4117W32;
                        }
                        MMViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                    }
                    MMViewerActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    MMViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = MMViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    MMViewerActivityFragment mMViewerActivityFragment = MMViewerActivityFragment.this;
                    mMViewerActivityFragment.m4078s4(mMViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4945Y0(MMViewerActivityFragment.this.f75850c4, "base"));
                MMViewerActivityFragment mMViewerActivityFragment2 = MMViewerActivityFragment.this;
                mMViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", mMViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                MMViewerActivityFragment.this.m4092j4();
                MMViewerActivityFragment.this.m4098g4();
                MMViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                MMViewerActivityFragment.this.m44735q2(false);
                MMViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4393D4("asdfafdsaf");
            return true;
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f75047y4);
            bundle.putString("TitleProperty", "label");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        if (str2.equals("image")) {
            m4393D4(str3);
            return true;
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public void m4392x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f75047y4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4391y4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75048z4 + 1;
        this.f75048z4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded3\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded3(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: z4 */
    public String m4390z4(String str, String str2, String str3, String str4) {
        int i = this.f75048z4 + 1;
        this.f75048z4 = i;
        String valueOf = String.valueOf(i);
        return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
    }
}
