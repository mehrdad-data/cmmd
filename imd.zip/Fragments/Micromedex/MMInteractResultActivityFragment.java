package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MMInteractResultActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public NotStickySectionAdapter f74979A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f74980B4;

    /* renamed from: C4 */
    public ArrayList<Bundle> f74981C4;

    /* renamed from: w4 */
    public RecyclerView f74982w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f74983x4;

    /* renamed from: y4 */
    public Bundle f74984y4;

    /* renamed from: z4 */
    public ArrayList<String> f74985z4;

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74982w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(this.f75851d4.split("-")[1], ";;;;;");
        this.f75863p4.m4897m(this.f75850c4, "delete from selected_drugs");
        for (String str : splitByWholeSeparator) {
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str, ",,,,,");
            this.f75863p4.m4897m(this.f75850c4, "Insert into selected_drugs values (" + splitByWholeSeparator2[0] + ", '" + splitByWholeSeparator2[1] + "', 0)");
        }
        this.f74980B4 = this.f75863p4.m4955V(this.f75850c4, "SELECT title, doc_id, severity, (SELECT descrip FROM dict_severity WHERE id = severity) severity_descr FROM v_interactions");
        this.f75852e4 = "Found " + this.f74980B4.size() + " Interactions";
        this.f74981C4 = this.f75863p4.m4941Z1(this.f74980B4, "severity_descr");
        NotStickySectionAdapter notStickySectionAdapter = new NotStickySectionAdapter(m44716w(), this.f74981C4, "title", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMInteractResultActivityFragment.1
            @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
            /* renamed from: f0 */
            public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                String[] splitByWholeSeparator3 = StringUtils.splitByWholeSeparator(bundle2.getString("title"), " : ");
                int i2 = 0;
                String str2 = splitByWholeSeparator3[0];
                String str3 = splitByWholeSeparator3[1];
                rippleTextFullViewHolder.f83284I.setText(str2);
                rippleTextFullViewHolder.f83285J.setText(str3);
                String string = bundle2.getString("severity");
                if (string.equals(IcyHeaders.f35463C2)) {
                    i2 = C4804R.C4807drawable.f86754xinteraction;
                } else if (string.equals(ExifInterface.f14403S4)) {
                    i2 = C4804R.C4807drawable.f86564dinteraction;
                } else if (string.equals(ExifInterface.f14411T4)) {
                    i2 = C4804R.C4807drawable.f86552cinteraction;
                } else if (string.equals("4")) {
                    i2 = C4804R.C4807drawable.f86515binteraction;
                }
                rippleTextFullViewHolder.f83286K.setImageDrawable(MMInteractResultActivityFragment.this.m44782a0().getDrawable(i2));
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMInteractResultActivityFragment.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        MMInteractResultActivityFragment mMInteractResultActivityFragment = MMInteractResultActivityFragment.this;
                        CompressHelper compressHelper = mMInteractResultActivityFragment.f75863p4;
                        Bundle bundle3 = mMInteractResultActivityFragment.f75850c4;
                        compressHelper.m4883q1(bundle3, "doc-" + bundle2.getString("doc_id") + ",,,,," + bundle2.getString("title"), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
            /* renamed from: i0 */
            public String mo3387i0(String str2) {
                return str2;
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
            /* renamed from: k0 */
            public RecyclerView.ViewHolder mo3385k0(View view2) {
                return new RippleTextFullViewHolder(view2);
            }
        };
        this.f74979A4 = notStickySectionAdapter;
        this.f74982w4.setAdapter(notStickySectionAdapter);
        m4415x4();
        m4100f3(C4804R.C4811menu.f87326favorite);
        m44735q2(false);
        m4140G3();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f74983x4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f74983x4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    /* renamed from: x4 */
    public void m4415x4() {
        this.f74982w4.setItemAnimator(new DefaultItemAnimator());
        this.f74982w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f74982w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }
}
