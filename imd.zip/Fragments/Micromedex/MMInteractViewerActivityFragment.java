package net.imedicaldoctor.imd.Fragments.Micromedex;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.common.net.HttpHeaders;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MMInteractViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f75009w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f75010x4;

    /* renamed from: y4 */
    public int f75011y4;

    /* renamed from: A4 */
    public String m4411A4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75011y4 + 1;
        this.f75011y4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: B4 */
    public String m4410B4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75011y4 + 1;
        this.f75011y4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded2\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded2(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: C4 */
    public String m4409C4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMInteractViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    String str = MMInteractViewerActivityFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        iMDLogger.m3294f("Loading Document", MMInteractViewerActivityFragment.this.f75851d4);
                        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(MMInteractViewerActivityFragment.this.f75851d4.split("-")[1], ",,,,,");
                        String str2 = splitByWholeSeparator[0];
                        MMInteractViewerActivityFragment mMInteractViewerActivityFragment = MMInteractViewerActivityFragment.this;
                        mMInteractViewerActivityFragment.f75852e4 = splitByWholeSeparator[1];
                        CompressHelper compressHelper = mMInteractViewerActivityFragment.f75863p4;
                        Bundle bundle2 = mMInteractViewerActivityFragment.f75850c4;
                        compressHelper.m4897m(bundle2, "Update app_state set value=" + str2 + " where key='current_doc'");
                        MMInteractViewerActivityFragment mMInteractViewerActivityFragment2 = MMInteractViewerActivityFragment.this;
                        ArrayList<Bundle> m4955V = mMInteractViewerActivityFragment2.f75863p4.m4955V(mMInteractViewerActivityFragment2.f75850c4, "Select * from v_interactions_mono");
                        if (m4955V != null && m4955V.size() != 0) {
                            MMInteractViewerActivityFragment.this.f75010x4 = new ArrayList<>();
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment3 = MMInteractViewerActivityFragment.this;
                            mMInteractViewerActivityFragment3.f75011y4 = 0;
                            mMInteractViewerActivityFragment3.f75009w4 = m4955V.get(0);
                            StringBuilder sb = new StringBuilder();
                            sb.append("");
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment4 = MMInteractViewerActivityFragment.this;
                            sb.append(mMInteractViewerActivityFragment4.m4410B4("Evidence", "", "LTR", mMInteractViewerActivityFragment4.f75009w4.getString("evidence"), "", "margin-left:10px;margin-top:5px", ""));
                            String sb2 = sb.toString();
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment5 = MMInteractViewerActivityFragment.this;
                            mMInteractViewerActivityFragment5.m4408x4("Evidence", mMInteractViewerActivityFragment5.f75011y4);
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(sb2);
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment6 = MMInteractViewerActivityFragment.this;
                            sb3.append(mMInteractViewerActivityFragment6.m4410B4("Onset", "", "LTR", mMInteractViewerActivityFragment6.f75009w4.getString("onset"), "", "margin-left:10px;margin-top:5px", ""));
                            String sb4 = sb3.toString();
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment7 = MMInteractViewerActivityFragment.this;
                            mMInteractViewerActivityFragment7.m4408x4("Onset", mMInteractViewerActivityFragment7.f75011y4);
                            StringBuilder sb5 = new StringBuilder();
                            sb5.append(sb4);
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment8 = MMInteractViewerActivityFragment.this;
                            sb5.append(mMInteractViewerActivityFragment8.m4410B4("Severity", "", "LTR", mMInteractViewerActivityFragment8.f75009w4.getString("severity"), "", "margin-left:10px;margin-top:5px", ""));
                            String sb6 = sb5.toString();
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment9 = MMInteractViewerActivityFragment.this;
                            mMInteractViewerActivityFragment9.m4408x4("Severity", mMInteractViewerActivityFragment9.f75011y4);
                            StringBuilder sb7 = new StringBuilder();
                            sb7.append(sb6);
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment10 = MMInteractViewerActivityFragment.this;
                            sb7.append(mMInteractViewerActivityFragment10.m4410B4(HttpHeaders.f53975g, "", "LTR", mMInteractViewerActivityFragment10.f75009w4.getString("warning"), "", "margin-left:10px;margin-top:5px", ""));
                            String sb8 = sb7.toString();
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment11 = MMInteractViewerActivityFragment.this;
                            mMInteractViewerActivityFragment11.m4408x4(HttpHeaders.f53975g, mMInteractViewerActivityFragment11.f75011y4);
                            StringBuilder sb9 = new StringBuilder();
                            sb9.append(sb8);
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment12 = MMInteractViewerActivityFragment.this;
                            sb9.append(mMInteractViewerActivityFragment12.m4410B4("Description", "", "LTR", mMInteractViewerActivityFragment12.f75009w4.getString("monograph"), "", "margin-left:10px;margin-top:5px", ""));
                            String sb10 = sb9.toString();
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment13 = MMInteractViewerActivityFragment.this;
                            mMInteractViewerActivityFragment13.m4408x4("Description", mMInteractViewerActivityFragment13.f75011y4);
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment14 = MMInteractViewerActivityFragment.this;
                            String m4117W3 = mMInteractViewerActivityFragment14.m4117W3(mMInteractViewerActivityFragment14.m44716w(), "MMHeader.css");
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment15 = MMInteractViewerActivityFragment.this;
                            String m4117W32 = mMInteractViewerActivityFragment15.m4117W3(mMInteractViewerActivityFragment15.m44716w(), "MMFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", MMInteractViewerActivityFragment.this.f75852e4).replace("[include]", "");
                            MMInteractViewerActivityFragment mMInteractViewerActivityFragment16 = MMInteractViewerActivityFragment.this;
                            mMInteractViewerActivityFragment16.f75847Z3 = replace + sb10 + m4117W32;
                        }
                        MMInteractViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                    }
                    MMInteractViewerActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    MMInteractViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Micromedex.MMInteractViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = MMInteractViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    MMInteractViewerActivityFragment mMInteractViewerActivityFragment = MMInteractViewerActivityFragment.this;
                    mMInteractViewerActivityFragment.m4078s4(mMInteractViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4945Y0(MMInteractViewerActivityFragment.this.f75850c4, "base"));
                MMInteractViewerActivityFragment mMInteractViewerActivityFragment2 = MMInteractViewerActivityFragment.this;
                mMInteractViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", mMInteractViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                MMInteractViewerActivityFragment.this.m4092j4();
                MMInteractViewerActivityFragment.this.m4098g4();
                MMInteractViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                MMInteractViewerActivityFragment.this.m44735q2(false);
                MMInteractViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        if (menuItem.getItemId() == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f75010x4);
            bundle.putString("TitleProperty", "label");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public void m4408x4(String str, int i) {
        Bundle bundle = new Bundle();
        bundle.putString("sequence", String.valueOf(i));
        bundle.putString("label", str);
        this.f75010x4.add(bundle);
    }

    /* renamed from: y4 */
    public String m4407y4(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i = this.f75011y4 + 1;
        this.f75011y4 = i;
        String valueOf = String.valueOf(i);
        return "<a name=\"f" + valueOf + "\"><div id=\"h" + valueOf + "\" class=\"headerExpanded3\"  DIR=\"" + str3 + "\" onclick=\"collapse(f" + valueOf + ");toggleHeaderExpanded3(h" + valueOf + ");\"><span class=\"fieldname\" style=\"font-family:" + str2 + ";\">" + str + "</span></div></a><div class=\"content\" DIR=\"" + str7 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str5 + "; " + str6 + "\">" + str4 + "</div>";
    }

    /* renamed from: z4 */
    public String m4406z4(String str, String str2, String str3, String str4) {
        int i = this.f75011y4 + 1;
        this.f75011y4 = i;
        String valueOf = String.valueOf(i);
        return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + valueOf + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
    }
}
