package net.imedicaldoctor.imd.Fragments.Martindale;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.material.tabs.TabLayout;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class MDViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public String f74886A4;

    /* renamed from: B4 */
    public TabLayout f74887B4;

    /* renamed from: w4 */
    public Bundle f74888w4;

    /* renamed from: x4 */
    public ArrayList<String> f74889x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f74890y4;

    /* renamed from: z4 */
    public ArrayList<Bundle> f74891z4;

    /* renamed from: A4 */
    private void m4448A4(String str) {
        ArrayList<String> arrayList = this.f74889x4;
        if (arrayList == null || arrayList.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f74889x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", next);
            bundle.putString("Description", "");
            bundle.putString("id", next);
            if (new File(next).length() > 5000) {
                arrayList2.add(bundle);
            }
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4445z4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f74889x4 = arrayList;
            mo3978f4();
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return m4071w3(this.f74889x4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        super.mo3569S3(webView, str);
        this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        this.f75853f4.loadUrl("javascript:console.log(\"images,,,,,\" + getImageList());");
        this.f75853f4.loadUrl("javascript:onBodyLoad();");
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87179fragment_new_viewer_tab, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74887B4 = (TabLayout) this.f75849b4.findViewById(C4804R.C4808id.f87042tabs);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Martindale.MDViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    String str = MDViewerActivityFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        MDViewerActivityFragment mDViewerActivityFragment = MDViewerActivityFragment.this;
                        CompressHelper compressHelper = mDViewerActivityFragment.f75863p4;
                        Bundle bundle2 = mDViewerActivityFragment.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from docs where id=" + MDViewerActivityFragment.this.f75851d4);
                        if (m4955V != null && m4955V.size() != 0) {
                            MDViewerActivityFragment.this.f74888w4 = m4955V.get(0);
                            MDViewerActivityFragment mDViewerActivityFragment2 = MDViewerActivityFragment.this;
                            mDViewerActivityFragment2.f75852e4 = mDViewerActivityFragment2.f74888w4.getString("title");
                            MDViewerActivityFragment.this.m4447x4("Monograph");
                            if (MDViewerActivityFragment.this.f74888w4.getString("adult_ed").length() > 0) {
                                MDViewerActivityFragment.this.m4447x4("Adult Pt Ed");
                            }
                            if (MDViewerActivityFragment.this.f74888w4.getString("ped_ed").length() > 0) {
                                MDViewerActivityFragment.this.m4447x4("Ped Pt Ed");
                            }
                            if (MDViewerActivityFragment.this.f74888w4.getString("product_list").length() > 0) {
                                MDViewerActivityFragment.this.m4447x4("Products");
                            }
                            MDViewerActivityFragment.this.f74887B4.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: net.imedicaldoctor.imd.Fragments.Martindale.MDViewerActivityFragment.1.1
                                @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                                /* renamed from: a */
                                public void mo4174a(TabLayout.Tab tab) {
                                }

                                @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                                /* renamed from: b */
                                public void mo4173b(TabLayout.Tab tab) {
                                    MDViewerActivityFragment.this.m4446y4(tab.m24875n().toString());
                                }

                                @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
                                /* renamed from: c */
                                public void mo4172c(TabLayout.Tab tab) {
                                }
                            });
                        }
                        MDViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                    }
                    MDViewerActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    MDViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Martindale.MDViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = MDViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    MDViewerActivityFragment mDViewerActivityFragment = MDViewerActivityFragment.this;
                    mDViewerActivityFragment.m4078s4(mDViewerActivityFragment.f75837P3);
                    return;
                }
                MDViewerActivityFragment.this.m4446y4("Monograph");
                MDViewerActivityFragment.this.m4092j4();
                MDViewerActivityFragment.this.m4098g4();
                MDViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                MDViewerActivityFragment.this.m44735q2(false);
                MDViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4448A4("asdfafdsaf");
            return true;
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f74891z4);
            bundle.putString("TitleProperty", "title");
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        String str4;
        if (str2.equals("image")) {
            m4448A4(str3);
            return true;
        }
        if (str2.equals(Annotation.f59806M2)) {
            String m4904j1 = this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(str3, "/"));
            if (m4904j1 == null || m4904j1.length() == 0) {
                return true;
            }
            if (m4904j1.contains("?")) {
                m4904j1 = StringUtils.splitByWholeSeparator(m4904j1, "?")[0];
            }
            if (str3.contains("/pated_f/")) {
                Bundle m4969Q0 = this.f75863p4.m4969Q0("Name", "259_pated_f.sqlite");
                if (m4969Q0 == null) {
                    CompressHelper.m4921e2(m44716w(), "You Must Install Adult Patient Education Database", 1);
                    return true;
                }
                this.f75863p4.m4883q1(m4969Q0, m4904j1, null, null);
            }
            if (str3.contains("/pedip_f/")) {
                Bundle m4969Q02 = this.f75863p4.m4969Q0("Name", "261_pedip_f.sqlite");
                if (m4969Q02 == null) {
                    CompressHelper.m4921e2(m44716w(), "You Must Install Pediatric Patient Education Database", 1);
                    return true;
                }
                this.f75863p4.m4883q1(m4969Q02, m4904j1, null, null);
            }
            if (m4904j1.contains("#")) {
                str4 = this.f75863p4.m4904j1(StringUtils.splitByWholeSeparator(m4904j1, "#"));
                m4904j1 = StringUtils.splitByWholeSeparator(m4904j1, "#")[0];
            } else {
                str4 = "";
            }
            if (m4904j1.equals(this.f75851d4)) {
                mo4144C3(str4);
                return true;
            }
            CompressHelper compressHelper = this.f75863p4;
            Bundle bundle = this.f75850c4;
            if (compressHelper.m4907i1(compressHelper.m4955V(bundle, "Select * from docs where id = '" + m4904j1 + "'")) != null) {
                this.f75863p4.m4883q1(this.f75850c4, m4904j1, null, str4);
            }
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }

    /* renamed from: x4 */
    public void m4447x4(String str) {
        TabLayout.Tab m24950D = this.f74887B4.m24950D();
        m24950D.m24890D(str);
        this.f74887B4.m24926e(m24950D);
    }

    /* JADX WARN: Can't wrap try/catch for region: R(7:1|(1:3)(2:13|(1:15)(2:16|(1:18)(6:19|(1:21)(1:22)|5|6|7|8)))|4|5|6|7|8) */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0110, code lost:
        r8 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0111, code lost:
        com.google.firebase.crashlytics.FirebaseCrashlytics.m18030d().m18027g(r8);
        r8.printStackTrace();
     */
    /* renamed from: y4 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void m4446y4(java.lang.String r8) {
        /*
            Method dump skipped, instructions count: 335
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.Martindale.MDViewerActivityFragment.m4446y4(java.lang.String):void");
    }

    /* renamed from: z4 */
    public String m4445z4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }
}
