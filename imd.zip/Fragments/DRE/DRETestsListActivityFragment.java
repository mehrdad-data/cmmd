package net.imedicaldoctor.imd.Fragments.DRE;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.css.CSS;
import java.text.SimpleDateFormat;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import org.apache.commons.lang3.StringUtils;
import saman.zamani.persiandate.PersianDate;
import saman.zamani.persiandate.PersianDateFormat;

/* loaded from: classes2.dex */
public class DRETestsListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74254b4;

    /* renamed from: c4 */
    public String f74255c4;

    /* renamed from: d4 */
    public boolean f74256d4;

    /* loaded from: classes2.dex */
    public class TestScoreViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74264I;

        /* renamed from: J */
        public TextView f74265J;

        /* renamed from: K */
        public TextView f74266K;

        /* renamed from: L */
        public TextView f74267L;

        /* renamed from: M */
        public ImageView f74268M;

        /* renamed from: N */
        public TextView f74269N;

        /* renamed from: O */
        public MaterialRippleLayout f74270O;

        public TestScoreViewHolder(View view) {
            super(view);
            this.f74264I = (TextView) view.findViewById(C4804R.C4808id.f87049text_date);
            this.f74265J = (TextView) view.findViewById(C4804R.C4808id.f87051text_info1);
            this.f74266K = (TextView) view.findViewById(C4804R.C4808id.f87052text_info2);
            this.f74270O = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            this.f74267L = (TextView) view.findViewById(C4804R.C4808id.f87055text_score);
            this.f74268M = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
            this.f74269N = (TextView) view.findViewById(C4804R.C4808id.f87054text_resume);
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        appBarLayout.m27445s(false, false);
        appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestsListActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                relativeLayout.setVisibility(0);
            }
        }, 800L);
        if (this.f75215L3.m4955V(this.f75212I3, "Select CorrPerc from Questions limit 1") == null) {
            this.f74256d4 = true;
        } else {
            this.f74256d4 = false;
        }
        this.f75218O3 = this.f75215L3.m4955V(this.f75212I3, "Select * from tests order by id desc");
        ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87237list_view_item_dre_test) { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestsListActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                TextView textView;
                String str;
                MaterialRippleLayout materialRippleLayout;
                View.OnClickListener onClickListener;
                TestScoreViewHolder testScoreViewHolder = (TestScoreViewHolder) viewHolder;
                testScoreViewHolder.f74264I.setTypeface(ResourcesCompat.m47479g(DRETestsListActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74265J.setTypeface(ResourcesCompat.m47479g(DRETestsListActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74266K.setTypeface(ResourcesCompat.m47479g(DRETestsListActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74269N.setTypeface(ResourcesCompat.m47479g(DRETestsListActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74267L.setTypeface(ResourcesCompat.m47479g(DRETestsListActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74264I.setText(DRETestsListActivityFragment.this.m4710l3(bundle2.getString("createdDate")));
                int length = StringUtils.splitByWholeSeparator(bundle2.getString("qIds"), ",").length;
                String str2 = bundle2.getString("mode").equals("Testing") ? "امتحان" : "مطالعه";
                testScoreViewHolder.f74265J.setText(length + " سوال. حالت مطالعه: " + str2);
                if (DRETestsListActivityFragment.this.f74256d4) {
                    textView = testScoreViewHolder.f74266K;
                    str = bundle2.getString("subject");
                } else {
                    textView = testScoreViewHolder.f74266K;
                    str = bundle2.getString("subject") + " , " + bundle2.getString("system");
                }
                textView.setText(str);
                if (bundle2.getString("done").equals(IcyHeaders.f35463C2)) {
                    testScoreViewHolder.f74268M.setImageDrawable(DRETestsListActivityFragment.this.m44782a0().getDrawable(C4804R.C4807drawable.f86555circle_green));
                    testScoreViewHolder.f74269N.setText("نمره");
                    testScoreViewHolder.f74267L.setVisibility(0);
                    testScoreViewHolder.f74267L.setText(bundle2.getString(FirebaseAnalytics.Param.f55169D) + CSS.Value.f65657n0);
                    materialRippleLayout = testScoreViewHolder.f74270O;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestsListActivityFragment.2.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            DRETestsListActivityFragment dRETestsListActivityFragment = DRETestsListActivityFragment.this;
                            CompressHelper compressHelper = dRETestsListActivityFragment.f75215L3;
                            Bundle bundle3 = dRETestsListActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "testresult-" + bundle2.getString("id"), null, null);
                        }
                    };
                } else {
                    testScoreViewHolder.f74268M.setImageDrawable(DRETestsListActivityFragment.this.m44782a0().getDrawable(C4804R.C4807drawable.f86554circle_blue));
                    testScoreViewHolder.f74269N.setText("ادامه");
                    testScoreViewHolder.f74267L.setVisibility(8);
                    materialRippleLayout = testScoreViewHolder.f74270O;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestsListActivityFragment.2.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            DRETestsListActivityFragment dRETestsListActivityFragment = DRETestsListActivityFragment.this;
                            CompressHelper compressHelper = dRETestsListActivityFragment.f75215L3;
                            Bundle bundle3 = dRETestsListActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "test-" + bundle2.getString("id"), null, null);
                        }
                    };
                }
                materialRippleLayout.setOnClickListener(onClickListener);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new TestScoreViewHolder(view);
            }
        };
        this.f75216M3 = chaptersAdapter;
        chaptersAdapter.f83219h = "آزمونی وجود ندارد";
        this.f75227X3.setAdapter(chaptersAdapter);
        m4338Q2();
        m44735q2(false);
        this.f75223T3.setVisibility(8);
        this.f75222S3.setTitle("آزمون های پیشین");
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74254b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74254b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return "";
    }

    /* renamed from: l3 */
    public String m4710l3(String str) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ");
        new SimpleDateFormat("MM dd,yyyy HH:mm:ss");
        try {
            return new PersianDateFormat().m79a(new PersianDate(Long.valueOf(simpleDateFormat.parse(str).getTime())));
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            return str;
        }
    }
}
