package net.imedicaldoctor.imd.Fragments.DRE;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import androidx.appcompat.app.AlertDialog;
import androidx.exifinterface.media.ExifInterface;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.Annotation;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class DRETestViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public ArrayList<Bundle> f74236A4;

    /* renamed from: B4 */
    public int f74237B4;

    /* renamed from: C4 */
    public Bundle f74238C4;

    /* renamed from: D4 */
    public Date f74239D4;

    /* renamed from: E4 */
    public String f74240E4;

    /* renamed from: F4 */
    public boolean f74241F4;

    /* renamed from: w4 */
    public Bundle f74242w4;

    /* renamed from: x4 */
    public ArrayList<String> f74243x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f74244y4;

    /* renamed from: z4 */
    public ArrayList<Bundle> f74245z4;

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: B4 */
    public void m4726B4() {
        CompressHelper compressHelper = this.f75863p4;
        Bundle bundle = this.f75850c4;
        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select * from images where questionId = " + this.f74236A4.get(this.f74237B4).getString("id"));
        if (m4955V == null) {
            m4955V = new ArrayList<>();
        }
        Iterator<Bundle> it2 = m4955V.iterator();
        while (it2.hasNext()) {
            String string = it2.next().getString("filename");
            String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, string, "media-E");
            if (new File(m4942Z0).exists()) {
                try {
                    byte[] m4867w = this.f75863p4.m4867w(FileUtils.readFileToByteArray(new File(m4942Z0)), string, "127");
                    String m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, string, "base");
                    if (new File(m4942Z02).exists()) {
                        new File(m4942Z02).delete();
                    }
                    FileUtils.writeByteArrayToFile(new File(m4942Z02), m4867w, false);
                    new File(m4942Z02).deleteOnExit();
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    e.printStackTrace();
                }
            }
        }
        this.f74244y4 = m4955V;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: C4 */
    public void m4725C4(ArrayList<String> arrayList) {
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            String m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, next, "media-E");
            if (new File(m4942Z0).exists()) {
                try {
                    byte[] m4867w = this.f75863p4.m4867w(FileUtils.readFileToByteArray(new File(m4942Z0)), next, "127");
                    String m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, next, "base");
                    if (new File(m4942Z02).exists()) {
                        new File(m4942Z02).delete();
                    }
                    FileUtils.writeByteArrayToFile(new File(m4942Z02), m4867w, false);
                    new File(m4942Z02).deleteOnExit();
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    e.printStackTrace();
                }
            }
        }
        this.f74243x4 = arrayList;
    }

    /* renamed from: M4 */
    private void m4715M4(String str) {
        ArrayList<String> arrayList = this.f74243x4;
        if ((arrayList == null && this.f74244y4 == null) || arrayList.size() + this.f74244y4.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator<String> it2 = this.f74243x4.iterator();
        while (it2.hasNext()) {
            String next = it2.next();
            Bundle bundle = new Bundle();
            bundle.putString("ImagePath", CompressHelper.m4942Z0(this.f75850c4, next, "base"));
            bundle.putString("Description", "");
            bundle.putString("id", next);
            arrayList2.add(bundle);
        }
        Iterator<Bundle> it3 = this.f74244y4.iterator();
        while (it3.hasNext()) {
            Bundle next2 = it3.next();
            Bundle bundle2 = new Bundle();
            bundle2.putString("ImagePath", CompressHelper.m4942Z0(this.f75850c4, next2.getString("filename"), "base"));
            bundle2.putString("Description", next2.getString("title"));
            bundle2.putString("id", next2.getString("mediaId"));
            if (next2.getString("filename").endsWith(".mov")) {
                bundle2.putString("isVideo", "");
            }
            if (next2.getString("filename").endsWith(".mp4")) {
                bundle2.putString("isVideo", "");
            }
            arrayList2.add(bundle2);
        }
        int i = 0;
        for (int i2 = 0; i2 < arrayList2.size(); i2++) {
            if (str.contains(((Bundle) arrayList2.get(i2)).getString("id"))) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList2);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    /* renamed from: A4 */
    public void m4727A4() {
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setEnabled(true);
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setIcon(C4804R.C4807drawable.f86585ic_action_next_item);
    }

    /* renamed from: F4 */
    public String m4722F4(Date date) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ").format(date);
    }

    /* renamed from: G4 */
    public String m4721G4(String str) {
        return str.equals(IcyHeaders.f35463C2) ? "الف" : str.equals(ExifInterface.f14403S4) ? "ب" : str.equals(ExifInterface.f14411T4) ? "ج" : str.equals("4") ? "د" : str.equals("5") ? "ه" : str.equals("6") ? "خ" : str.equals("7") ? "G" : str.equals("8") ? "H" : str;
    }

    /* renamed from: H4 */
    public void m4720H4(final String str, final boolean z) {
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestViewerActivityFragment.3
            /* JADX WARN: Removed duplicated region for block: B:58:0x0379  */
            /* JADX WARN: Removed duplicated region for block: B:59:0x0382  */
            /* JADX WARN: Removed duplicated region for block: B:66:0x03bc  */
            /* JADX WARN: Removed duplicated region for block: B:69:0x03c3  */
            /* JADX WARN: Removed duplicated region for block: B:70:0x03ca  */
            @Override // java.lang.Runnable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public void run() {
                /*
                    Method dump skipped, instructions count: 997
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.DRE.DRETestViewerActivityFragment.RunnableC37703.run():void");
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestViewerActivityFragment.4
            @Override // java.lang.Runnable
            public void run() {
                String str2 = DRETestViewerActivityFragment.this.f75837P3;
                if (str2 != null && str2.length() > 0) {
                    DRETestViewerActivityFragment dRETestViewerActivityFragment = DRETestViewerActivityFragment.this;
                    dRETestViewerActivityFragment.m4078s4(dRETestViewerActivityFragment.f75837P3);
                    return;
                }
                DRETestViewerActivityFragment.this.m4718J4();
                if (z) {
                    DRETestViewerActivityFragment.this.f74240E4 = "answerSectionsa";
                }
            }
        });
    }

    /* renamed from: I4 */
    public void m4719I4() {
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                DRETestViewerActivityFragment.this.f74239D4 = new Date();
                DRETestViewerActivityFragment.this.f75852e4 = "سوال " + String.valueOf(DRETestViewerActivityFragment.this.f74237B4 + 1) + " از " + DRETestViewerActivityFragment.this.f74236A4.size();
                DRETestViewerActivityFragment dRETestViewerActivityFragment = DRETestViewerActivityFragment.this;
                StringBuilder sb = new StringBuilder();
                sb.append("question-");
                DRETestViewerActivityFragment dRETestViewerActivityFragment2 = DRETestViewerActivityFragment.this;
                sb.append(dRETestViewerActivityFragment2.f74236A4.get(dRETestViewerActivityFragment2.f74237B4).getString("id"));
                dRETestViewerActivityFragment.f75851d4 = sb.toString();
                DRETestViewerActivityFragment dRETestViewerActivityFragment3 = DRETestViewerActivityFragment.this;
                Bundle bundle = dRETestViewerActivityFragment3.f74236A4.get(dRETestViewerActivityFragment3.f74237B4);
                String string = bundle.getString("id");
                Bundle bundle2 = DRETestViewerActivityFragment.this.f74238C4;
                String str = "100";
                if (bundle2 != null) {
                    String string2 = bundle2.getString("id");
                    DRETestViewerActivityFragment dRETestViewerActivityFragment4 = DRETestViewerActivityFragment.this;
                    ArrayList<Bundle> m4955V = dRETestViewerActivityFragment4.f75863p4.m4955V(dRETestViewerActivityFragment4.f75850c4, "Select * from logs where testId=" + string2 + " AND qid = " + string);
                    if (m4955V == null || m4955V.size() <= 0) {
                        if (DRETestViewerActivityFragment.this.f74238C4.getString("done").equals(IcyHeaders.f35463C2)) {
                            DRETestViewerActivityFragment.this.m4720H4("100", false);
                            return;
                        }
                    } else if (!DRETestViewerActivityFragment.this.f74238C4.getString("mode").equals("Testing")) {
                        DRETestViewerActivityFragment.this.m4720H4(m4955V.get(0).getString("selectedAnswer"), false);
                        return;
                    } else if (!DRETestViewerActivityFragment.this.f74238C4.getString("done").equals("0")) {
                        DRETestViewerActivityFragment.this.m4720H4(m4955V.get(0).getString("selectedAnswer"), false);
                        return;
                    } else {
                        str = m4955V.get(0).getString("selectedAnswer");
                    }
                }
                String m5015B = DRETestViewerActivityFragment.this.f75863p4.m5015B(bundle.getString("question"), string, "127");
                String string3 = bundle.getString("explanation");
                if (string3 != null) {
                    DRETestViewerActivityFragment.this.f75863p4.m5015B(string3, string, "127");
                }
                DRETestViewerActivityFragment dRETestViewerActivityFragment5 = DRETestViewerActivityFragment.this;
                String m4117W3 = dRETestViewerActivityFragment5.m4117W3(dRETestViewerActivityFragment5.m44716w(), "DREHeader.css");
                StringBuilder sb2 = new StringBuilder();
                sb2.append(m4117W3);
                DRETestViewerActivityFragment dRETestViewerActivityFragment6 = DRETestViewerActivityFragment.this;
                sb2.append(dRETestViewerActivityFragment6.m4117W3(dRETestViewerActivityFragment6.m44716w(), "DREQuestion.css"));
                String replace = sb2.toString().replace("[size]", "200");
                ArrayList arrayList = new ArrayList();
                String string4 = bundle.getString("otherMedias");
                if (string4.length() > 0) {
                    for (String str2 : StringUtils.splitByWholeSeparator(string4, ",")) {
                        arrayList.add(str2);
                    }
                }
                DRETestViewerActivityFragment.this.m4725C4(arrayList);
                DRETestViewerActivityFragment.this.m4726B4();
                DRETestViewerActivityFragment dRETestViewerActivityFragment7 = DRETestViewerActivityFragment.this;
                ArrayList<Bundle> m4955V2 = dRETestViewerActivityFragment7.f75863p4.m4955V(dRETestViewerActivityFragment7.f75850c4, "select * from answers where qId = " + string);
                String replace2 = replace.replace("[correctID]", bundle.getString("corrAns")).replace("[Question]", m5015B);
                Iterator<Bundle> it2 = m4955V2.iterator();
                String str3 = "";
                while (it2.hasNext()) {
                    Bundle next = it2.next();
                    String m5015B2 = DRETestViewerActivityFragment.this.f75863p4.m5015B(next.getString("answerText"), string, "127");
                    String string5 = next.getString("row");
                    str3 = str3 + ("<tr><td width=\"16\" id=\"Qbank-Answer-Row-Image-" + string5 + "\"></td><td><input type=\"radio\" name=\"Qbank-Answer-Button-Group\" onclick=\"answerChanged(" + string5 + ")\" " + (string5.equals(str) ? "checked=\"checked\"" : "") + "></td><td class=\"answerOptionNumber\"><span>" + DRETestViewerActivityFragment.this.m4721G4(string5) + ". </span></td><td><span id=\"AnswerText" + string5 + "\" onclick=\"answerClickedForStrikeout(" + string5 + ");\">" + m5015B2 + "</span></td></tr>");
                }
                DRETestViewerActivityFragment.this.f75847Z3 = replace2.replace("[Answers]", str3 + "<p style=\"text-align:left;font-size:small;\">" + (bundle.getString("type") + " - " + bundle.getString("area") + " - " + bundle.getString("Month") + " - " + bundle.getString("Year")) + "</p>").replace(";font-family:", ";disable-font-family:").replace("style=\"font-family:", "style=\"disable-font-family:");
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = DRETestViewerActivityFragment.this.f75837P3;
                if (str == null || str.length() <= 0) {
                    DRETestViewerActivityFragment.this.m4718J4();
                    return;
                }
                DRETestViewerActivityFragment dRETestViewerActivityFragment = DRETestViewerActivityFragment.this;
                dRETestViewerActivityFragment.m4078s4(dRETestViewerActivityFragment.f75837P3);
            }
        });
    }

    /* renamed from: J4 */
    public void m4718J4() {
        File file = new File(CompressHelper.m4945Y0(this.f75850c4, "base"));
        this.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", this.f75847Z3, "text/html", "utf-8", null);
        String str = this.f75852e4;
        if (str != null) {
            this.f75858k4.setTitle(str);
            m4101e4(this.f75852e4);
            m4130O2();
        }
        mo3978f4();
        m4096h4(this.f75858k4.getMenu());
        m4714N4();
    }

    /* renamed from: K4 */
    public void m4717K4(String str) {
        String str2;
        String string = this.f74236A4.get(this.f74237B4).getString("id");
        String string2 = this.f74236A4.get(this.f74237B4).getString("corrAns");
        Date date = new Date();
        String m4722F4 = m4722F4(date);
        long time = (date.getTime() - this.f74239D4.getTime()) / 1000;
        Bundle bundle = this.f74238C4;
        String string3 = bundle != null ? bundle.getString("id") : "null";
        ArrayList<Bundle> m4955V = this.f75863p4.m4955V(this.f75850c4, "Select * from logs where testId=" + string3 + " AND qid = " + string);
        if (m4955V == null || m4955V.size() <= 0) {
            str2 = "Insert into logs (id, qid, selectedAnswer, corrAnswer, answerDate, time, testId) values (null, " + string + ", " + str + ", " + string2 + ", '" + str + "', " + time + ", " + string3 + ")";
        } else {
            str2 = "Update logs set selectedAnswer = " + str + ", answerDate='" + m4722F4 + "', time=" + time + " where id=" + m4955V.get(0).getString("id");
        }
        this.f75863p4.m4897m(this.f75850c4, str2);
    }

    /* renamed from: L4 */
    public String m4716L4(String str) {
        ArrayList arrayList = new ArrayList(Arrays.asList(StringUtils.splitByWholeSeparator(str, "/")));
        arrayList.remove(arrayList.size() - 1);
        return StringUtils.join(arrayList, "/");
    }

    /* renamed from: N4 */
    public void m4714N4() {
        this.f75839R3.findItem(C4804R.C4808id.f86795action_stop).setVisible(false);
        if (this.f74238C4 != null) {
            this.f75839R3.findItem(C4804R.C4808id.f86795action_stop).setVisible(true);
        }
        m4711z4();
        m4727A4();
        if (this.f74237B4 <= 0) {
            m4713x4();
        }
        if (this.f74237B4 >= this.f74236A4.size() - 1) {
            m4712y4();
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: P3 */
    public boolean mo3571P3(ConsoleMessage consoleMessage) {
        String str;
        String[] splitByWholeSeparator;
        String[] split = consoleMessage.message().split(",,,,,");
        String m4945Y0 = CompressHelper.m4945Y0(this.f75850c4, "base");
        if (split[0].equals("images")) {
            if (split.length < 2) {
                return true;
            }
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(split[1], "|");
            ArrayList<String> arrayList = new ArrayList<>();
            for (String str2 : splitByWholeSeparator2) {
                if (str2.contains("/")) {
                    String replace = m4945Y0.replace("file://", "");
                    str = replace.substring(0, replace.length() - 1);
                    for (String str3 : StringUtils.splitByWholeSeparator(str2, "/")) {
                        str = str3.equals("..") ? m4716L4(str) : str + "/" + str3;
                    }
                } else {
                    str = m4945Y0 + "/" + str2;
                }
                if (new File(str).length() > SimpleExoPlayer.f32068s1) {
                    arrayList.add(str);
                }
                iMDLogger.m3290j("EPUB Images", "Imagepath = : " + str);
            }
            this.f74243x4 = arrayList;
            mo3978f4();
        } else if (split[0].equals("answer")) {
            String str4 = split[1];
            m4717K4(str4);
            Bundle bundle = this.f74238C4;
            if (bundle == null || !bundle.getString("mode").equals("Testing")) {
                m4720H4(str4, true);
            }
        }
        return super.mo3571P3(consoleMessage);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        return null;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        this.f75853f4.loadUrl("javascript:for (var i=0; i < document.images.length; i++) { document.images[i].onclick = function(e){window.location.href=\"image://\" + e.target.src;}}");
        this.f75853f4.loadUrl("javascript:onBodyLoad();");
        String str2 = this.f74240E4;
        if (str2 != null) {
            mo4144C3(str2);
            this.f74240E4 = null;
        }
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (this.f75863p4.m4955V(this.f75850c4, "Select CorrPerc from Questions limit 1") == null) {
            this.f74241F4 = true;
        } else {
            this.f74241F4 = false;
        }
        if (m44859B() == null) {
            return this.f75849b4;
        }
        try {
            String str = this.f75847Z3;
            if (str == null || str.length() == 0) {
                m4098g4();
                m44735q2(false);
                m4100f3(C4804R.C4811menu.f87406uworld_test);
                m4140G3();
                iMDLogger.m3294f("Loading Document", this.f75851d4);
                if (this.f75851d4.contains("-")) {
                    String[] split = this.f75851d4.split("-");
                    if (split[0].equals("test")) {
                        CompressHelper compressHelper = this.f75863p4;
                        Bundle bundle2 = this.f75850c4;
                        this.f74238C4 = compressHelper.m4907i1(compressHelper.m4955V(bundle2, "Select * from tests where id =" + split[1]));
                        CompressHelper compressHelper2 = this.f75863p4;
                        Bundle bundle3 = this.f75850c4;
                        this.f74236A4 = compressHelper2.m4955V(bundle3, "Select * from Questions where id in (" + this.f74238C4.getString("qIds") + ")");
                        this.f74237B4 = Integer.valueOf(this.f74238C4.getString("qIndex")).intValue();
                        if (m44859B().containsKey("gotoQIndex")) {
                            this.f74237B4 = m44859B().getInt("gotoQIndex");
                        }
                    } else if (split[0].equals("question")) {
                        CompressHelper compressHelper3 = this.f75863p4;
                        Bundle bundle4 = this.f75850c4;
                        this.f74236A4 = compressHelper3.m4955V(bundle4, "Select * from Questions where id=" + split[1]);
                        this.f74237B4 = 0;
                    } else if (split[0].equals("answer")) {
                        CompressHelper compressHelper4 = this.f75863p4;
                        Bundle bundle5 = this.f75850c4;
                        this.f74236A4 = compressHelper4.m4955V(bundle5, "Select * from Questions where id=" + split[1]);
                        this.f74237B4 = 0;
                        m4720H4(null, false);
                    }
                } else {
                    this.f74236A4 = this.f75863p4.m4955V(this.f75850c4, m44859B().getString("Query"));
                    this.f74237B4 = m44859B().getInt("QuestionIndex");
                }
                m4719I4();
            }
            m4087m3();
            m4092j4();
        } catch (Exception e) {
            e.printStackTrace();
            m4080r4(e);
        }
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int i;
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86771action_favorites) {
            new Bundle();
            String str = "Question " + this.f74236A4.get(this.f74237B4).getString("id") + " - " + this.f74236A4.get(this.f74237B4).getString("title");
            if (menuItem.getTitle().equals("Add Favorite")) {
                m4132N2(str, this.f75851d4);
                menuItem.setTitle("Remove Favorite");
                i = C4804R.C4807drawable.f86584ic_action_favorite_yellow;
            } else {
                mo4084p3(this.f75851d4);
                menuItem.setTitle("Add Favorite");
                i = C4804R.C4807drawable.f86582ic_action_favorite;
            }
            menuItem.setIcon(i);
            return true;
        } else if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4715M4("asdfafdsaf");
            return true;
        } else {
            if (itemId == C4804R.C4808id.f86780action_previous) {
                this.f74237B4--;
                m4719I4();
                m4714N4();
            }
            if (itemId == C4804R.C4808id.f86778action_next) {
                this.f74237B4++;
                m4719I4();
                m4714N4();
                if (this.f74238C4 != null) {
                    this.f75863p4.m4897m(this.f75850c4, "Update tests set qIndex=" + this.f74237B4 + " where id=" + this.f74238C4.getString("id"));
                }
            }
            if (itemId == C4804R.C4808id.f86795action_stop) {
                new AlertDialog.Builder(m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("اتمام آزمون ؟").mo26266y("بله", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestViewerActivityFragment.6
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        DRETestViewerActivityFragment dRETestViewerActivityFragment = DRETestViewerActivityFragment.this;
                        if (dRETestViewerActivityFragment.f74238C4 == null) {
                            return;
                        }
                        CompressHelper compressHelper = dRETestViewerActivityFragment.f75863p4;
                        Bundle bundle = dRETestViewerActivityFragment.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select questions.id,selectedAnswer,corrAnswer,time  from Questions left outer join (select * from logs where testId=" + DRETestViewerActivityFragment.this.f74238C4.getString("id") + ") as logs2 on questions.id=logs2.qid where questions.id in (" + DRETestViewerActivityFragment.this.f74238C4.getString("qIds") + ")");
                        Iterator<Bundle> it2 = m4955V.iterator();
                        float f = 0.0f;
                        while (it2.hasNext()) {
                            Bundle next = it2.next();
                            if (next.getString("selectedAnswer").length() != 0 && next.getString("selectedAnswer").equals(next.getString("corrAnswer"))) {
                                f += 1.0f;
                            }
                        }
                        int size = (int) ((f / m4955V.size()) * 100.0f);
                        DRETestViewerActivityFragment dRETestViewerActivityFragment2 = DRETestViewerActivityFragment.this;
                        CompressHelper compressHelper2 = dRETestViewerActivityFragment2.f75863p4;
                        Bundle bundle2 = dRETestViewerActivityFragment2.f75850c4;
                        compressHelper2.m4897m(bundle2, "Update tests set score='" + size + "', done=1 where id=" + DRETestViewerActivityFragment.this.f74238C4.getString("id"));
                        DRETestViewerActivityFragment dRETestViewerActivityFragment3 = DRETestViewerActivityFragment.this;
                        CompressHelper compressHelper3 = dRETestViewerActivityFragment3.f75863p4;
                        Bundle bundle3 = dRETestViewerActivityFragment3.f75850c4;
                        compressHelper3.m4883q1(bundle3, "testresult-" + DRETestViewerActivityFragment.this.f74238C4.getString("id"), null, null);
                    }
                }).mo26284p("خیر", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestViewerActivityFragment.5
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                    }
                }).m52864I();
            }
            return super.mo3709e1(menuItem);
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: m4 */
    public boolean mo3567m4() {
        return false;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        if (str2.equals("image")) {
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "/");
            m4715M4(splitByWholeSeparator[splitByWholeSeparator.length - 1]);
            return true;
        }
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        if (str3.contains("USMLEWorld-Question-Answer-Changed")) {
            this.f75853f4.loadUrl("javascript:console.log(\"answer,,,,,\" + prevAnswerID);");
            return true;
        } else if (str3.contains("/2323")) {
            m4715M4("soheilvb");
            return true;
        } else {
            if (str2.equals(Annotation.f59806M2)) {
                String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str3, "/");
                m4715M4(splitByWholeSeparator2[splitByWholeSeparator2.length - 1]);
            }
            return true;
        }
    }

    /* renamed from: x4 */
    public void m4713x4() {
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setEnabled(false);
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setIcon(C4804R.C4807drawable.f86590ic_action_previous_item_disabled);
    }

    /* renamed from: y4 */
    public void m4712y4() {
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setEnabled(false);
        this.f75839R3.findItem(C4804R.C4808id.f86778action_next).setIcon(C4804R.C4807drawable.f86587ic_action_next_item_disabled);
    }

    /* renamed from: z4 */
    public void m4711z4() {
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setEnabled(true);
        this.f75839R3.findItem(C4804R.C4808id.f86780action_previous).setIcon(C4804R.C4807drawable.f86588ic_action_previous_item);
    }
}
