package net.imedicaldoctor.imd.Fragments.DRE;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextCheckViewHolder;

/* loaded from: classes2.dex */
public class DRESelectDialog extends DialogFragment {
    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87174fragment_new_section_viewer, (ViewGroup) null);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(C4804R.C4808id.f87001recycler_view);
        ArrayList parcelableArrayList = m44859B().getParcelableArrayList("Items");
        String string = m44859B().getString("TitleProperty");
        final int i = m44859B().containsKey("Position") ? m44859B().getInt("Position") : 0;
        recyclerView.setAdapter(new ChaptersAdapter(m44716w(), parcelableArrayList, string, C4804R.C4810layout.f87263list_view_item_ripple_text_check) { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRESelectDialog.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, final int i2) {
                ImageView imageView;
                int i3;
                RippleTextCheckViewHolder rippleTextCheckViewHolder = (RippleTextCheckViewHolder) viewHolder;
                rippleTextCheckViewHolder.f83270I.setTypeface(ResourcesCompat.m47479g(DRESelectDialog.this.m44716w(), C4804R.font.f86758iransans));
                if (i2 == i) {
                    imageView = rippleTextCheckViewHolder.f83272K;
                    i3 = 0;
                } else {
                    imageView = rippleTextCheckViewHolder.f83272K;
                    i3 = 8;
                }
                imageView.setVisibility(i3);
                rippleTextCheckViewHolder.f83270I.setText(bundle2.getString(this.f83217f));
                rippleTextCheckViewHolder.f83271J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRESelectDialog.1.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        DRESelectDialog.this.mo27002R2();
                        DRESelectDialog.this.m4734j3(bundle2, i2);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                return new RippleTextCheckViewHolder(view);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
        recyclerView.m42923n(new DividerItemDecoration(m44716w(), 1));
        builder.setView(inflate);
        return builder.create();
    }

    /* renamed from: j3 */
    public void m4734j3(Bundle bundle, int i) {
        if (m44753k0() instanceof DREMainActivityFragment) {
            ((DREMainActivityFragment) m44753k0()).m4739u3(m44859B().getString("Type"), bundle, i);
        }
    }
}
