package net.imedicaldoctor.imd.Fragments.DRE;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.res.ResourcesCompat;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter;
import net.imedicaldoctor.imd.ViewHolders.HeaderCellViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleSearchContentViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class DREMainActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public ArrayList<String> f74131b4;

    /* renamed from: c4 */
    public ArrayList<Bundle> f74132c4;

    /* renamed from: d4 */
    public ArrayList<Bundle> f74133d4;

    /* renamed from: e4 */
    public ArrayList<Bundle> f74134e4;

    /* renamed from: f4 */
    public ArrayList<Bundle> f74135f4;

    /* renamed from: g4 */
    public ArrayList<Bundle> f74136g4;

    /* renamed from: h4 */
    public ArrayList<Bundle> f74137h4;

    /* renamed from: i4 */
    public ArrayList<Bundle> f74138i4;

    /* renamed from: j4 */
    public ArrayList<Bundle> f74139j4;

    /* renamed from: k4 */
    public ArrayList<Bundle> f74140k4;

    /* renamed from: v4 */
    public boolean f74151v4;

    /* renamed from: l4 */
    public int f74141l4 = 0;

    /* renamed from: m4 */
    public int f74142m4 = 0;

    /* renamed from: n4 */
    public int f74143n4 = 0;

    /* renamed from: o4 */
    public int f74144o4 = 0;

    /* renamed from: p4 */
    public int f74145p4 = 0;

    /* renamed from: q4 */
    public int f74146q4 = 0;

    /* renamed from: r4 */
    public int f74147r4 = 40;

    /* renamed from: s4 */
    public int f74148s4 = 0;

    /* renamed from: t4 */
    public int f74149t4 = 0;

    /* renamed from: u4 */
    public int f74150u4 = 0;

    /* renamed from: w4 */
    private final String f74152w4 = "سوالات";

    /* renamed from: x4 */
    private final String f74153x4 = "ساخت آزمون";

    /* renamed from: y4 */
    private final String f74154y4 = "آزمون های قبلی";

    /* renamed from: z4 */
    private final String f74155z4 = "تنظیمات";

    /* renamed from: A4 */
    private final String f74122A4 = "subject";

    /* renamed from: B4 */
    private final String f74123B4 = "system";

    /* renamed from: C4 */
    private final String f74124C4 = "type";

    /* renamed from: D4 */
    private final String f74125D4 = "year";

    /* renamed from: E4 */
    private final String f74126E4 = "area";

    /* renamed from: F4 */
    private final String f74127F4 = "numberquestion";

    /* renamed from: G4 */
    private final String f74128G4 = "testMode";

    /* renamed from: H4 */
    private final String f74129H4 = "filter";

    /* renamed from: I4 */
    private final String f74130I4 = "hardness";

    /* loaded from: classes2.dex */
    public class AccountTextViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        private TextView f74163I;

        /* renamed from: J */
        private MaterialRippleLayout f74164J;

        public AccountTextViewHolder(View view) {
            super(view);
            this.f74163I = (TextView) view.findViewById(C4804R.C4808id.text);
            this.f74164J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        }
    }

    /* loaded from: classes2.dex */
    public class UWAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        private final int f74166d = 0;

        /* renamed from: e */
        private final int f74167e = 4;

        /* renamed from: f */
        private final int f74168f = 1;

        /* renamed from: g */
        private final int f74169g = 2;

        /* renamed from: h */
        private final int f74170h = 3;

        public UWAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            DREMainActivityFragment dREMainActivityFragment = DREMainActivityFragment.this;
            Bundle m4748l3 = dREMainActivityFragment.m4748l3(i, dREMainActivityFragment.f74131b4);
            if (!m4748l3.getString("Type").equals("Header") && m4748l3.getString("Type").equals("Item")) {
                String string = m4748l3.getString("Section");
                int i2 = m4748l3.getInt("Index");
                if (string.equals("سوالات")) {
                    return 1;
                }
                if (string.equals("ساخت آزمون")) {
                    if (DREMainActivityFragment.this.f74151v4) {
                        if (i2 == 8) {
                            return 4;
                        }
                        return i2 == 7 ? 3 : 2;
                    } else if (i2 == 10) {
                        return 4;
                    } else {
                        return i2 == 9 ? 3 : 2;
                    }
                } else if (string.equals("آزمون های قبلی")) {
                    return 1;
                } else {
                    if (string.equals("تنظیمات")) {
                        return 3;
                    }
                }
            }
            return 0;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            MaterialRippleLayout materialRippleLayout;
            View.OnClickListener onClickListener;
            AccountTextViewHolder accountTextViewHolder;
            HeaderCellViewHolder headerCellViewHolder;
            TextView textView;
            StringBuilder sb;
            DREMainActivityFragment dREMainActivityFragment = DREMainActivityFragment.this;
            Bundle m4748l3 = dREMainActivityFragment.m4748l3(i, dREMainActivityFragment.f74131b4);
            if (m4748l3.getString("Type").equals("Header")) {
                HeaderCellViewHolder headerCellViewHolder2 = (HeaderCellViewHolder) viewHolder;
                headerCellViewHolder2.f83245I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                headerCellViewHolder2.f83245I.setText(m4748l3.getString("Text"));
            }
            if (m4748l3.getString("Type").equals("Item")) {
                String string = m4748l3.getString("Section");
                int i2 = m4748l3.getInt("Index");
                if (string.equals("سوالات")) {
                    RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                    rippleTextViewHolder.f83300I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                    if (i2 == 0) {
                        rippleTextViewHolder.f83300I.setText("تمام سوالات");
                        materialRippleLayout = rippleTextViewHolder.f83301J;
                        onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                DREMainActivityFragment dREMainActivityFragment2 = DREMainActivityFragment.this;
                                dREMainActivityFragment2.f75215L3.m4979N(DRETocActivity.class, DRETocActivityFragment.class, dREMainActivityFragment2.m4745o3("0"));
                            }
                        };
                    } else if (i2 != 1) {
                        return;
                    } else {
                        rippleTextViewHolder.f83300I.setText("سوالات دلخواه");
                        materialRippleLayout = rippleTextViewHolder.f83301J;
                        onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.2
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                DREMainActivityFragment dREMainActivityFragment2 = DREMainActivityFragment.this;
                                dREMainActivityFragment2.f75215L3.m4979N(DRETocActivity.class, DRETocActivityFragment.class, dREMainActivityFragment2.m4745o3(ExifInterface.f14411T4));
                            }
                        };
                    }
                } else if (string.equals("ساخت آزمون")) {
                    DREMainActivityFragment dREMainActivityFragment2 = DREMainActivityFragment.this;
                    if (dREMainActivityFragment2.f74151v4) {
                        if (i2 == 8) {
                            headerCellViewHolder = (HeaderCellViewHolder) viewHolder;
                            textView = headerCellViewHolder.f83245I;
                            sb = new StringBuilder();
                            sb.append(DREMainActivityFragment.this.f74141l4);
                            sb.append(" سوال ");
                            textView.setText(sb.toString());
                            headerCellViewHolder.f83245I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                            return;
                        } else if (i2 == 7) {
                            accountTextViewHolder = (AccountTextViewHolder) viewHolder;
                            accountTextViewHolder.f74163I.setTextColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
                            accountTextViewHolder.f74163I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                            if (DREMainActivityFragment.this.f74141l4 > 0) {
                                accountTextViewHolder.f74164J.setBackgroundColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.green_dark));
                                accountTextViewHolder.f74163I.setText("ساخت امتحان");
                                materialRippleLayout = accountTextViewHolder.f74164J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.3
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment3 = DREMainActivityFragment.this;
                                        String str = StringUtils.splitByWholeSeparator(dREMainActivityFragment3.f74137h4.get(dREMainActivityFragment3.f74147r4).getString("title"), StringUtils.SPACE)[0];
                                        String m4746n3 = DREMainActivityFragment.this.m4746n3(new Date());
                                        DREMainActivityFragment dREMainActivityFragment4 = DREMainActivityFragment.this;
                                        String string2 = dREMainActivityFragment4.f74132c4.get(dREMainActivityFragment4.f74142m4).getString("name");
                                        String m4741s3 = DREMainActivityFragment.this.m4741s3();
                                        DREMainActivityFragment dREMainActivityFragment5 = DREMainActivityFragment.this;
                                        CompressHelper compressHelper = dREMainActivityFragment5.f75215L3;
                                        Bundle bundle = dREMainActivityFragment5.f75212I3;
                                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select id from questions where " + m4741s3 + " order by random() limit " + str);
                                        ArrayList arrayList = new ArrayList();
                                        Iterator<Bundle> it2 = m4955V.iterator();
                                        while (it2.hasNext()) {
                                            arrayList.add(it2.next().getString("id"));
                                        }
                                        String join = StringUtils.join(arrayList, ",");
                                        ArrayList arrayList2 = new ArrayList();
                                        arrayList2.add("Reading");
                                        arrayList2.add("Testing");
                                        DREMainActivityFragment dREMainActivityFragment6 = DREMainActivityFragment.this;
                                        CompressHelper compressHelper2 = dREMainActivityFragment6.f75215L3;
                                        Bundle bundle2 = dREMainActivityFragment6.f75212I3;
                                        compressHelper2.m4897m(bundle2, "Insert into Tests (id, qIds, createdDate, qIndex, done, mode, right, wrong, subject, system, hard) values (null, '" + join + "', '" + m4746n3 + "', 0, 0, '" + ((String) arrayList2.get(DREMainActivityFragment.this.f74148s4)) + "', 0, 0, '" + string2 + "', '', '')");
                                        DREMainActivityFragment dREMainActivityFragment7 = DREMainActivityFragment.this;
                                        CompressHelper compressHelper3 = dREMainActivityFragment7.f75215L3;
                                        String string3 = compressHelper3.m4907i1(compressHelper3.m4955V(dREMainActivityFragment7.f75212I3, "SELECT id FROM Tests ORDER BY id DESC LIMIT 1")).getString("id");
                                        DREMainActivityFragment dREMainActivityFragment8 = DREMainActivityFragment.this;
                                        CompressHelper compressHelper4 = dREMainActivityFragment8.f75215L3;
                                        Bundle bundle3 = dREMainActivityFragment8.f75212I3;
                                        StringBuilder sb2 = new StringBuilder();
                                        sb2.append("test-");
                                        sb2.append(string3);
                                        compressHelper4.m4883q1(bundle3, sb2.toString(), null, null);
                                    }
                                };
                            }
                            accountTextViewHolder.f74164J.setBackgroundColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.f86225material_grey_700));
                            accountTextViewHolder.f74163I.setText("سوالی وجود ندارد");
                            return;
                        } else {
                            RippleTextViewHolder rippleTextViewHolder2 = (RippleTextViewHolder) viewHolder;
                            rippleTextViewHolder2.f83300I.setTypeface(ResourcesCompat.m47479g(dREMainActivityFragment2.m44716w(), C4804R.font.f86758iransans));
                            if (i2 == 0) {
                                TextView textView2 = rippleTextViewHolder2.f83300I;
                                DREMainActivityFragment dREMainActivityFragment3 = DREMainActivityFragment.this;
                                textView2.setText(dREMainActivityFragment3.f74137h4.get(dREMainActivityFragment3.f74147r4).getString("title"));
                                materialRippleLayout = rippleTextViewHolder2.f83301J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.4
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment4 = DREMainActivityFragment.this;
                                        dREMainActivityFragment4.m4738v3("numberquestion", dREMainActivityFragment4.f74137h4, "title", dREMainActivityFragment4.f74147r4);
                                    }
                                };
                            } else if (i2 == 1) {
                                TextView textView3 = rippleTextViewHolder2.f83300I;
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append("حالت آزمون : ");
                                DREMainActivityFragment dREMainActivityFragment4 = DREMainActivityFragment.this;
                                sb2.append(dREMainActivityFragment4.f74138i4.get(dREMainActivityFragment4.f74148s4).getString("title"));
                                textView3.setText(sb2.toString());
                                materialRippleLayout = rippleTextViewHolder2.f83301J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.5
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment5 = DREMainActivityFragment.this;
                                        dREMainActivityFragment5.m4738v3("testMode", dREMainActivityFragment5.f74138i4, "title", dREMainActivityFragment5.f74148s4);
                                    }
                                };
                            } else if (i2 == 2) {
                                TextView textView4 = rippleTextViewHolder2.f83300I;
                                DREMainActivityFragment dREMainActivityFragment5 = DREMainActivityFragment.this;
                                textView4.setText(dREMainActivityFragment5.f74132c4.get(dREMainActivityFragment5.f74142m4).getString("name"));
                                materialRippleLayout = rippleTextViewHolder2.f83301J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.6
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment6 = DREMainActivityFragment.this;
                                        dREMainActivityFragment6.m4738v3("subject", dREMainActivityFragment6.f74132c4, "name", dREMainActivityFragment6.f74142m4);
                                    }
                                };
                            } else if (i2 == 3) {
                                TextView textView5 = rippleTextViewHolder2.f83300I;
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append("نوع سوالات : ");
                                DREMainActivityFragment dREMainActivityFragment6 = DREMainActivityFragment.this;
                                sb3.append(dREMainActivityFragment6.f74134e4.get(dREMainActivityFragment6.f74145p4).getString("name"));
                                textView5.setText(sb3.toString());
                                materialRippleLayout = rippleTextViewHolder2.f83301J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.7
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment7 = DREMainActivityFragment.this;
                                        dREMainActivityFragment7.m4738v3("type", dREMainActivityFragment7.f74134e4, "name", dREMainActivityFragment7.f74145p4);
                                    }
                                };
                            } else if (i2 == 4) {
                                TextView textView6 = rippleTextViewHolder2.f83300I;
                                StringBuilder sb4 = new StringBuilder();
                                sb4.append("منطقه : ");
                                DREMainActivityFragment dREMainActivityFragment7 = DREMainActivityFragment.this;
                                sb4.append(dREMainActivityFragment7.f74136g4.get(dREMainActivityFragment7.f74146q4).getString("name"));
                                textView6.setText(sb4.toString());
                                materialRippleLayout = rippleTextViewHolder2.f83301J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.8
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment8 = DREMainActivityFragment.this;
                                        dREMainActivityFragment8.m4738v3("area", dREMainActivityFragment8.f74136g4, "name", dREMainActivityFragment8.f74146q4);
                                    }
                                };
                            } else if (i2 == 5) {
                                TextView textView7 = rippleTextViewHolder2.f83300I;
                                StringBuilder sb5 = new StringBuilder();
                                sb5.append("زمان : ");
                                DREMainActivityFragment dREMainActivityFragment8 = DREMainActivityFragment.this;
                                sb5.append(dREMainActivityFragment8.f74135f4.get(dREMainActivityFragment8.f74144o4).getString("name"));
                                textView7.setText(sb5.toString());
                                materialRippleLayout = rippleTextViewHolder2.f83301J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.9
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment9 = DREMainActivityFragment.this;
                                        dREMainActivityFragment9.m4738v3("year", dREMainActivityFragment9.f74135f4, "name", dREMainActivityFragment9.f74144o4);
                                    }
                                };
                            } else if (i2 != 6) {
                                return;
                            } else {
                                TextView textView8 = rippleTextViewHolder2.f83300I;
                                StringBuilder sb6 = new StringBuilder();
                                sb6.append("محدود کردن : ");
                                DREMainActivityFragment dREMainActivityFragment9 = DREMainActivityFragment.this;
                                sb6.append(dREMainActivityFragment9.f74139j4.get(dREMainActivityFragment9.f74150u4).getString("title"));
                                textView8.setText(sb6.toString());
                                materialRippleLayout = rippleTextViewHolder2.f83301J;
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.10
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view) {
                                        DREMainActivityFragment dREMainActivityFragment10 = DREMainActivityFragment.this;
                                        dREMainActivityFragment10.m4738v3("filter", dREMainActivityFragment10.f74139j4, "title", dREMainActivityFragment10.f74150u4);
                                    }
                                };
                            }
                        }
                    } else if (i2 == 10) {
                        headerCellViewHolder = (HeaderCellViewHolder) viewHolder;
                        textView = headerCellViewHolder.f83245I;
                        sb = new StringBuilder();
                        sb.append(DREMainActivityFragment.this.f74141l4);
                        sb.append(" سوال ");
                        textView.setText(sb.toString());
                        headerCellViewHolder.f83245I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                        return;
                    } else if (i2 == 9) {
                        accountTextViewHolder = (AccountTextViewHolder) viewHolder;
                        accountTextViewHolder.f74163I.setTextColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
                        accountTextViewHolder.f74163I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                        if (DREMainActivityFragment.this.f74141l4 > 0) {
                            accountTextViewHolder.f74164J.setBackgroundColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.green_dark));
                            accountTextViewHolder.f74163I.setText("ساخت امتحان");
                            materialRippleLayout = accountTextViewHolder.f74164J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.11
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment10 = DREMainActivityFragment.this;
                                    String str = StringUtils.splitByWholeSeparator(dREMainActivityFragment10.f74137h4.get(dREMainActivityFragment10.f74147r4).getString("title"), StringUtils.SPACE)[0];
                                    String m4746n3 = DREMainActivityFragment.this.m4746n3(new Date());
                                    DREMainActivityFragment dREMainActivityFragment11 = DREMainActivityFragment.this;
                                    String string2 = dREMainActivityFragment11.f74132c4.get(dREMainActivityFragment11.f74142m4).getString("name");
                                    DREMainActivityFragment dREMainActivityFragment12 = DREMainActivityFragment.this;
                                    String string3 = dREMainActivityFragment12.f74133d4.get(dREMainActivityFragment12.f74143n4).getString("name");
                                    DREMainActivityFragment dREMainActivityFragment13 = DREMainActivityFragment.this;
                                    String string4 = dREMainActivityFragment13.f74140k4.get(dREMainActivityFragment13.f74149t4).getString("title");
                                    String m4741s3 = DREMainActivityFragment.this.m4741s3();
                                    DREMainActivityFragment dREMainActivityFragment14 = DREMainActivityFragment.this;
                                    CompressHelper compressHelper = dREMainActivityFragment14.f75215L3;
                                    Bundle bundle = dREMainActivityFragment14.f75212I3;
                                    ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle, "Select id from questions where " + m4741s3 + " order by random() limit " + str);
                                    ArrayList arrayList = new ArrayList();
                                    Iterator<Bundle> it2 = m4955V.iterator();
                                    while (it2.hasNext()) {
                                        arrayList.add(it2.next().getString("id"));
                                    }
                                    String join = StringUtils.join(arrayList, ",");
                                    ArrayList arrayList2 = new ArrayList();
                                    arrayList2.add("Reading");
                                    arrayList2.add("Testing");
                                    DREMainActivityFragment dREMainActivityFragment15 = DREMainActivityFragment.this;
                                    CompressHelper compressHelper2 = dREMainActivityFragment15.f75215L3;
                                    Bundle bundle2 = dREMainActivityFragment15.f75212I3;
                                    compressHelper2.m4897m(bundle2, "Insert into Tests (id, qIds, createdDate, qIndex, done, mode, right, wrong, subject, system, hard) values (null, '" + join + "', '" + m4746n3 + "', 0, 0, '" + ((String) arrayList2.get(DREMainActivityFragment.this.f74148s4)) + "', 0, 0, '" + string2 + "', '" + string3 + "', '" + string4 + "')");
                                    DREMainActivityFragment dREMainActivityFragment16 = DREMainActivityFragment.this;
                                    CompressHelper compressHelper3 = dREMainActivityFragment16.f75215L3;
                                    String string5 = compressHelper3.m4907i1(compressHelper3.m4955V(dREMainActivityFragment16.f75212I3, "SELECT id FROM Tests ORDER BY id DESC LIMIT 1")).getString("id");
                                    DREMainActivityFragment dREMainActivityFragment17 = DREMainActivityFragment.this;
                                    CompressHelper compressHelper4 = dREMainActivityFragment17.f75215L3;
                                    Bundle bundle3 = dREMainActivityFragment17.f75212I3;
                                    StringBuilder sb7 = new StringBuilder();
                                    sb7.append("test-");
                                    sb7.append(string5);
                                    compressHelper4.m4883q1(bundle3, sb7.toString(), null, null);
                                }
                            };
                        }
                        accountTextViewHolder.f74164J.setBackgroundColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.f86225material_grey_700));
                        accountTextViewHolder.f74163I.setText("سوالی وجود ندارد");
                        return;
                    } else {
                        RippleTextViewHolder rippleTextViewHolder3 = (RippleTextViewHolder) viewHolder;
                        rippleTextViewHolder3.f83300I.setTypeface(ResourcesCompat.m47479g(dREMainActivityFragment2.m44716w(), C4804R.font.f86758iransans));
                        if (i2 == 0) {
                            TextView textView9 = rippleTextViewHolder3.f83300I;
                            DREMainActivityFragment dREMainActivityFragment10 = DREMainActivityFragment.this;
                            textView9.setText(dREMainActivityFragment10.f74137h4.get(dREMainActivityFragment10.f74147r4).getString("title"));
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.12
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment11 = DREMainActivityFragment.this;
                                    dREMainActivityFragment11.m4738v3("numberquestion", dREMainActivityFragment11.f74137h4, "title", dREMainActivityFragment11.f74147r4);
                                }
                            };
                        } else if (i2 == 1) {
                            TextView textView10 = rippleTextViewHolder3.f83300I;
                            StringBuilder sb7 = new StringBuilder();
                            sb7.append("حالت آزمون : ");
                            DREMainActivityFragment dREMainActivityFragment11 = DREMainActivityFragment.this;
                            sb7.append(dREMainActivityFragment11.f74138i4.get(dREMainActivityFragment11.f74148s4).getString("title"));
                            textView10.setText(sb7.toString());
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.13
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment12 = DREMainActivityFragment.this;
                                    dREMainActivityFragment12.m4738v3("testMode", dREMainActivityFragment12.f74138i4, "title", dREMainActivityFragment12.f74148s4);
                                }
                            };
                        } else if (i2 == 2) {
                            TextView textView11 = rippleTextViewHolder3.f83300I;
                            DREMainActivityFragment dREMainActivityFragment12 = DREMainActivityFragment.this;
                            textView11.setText(dREMainActivityFragment12.f74132c4.get(dREMainActivityFragment12.f74142m4).getString("name"));
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.14
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment13 = DREMainActivityFragment.this;
                                    dREMainActivityFragment13.m4738v3("subject", dREMainActivityFragment13.f74132c4, "name", dREMainActivityFragment13.f74142m4);
                                }
                            };
                        } else if (i2 == 3) {
                            TextView textView12 = rippleTextViewHolder3.f83300I;
                            DREMainActivityFragment dREMainActivityFragment13 = DREMainActivityFragment.this;
                            textView12.setText(dREMainActivityFragment13.f74133d4.get(dREMainActivityFragment13.f74143n4).getString("name"));
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.15
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment14 = DREMainActivityFragment.this;
                                    dREMainActivityFragment14.m4738v3("system", dREMainActivityFragment14.f74133d4, "name", dREMainActivityFragment14.f74143n4);
                                }
                            };
                        } else if (i2 == 4) {
                            TextView textView13 = rippleTextViewHolder3.f83300I;
                            StringBuilder sb8 = new StringBuilder();
                            sb8.append("نوع سوالات : ");
                            DREMainActivityFragment dREMainActivityFragment14 = DREMainActivityFragment.this;
                            sb8.append(dREMainActivityFragment14.f74134e4.get(dREMainActivityFragment14.f74145p4).getString("name"));
                            textView13.setText(sb8.toString());
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.16
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment15 = DREMainActivityFragment.this;
                                    dREMainActivityFragment15.m4738v3("type", dREMainActivityFragment15.f74134e4, "name", dREMainActivityFragment15.f74145p4);
                                }
                            };
                        } else if (i2 == 5) {
                            TextView textView14 = rippleTextViewHolder3.f83300I;
                            StringBuilder sb9 = new StringBuilder();
                            sb9.append("منطقه : ");
                            DREMainActivityFragment dREMainActivityFragment15 = DREMainActivityFragment.this;
                            sb9.append(dREMainActivityFragment15.f74136g4.get(dREMainActivityFragment15.f74146q4).getString("name"));
                            textView14.setText(sb9.toString());
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.17
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment16 = DREMainActivityFragment.this;
                                    dREMainActivityFragment16.m4738v3("area", dREMainActivityFragment16.f74136g4, "name", dREMainActivityFragment16.f74146q4);
                                }
                            };
                        } else if (i2 == 6) {
                            TextView textView15 = rippleTextViewHolder3.f83300I;
                            StringBuilder sb10 = new StringBuilder();
                            sb10.append("زمان : ");
                            DREMainActivityFragment dREMainActivityFragment16 = DREMainActivityFragment.this;
                            sb10.append(dREMainActivityFragment16.f74135f4.get(dREMainActivityFragment16.f74144o4).getString("name"));
                            textView15.setText(sb10.toString());
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.18
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment17 = DREMainActivityFragment.this;
                                    dREMainActivityFragment17.m4738v3("year", dREMainActivityFragment17.f74135f4, "name", dREMainActivityFragment17.f74144o4);
                                }
                            };
                        } else if (i2 == 7) {
                            TextView textView16 = rippleTextViewHolder3.f83300I;
                            StringBuilder sb11 = new StringBuilder();
                            sb11.append("محدود کردن : ");
                            DREMainActivityFragment dREMainActivityFragment17 = DREMainActivityFragment.this;
                            sb11.append(dREMainActivityFragment17.f74139j4.get(dREMainActivityFragment17.f74150u4).getString("title"));
                            textView16.setText(sb11.toString());
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.19
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment18 = DREMainActivityFragment.this;
                                    dREMainActivityFragment18.m4738v3("filter", dREMainActivityFragment18.f74139j4, "title", dREMainActivityFragment18.f74150u4);
                                }
                            };
                        } else if (i2 != 8) {
                            return;
                        } else {
                            TextView textView17 = rippleTextViewHolder3.f83300I;
                            StringBuilder sb12 = new StringBuilder();
                            sb12.append("سختی : ");
                            DREMainActivityFragment dREMainActivityFragment18 = DREMainActivityFragment.this;
                            sb12.append(dREMainActivityFragment18.f74140k4.get(dREMainActivityFragment18.f74149t4).getString("title"));
                            textView17.setText(sb12.toString());
                            materialRippleLayout = rippleTextViewHolder3.f83301J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.20
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    DREMainActivityFragment dREMainActivityFragment19 = DREMainActivityFragment.this;
                                    dREMainActivityFragment19.m4738v3("hardness", dREMainActivityFragment19.f74140k4, "title", dREMainActivityFragment19.f74149t4);
                                }
                            };
                        }
                    }
                } else if (string.equals("آزمون های قبلی")) {
                    RippleTextViewHolder rippleTextViewHolder4 = (RippleTextViewHolder) viewHolder;
                    rippleTextViewHolder4.f83300I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                    if (i2 == 0) {
                        rippleTextViewHolder4.f83300I.setText("آخرین آزمون");
                        materialRippleLayout = rippleTextViewHolder4.f83301J;
                        onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.21
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                CompressHelper compressHelper;
                                Bundle bundle;
                                StringBuilder sb13;
                                String str;
                                DREMainActivityFragment dREMainActivityFragment19 = DREMainActivityFragment.this;
                                CompressHelper compressHelper2 = dREMainActivityFragment19.f75215L3;
                                Bundle m4907i1 = compressHelper2.m4907i1(compressHelper2.m4955V(dREMainActivityFragment19.f75212I3, "Select * from tests order by id desc limit 1"));
                                if (m4907i1 == null) {
                                    CompressHelper.m4921e2(DREMainActivityFragment.this.m44716w(), "تا الان آزمونی نساختید", 0);
                                    return;
                                }
                                if (m4907i1.getString("done").equals(IcyHeaders.f35463C2)) {
                                    DREMainActivityFragment dREMainActivityFragment20 = DREMainActivityFragment.this;
                                    compressHelper = dREMainActivityFragment20.f75215L3;
                                    bundle = dREMainActivityFragment20.f75212I3;
                                    sb13 = new StringBuilder();
                                    str = "testresult-";
                                } else {
                                    DREMainActivityFragment dREMainActivityFragment21 = DREMainActivityFragment.this;
                                    compressHelper = dREMainActivityFragment21.f75215L3;
                                    bundle = dREMainActivityFragment21.f75212I3;
                                    sb13 = new StringBuilder();
                                    str = "test-";
                                }
                                sb13.append(str);
                                sb13.append(m4907i1.getString("id"));
                                compressHelper.m4883q1(bundle, sb13.toString(), null, null);
                            }
                        };
                    } else if (i2 != 1) {
                        return;
                    } else {
                        rippleTextViewHolder4.f83300I.setText("آزمون های پیشین");
                        materialRippleLayout = rippleTextViewHolder4.f83301J;
                        onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.22
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                DREMainActivityFragment dREMainActivityFragment19 = DREMainActivityFragment.this;
                                dREMainActivityFragment19.f75215L3.m4979N(DRETestsListActivity.class, DRETestsListActivityFragment.class, dREMainActivityFragment19.m4745o3("0"));
                            }
                        };
                    }
                } else if (!string.equals("تنظیمات")) {
                    return;
                } else {
                    AccountTextViewHolder accountTextViewHolder2 = (AccountTextViewHolder) viewHolder;
                    accountTextViewHolder2.f74163I.setTypeface(ResourcesCompat.m47479g(DREMainActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                    accountTextViewHolder2.f74163I.setTextColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.white));
                    accountTextViewHolder2.f74163I.setText("پاک کردن تاریخچه");
                    accountTextViewHolder2.f74164J.setBackgroundColor(DREMainActivityFragment.this.m44782a0().getColor(C4804R.C4806color.red));
                    materialRippleLayout = accountTextViewHolder2.f74164J;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.23
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            new AlertDialog.Builder(DREMainActivityFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("This will delete all tests and history").mo26266y("OK", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.23.2
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface, int i3) {
                                    DREMainActivityFragment dREMainActivityFragment19 = DREMainActivityFragment.this;
                                    dREMainActivityFragment19.f75215L3.m4897m(dREMainActivityFragment19.f75212I3, "delete from logs");
                                    DREMainActivityFragment dREMainActivityFragment20 = DREMainActivityFragment.this;
                                    dREMainActivityFragment20.f75215L3.m4897m(dREMainActivityFragment20.f75212I3, "delete from tests");
                                    DREMainActivityFragment dREMainActivityFragment21 = DREMainActivityFragment.this;
                                    dREMainActivityFragment21.f75215L3.m4897m(dREMainActivityFragment21.f75212I3, "delete from flags");
                                }
                            }).mo26284p("Cancel", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.UWAdapter.23.1
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface dialogInterface, int i3) {
                                }
                            }).m52864I();
                        }
                    };
                }
                materialRippleLayout.setOnClickListener(onClickListener);
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i != 0) {
                if (i != 1) {
                    if (i != 2) {
                        if (i == 3) {
                            return new AccountTextViewHolder(LayoutInflater.from(DREMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87218list_view_item_account_text, viewGroup, false));
                        } else if (i != 4) {
                            return null;
                        } else {
                            return new HeaderCellViewHolder(LayoutInflater.from(DREMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87241list_view_item_footer, viewGroup, false));
                        }
                    }
                    return new RippleTextViewHolder(LayoutInflater.from(DREMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87270list_view_item_ripple_text_list, viewGroup, false));
                }
                return new RippleTextViewHolder(LayoutInflater.from(DREMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
            }
            return new HeaderCellViewHolder(LayoutInflater.from(DREMainActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false));
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            DREMainActivityFragment dREMainActivityFragment = DREMainActivityFragment.this;
            return dREMainActivityFragment.m4737w3(dREMainActivityFragment.f74131b4);
        }
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        m4337R2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        ((AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar)).m27445s(true, false);
        ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
        this.f74132c4 = this.f75215L3.m4955V(this.f75212I3, "select 0 as id,'تمام دروس' as name , sum(count) as count,0 o from lessons union select id, name,count, 1 o from lessons order by o,name");
        ArrayList<Bundle> m4955V = this.f75215L3.m4955V(this.f75212I3, "select 0 as id, 'تمام بخش ها' as name , sum(count) as count,0 o from divisions union select id, name,count,1 o from divisions order by o,name");
        this.f74133d4 = m4955V;
        if (m4955V == null) {
            this.f74151v4 = true;
        } else {
            this.f74151v4 = false;
        }
        this.f74134e4 = this.f75215L3.m4955V(this.f75212I3, "select 'تمام امتحان ها' as name,0 o from questions union select distinct(type) as name,1 o from questions order by o asc,name desc");
        this.f74135f4 = this.f75215L3.m4955V(this.f75212I3, "select 'تمام سال ها' as name,0 o from questions union select distinct(year) as name,1 o from questions order by o,name");
        this.f74136g4 = this.f75215L3.m4955V(this.f75212I3, "select 'تمام مناطق' as name,0 o from questions union select distinct(area) as name,1 o from questions order by o,name");
        this.f74137h4 = new ArrayList<>();
        for (int i = 0; i < 101; i++) {
            ArrayList<Bundle> arrayList = this.f74137h4;
            arrayList.add(m4744p3(i + " سوال "));
        }
        ArrayList<Bundle> arrayList2 = new ArrayList<>();
        this.f74138i4 = arrayList2;
        arrayList2.add(m4744p3("مطالعه"));
        this.f74138i4.add(m4744p3("امتحان"));
        if (!this.f74151v4) {
            ArrayList<Bundle> arrayList3 = new ArrayList<>();
            this.f74140k4 = arrayList3;
            arrayList3.add(m4742r3("تمام سوالات", "0", "100"));
            this.f74140k4.add(m4742r3("آسان", "75", "100"));
            this.f74140k4.add(m4742r3("متوسط", "50", "75"));
            this.f74140k4.add(m4742r3("سخت", "25", "50"));
            this.f74140k4.add(m4742r3("خیلی سخت", "0", "25"));
        }
        ArrayList<Bundle> arrayList4 = new ArrayList<>();
        this.f74139j4 = arrayList4;
        arrayList4.add(m4743q3("تمام سوالات", ""));
        this.f74139j4.add(m4743q3("زده نشده", "not (id in (select distinct qid from logs))"));
        this.f74139j4.add(m4743q3("نادرست", "id in (select qid from (select qid,max(rowid),selectedanswer<>corrAnswer as res from logs group by qid) where res=1) "));
        this.f74139j4.add(m4743q3("انتخاب شده", "id in (select qid from flags)"));
        m44735q2(false);
        ArrayList<String> arrayList5 = new ArrayList<>();
        this.f74131b4 = arrayList5;
        arrayList5.add("سوالات");
        this.f74131b4.add("ساخت آزمون");
        this.f74131b4.add("آزمون های قبلی");
        this.f74131b4.add("تنظیمات");
        this.f75217N3 = new ContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter
            /* renamed from: d0 */
            public void mo3398d0(RecyclerView.ViewHolder viewHolder, int i2, Bundle bundle2) {
                String str;
                StringBuilder sb;
                String str2;
                RippleSearchContentViewHolder rippleSearchContentViewHolder = (RippleSearchContentViewHolder) viewHolder;
                rippleSearchContentViewHolder.f83264I.setText(bundle2.getString("text"));
                final String string = bundle2.getString("type");
                final String string2 = bundle2.getString("contentId");
                if (string.equals("0")) {
                    rippleSearchContentViewHolder.f83265J.setVisibility(8);
                    rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.1.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            DREMainActivityFragment dREMainActivityFragment = DREMainActivityFragment.this;
                            CompressHelper compressHelper = dREMainActivityFragment.f75215L3;
                            Bundle bundle3 = dREMainActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "question-" + string2, null, null);
                        }
                    });
                    return;
                }
                if (string.equals(IcyHeaders.f35463C2)) {
                    sb = new StringBuilder();
                    sb.append("<font color=\"red\">");
                    str2 = "Question";
                } else if (string.equals(ExifInterface.f14403S4)) {
                    sb = new StringBuilder();
                    sb.append("<font color=\"red\">");
                    str2 = "Explanation";
                } else if (!string.equals(ExifInterface.f14411T4)) {
                    str = "";
                    final String str3 = str + StringUtils.SPACE + bundle2.getString("subText");
                    rippleSearchContentViewHolder.f83265J.setText(Html.fromHtml(str3));
                    rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.1.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            if (string.equals(ExifInterface.f14403S4)) {
                                DREMainActivityFragment dREMainActivityFragment = DREMainActivityFragment.this;
                                CompressHelper compressHelper = dREMainActivityFragment.f75215L3;
                                Bundle bundle3 = dREMainActivityFragment.f75212I3;
                                compressHelper.m4883q1(bundle3, "answer-" + string2, DREMainActivityFragment.this.m4332W2(str3), null);
                                return;
                            }
                            DREMainActivityFragment dREMainActivityFragment2 = DREMainActivityFragment.this;
                            CompressHelper compressHelper2 = dREMainActivityFragment2.f75215L3;
                            Bundle bundle4 = dREMainActivityFragment2.f75212I3;
                            compressHelper2.m4883q1(bundle4, "question-" + string2, DREMainActivityFragment.this.m4332W2(str3), null);
                        }
                    });
                } else {
                    sb = new StringBuilder();
                    sb.append("<font color=\"red\">");
                    str2 = "Answer";
                }
                sb.append(str2);
                sb.append("</font>");
                str = sb.toString();
                final String str32 = str + StringUtils.SPACE + bundle2.getString("subText");
                rippleSearchContentViewHolder.f83265J.setText(Html.fromHtml(str32));
                rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DREMainActivityFragment.1.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (string.equals(ExifInterface.f14403S4)) {
                            DREMainActivityFragment dREMainActivityFragment = DREMainActivityFragment.this;
                            CompressHelper compressHelper = dREMainActivityFragment.f75215L3;
                            Bundle bundle3 = dREMainActivityFragment.f75212I3;
                            compressHelper.m4883q1(bundle3, "answer-" + string2, DREMainActivityFragment.this.m4332W2(str32), null);
                            return;
                        }
                        DREMainActivityFragment dREMainActivityFragment2 = DREMainActivityFragment.this;
                        CompressHelper compressHelper2 = dREMainActivityFragment2.f75215L3;
                        Bundle bundle4 = dREMainActivityFragment2.f75212I3;
                        compressHelper2.m4883q1(bundle4, "question-" + string2, DREMainActivityFragment.this.m4332W2(str32), null);
                    }
                });
            }
        };
        m4747m3();
        UWAdapter uWAdapter = new UWAdapter();
        this.f75216M3 = uWAdapter;
        this.f75227X3.setAdapter(uWAdapter);
        m4338Q2();
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75217N3.m3396f0(this.f75219P3);
        this.f75227X3.setAdapter(this.f75217N3);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    /* renamed from: l3 */
    public Bundle m4748l3(int i, ArrayList<String> arrayList) {
        Iterator<String> it2 = arrayList.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            String next = it2.next();
            if (i == i2) {
                Bundle bundle = new Bundle();
                bundle.putString("Text", next);
                bundle.putString("Type", "Header");
                return bundle;
            }
            int m4740t3 = i2 + m4740t3(next);
            if (i <= m4740t3) {
                Bundle bundle2 = new Bundle();
                bundle2.putString("Section", next);
                bundle2.putInt("Index", (i - (m4740t3 - m4740t3(next))) - 1);
                bundle2.putString("Type", "Item");
                return bundle2;
            }
            i2 = m4740t3 + 1;
        }
        return null;
    }

    /* renamed from: m3 */
    public void m4747m3() {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(bundle, "select count(*) as c from questions where " + m4741s3()));
        this.f74141l4 = m4907i1 == null ? 0 : Integer.valueOf(m4907i1.getString("c")).intValue();
    }

    /* renamed from: n3 */
    public String m4746n3(Date date) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ").format(date);
    }

    /* renamed from: o3 */
    public Bundle m4745o3(String str) {
        Bundle bundle = new Bundle();
        bundle.putBundle("DB", this.f75212I3);
        bundle.putString("ParentId", str);
        return bundle;
    }

    /* renamed from: p3 */
    public Bundle m4744p3(String str) {
        Bundle bundle = new Bundle();
        bundle.putString("title", str);
        return bundle;
    }

    /* renamed from: q3 */
    public Bundle m4743q3(String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putString("title", str);
        bundle.putString("sql", str2);
        return bundle;
    }

    /* renamed from: r3 */
    public Bundle m4742r3(String str, String str2, String str3) {
        Bundle bundle = new Bundle();
        bundle.putString("title", str);
        bundle.putString("Min", str2);
        bundle.putString("Max", str3);
        return bundle;
    }

    /* renamed from: s3 */
    public String m4741s3() {
        ArrayList arrayList = new ArrayList();
        String string = this.f74132c4.get(this.f74142m4).getString("id");
        String string2 = !this.f74151v4 ? this.f74133d4.get(this.f74143n4).getString("id") : "";
        String string3 = this.f74134e4.get(this.f74145p4).getString("name");
        String string4 = this.f74135f4.get(this.f74144o4).getString("name");
        String string5 = this.f74136g4.get(this.f74146q4).getString("name");
        if (!this.f74151v4) {
            String string6 = this.f74140k4.get(this.f74149t4).getString("Min");
            String string7 = this.f74140k4.get(this.f74149t4).getString("Max");
            arrayList.add("CorrPerc > " + string6);
            arrayList.add("CorrPerc < " + string7);
        }
        String string8 = this.f74139j4.get(this.f74150u4).getString("sql");
        if (!string.equals("0")) {
            arrayList.add("lessonId = " + string);
        }
        if (!this.f74151v4 && !string2.equals("0")) {
            arrayList.add("divId = " + string2);
        }
        if (!string3.equals("تمام امتحان ها")) {
            arrayList.add("type = '" + string3 + "'");
        }
        if (!string4.equals("تمام سال ها")) {
            arrayList.add("Year = '" + string4 + "'");
        }
        if (!string5.equals("تمام مناطق")) {
            arrayList.add("area = '" + string5 + "'");
        }
        if (string8.length() > 0) {
            arrayList.add(string8);
        }
        if (arrayList.size() == 0) {
            arrayList.add("1=1");
        }
        return StringUtils.join(arrayList, " AND ");
    }

    /* renamed from: t3 */
    public int m4740t3(String str) {
        if (str.equals("سوالات")) {
            return 2;
        }
        if (str.equals("ساخت آزمون")) {
            return this.f74151v4 ? 9 : 11;
        } else if (str.equals("آزمون های قبلی")) {
            return 2;
        } else {
            return str.equals("تنظیمات") ? 1 : 0;
        }
    }

    /* renamed from: u3 */
    public void m4739u3(String str, Bundle bundle, int i) {
        if (str.equals("filter")) {
            this.f74150u4 = i;
        } else if (str.equals("hardness")) {
            this.f74149t4 = i;
        } else if (str.equals("testMode")) {
            this.f74148s4 = i;
        } else if (str.equals("numberquestion")) {
            this.f74147r4 = i;
        } else if (str.equals("system")) {
            this.f74143n4 = i;
        } else if (str.equals("subject")) {
            this.f74142m4 = i;
        } else if (str.equals("year")) {
            this.f74144o4 = i;
        } else if (str.equals("area")) {
            this.f74146q4 = i;
        } else if (str.equals("type")) {
            this.f74145p4 = i;
        }
        m4747m3();
        this.f75216M3.m42860G();
    }

    /* renamed from: v3 */
    public void m4738v3(String str, ArrayList<Bundle> arrayList, String str2, int i) {
        DRESelectDialog dRESelectDialog = new DRESelectDialog();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("Items", arrayList);
        bundle.putString("TitleProperty", str2);
        bundle.putInt("Position", i);
        bundle.putString("Type", str);
        dRESelectDialog.m44844E2(this, 0);
        dRESelectDialog.m44751k2(bundle);
        dRESelectDialog.m44870c3(true);
        dRESelectDialog.mo29915h3(m44820L(), "asdfasdfasdf");
    }

    /* renamed from: w3 */
    public int m4737w3(ArrayList<String> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return 0;
        }
        Iterator<String> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            i = i + m4740t3(it2.next()) + 1;
        }
        return i;
    }
}
