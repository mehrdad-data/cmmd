package net.imedicaldoctor.imd.Fragments.DRE;

import android.os.Bundle;
import java.util.ArrayList;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.Martindale.MDListActivity;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;

/* loaded from: classes2.dex */
public class DRETocActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public String f74272b4;

    /* renamed from: c4 */
    public String f74273c4 = "";

    /* renamed from: d4 */
    public boolean f74274d4;

    /* renamed from: e4 */
    public ArrayList<String> f74275e4;

    /* renamed from: f4 */
    public String f74276f4;

    /* JADX WARN: Removed duplicated region for block: B:49:0x028a  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x029e  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x02ad A[LOOP:0: B:55:0x02a7->B:57:0x02ad, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x02c7  */
    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.view.View mo3277U0(android.view.LayoutInflater r17, android.view.ViewGroup r18, android.os.Bundle r19) {
        /*
            Method dump skipped, instructions count: 803
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.Fragments.DRE.DRETocActivityFragment.mo3277U0(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle):android.view.View");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75217N3.m3396f0(this.f75219P3);
        this.f75227X3.setAdapter(this.f75217N3);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: k3 */
    public String mo4205k3() {
        return this.f74273c4;
    }

    /* renamed from: l3 */
    public void m4709l3(Bundle bundle, int i) {
        m4330Y2();
        if (!bundle.getString("docId").equals("0")) {
            this.f75215L3.m4883q1(this.f75212I3, bundle.getString("docId"), null, null);
            return;
        }
        Bundle bundle2 = new Bundle();
        bundle2.putBundle("DB", this.f75212I3);
        bundle2.putString("ParentId", bundle.getString("id"));
        this.f75215L3.m4979N(MDListActivity.class, DRETocActivityFragment.class, bundle2);
    }
}
