package net.imedicaldoctor.imd.Fragments.DRE;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.css.CSS;
import com.itextpdf.tool.xml.html.HTML;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.HeaderCellViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import saman.zamani.persiandate.PersianDate;
import saman.zamani.persiandate.PersianDateFormat;

/* loaded from: classes2.dex */
public class DRETestResultActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public UWTestResultAdapter f74202A4;

    /* renamed from: B4 */
    public ArrayList<Bundle> f74203B4;

    /* renamed from: C4 */
    public Bundle f74204C4;

    /* renamed from: D4 */
    public int f74205D4 = 0;

    /* renamed from: E4 */
    public int f74206E4 = 0;

    /* renamed from: F4 */
    public int f74207F4 = 0;

    /* renamed from: G4 */
    public final int f74208G4 = 0;

    /* renamed from: H4 */
    public final int f74209H4 = 1;

    /* renamed from: I4 */
    public final int f74210I4 = 2;

    /* renamed from: J4 */
    public final int f74211J4 = 3;

    /* renamed from: K4 */
    public boolean f74212K4;

    /* renamed from: w4 */
    public RecyclerView f74213w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f74214x4;

    /* renamed from: y4 */
    public Bundle f74215y4;

    /* renamed from: z4 */
    public ArrayList<String> f74216z4;

    /* loaded from: classes2.dex */
    public class QuestionViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74217I;

        /* renamed from: J */
        public TextView f74218J;

        /* renamed from: K */
        public TextView f74219K;

        /* renamed from: L */
        public TextView f74220L;

        /* renamed from: M */
        public ImageView f74221M;

        /* renamed from: N */
        public MaterialRippleLayout f74222N;

        public QuestionViewHolder(View view) {
            super(view);
            this.f74217I = (TextView) view.findViewById(C4804R.C4808id.f87053text_number);
            this.f74218J = (TextView) view.findViewById(C4804R.C4808id.f87057text_title);
            this.f74219K = (TextView) view.findViewById(C4804R.C4808id.f87048text_correct);
            this.f74222N = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            this.f74220L = (TextView) view.findViewById(C4804R.C4808id.f87056text_time);
            this.f74221M = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        }
    }

    /* loaded from: classes2.dex */
    public class TestScoreViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f74224I;

        /* renamed from: J */
        public TextView f74225J;

        /* renamed from: K */
        public TextView f74226K;

        /* renamed from: L */
        public TextView f74227L;

        /* renamed from: M */
        public ImageView f74228M;

        /* renamed from: N */
        public TextView f74229N;

        /* renamed from: O */
        public MaterialRippleLayout f74230O;

        public TestScoreViewHolder(View view) {
            super(view);
            this.f74224I = (TextView) view.findViewById(C4804R.C4808id.f87049text_date);
            this.f74225J = (TextView) view.findViewById(C4804R.C4808id.f87051text_info1);
            this.f74226K = (TextView) view.findViewById(C4804R.C4808id.f87052text_info2);
            this.f74230O = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
            this.f74227L = (TextView) view.findViewById(C4804R.C4808id.f87055text_score);
            this.f74228M = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
            this.f74229N = (TextView) view.findViewById(C4804R.C4808id.f87054text_resume);
        }
    }

    /* loaded from: classes2.dex */
    public class UWTestResultAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        public String f74232d;

        public UWTestResultAdapter() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            if (i == 0) {
                return 0;
            }
            if (i == 1) {
                return 1;
            }
            return i == DRETestResultActivityFragment.this.f74203B4.size() + 2 ? 3 : 2;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
            TextView textView;
            StringBuilder sb;
            ImageView imageView;
            Resources m44782a0;
            int i2;
            String str;
            int m42556F = viewHolder.m42556F();
            if (m42556F == 3) {
                HeaderCellViewHolder headerCellViewHolder = (HeaderCellViewHolder) viewHolder;
                headerCellViewHolder.f83245I.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                textView = headerCellViewHolder.f83245I;
                sb = new StringBuilder();
                sb.append(DRETestResultActivityFragment.this.f74205D4);
                sb.append(" درست . ");
                sb.append(DRETestResultActivityFragment.this.f74206E4);
                sb.append(" نادرست . ");
                sb.append(DRETestResultActivityFragment.this.f74207F4);
                sb.append(" نزده");
            } else if (m42556F == 1) {
                HeaderCellViewHolder headerCellViewHolder2 = (HeaderCellViewHolder) viewHolder;
                headerCellViewHolder2.f83245I.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                textView = headerCellViewHolder2.f83245I;
                str = "سوالات";
                textView.setText(str);
            } else if (m42556F == 2) {
                final int i3 = i - 2;
                Bundle bundle = DRETestResultActivityFragment.this.f74203B4.get(i3);
                QuestionViewHolder questionViewHolder = (QuestionViewHolder) viewHolder;
                questionViewHolder.f74217I.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                questionViewHolder.f74218J.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                questionViewHolder.f74220L.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                questionViewHolder.f74219K.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                questionViewHolder.f74217I.setText(String.valueOf(i3 + 1));
                questionViewHolder.f74218J.setText(bundle.getString("title"));
                if (DRETestResultActivityFragment.this.f74212K4) {
                    questionViewHolder.f74219K.setText("-");
                } else {
                    TextView textView2 = questionViewHolder.f74219K;
                    textView2.setText(bundle.getString("CorrPerc") + CSS.Value.f65657n0);
                }
                TextView textView3 = questionViewHolder.f74220L;
                textView3.setText(bundle.getString(HTML.Tag.f65879P0) + " ثانیه");
                String string = bundle.getString("selectedAnswer");
                String string2 = bundle.getString("corrAnswer");
                if (string.length() == 0) {
                    imageView = questionViewHolder.f74221M;
                    m44782a0 = DRETestResultActivityFragment.this.m44782a0();
                    i2 = C4804R.C4807drawable.f86669omitted_icon;
                } else if (string.equals(string2)) {
                    imageView = questionViewHolder.f74221M;
                    m44782a0 = DRETestResultActivityFragment.this.m44782a0();
                    i2 = C4804R.C4807drawable.f86561correct_icon;
                } else {
                    imageView = questionViewHolder.f74221M;
                    m44782a0 = DRETestResultActivityFragment.this.m44782a0();
                    i2 = C4804R.C4807drawable.f86611incorrect_icon;
                }
                imageView.setImageDrawable(m44782a0.getDrawable(i2));
                questionViewHolder.f74222N.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.DRE.DRETestResultActivityFragment.UWTestResultAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        Bundle bundle2 = new Bundle();
                        bundle2.putInt("gotoQIndex", i3);
                        DRETestResultActivityFragment dRETestResultActivityFragment = DRETestResultActivityFragment.this;
                        CompressHelper compressHelper = dRETestResultActivityFragment.f75863p4;
                        Bundle bundle3 = dRETestResultActivityFragment.f75850c4;
                        compressHelper.m4880r1(bundle3, "test-" + DRETestResultActivityFragment.this.f74204C4.getString("id"), null, null, bundle2);
                    }
                });
                return;
            } else if (m42556F != 0) {
                return;
            } else {
                TestScoreViewHolder testScoreViewHolder = (TestScoreViewHolder) viewHolder;
                testScoreViewHolder.f74224I.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74225J.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74226K.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74229N.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                testScoreViewHolder.f74227L.setTypeface(ResourcesCompat.m47479g(DRETestResultActivityFragment.this.m44716w(), C4804R.font.f86758iransans));
                TextView textView4 = testScoreViewHolder.f74224I;
                DRETestResultActivityFragment dRETestResultActivityFragment = DRETestResultActivityFragment.this;
                textView4.setText(dRETestResultActivityFragment.m4732y4(dRETestResultActivityFragment.f74204C4.getString("createdDate")));
                String str2 = DRETestResultActivityFragment.this.f74204C4.getString("mode").equals("Testing") ? "امتحان" : "مطالعه";
                TextView textView5 = testScoreViewHolder.f74225J;
                textView5.setText(DRETestResultActivityFragment.this.f74203B4.size() + " سوال . حالت مطالعه: " + str2);
                DRETestResultActivityFragment dRETestResultActivityFragment2 = DRETestResultActivityFragment.this;
                if (dRETestResultActivityFragment2.f74212K4) {
                    testScoreViewHolder.f74226K.setText(dRETestResultActivityFragment2.f74204C4.getString("subject"));
                } else {
                    TextView textView6 = testScoreViewHolder.f74226K;
                    textView6.setText(DRETestResultActivityFragment.this.f74204C4.getString("subject") + " , " + DRETestResultActivityFragment.this.f74204C4.getString("system"));
                }
                testScoreViewHolder.f74228M.setImageDrawable(DRETestResultActivityFragment.this.m44782a0().getDrawable(C4804R.C4807drawable.f86555circle_green));
                testScoreViewHolder.f74229N.setText("نمره");
                testScoreViewHolder.f74227L.setVisibility(0);
                textView = testScoreViewHolder.f74227L;
                sb = new StringBuilder();
                sb.append(DRETestResultActivityFragment.this.f74204C4.getString(FirebaseAnalytics.Param.f55169D));
                sb.append(CSS.Value.f65657n0);
            }
            str = sb.toString();
            textView.setText(str);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 3) {
                return new HeaderCellViewHolder(LayoutInflater.from(DRETestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87241list_view_item_footer, viewGroup, false));
            }
            if (i == 1) {
                return new HeaderCellViewHolder(LayoutInflater.from(DRETestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false));
            }
            if (i == 2) {
                return new QuestionViewHolder(LayoutInflater.from(DRETestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87236list_view_item_dre_quetion, viewGroup, false));
            } else if (i == 0) {
                return new TestScoreViewHolder(LayoutInflater.from(DRETestResultActivityFragment.this.m44716w()).inflate(C4804R.C4810layout.f87237list_view_item_dre_test, viewGroup, false));
            } else {
                return null;
            }
        }

        /* renamed from: d0 */
        public String m4731d0(String str) {
            return str;
        }

        /* renamed from: e0 */
        public void m4730e0(RecyclerView.ViewHolder viewHolder, Bundle bundle, int i) {
        }

        /* renamed from: f0 */
        public void m4729f0(Bundle bundle, int i) {
        }

        /* renamed from: g0 */
        public RecyclerView.ViewHolder m4728g0(View view) {
            return new RippleTextViewHolder(view);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return DRETestResultActivityFragment.this.f74203B4.size() + 2 + 1;
        }
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        CompressHelper compressHelper;
        Bundle bundle2;
        StringBuilder sb;
        String str;
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87170fragment_new_list_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        this.f74213w4 = (RecyclerView) this.f75849b4.findViewById(C4804R.C4808id.f87001recycler_view);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        String str2 = this.f75851d4.split("-")[1];
        if (this.f75863p4.m4955V(this.f75850c4, "Select CorrPerc from Questions limit 1") == null) {
            this.f74212K4 = true;
        } else {
            this.f74212K4 = false;
        }
        CompressHelper compressHelper2 = this.f75863p4;
        this.f74204C4 = compressHelper2.m4907i1(compressHelper2.m4955V(this.f75850c4, "select * from tests where id=" + str2));
        if (this.f74212K4) {
            compressHelper = this.f75863p4;
            bundle2 = this.f75850c4;
            sb = new StringBuilder();
            str = "Select questions.id,'سوال شماره '|| questions.id as title,selectedAnswer,corrAnswer,time  from Questions left outer join (select * from logs where testId=";
        } else {
            compressHelper = this.f75863p4;
            bundle2 = this.f75850c4;
            sb = new StringBuilder();
            str = "Select questions.id,CorrPerc,'سوال شماره '|| questions.id as title,selectedAnswer,corrAnswer,time  from Questions left outer join (select * from logs where testId=";
        }
        sb.append(str);
        sb.append(str2);
        sb.append(") as logs2 on questions.id=logs2.qid where questions.id in (");
        sb.append(this.f74204C4.getString("qIds"));
        sb.append(")");
        this.f74203B4 = compressHelper.m4955V(bundle2, sb.toString());
        this.f75852e4 = "نتیجه آزمون";
        Iterator<Bundle> it2 = this.f74203B4.iterator();
        while (it2.hasNext()) {
            Bundle next = it2.next();
            if (next.getString("selectedAnswer").length() == 0) {
                this.f74207F4++;
            } else if (next.getString("selectedAnswer").equals(next.getString("corrAnswer"))) {
                this.f74205D4++;
            } else {
                this.f74206E4++;
            }
        }
        UWTestResultAdapter uWTestResultAdapter = new UWTestResultAdapter();
        this.f74202A4 = uWTestResultAdapter;
        this.f74213w4.setAdapter(uWTestResultAdapter);
        m4733x4();
        m4100f3(C4804R.C4811menu.f87324empty);
        m44735q2(false);
        m4140G3();
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        Bundle m4073v3;
        ArrayList<Bundle> arrayList = this.f74214x4;
        if (arrayList == null || arrayList.size() == 0 || (m4073v3 = m4073v3(this.f74214x4)) == null) {
            return;
        }
        Glide.m40315G(m44716w()).mo40145t("http://www.epocrates.com/pillimages/" + (m4073v3.getString("FILENAME") + ".jpg")).m40191t2(this.f75859l4);
    }

    /* renamed from: x4 */
    public void m4733x4() {
        this.f74213w4.setItemAnimator(new DefaultItemAnimator());
        this.f74213w4.m42923n(new DividerItemDecoration(m44716w(), 1));
        this.f74213w4.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
    }

    /* renamed from: y4 */
    public String m4732y4(String str) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ZZZ");
        new SimpleDateFormat("MM dd,yyyy HH:mm:ss");
        try {
            return new PersianDateFormat().m79a(new PersianDate(Long.valueOf(simpleDateFormat.parse(str).getTime())));
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            return str;
        }
    }
}
