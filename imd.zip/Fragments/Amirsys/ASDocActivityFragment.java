package net.imedicaldoctor.imd.Fragments.Amirsys;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class ASDocActivityFragment extends ViewerHelperFragment {

    /* renamed from: A4 */
    public String f73941A4;

    /* renamed from: w4 */
    public Bundle f73942w4;

    /* renamed from: x4 */
    public ArrayList<Bundle> f73943x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f73944y4;

    /* renamed from: z4 */
    public ArrayList<Bundle> f73945z4;

    /* renamed from: x4 */
    private void m4797x4(String str) {
        if (this.f73944y4.size() == 0) {
            CompressHelper.m4921e2(m44716w(), "There is no media in this document", 1);
            return;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(this.f73944y4);
        int i = 0;
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            if (((Bundle) arrayList.get(i2)).getString("id").startsWith(str)) {
                i = i2;
            }
        }
        Intent intent = new Intent(m44716w(), GalleryActivity.class);
        intent.putExtra("Images", arrayList);
        intent.putExtra("Start", i);
        mo4139H2(intent);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S2 */
    public String mo3979S2() {
        ArrayList<Bundle> arrayList = this.f73943x4;
        if (arrayList == null || arrayList.size() <= 0) {
            return null;
        }
        Bundle m4073v3 = m4073v3(this.f73943x4);
        Bundle bundle = this.f75850c4;
        return CompressHelper.m4942Z0(bundle, m4073v3.getString("id") + ".jpg", "images-E");
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Amirsys.ASDocActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                try {
                    String str = ASDocActivityFragment.this.f75847Z3;
                    if (str == null || str.length() == 0) {
                        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(ASDocActivityFragment.this.f75851d4, ",,,");
                        ASDocActivityFragment aSDocActivityFragment = ASDocActivityFragment.this;
                        aSDocActivityFragment.f73941A4 = splitByWholeSeparator[1];
                        CompressHelper compressHelper = aSDocActivityFragment.f75863p4;
                        Bundle bundle2 = aSDocActivityFragment.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from topics where id='" + ASDocActivityFragment.this.f73941A4 + "'");
                        if (m4955V != null && m4955V.size() != 0) {
                            ASDocActivityFragment.this.f73942w4 = m4955V.get(0);
                            ASDocActivityFragment aSDocActivityFragment2 = ASDocActivityFragment.this;
                            aSDocActivityFragment2.f75852e4 = ASDocActivityFragment.this.f73942w4.getString("title") + " - " + ASDocActivityFragment.this.f73942w4.getString("category");
                            ASDocActivityFragment aSDocActivityFragment3 = ASDocActivityFragment.this;
                            CompressHelper compressHelper2 = aSDocActivityFragment3.f75863p4;
                            Bundle bundle3 = aSDocActivityFragment3.f75850c4;
                            aSDocActivityFragment3.f73945z4 = compressHelper2.m4955V(bundle3, "Select * from fields where topicId='" + ASDocActivityFragment.this.f73941A4 + "'");
                            ASDocActivityFragment aSDocActivityFragment4 = ASDocActivityFragment.this;
                            CompressHelper compressHelper3 = aSDocActivityFragment4.f75863p4;
                            Bundle bundle4 = aSDocActivityFragment4.f75850c4;
                            aSDocActivityFragment4.f73943x4 = compressHelper3.m4955V(bundle4, "Select * from images where topic_id='" + ASDocActivityFragment.this.f73941A4 + "'");
                            ASDocActivityFragment aSDocActivityFragment5 = ASDocActivityFragment.this;
                            if (aSDocActivityFragment5.f73943x4 == null) {
                                aSDocActivityFragment5.f73943x4 = new ArrayList<>();
                            }
                            ASDocActivityFragment.this.f73944y4 = new ArrayList<>();
                            Iterator<Bundle> it2 = ASDocActivityFragment.this.f73943x4.iterator();
                            while (it2.hasNext()) {
                                Bundle next = it2.next();
                                Bundle bundle5 = new Bundle();
                                Bundle bundle6 = ASDocActivityFragment.this.f75850c4;
                                bundle5.putString("ImagePath", CompressHelper.m4942Z0(bundle6, next.getString("id") + ".jpg", "images-E"));
                                bundle5.putString("id", next.getString("id"));
                                bundle5.putString("Encrypted", IcyHeaders.f35463C2);
                                bundle5.putString("DescriptionHTML2", ASDocActivityFragment.this.f75863p4.m5015B(next.getString(HTML.Tag.f65910g), next.getString("id"), "127"));
                                bundle5.putBundle("db", ASDocActivityFragment.this.f75850c4);
                                ASDocActivityFragment.this.f73944y4.add(bundle5);
                            }
                            ASDocActivityFragment aSDocActivityFragment6 = ASDocActivityFragment.this;
                            String m4117W3 = aSDocActivityFragment6.m4117W3(aSDocActivityFragment6.m44716w(), "ASHeader.css");
                            ASDocActivityFragment aSDocActivityFragment7 = ASDocActivityFragment.this;
                            String m4117W32 = aSDocActivityFragment7.m4117W3(aSDocActivityFragment7.m44716w(), "ASFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", ASDocActivityFragment.this.f75852e4).replace("[include]", "");
                            ASDocActivityFragment aSDocActivityFragment8 = ASDocActivityFragment.this;
                            String m5015B = aSDocActivityFragment8.f75863p4.m5015B(aSDocActivityFragment8.f73942w4.getString("content"), ASDocActivityFragment.this.f73942w4.getString("id"), "127");
                            ASDocActivityFragment aSDocActivityFragment9 = ASDocActivityFragment.this;
                            aSDocActivityFragment9.f75847Z3 = replace + m5015B + m4117W32;
                        }
                        ASDocActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                    }
                    ASDocActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    ASDocActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Amirsys.ASDocActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = ASDocActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    ASDocActivityFragment aSDocActivityFragment = ASDocActivityFragment.this;
                    aSDocActivityFragment.m4078s4(aSDocActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4945Y0(ASDocActivityFragment.this.f75850c4, "base"));
                ASDocActivityFragment aSDocActivityFragment2 = ASDocActivityFragment.this;
                aSDocActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", aSDocActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                ASDocActivityFragment.this.m4092j4();
                ASDocActivityFragment.this.m4098g4();
                ASDocActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                ASDocActivityFragment.this.m44735q2(false);
                ASDocActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == C4804R.C4808id.f86774action_gallery) {
            m4797x4("soheilvb");
        }
        if (itemId == C4804R.C4808id.f86776action_menu) {
            ASSectionViewer aSSectionViewer = new ASSectionViewer();
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("Items", this.f73945z4);
            bundle.putString("TitleProperty", "fieldTitle");
            aSSectionViewer.m44751k2(bundle);
            aSSectionViewer.m44844E2(this, 0);
            aSSectionViewer.m44870c3(true);
            aSSectionViewer.mo29915h3(m44820L(), "asdfasdfasdf");
        }
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: f4 */
    public void mo3978f4() {
        new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.Amirsys.ASDocActivityFragment.3

            /* renamed from: a */
            byte[] f73948a;

            @Override // android.os.AsyncTask
            protected Object doInBackground(Object[] objArr) {
                try {
                    File file = new File(ASDocActivityFragment.this.mo3979S2());
                    this.f73948a = new CompressHelper(ASDocActivityFragment.this.m44716w()).m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127");
                    return null;
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    iMDLogger.m3294f("ImageGallery", "Error in decrypting image");
                    return null;
                }
            }

            @Override // android.os.AsyncTask
            protected void onPostExecute(Object obj) {
                super.onPostExecute(obj);
                Glide.m40315G(ASDocActivityFragment.this.m44716w()).mo40151h(this.f73948a).m40191t2(ASDocActivityFragment.this.f75859l4);
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }
}
