package net.imedicaldoctor.imd.Fragments.Amirsys;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;

/* loaded from: classes2.dex */
public class ASListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f73950b4;

    /* renamed from: c4 */
    public String f73951c4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        CompressHelper compressHelper;
        Bundle bundle2;
        String str2;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            str = null;
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Amirsys.ASListActivityFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            str = m44859B().getString("ParentId");
        }
        this.f73951c4 = str;
        if (this.f73951c4 == null) {
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            str2 = "SELECT * FROM categories";
        } else {
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            str2 = "select * from topics where id in (select topicId from cats_topics where catId = '" + this.f73951c4 + "') order by title collate nocase asc";
        }
        this.f75218O3 = compressHelper.m4955V(bundle2, str2);
        this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "title", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Amirsys.ASListActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: f0 */
            public void mo3405f0(Bundle bundle3, int i) {
                ASListActivityFragment.this.m4796l3(bundle3, i);
            }
        };
        this.f73950b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", "content") { // from class: net.imedicaldoctor.imd.Fragments.Amirsys.ASListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: g0 */
            public void mo3380g0(Bundle bundle3, int i) {
                ASListActivityFragment.this.m4330Y2();
                ASListActivityFragment aSListActivityFragment = ASListActivityFragment.this;
                CompressHelper compressHelper2 = aSListActivityFragment.f75215L3;
                Bundle bundle4 = aSListActivityFragment.f75212I3;
                compressHelper2.m4883q1(bundle4, "menu,,," + bundle3.getString("contentId"), null, null);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle3) {
                ASListActivityFragment.this.m4330Y2();
                ASListActivityFragment.this.f75223T3.m51655i0(bundle3.getString("word"), true);
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f73950b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f73950b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match '(text:" + str + "* OR content:" + str + "*) AND type:1'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
    }

    /* renamed from: l3 */
    public void m4796l3(Bundle bundle, int i) {
        m4330Y2();
        if (this.f73951c4 == null) {
            Bundle bundle2 = new Bundle();
            bundle2.putBundle("DB", this.f75212I3);
            bundle2.putString("ParentId", bundle.getString("id"));
            this.f75215L3.m4979N(ASListActivity.class, ASListActivityFragment.class, bundle2);
            return;
        }
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle3 = this.f75212I3;
        compressHelper.m4883q1(bundle3, "menu,,," + bundle.getString("id"), null, null);
    }
}
