package net.imedicaldoctor.imd.Fragments.Amirsys;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Fragments.DividerItemDecoration;
import net.imedicaldoctor.imd.Fragments.Facts.FTViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.IranDaru.IDViewerActivity;
import net.imedicaldoctor.imd.Fragments.LWW.LWWViewerFragment;
import net.imedicaldoctor.imd.Fragments.Martindale.MDViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Micromedex.MMIVViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Micromedex.MMInteractViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Micromedex.MMNeoViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Micromedex.MMViewerActivityFragment;
import net.imedicaldoctor.imd.Fragments.Statdx.SDDocActivityFragment;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;

/* loaded from: classes2.dex */
public class ASSectionViewer extends DialogFragment {
    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87174fragment_new_section_viewer, (ViewGroup) null);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(C4804R.C4808id.f87001recycler_view);
        recyclerView.setAdapter(new ChaptersAdapter(m44716w(), m44859B().getParcelableArrayList("Items"), m44859B().getString("TitleProperty"), C4804R.C4810layout.f87261list_view_item_ripple_text) { // from class: net.imedicaldoctor.imd.Fragments.Amirsys.ASSectionViewer.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: f0 */
            public void mo3405f0(Bundle bundle2, int i) {
                ASSectionViewer.this.mo27002R2();
                ASSectionViewer.this.m4788j3(bundle2);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(m44716w(), 1, false));
        recyclerView.m42923n(new DividerItemDecoration(m44716w(), 1));
        builder.setView(inflate);
        return builder.create();
    }

    /* renamed from: j3 */
    public void m4788j3(Bundle bundle) {
        ViewerHelperFragment viewerHelperFragment;
        StringBuilder sb;
        String str;
        String string;
        if (m44753k0() instanceof LWWViewerFragment) {
            ((LWWViewerFragment) m44753k0()).mo4144C3(bundle.getString("id"));
            return;
        }
        if (!(m44753k0() instanceof MMViewerActivityFragment)) {
            if (!(m44753k0() instanceof ASDocActivityFragment)) {
                if (!(m44753k0() instanceof FTViewerActivityFragment)) {
                    if (m44753k0() instanceof IDViewerActivity.IDViewerFragment) {
                        viewerHelperFragment = (IDViewerActivity.IDViewerFragment) m44753k0();
                        str = "fDrugGenericID";
                    } else if (m44753k0() instanceof MDViewerActivityFragment) {
                        viewerHelperFragment = (MDViewerActivityFragment) m44753k0();
                    } else if (m44753k0() instanceof MMInteractViewerActivityFragment) {
                        viewerHelperFragment = (MMInteractViewerActivityFragment) m44753k0();
                        str = "f" + bundle.getString("sequence");
                    } else if (m44753k0() instanceof MMIVViewerActivityFragment) {
                        viewerHelperFragment = (MMIVViewerActivityFragment) m44753k0();
                        sb = new StringBuilder();
                    } else if (m44753k0() instanceof MMNeoViewerActivityFragment) {
                        viewerHelperFragment = (MMNeoViewerActivityFragment) m44753k0();
                        sb = new StringBuilder();
                    } else if (!(m44753k0() instanceof SDDocActivityFragment)) {
                        return;
                    } else {
                        viewerHelperFragment = (SDDocActivityFragment) m44753k0();
                    }
                    string = bundle.getString(str);
                    viewerHelperFragment.mo4144C3(string);
                }
                viewerHelperFragment = (FTViewerActivityFragment) m44753k0();
                string = bundle.getString("fId");
                viewerHelperFragment.mo4144C3(string);
            }
            viewerHelperFragment = (ASDocActivityFragment) m44753k0();
            string = bundle.getString("fieldId");
            viewerHelperFragment.mo4144C3(string);
        }
        viewerHelperFragment = (MMViewerActivityFragment) m44753k0();
        sb = new StringBuilder();
        sb.append("f");
        sb.append(bundle.getString("sequence"));
        string = sb.toString();
        viewerHelperFragment.mo4144C3(string);
    }
}
