package net.imedicaldoctor.imd.Fragments.Noskheha;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import java.io.File;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class NOSViewerActivityFragment extends ViewerHelperFragment {

    /* renamed from: w4 */
    public Bundle f75087w4;

    /* renamed from: x4 */
    public ArrayList<String> f75088x4;

    /* renamed from: y4 */
    public ArrayList<Bundle> f75089y4;

    /* renamed from: z4 */
    public boolean f75090z4;

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: y4 */
    public String m4378y4(String str, String str2, String str3, String str4, String str5) {
        return "<div class=\"content\" DIR=\"" + str4 + "\" id=\"f" + str5 + "\" style=\"font-family:" + str2 + "; " + str3 + "\">" + str + "</div>";
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: S3 */
    public void mo3569S3(WebView webView, String str) {
        super.mo3569S3(webView, str);
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = this.f75849b4;
        if (view != null) {
            return view;
        }
        View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
        this.f75849b4 = inflate;
        this.f75090z4 = true;
        m4094i4(inflate, bundle);
        if (m44859B() == null) {
            return this.f75849b4;
        }
        m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Noskheha.NOSViewerActivityFragment.1
            @Override // java.lang.Runnable
            public void run() {
                NOSViewerActivityFragment nOSViewerActivityFragment;
                String str;
                String str2;
                String str3;
                String str4;
                try {
                    String str5 = NOSViewerActivityFragment.this.f75847Z3;
                    if (str5 == null || str5.length() == 0) {
                        iMDLogger.m3294f("Loading Document", NOSViewerActivityFragment.this.f75851d4);
                        NOSViewerActivityFragment nOSViewerActivityFragment2 = NOSViewerActivityFragment.this;
                        CompressHelper compressHelper = nOSViewerActivityFragment2.f75863p4;
                        Bundle bundle2 = nOSViewerActivityFragment2.f75850c4;
                        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "Select * from docs where id=" + NOSViewerActivityFragment.this.f75851d4);
                        if (m4955V != null && m4955V.size() != 0) {
                            NOSViewerActivityFragment.this.f75087w4 = m4955V.get(0);
                            NOSViewerActivityFragment nOSViewerActivityFragment3 = NOSViewerActivityFragment.this;
                            nOSViewerActivityFragment3.f75852e4 = nOSViewerActivityFragment3.f75087w4.getString("name");
                            NOSViewerActivityFragment nOSViewerActivityFragment4 = NOSViewerActivityFragment.this;
                            nOSViewerActivityFragment4.f75852e4 = nOSViewerActivityFragment4.f75852e4.replace("\\n", StringUtils.SPACE);
                            String replace = NOSViewerActivityFragment.this.f75087w4.getString("content").replace("\\n", "<br />");
                            if (NOSViewerActivityFragment.this.f75850c4.getString("Name").equals("orders.db")) {
                                nOSViewerActivityFragment = NOSViewerActivityFragment.this;
                                str = "";
                                str2 = "";
                                str3 = "LTR";
                                str4 = "0";
                            } else {
                                nOSViewerActivityFragment = NOSViewerActivityFragment.this;
                                str = "X Traffic";
                                str2 = "";
                                str3 = "RTL";
                                str4 = "0";
                            }
                            String m4378y4 = nOSViewerActivityFragment.m4378y4(replace, str, str2, str3, str4);
                            NOSViewerActivityFragment nOSViewerActivityFragment5 = NOSViewerActivityFragment.this;
                            String m4117W3 = nOSViewerActivityFragment5.m4117W3(nOSViewerActivityFragment5.m44716w(), "IDHeader.css");
                            NOSViewerActivityFragment nOSViewerActivityFragment6 = NOSViewerActivityFragment.this;
                            String m4117W32 = nOSViewerActivityFragment6.m4117W3(nOSViewerActivityFragment6.m44716w(), "IDFooter.css");
                            String replace2 = m4117W3.replace("[size]", "200").replace("[title]", NOSViewerActivityFragment.this.f75852e4).replace("[include]", "");
                            NOSViewerActivityFragment nOSViewerActivityFragment7 = NOSViewerActivityFragment.this;
                            nOSViewerActivityFragment7.f75847Z3 = replace2 + m4378y4 + m4117W32;
                        }
                        NOSViewerActivityFragment.this.f75837P3 = "Document doesn't exist";
                        return;
                    }
                    NOSViewerActivityFragment.this.m4087m3();
                } catch (Exception e) {
                    e.printStackTrace();
                    NOSViewerActivityFragment.this.f75837P3 = e.getLocalizedMessage();
                }
            }
        }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Noskheha.NOSViewerActivityFragment.2
            @Override // java.lang.Runnable
            public void run() {
                String str = NOSViewerActivityFragment.this.f75837P3;
                if (str != null && str.length() > 0) {
                    NOSViewerActivityFragment nOSViewerActivityFragment = NOSViewerActivityFragment.this;
                    nOSViewerActivityFragment.m4078s4(nOSViewerActivityFragment.f75837P3);
                    return;
                }
                File file = new File(CompressHelper.m4945Y0(NOSViewerActivityFragment.this.f75850c4, "base"));
                NOSViewerActivityFragment.this.m4092j4();
                NOSViewerActivityFragment nOSViewerActivityFragment2 = NOSViewerActivityFragment.this;
                nOSViewerActivityFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", nOSViewerActivityFragment2.f75847Z3, "text/html", "utf-8", null);
                NOSViewerActivityFragment.this.m4098g4();
                NOSViewerActivityFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                NOSViewerActivityFragment.this.m44735q2(false);
                NOSViewerActivityFragment.this.m4140G3();
            }
        });
        return this.f75849b4;
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: e1 */
    public boolean mo3709e1(MenuItem menuItem) {
        menuItem.getItemId();
        return super.mo3709e1(menuItem);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: e3 */
    public void mo3568e3(Menu menu) {
        menu.removeItem(C4804R.C4808id.f86774action_gallery);
        menu.removeItem(C4804R.C4808id.f86776action_menu);
    }

    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
    /* renamed from: p4 */
    public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
        iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
        return true;
    }
}
