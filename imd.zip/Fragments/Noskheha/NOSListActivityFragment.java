package net.imedicaldoctor.imd.Fragments.Noskheha;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class NOSListActivityFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f75079b4;

    /* renamed from: c4 */
    public String f75080c4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        CompressHelper compressHelper;
        Bundle bundle2;
        String str;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            this.f75080c4 = "0";
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            str = "Select * from category order by name asc";
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.Noskheha.NOSListActivityFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            this.f75080c4 = m44859B().getString("ParentId");
            compressHelper = this.f75215L3;
            bundle2 = this.f75212I3;
            str = "select * from docs where catId=" + this.f75080c4;
        }
        this.f75218O3 = compressHelper.m4955V(bundle2, str);
        this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "name", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.Noskheha.NOSListActivityFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: d0 */
            public String mo3407d0(String str2) {
                return str2.replace("\\n", StringUtils.SPACE);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: f0 */
            public void mo3405f0(Bundle bundle3, int i) {
                if (!NOSListActivityFragment.this.f75080c4.equals("0")) {
                    NOSListActivityFragment nOSListActivityFragment = NOSListActivityFragment.this;
                    nOSListActivityFragment.f75215L3.m4883q1(nOSListActivityFragment.f75212I3, bundle3.getString("id"), null, null);
                    return;
                }
                Bundle bundle4 = new Bundle();
                bundle4.putBundle("DB", NOSListActivityFragment.this.f75212I3);
                bundle4.putString("ParentId", bundle3.getString("id"));
                NOSListActivityFragment.this.f75215L3.m4979N(NOSListActivity.class, NOSListActivityFragment.class, bundle4);
            }
        };
        this.f75079b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", "content", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.Noskheha.NOSListActivityFragment.3
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle3, int i) {
                TextView textView;
                int i2;
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle3.getString("text").replace("\\n", StringUtils.SPACE));
                rippleTextFullViewHolder.f83285J.setText(bundle3.getString("content"));
                if (bundle3.getString("content").length() == 0) {
                    textView = rippleTextFullViewHolder.f83285J;
                    i2 = 8;
                } else {
                    textView = rippleTextFullViewHolder.f83285J;
                    i2 = 0;
                }
                textView.setVisibility(i2);
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.Noskheha.NOSListActivityFragment.3.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        NOSListActivityFragment.this.m4330Y2();
                        NOSListActivityFragment nOSListActivityFragment = NOSListActivityFragment.this;
                        nOSListActivityFragment.f75215L3.m4883q1(nOSListActivityFragment.f75212I3, bundle3.getString("contentId"), null, null);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle3) {
                NOSListActivityFragment.this.m4330Y2();
                NOSListActivityFragment.this.f75223T3.m51655i0(bundle3.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f75079b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f75079b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match 'text:" + str + "* AND type:1'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        return null;
    }
}
