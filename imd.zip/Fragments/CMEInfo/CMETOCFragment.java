package net.imedicaldoctor.imd.Fragments.CMEInfo;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import at.grabner.circleprogress.CircleProgressView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.common.net.HttpHeaders;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.css.CSS;
import com.itextpdf.tool.xml.html.HTML;
import com.p009dd.CircularProgressButton;
import java.io.File;
import java.io.FilenameFilter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Timer;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Fragments.downloadFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.iMD;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class CMETOCFragment extends SearchHelperFragment {

    /* renamed from: A4 */
    public static final String f73990A4 = "fileSize";

    /* renamed from: B4 */
    public static final String f73991B4 = "Icon";

    /* renamed from: C4 */
    public static final String f73992C4 = "name";

    /* renamed from: D4 */
    public static final String f73993D4 = "type";

    /* renamed from: E4 */
    public static final String f73994E4 = "version";

    /* renamed from: F4 */
    public static final String f73995F4 = "Delta";

    /* renamed from: G4 */
    public static final String f73996G4 = "Update";

    /* renamed from: H4 */
    public static final String f73997H4 = "Rebuilding";

    /* renamed from: I4 */
    public static final String f73998I4 = "Parts";

    /* renamed from: J4 */
    public static final String f73999J4 = "folderSizeKey";

    /* renamed from: K4 */
    public static final String f74000K4 = "videoIdKey";

    /* renamed from: L4 */
    public static final String f74001L4 = "savePathKey";

    /* renamed from: M4 */
    public static final String f74002M4 = "LatestKey";

    /* renamed from: k4 */
    public static final String f74003k4 = "bytesDownloaded";

    /* renamed from: l4 */
    public static final String f74004l4 = "bytesTotal";

    /* renamed from: m4 */
    public static final String f74005m4 = "avgSpeed";

    /* renamed from: n4 */
    public static final String f74006n4 = "remaining";

    /* renamed from: o4 */
    public static final String f74007o4 = "Progress";

    /* renamed from: p4 */
    public static final String f74008p4 = "Title";

    /* renamed from: q4 */
    public static final String f74009q4 = "URL";

    /* renamed from: r4 */
    public static final String f74010r4 = "FileName";

    /* renamed from: s4 */
    public static final String f74011s4 = "MD5";

    /* renamed from: t4 */
    public static final String f74012t4 = "PartFileSize";

    /* renamed from: u4 */
    public static final String f74013u4 = "price";

    /* renamed from: v4 */
    public static final String f74014v4 = "Buy";

    /* renamed from: w4 */
    public static final String f74015w4 = "downloader";

    /* renamed from: x4 */
    public static final String f74016x4 = "retry";

    /* renamed from: y4 */
    public static final String f74017y4 = "completed";

    /* renamed from: z4 */
    public static final String f74018z4 = "error";

    /* renamed from: b4 */
    public DownloadsAdapter f74019b4;

    /* renamed from: c4 */
    public ArrayList<Bundle> f74020c4;

    /* renamed from: d4 */
    public String f74021d4;

    /* renamed from: e4 */
    public ArrayList<Bundle> f74022e4;

    /* renamed from: f4 */
    public Typeface f74023f4;

    /* renamed from: g4 */
    private Activity f74024g4;

    /* renamed from: h4 */
    private Timer f74025h4;

    /* renamed from: i4 */
    public downloadFragment f74026i4;

    /* renamed from: j4 */
    public int f74027j4;

    /* loaded from: classes2.dex */
    public class DownloadCellViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        private TextView f74046I;

        /* renamed from: J */
        private TextView f74047J;

        /* renamed from: K */
        private Button f74048K;

        /* renamed from: L */
        private CircleProgressView f74049L;

        public DownloadCellViewHolder(View view) {
            super(view);
            this.f74046I = (TextView) view.findViewById(C4804R.C4808id.title);
            this.f74047J = (TextView) view.findViewById(C4804R.C4808id.f87035subtitle);
            Button button = (Button) view.findViewById(C4804R.C4808id.f86877download_button);
            this.f74048K = button;
            button.setTypeface(CMETOCFragment.this.f74023f4);
            this.f74049L = (CircleProgressView) view.findViewById(C4804R.C4808id.f86842circleView);
        }
    }

    /* loaded from: classes2.dex */
    public class DownloadsAdapter extends RecyclerView.Adapter {

        /* renamed from: d */
        public ArrayList<Bundle> f74051d;

        /* renamed from: e */
        public ArrayList<Bundle> f74052e;

        public DownloadsAdapter(ArrayList<Bundle> arrayList, ArrayList<Bundle> arrayList2) {
            this.f74051d = arrayList;
            this.f74052e = arrayList2;
        }

        /* renamed from: d0 */
        private void m4771d0(final CircularProgressButton circularProgressButton) {
            circularProgressButton.setProgress(1);
            circularProgressButton.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.9
                @Override // java.lang.Runnable
                public void run() {
                    circularProgressButton.setProgress(0);
                    circularProgressButton.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.9.1
                        @Override // java.lang.Runnable
                        public void run() {
                            circularProgressButton.setProgress(1);
                        }
                    }, 100L);
                }
            }, 100L);
        }

        /* renamed from: e0 */
        private double m4770e0(Bundle bundle, String str) {
            try {
                if (bundle.containsKey(str)) {
                    return bundle.getDouble(str);
                }
                return 0.0d;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                return 0.0d;
            }
        }

        /* renamed from: g0 */
        private long m4768g0(Bundle bundle, String str) {
            try {
                if (bundle.containsKey(str)) {
                    return bundle.getLong(str);
                }
                return 0L;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                return 0L;
            }
        }

        /* renamed from: h0 */
        private String m4767h0(int i) {
            return m4764k0(i / 3600) + " : " + m4764k0((i % 3600) / 60) + " : " + m4764k0(i % 60);
        }

        /* renamed from: k0 */
        private String m4764k0(int i) {
            if (i == 0) {
                return "00";
            }
            if (i / 10 == 0) {
                return "0" + i;
            }
            return String.valueOf(i);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: C */
        public int mo3384C(int i) {
            if (m4765j0() == 0) {
                return 0;
            }
            ArrayList<Bundle> arrayList = this.f74051d;
            if (arrayList == null || arrayList.size() <= 0) {
                return CMETOCFragment.this.m4776w3(this.f74052e.get(i)) ? 1 : 2;
            } else if (i < this.f74051d.size()) {
                return 3;
            } else {
                return CMETOCFragment.this.m4776w3(this.f74052e.get(i - this.f74051d.size())) ? 1 : 2;
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: R */
        public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
            TextView textView;
            int color;
            ProgressBar progressBar;
            if (viewHolder.m42556F() == 3) {
                RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                rippleTextViewHolder.f83300I.setText(this.f74051d.get(i).getString("name"));
                rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CMETOCFragment.this.m4330Y2();
                        Bundle bundle = new Bundle();
                        bundle.putBundle("DB", CMETOCFragment.this.f75212I3);
                        bundle.putString("ParentId", DownloadsAdapter.this.f74051d.get(i).getString("id"));
                        CMETOCFragment.this.f75215L3.m4979N(CMETOC.class, CMETOCFragment.class, bundle);
                    }
                });
                return;
            }
            final Bundle bundle = this.f74052e.get(i - this.f74051d.size());
            int i2 = 0;
            if (CMETOCFragment.this.m4776w3(bundle)) {
                VideoCellViewHolder videoCellViewHolder = (VideoCellViewHolder) viewHolder;
                videoCellViewHolder.f74079I.setText(CMETOCFragment.this.m4779t3(bundle));
                String string = bundle.getString(CSS.Property.f65564m0);
                if (string == "") {
                    progressBar = videoCellViewHolder.f74080J;
                } else {
                    long longValue = Long.valueOf(string).longValue();
                    Long valueOf = Long.valueOf(bundle.getString("dur"));
                    Log.e("Progress bar", "Duration " + bundle.getString("dur") + ", position : " + bundle.getString(CSS.Property.f65564m0));
                    videoCellViewHolder.f74080J.setMax(10000);
                    progressBar = videoCellViewHolder.f74080J;
                    i2 = (int) (((double) (((float) longValue) / ((float) valueOf.longValue()))) * 10000.0d);
                }
                progressBar.setProgress(i2);
                videoCellViewHolder.f74081K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CMETOCFragment cMETOCFragment = CMETOCFragment.this;
                        cMETOCFragment.f74027j4 = i;
                        String m4942Z0 = CompressHelper.m4942Z0(cMETOCFragment.f75212I3, bundle.getString("name"), "temp");
                        if (bundle.containsKey("dbname")) {
                            Bundle bundle2 = CMETOCFragment.this.f75212I3;
                            m4942Z0 = CompressHelper.m4942Z0(bundle2, bundle.getString("dbname") + "-" + bundle.getString("name"), "temp");
                        }
                        if (!CMETOCFragment.this.f75212I3.getString("Type").equals("cme")) {
                            m4942Z0 = CompressHelper.m4942Z0(CMETOCFragment.this.f75212I3, bundle.getString("name"), "videos");
                        }
                        Intent intent = new Intent(CMETOCFragment.this.m4780s3(), Player.class);
                        intent.putExtra("Address", m4942Z0);
                        intent.putExtra("DB", CMETOCFragment.this.f75212I3);
                        String string2 = bundle.getString(CSS.Property.f65564m0);
                        if (string2 == "") {
                            string2 = "0";
                        }
                        intent.putExtra(HttpHeaders.f53988m0, Long.valueOf(string2));
                        intent.putExtra("VideoID", bundle.getString("id"));
                        CMETOCFragment.this.m4780s3().startActivity(intent);
                    }
                });
                return;
            }
            DownloadCellViewHolder downloadCellViewHolder = (DownloadCellViewHolder) viewHolder;
            downloadCellViewHolder.f74046I.setText(CMETOCFragment.this.m4779t3(bundle));
            Bundle m4781r3 = CMETOCFragment.this.m4781r3(bundle);
            if (m4781r3 == null) {
                m4781r3 = new Bundle();
                m4781r3.putString("fileSize", bundle.getString("fileSize"));
            }
            if (m4781r3.containsKey("completed")) {
                downloadCellViewHolder.f74047J.setText("Download Completed");
                downloadCellViewHolder.f74047J.setTextColor(CMETOCFragment.this.m44782a0().getColor(C4804R.C4806color.f86117green_real));
                if (m4781r3.containsKey("Rebuilding")) {
                    downloadCellViewHolder.f74047J.setText("Rebuilding ...");
                }
                downloadCellViewHolder.f74048K.setVisibility(8);
                downloadCellViewHolder.f74049L.setVisibility(8);
            } else if (!m4781r3.containsKey("downloader")) {
                downloadCellViewHolder.f74048K.setVisibility(0);
                downloadCellViewHolder.f74049L.setVisibility(8);
                try {
                    if (m4781r3.containsKey("error")) {
                        downloadCellViewHolder.f74047J.setText(m4781r3.getString("error"));
                        textView = downloadCellViewHolder.f74047J;
                        color = CMETOCFragment.this.m44782a0().getColor(C4804R.C4806color.red);
                    } else {
                        downloadCellViewHolder.f74047J.setText(CMETOCFragment.this.m4777v3(Long.valueOf(m4781r3.getString("fileSize")).longValue()));
                        textView = downloadCellViewHolder.f74047J;
                        color = CMETOCFragment.this.m44782a0().getColor(C4804R.C4806color.f86109darkGrey);
                    }
                    textView.setTextColor(color);
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                    downloadCellViewHolder.f74047J.setText("Error occured, try again");
                    e.printStackTrace();
                }
                downloadCellViewHolder.f74048K.setText("Download");
                downloadCellViewHolder.f74048K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.6
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CMETOCFragment.this.m4784o3(bundle);
                        CMETOCFragment.this.m4787l3();
                    }
                });
                downloadCellViewHolder.f74048K.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.7
                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View view) {
                        String m4861y = CMETOCFragment.this.f75215L3.m4861y();
                        ArrayList arrayList = new ArrayList();
                        String str = m4861y + "/" + bundle.getString("name");
                        arrayList.add(str);
                        for (int i3 = 1; i3 < 11; i3++) {
                            arrayList.add(str + "." + i3);
                            arrayList.add(str + "." + i3 + ".download");
                        }
                        Iterator it2 = arrayList.iterator();
                        while (it2.hasNext()) {
                            String str2 = (String) it2.next();
                            if (new File(str2).exists()) {
                                new File(str2).delete();
                            }
                        }
                        CompressHelper.m4921e2(CMETOCFragment.this.m4780s3(), "All Temp Files Deleted", 1);
                        return true;
                    }
                });
            } else {
                DecimalFormat decimalFormat = new DecimalFormat("#,##0.#");
                downloadCellViewHolder.f74048K.setVisibility(8);
                downloadCellViewHolder.f74049L.setVisibility(0);
                double m4770e0 = m4770e0(m4781r3, "bytesDownloaded");
                double m4770e02 = m4770e0(m4781r3, "bytesTotal");
                long m4768g0 = m4768g0(m4781r3, "avgSpeed");
                long m4768g02 = m4768g0(m4781r3, "remaining");
                int m4769f0 = m4769f0(m4781r3, "Progress");
                String str = decimalFormat.format((m4770e0 / 1024.0d) / 1024.0d) + " of " + decimalFormat.format((m4770e02 / 1024.0d) / 1024.0d) + " MB(" + CMETOCFragment.this.m4777v3(m4768g0) + "/s), " + m4767h0((int) m4768g02) + " remaining";
                downloadCellViewHolder.f74047J.setTextColor(CMETOCFragment.this.m44782a0().getColor(C4804R.C4806color.f86109darkGrey));
                if (m4770e0 == 0.0d) {
                    downloadCellViewHolder.f74049L.m41214u();
                    str = "Preparing Download";
                } else {
                    downloadCellViewHolder.f74049L.m41213v();
                }
                downloadCellViewHolder.f74047J.setText(str);
                if (m4769f0 == 0) {
                    downloadCellViewHolder.f74049L.setValue(1.0f);
                } else {
                    downloadCellViewHolder.f74049L.setValue(m4769f0);
                }
                downloadCellViewHolder.f74049L.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.8
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CMETOCFragment.this.m4786m3(bundle);
                    }
                });
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: T */
        public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
            if (i == 1) {
                View inflate = LayoutInflater.from(CMETOCFragment.this.m4780s3()).inflate(C4804R.C4810layout.f87303list_view_item_video, viewGroup, false);
                inflate.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CMETOCFragment.this.m4330Y2();
                    }
                });
                return new VideoCellViewHolder(inflate);
            } else if (i == 2) {
                View inflate2 = LayoutInflater.from(CMETOCFragment.this.m4780s3()).inflate(C4804R.C4810layout.f87225list_view_item_cme_download, viewGroup, false);
                inflate2.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CMETOCFragment.this.m4330Y2();
                    }
                });
                return new DownloadCellViewHolder(inflate2);
            } else if (i == 3) {
                View inflate3 = LayoutInflater.from(CMETOCFragment.this.m4780s3()).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false);
                inflate3.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.DownloadsAdapter.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CMETOCFragment.this.m4330Y2();
                    }
                });
                return new RippleTextViewHolder(inflate3);
            } else {
                return null;
            }
        }

        /* renamed from: f0 */
        public int m4769f0(Bundle bundle, String str) {
            if (bundle.containsKey(str)) {
                return bundle.getInt(str);
            }
            return 0;
        }

        /* renamed from: i0 */
        public Bundle m4766i0(int i) {
            return this.f74052e.get(i - this.f74051d.size());
        }

        /* renamed from: j0 */
        public int m4765j0() {
            ArrayList<Bundle> arrayList = this.f74051d;
            int size = arrayList != null ? 0 + arrayList.size() : 0;
            ArrayList<Bundle> arrayList2 = this.f74052e;
            return arrayList2 != null ? size + arrayList2.size() : size;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        /* renamed from: s */
        public int mo3359s() {
            return m4765j0();
        }
    }

    /* loaded from: classes2.dex */
    public abstract class UIActionClass extends ItemTouchHelper.Callback {

        /* renamed from: i */
        Context f74071i;

        /* renamed from: j */
        private Paint f74072j;

        /* renamed from: k */
        private ColorDrawable f74073k = new ColorDrawable();

        /* renamed from: l */
        private int f74074l = Color.parseColor("#b80f0a");

        /* renamed from: m */
        private Drawable f74075m;

        /* renamed from: n */
        private int f74076n;

        /* renamed from: o */
        private int f74077o;

        UIActionClass(Context context) {
            this.f74071i = context;
            Paint paint = new Paint();
            this.f74072j = paint;
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            Drawable m47744h = ContextCompat.m47744h(this.f74071i, 17301564);
            this.f74075m = m47744h;
            this.f74076n = m47744h.getIntrinsicWidth();
            this.f74077o = this.f74075m.getIntrinsicHeight();
        }

        /* renamed from: E */
        private void m4763E(Canvas canvas, Float f, Float f2, Float f3, Float f4) {
            canvas.drawRect(f.floatValue(), f2.floatValue(), f3.floatValue(), f4.floatValue(), this.f74072j);
        }

        @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
        /* renamed from: A */
        public boolean mo3761A(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder2) {
            return false;
        }

        @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
        /* renamed from: l */
        public int mo3759l(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
            return viewHolder.m42556F() == 1 ? ItemTouchHelper.Callback.m43215v(0, 4) : ItemTouchHelper.Callback.m43215v(0, 0);
        }

        @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
        /* renamed from: n */
        public float mo3758n(@NonNull RecyclerView.ViewHolder viewHolder) {
            return 0.7f;
        }

        @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
        /* renamed from: w */
        public void mo3757w(@NonNull Canvas canvas, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float f, float f2, int i, boolean z) {
            super.mo3757w(canvas, recyclerView, viewHolder, f, f2, i, z);
            View view = viewHolder.f18491a;
            int height = view.getHeight();
            boolean z2 = true;
            if (viewHolder.m42556F() == 1) {
                if (!((f != 0.0f || z) ? false : false)) {
                    this.f74073k.setColor(this.f74074l);
                    this.f74073k.setBounds(view.getRight() + ((int) f), view.getTop(), view.getRight(), view.getBottom());
                    this.f74073k.draw(canvas);
                    int top = view.getTop();
                    int i2 = this.f74077o;
                    int i3 = top + ((height - i2) / 2);
                    int i4 = (height - i2) / 2;
                    this.f74075m.setBounds((view.getRight() - i4) - this.f74076n, i3, view.getRight() - i4, this.f74077o + i3);
                    this.f74075m.draw(canvas);
                    super.mo3757w(canvas, recyclerView, viewHolder, f, f2, i, z);
                }
            }
            m4763E(canvas, Float.valueOf(view.getRight() + f), Float.valueOf(view.getTop()), Float.valueOf(view.getRight()), Float.valueOf(view.getBottom()));
            super.mo3757w(canvas, recyclerView, viewHolder, f, f2, i, z);
        }
    }

    /* loaded from: classes2.dex */
    public class VideoCellViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        private TextView f74079I;

        /* renamed from: J */
        private ProgressBar f74080J;

        /* renamed from: K */
        private MaterialRippleLayout f74081K;

        public VideoCellViewHolder(View view) {
            super(view);
            this.f74079I = (TextView) view.findViewById(C4804R.C4808id.title);
            this.f74080J = (ProgressBar) view.findViewById(C4804R.C4808id.f86992progress_bar);
            this.f74081K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        }
    }

    /* renamed from: q3 */
    private void m4782q3() {
        new ItemTouchHelper(new UIActionClass(m44716w()) { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.6
            @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
            /* renamed from: D */
            public void mo3777D(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                try {
                    final int m42560B = viewHolder.m42560B();
                    new AlertDialog.Builder(CMETOCFragment.this.m44716w(), C4804R.style.f88094alertDialogTheme).mo26292l("Are you really want to delete this video ?").mo26266y("Yes", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.6.2
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i2) {
                            Bundle m4766i0 = ((DownloadsAdapter) CMETOCFragment.this.f75227X3.getAdapter()).m4766i0(m42560B);
                            String m4942Z0 = CompressHelper.m4942Z0(CMETOCFragment.this.f75212I3, m4766i0.getString("name"), "temp");
                            if (m4766i0.containsKey("dbname")) {
                                Bundle bundle = CMETOCFragment.this.f75212I3;
                                m4942Z0 = CompressHelper.m4942Z0(bundle, m4766i0.getString("dbname") + "-" + m4766i0.getString("name"), "temp");
                            }
                            if (!CMETOCFragment.this.f75212I3.getString("Type").equals("cme")) {
                                m4942Z0 = CompressHelper.m4942Z0(CMETOCFragment.this.f75212I3, m4766i0.getString("name"), "videos");
                            }
                            new File(m4942Z0).delete();
                            CMETOCFragment.this.f75227X3.getAdapter().m42859H(m42560B);
                        }
                    }).mo26284p("No", new DialogInterface.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.6.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialogInterface, int i2) {
                            CMETOCFragment.this.f75227X3.getAdapter().m42859H(m42560B);
                        }
                    }).m52864I();
                } catch (Exception unused) {
                }
            }
        }).m43250m(this.f75227X3);
    }

    /* renamed from: u3 */
    private void m4778u3() {
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: M0 */
    public void mo3640M0(Activity activity) {
        super.mo3640M0(activity);
        this.f74024g4 = activity;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: T2 */
    public void mo4335T2() {
        if (this.f75212I3.containsKey("Damu")) {
            m4341N2();
            return;
        }
        SearchView searchView = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        this.f75223T3 = searchView;
        if (Build.VERSION.SDK_INT >= 26) {
            searchView.setImportantForAutofill(8);
        }
        this.f75223T3.setIconifiedByDefault(false);
        this.f75223T3.setQueryHint("Search");
        this.f75213J3 = true;
        ((ImageView) this.f75223T3.findViewById(C4804R.C4808id.search_close_btn)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CMETOCFragment.this.f75223T3.m51655i0("", false);
                CMETOCFragment.this.f75223T3.clearFocus();
                CMETOCFragment cMETOCFragment = CMETOCFragment.this;
                cMETOCFragment.f75227X3.setAdapter(cMETOCFragment.f75216M3);
                CMETOCFragment.this.m4330Y2();
                CMETOCFragment.this.mo4182c3();
            }
        });
        this.f75223T3.setOnQueryTextListener(new SearchView.OnQueryTextListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.8
            @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
            /* renamed from: a */
            public boolean mo3520a(final String str) {
                CMETOCFragment cMETOCFragment = CMETOCFragment.this;
                if (cMETOCFragment.f75213J3) {
                    cMETOCFragment.f75210G3 = str;
                    if (str.length() > 1) {
                        new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.8.1
                            @Override // android.os.AsyncTask
                            protected Object doInBackground(Object[] objArr) {
                                CMETOCFragment cMETOCFragment2 = CMETOCFragment.this;
                                CompressHelper compressHelper = cMETOCFragment2.f75215L3;
                                Bundle bundle = cMETOCFragment2.f75212I3;
                                cMETOCFragment2.f74020c4 = compressHelper.m4955V(bundle, "select * from toc where name like '%" + CMETOCFragment.this.f75223T3.getQuery().toString() + "%' AND NOT (id=999) COLLATE utf8_general_ci");
                                CMETOCFragment cMETOCFragment3 = CMETOCFragment.this;
                                cMETOCFragment3.f75219P3 = cMETOCFragment3.mo3981d3(str);
                                return null;
                            }

                            @Override // android.os.AsyncTask
                            protected void onPostExecute(Object obj) {
                                CMETOCFragment.this.mo3982a3();
                            }

                            @Override // android.os.AsyncTask
                            protected void onPreExecute() {
                            }
                        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
                        return true;
                    }
                    CMETOCFragment cMETOCFragment2 = CMETOCFragment.this;
                    cMETOCFragment2.f75227X3.setAdapter(cMETOCFragment2.f75216M3);
                    return false;
                }
                return true;
            }

            @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
            /* renamed from: b */
            public boolean mo3519b(String str) {
                return false;
            }
        });
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        String str;
        CompressHelper compressHelper;
        Bundle bundle2;
        StringBuilder sb;
        String str2;
        ArrayList<Bundle> m4955V;
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        this.f74023f4 = Typeface.createFromAsset(m44716w().getAssets(), "fonts/HelveticaNeue-Light.otf");
        this.f74026i4 = ((iMD) m44716w().getApplicationContext()).f83455D2;
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
        final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
        if (m44859B() == null || !m44859B().containsKey("ParentId")) {
            appBarLayout.m27445s(true, false);
            relativeLayout.setVisibility(0);
            str = null;
        } else {
            if (m44859B().getString("ParentId").equals("0")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.3
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
            }
            str = m44859B().getString("ParentId");
        }
        this.f74021d4 = str;
        if (this.f74021d4 == null) {
            this.f74021d4 = "0";
        }
        if (this.f74021d4.equals("11111")) {
            String[] list = new File(CompressHelper.m4945Y0(this.f75212I3, "temp")).list(new FilenameFilter() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.4
                @Override // java.io.FilenameFilter
                public boolean accept(File file, String str3) {
                    return str3.toLowerCase().endsWith("mp4");
                }
            });
            ArrayList arrayList = new ArrayList();
            for (String str3 : list) {
                arrayList.add("'" + str3 + "'");
            }
            m4955V = this.f75215L3.m4955V(this.f75212I3, "select *,medias.id as id ,logs.duration as dur from medias left outer join logs on medias.id=logs.id where dbname || '-' || name in (" + StringUtils.join(arrayList, ",") + ") ");
        } else {
            this.f75218O3 = this.f75215L3.m4955V(this.f75212I3, "Select * from toc where parentId = " + this.f74021d4);
            if (this.f75212I3.getString("Type").equals("cme")) {
                compressHelper = this.f75215L3;
                bundle2 = this.f75212I3;
                sb = new StringBuilder();
                str2 = "Select medias.*, logs.position, logs.vDate ,logs.duration as dur from medias left outer join logs  on medias.id=logs.id where tocId = ";
            } else {
                compressHelper = this.f75215L3;
                bundle2 = this.f75212I3;
                sb = new StringBuilder();
                str2 = "Select videos.id, videos.title, videos.path, videos.name, videos.tocId, videos.purpose, videos.fileSize, logs.position, logs.vDate ,logs.duration as dur from videos left outer join logs  on videos.id=logs.id where tocId =";
            }
            sb.append(str2);
            sb.append(this.f74021d4);
            m4955V = compressHelper.m4955V(bundle2, sb.toString());
        }
        this.f74022e4 = m4955V;
        if (this.f75218O3 == null) {
            this.f75218O3 = new ArrayList<>();
        }
        if (this.f74022e4 == null) {
            this.f74022e4 = new ArrayList<>();
        }
        if (this.f75212I3.getString("Name").equals("imdvideos.db") && this.f74021d4.equals("0")) {
            String[] list2 = new File(CompressHelper.m4945Y0(this.f75212I3, "temp")).list(new FilenameFilter() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.5
                @Override // java.io.FilenameFilter
                public boolean accept(File file, String str4) {
                    return str4.toLowerCase().endsWith("mp4");
                }
            });
            Bundle bundle3 = new Bundle();
            bundle3.putString("id", "11111");
            bundle3.putString("name", "Downloaded");
            bundle3.putString("videoCount", list2.length + "");
            this.f75218O3.add(0, bundle3);
        }
        this.f75216M3 = new DownloadsAdapter(this.f75218O3, this.f74022e4);
        m4783p3();
        this.f74019b4 = new DownloadsAdapter(this.f74020c4, this.f75219P3);
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        m4782q3();
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        if (this.f75219P3 == null) {
            this.f75219P3 = new ArrayList<>();
        }
        if (this.f74020c4 == null) {
            this.f74020c4 = new ArrayList<>();
        }
        DownloadsAdapter downloadsAdapter = new DownloadsAdapter(this.f74020c4, this.f75219P3);
        this.f74019b4 = downloadsAdapter;
        this.f75227X3.setAdapter(downloadsAdapter);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str, StringUtils.SPACE);
        ArrayList arrayList = new ArrayList();
        for (String str2 : splitByWholeSeparator) {
            arrayList.add("title like '%" + str2 + "%'");
        }
        if (this.f75212I3.getString("Type").equals("cme")) {
            return this.f75215L3.m4955V(this.f75212I3, "Select medias.*, logs.position, logs.vDate ,logs.duration as dur from medias left outer join logs  on medias.id=logs.id where " + StringUtils.join(arrayList, " AND "));
        }
        return this.f75215L3.m4955V(this.f75212I3, "Select videos.id, videos.title, videos.path, videos.name, videos.tocId, videos.purpose, videos.fileSize, logs.position, logs.vDate ,logs.duration as dur from videos left outer join logs  on videos.id=logs.id where title like '%" + str + "%'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        return null;
    }

    @Override // androidx.fragment.app.Fragment
    /* renamed from: l1 */
    public void mo3541l1() {
        CompressHelper compressHelper;
        Bundle bundle;
        StringBuilder sb;
        String str;
        ArrayList<Bundle> m4955V;
        DownloadsAdapter downloadsAdapter;
        ArrayList<Bundle> arrayList;
        super.mo3541l1();
        this.f74026i4 = ((iMD) m44716w().getApplicationContext()).f83455D2;
        if (this.f74021d4.equals("11111")) {
            String[] list = new File(CompressHelper.m4945Y0(this.f75212I3, "temp")).list(new FilenameFilter() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.1
                @Override // java.io.FilenameFilter
                public boolean accept(File file, String str2) {
                    return str2.toLowerCase().endsWith("mp4");
                }
            });
            ArrayList arrayList2 = new ArrayList();
            for (String str2 : list) {
                arrayList2.add("'" + str2 + "'");
            }
            m4955V = this.f75215L3.m4955V(this.f75212I3, "select *,medias.id as id ,logs.duration as dur from medias left outer join logs on medias.id=logs.id where dbname || '-' || name in (" + StringUtils.join(arrayList2, ",") + ") ");
        } else {
            if (this.f75212I3.getString("Type").equals("cme")) {
                compressHelper = this.f75215L3;
                bundle = this.f75212I3;
                sb = new StringBuilder();
                str = "Select medias.*, logs.position, logs.vDate ,logs.duration as dur from medias left outer join logs  on medias.id=logs.id where tocId = ";
            } else {
                compressHelper = this.f75215L3;
                bundle = this.f75212I3;
                sb = new StringBuilder();
                str = "Select videos.id, videos.title, videos.path, videos.name, videos.tocId, videos.purpose, videos.fileSize, logs.position, logs.vDate ,logs.duration as dur from videos left outer join logs  on videos.id=logs.id where tocId =";
            }
            sb.append(str);
            sb.append(this.f74021d4);
            m4955V = compressHelper.m4955V(bundle, sb.toString());
        }
        this.f74022e4 = m4955V;
        if (this.f75227X3.getAdapter() == this.f75216M3) {
            if (this.f74022e4 == null) {
                this.f74022e4 = new ArrayList<>();
            }
            downloadsAdapter = (DownloadsAdapter) this.f75216M3;
            arrayList = this.f74022e4;
        } else {
            ArrayList<Bundle> mo3981d3 = mo3981d3(this.f75223T3.getQuery().toString());
            this.f75219P3 = mo3981d3;
            if (mo3981d3 == null) {
                this.f75219P3 = new ArrayList<>();
            }
            ArrayList<Bundle> m4955V2 = this.f75215L3.m4955V(this.f75212I3, "select * from toc where name like '%" + this.f75223T3.getQuery().toString() + "%' AND NOT (id=999) COLLATE utf8_general_ci");
            this.f74020c4 = m4955V2;
            if (m4955V2 == null) {
                this.f74020c4 = new ArrayList<>();
            }
            downloadsAdapter = this.f74019b4;
            downloadsAdapter.f74051d = this.f74020c4;
            arrayList = this.f75219P3;
        }
        downloadsAdapter.f74052e = arrayList;
        this.f75227X3.getAdapter().m42860G();
    }

    /* renamed from: l3 */
    public void m4787l3() {
    }

    /* renamed from: m3 */
    public void m4786m3(Bundle bundle) {
        String str = this.f75212I3.getString("Name") + " - " + bundle.getString("name");
        Log.e("StopDownload", str);
        if (this.f74026i4.m3755B3(str) != null) {
            this.f74026i4.m3710d4(str);
        }
    }

    /* renamed from: n3 */
    public void m4785n3(String str) {
        int i = 0;
        if (this.f75227X3.getAdapter() == this.f75216M3) {
            ArrayList<Bundle> arrayList = this.f75218O3;
            int size = arrayList != null ? arrayList.size() : 0;
            while (i < this.f74022e4.size()) {
                if (str.equals(this.f75212I3.getString("Name") + " - " + this.f74022e4.get(i).getString("name"))) {
                    this.f75227X3.getAdapter().m42859H(size + i);
                }
                i++;
            }
            return;
        }
        ArrayList<Bundle> arrayList2 = this.f74020c4;
        int size2 = arrayList2 != null ? arrayList2.size() : 0;
        while (i < this.f75219P3.size()) {
            if (str.equals(this.f75212I3.getString("Name") + " - " + this.f75219P3.get(i).getString("name"))) {
                this.f75227X3.getAdapter().m42859H(size2 + i);
            }
            i++;
        }
    }

    /* renamed from: o3 */
    public void m4784o3(Bundle bundle) {
        String[] splitByWholeSeparator;
        String replace = this.f75212I3.getString("Name").replace(".db", "");
        if (bundle.containsKey("dbname")) {
            replace = bundle.getString("dbname").replace(".db", "");
        }
        String m5007D1 = this.f75215L3.m5007D1("http://" + (PreferenceManager.getDefaultSharedPreferences(m44716w()).getString("DownloadServer", HTML.Tag.f65923m0).equals("idl") ? "ivideos" : "videos") + ".imedicaldoctor.net/cmeinfo/" + replace + "/" + bundle.getString("name"));
        String m4942Z0 = CompressHelper.m4942Z0(this.f75212I3, bundle.getString("name"), "temp");
        if (bundle.containsKey("dbname")) {
            m4942Z0 = CompressHelper.m4942Z0(this.f75212I3, bundle.getString("dbname") + "-" + bundle.getString("name"), "temp");
        }
        if (!this.f75212I3.getString("Type").equals("cme")) {
            m5007D1 = this.f75215L3.m5007D1(this.f75215L3.m4991J() + "/dbs/usmle/" + this.f75212I3.getString("Name").replace(".db", "") + "/videos/" + bundle.getString("name") + ".mp4");
            m4942Z0 = CompressHelper.m4942Z0(this.f75212I3, bundle.getString("name"), "videos");
        }
        String str = m5007D1;
        String str2 = m4942Z0;
        String str3 = StringUtils.splitByWholeSeparator(str2, "/")[splitByWholeSeparator.length - 1];
        final String str4 = this.f75212I3.getString("Name") + " - " + bundle.getString("name");
        Log.e("AddDownloadForVideo", "Downloading " + str4 + " , " + str + " To " + str2);
        Bundle m3755B3 = this.f74026i4.m3755B3(str4);
        if (m3755B3 == null || !m3755B3.containsKey("downloader")) {
            this.f74026i4.m3687y3(bundle.getString("title"), str, str2, bundle.getString("fileSize"), str3, str4, "");
            this.f74026i4.m3724W3(str4, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.9
                @Override // java.lang.Runnable
                public void run() {
                    CMETOCFragment.this.m4785n3(str4);
                }
            });
        }
        this.f74026i4.m3712c4(str4);
    }

    /* renamed from: p3 */
    public void m4783p3() {
        try {
            Iterator<Bundle> it2 = this.f74022e4.iterator();
            while (it2.hasNext()) {
                final String str = this.f75212I3.getString("Name") + " - " + it2.next().getString("name");
                Log.e("Find Resource VideoID", str);
                Bundle m3755B3 = this.f74026i4.m3755B3(str);
                if (m3755B3 != null && m3755B3.containsKey("downloader")) {
                    this.f74026i4.m3724W3(str, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.CMETOCFragment.2
                        @Override // java.lang.Runnable
                        public void run() {
                            CMETOCFragment.this.m4785n3(str);
                        }
                    });
                }
            }
        } catch (Exception unused) {
        }
    }

    /* renamed from: r3 */
    public Bundle m4781r3(Bundle bundle) {
        String str = this.f75212I3.getString("Name") + " - " + bundle.getString("name");
        downloadFragment downloadfragment = this.f74026i4;
        if (downloadfragment == null) {
            return null;
        }
        return downloadfragment.m3755B3(str);
    }

    /* renamed from: s3 */
    public Activity m4780s3() {
        return this.f74024g4;
    }

    /* renamed from: t3 */
    public Spanned m4779t3(Bundle bundle) {
        String string;
        if (!bundle.containsKey("dbtitle") || (this.f75223T3.getQuery().toString().length() <= 0 && this.f74021d4 != "11111")) {
            string = bundle.getString("title");
        } else {
            string = "" + bundle.getString("title") + "<br/><font color=\"Gray\"><small>" + bundle.getString("dbtitle") + "</small></font>";
        }
        return Html.fromHtml(string);
    }

    /* renamed from: v3 */
    public String m4777v3(long j) {
        double d;
        if (j <= 0) {
            return "0";
        }
        int log10 = (int) (Math.log10(j) / Math.log10(1024.0d));
        return new DecimalFormat("#,##0.#").format(d / Math.pow(1024.0d, log10)) + StringUtils.SPACE + new String[]{"B", "KB", "MB", "GB", "TB"}[log10];
    }

    /* renamed from: w3 */
    public boolean m4776w3(Bundle bundle) {
        String m4942Z0 = CompressHelper.m4942Z0(this.f75212I3, bundle.getString("name"), "temp");
        if (bundle.containsKey("dbname")) {
            Bundle bundle2 = this.f75212I3;
            m4942Z0 = CompressHelper.m4942Z0(bundle2, bundle.getString("dbname") + "-" + bundle.getString("name"), "temp");
        }
        if (!this.f75212I3.getString("Type").equals("cme")) {
            m4942Z0 = CompressHelper.m4942Z0(this.f75212I3, bundle.getString("name"), "videos");
        }
        return new File(m4942Z0).exists();
    }
}
