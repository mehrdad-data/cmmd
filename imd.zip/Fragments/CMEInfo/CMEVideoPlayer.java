package net.imedicaldoctor.imd.Fragments.CMEInfo;

/* loaded from: classes2.dex */
public class CMEVideoPlayer {
}
