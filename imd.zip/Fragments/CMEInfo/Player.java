package net.imedicaldoctor.imd.Fragments.CMEInfo;

import android.app.ActionBar;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.p011ui.StyledPlayerView;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.upstream.C2206c;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.TransferListener;
import com.google.android.exoplayer2.upstream.crypto.AesFlushingCipher;
import com.google.common.net.HttpHeaders;
import com.itextpdf.text.pdf.codec.wmf.MetaDo;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.SequenceInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;

/* loaded from: classes2.dex */
public class Player extends AppCompatActivity {

    /* renamed from: a3 */
    public static SimpleExoPlayer f74083a3;

    /* renamed from: Q2 */
    StyledPlayerView f74084Q2;

    /* renamed from: R2 */
    Bundle f74085R2;

    /* renamed from: S2 */
    long f74086S2;

    /* renamed from: T2 */
    String f74087T2;

    /* renamed from: U2 */
    private float f74088U2;

    /* renamed from: V2 */
    float f74089V2 = 1.0f;

    /* renamed from: W2 */
    float f74090W2 = 1.2f;

    /* renamed from: X2 */
    float f74091X2 = 1.5f;

    /* renamed from: Y2 */
    float f74092Y2 = 2.0f;

    /* renamed from: Z2 */
    float f74093Z2 = 3.0f;

    /* loaded from: classes2.dex */
    public class InputStreamDataSource implements DataSource {

        /* renamed from: b */
        private Context f74099b;

        /* renamed from: c */
        private DataSpec f74100c;

        /* renamed from: d */
        private InputStream f74101d;

        /* renamed from: e */
        private long f74102e;

        /* renamed from: f */
        private boolean f74103f;

        /* renamed from: g */
        private byte[] f74104g;

        /* renamed from: h */
        private byte[] f74105h;

        /* renamed from: i */
        private CompressHelper f74106i;

        public InputStreamDataSource(Context context, DataSpec dataSpec) {
            this.f74099b = context;
            this.f74100c = dataSpec;
        }

        /* renamed from: t */
        private InputStream m4753t(Context context, Uri uri) {
            try {
                Log.e("ConvertUri", uri.getPath());
                final FileInputStream fileInputStream = new FileInputStream(new File(uri.getPath()));
                Log.e("ConvertURI", "fileInputStream available : " + fileInputStream.available());
                fileInputStream.available();
                final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.f74105h);
                SequenceInputStream sequenceInputStream = new SequenceInputStream(byteArrayInputStream, fileInputStream) { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.Player.InputStreamDataSource.1
                    @Override // java.io.SequenceInputStream, java.io.InputStream
                    public int available() throws IOException {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Available : ");
                        sb.append(fileInputStream.available());
                        Log.e("PlayerResult", sb.toString());
                        return fileInputStream.available() - 16;
                    }

                    @Override // java.io.InputStream
                    public long skip(long j) throws IOException {
                        Log.e("PlayerResult", "Call Skip : " + j);
                        if (j > 1024) {
                            byteArrayInputStream.skip(1024L);
                            fileInputStream.skip(j - 1024);
                        } else {
                            byteArrayInputStream.skip(j);
                        }
                        Log.e("PlayerResult", "Skip : " + j);
                        return j;
                    }
                };
                Log.e("ConvertURI", "Combined available : " + sequenceInputStream.available());
                this.f74101d = sequenceInputStream;
                return sequenceInputStream;
            } catch (Exception e) {
                Log.e("ConvertURI", "Error in creating inputstream");
                e.printStackTrace();
                return null;
            }
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        /* renamed from: a */
        public long mo4752a(DataSpec dataSpec) throws IOException {
            this.f74104g = new byte[MetaDo.f64337x];
            this.f74105h = new byte[1024];
            this.f74106i = new CompressHelper(Player.this.getApplicationContext());
            File file = new File(dataSpec.f39904a.getPath());
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
            randomAccessFile.seek(file.length() - 1040);
            randomAccessFile.read(this.f74104g, 0, MetaDo.f64337x);
            Log.e("Datasource open", "Scratch Length : " + this.f74104g.length);
            this.f74105h = this.f74106i.m4867w(this.f74104g, "kaplan", "127");
            Log.e("Datasource open", "Scratch DE Length : " + this.f74105h.length);
            try {
                InputStream m4753t = m4753t(this.f74099b, dataSpec.f39904a);
                this.f74101d = m4753t;
                long skip = m4753t.skip(dataSpec.f39910g);
                Log.e("Player", "Skipped : " + skip + " , Dataspec position: " + dataSpec.f39910g + ", DS Length: " + dataSpec.f39911h);
                if (skip < dataSpec.f39910g) {
                    Log.e("Player", "Skipped is lower than position");
                    throw new EOFException();
                }
                long j = dataSpec.f39911h;
                if (j != -1) {
                    this.f74102e = j;
                } else {
                    long available = this.f74101d.available();
                    this.f74102e = available;
                    if (available == 2147483647L) {
                        this.f74102e = -1L;
                    }
                }
                this.f74102e = this.f74102e;
                Log.e("Player", "Bytes remaining " + this.f74102e);
                this.f74103f = true;
                return this.f74102e;
            } catch (IOException e) {
                throw new IOException(e);
            }
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        public void close() throws IOException {
            try {
                try {
                    InputStream inputStream = this.f74101d;
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (IOException e) {
                    throw new IOException(e);
                }
            } finally {
                this.f74101d = null;
                if (this.f74103f) {
                    this.f74103f = false;
                }
            }
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        /* renamed from: d */
        public void mo4751d(TransferListener transferListener) {
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        public /* synthetic */ Map getResponseHeaders() {
            return C2206c.m31423a(this);
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        /* renamed from: r */
        public Uri mo4750r() {
            return this.f74100c.f39904a;
        }

        @Override // com.google.android.exoplayer2.upstream.DataReader
        public int read(byte[] bArr, int i, int i2) throws IOException {
            Log.e("Datasource Read", "offset: " + i + " , Readlength : " + i2);
            if (i2 == 0) {
                return 0;
            }
            long j = this.f74102e;
            if (j == 0) {
                return -1;
            }
            if (j != -1) {
                try {
                    i2 = (int) Math.min(j, i2);
                } catch (IOException e) {
                    throw new IOException(e);
                }
            }
            int read = this.f74101d.read(bArr, i, i2);
            if (read == -1) {
                if (this.f74102e == -1) {
                    return -1;
                }
                throw new IOException(new EOFException());
            }
            long j2 = this.f74102e;
            if (j2 != -1) {
                this.f74102e = j2 - read;
            }
            return read;
        }
    }

    /* loaded from: classes2.dex */
    public final class iMDDataSource implements DataSource {

        /* renamed from: b */
        private final DataSource f74111b;

        /* renamed from: c */
        private byte[] f74112c = new byte[MetaDo.f64337x];

        /* renamed from: d */
        private byte[] f74113d = new byte[1024];

        /* renamed from: e */
        private String f74114e;

        /* renamed from: f */
        private CompressHelper f74115f;
        @Nullable

        /* renamed from: g */
        private AesFlushingCipher f74116g;

        public iMDDataSource(DataSource dataSource, String str) {
            this.f74111b = dataSource;
            this.f74115f = new CompressHelper(Player.this.getApplicationContext());
            this.f74114e = str;
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        /* renamed from: a */
        public long mo4752a(DataSpec dataSpec) throws IOException {
            Log.e("Datasource open", "URI " + this.f74114e);
            File file = new File(this.f74114e);
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
            randomAccessFile.seek(file.length() - 1040);
            randomAccessFile.read(this.f74112c, 0, MetaDo.f64337x);
            long mo4752a = this.f74111b.mo4752a(dataSpec);
            Log.e("Datasource open", "DataLength : " + mo4752a);
            Log.e("Datasource open", "Scratch Length : " + this.f74112c.length);
            this.f74113d = this.f74115f.m4867w(this.f74112c, "kaplan", "127");
            Log.e("Datasource open", "Scratch DE Length : " + this.f74113d.length);
            return mo4752a - 16;
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        public void close() throws IOException {
            this.f74116g = null;
            this.f74111b.close();
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        /* renamed from: d */
        public void mo4751d(TransferListener transferListener) {
            this.f74111b.mo4751d(transferListener);
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        public Map<String, List<String>> getResponseHeaders() {
            return this.f74111b.getResponseHeaders();
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource
        /* renamed from: r */
        public Uri mo4750r() {
            return Uri.fromFile(Environment.getExternalStorageDirectory());
        }

        @Override // com.google.android.exoplayer2.upstream.DataReader
        public int read(byte[] bArr, int i, int i2) throws IOException {
            Log.e("Datasource Read", "offset: " + i + " , Readlength : " + i2);
            if (i2 == 0) {
                return 0;
            }
            if (i < 1024) {
                int i3 = 1024 - i;
                System.arraycopy(this.f74113d, i, bArr, i, i3);
                return i3;
            }
            return this.f74111b.read(bArr, i, 1024);
        }
    }

    /* loaded from: classes2.dex */
    public final class iMDDataSourceFactory implements DataSource.Factory {

        /* renamed from: a */
        private final DataSource f74118a;

        /* renamed from: b */
        private String f74119b;

        public iMDDataSourceFactory(DataSource dataSource, String str) {
            this.f74118a = dataSource;
            this.f74119b = str;
        }

        @Override // com.google.android.exoplayer2.upstream.DataSource.Factory
        /* renamed from: a */
        public DataSource mo4749a() {
            return new iMDDataSource(this.f74118a, this.f74119b);
        }
    }

    /* renamed from: q0 */
    private void m4756q0() {
        SimpleExoPlayer simpleExoPlayer = f74083a3;
        if (simpleExoPlayer != null) {
            simpleExoPlayer.stop();
            f74083a3.mo36902a();
            f74083a3 = null;
        }
    }

    /* renamed from: r0 */
    private void m4755r0() {
        Bundle bundle;
        StringBuilder sb;
        String str;
        Log.e("SaveLocation", "Starting");
        CompressHelper compressHelper = new CompressHelper(this);
        Bundle bundle2 = this.f74085R2;
        ArrayList<Bundle> m4955V = compressHelper.m4955V(bundle2, "select * from logs where id = " + this.f74087T2);
        long currentPosition = f74083a3.getCurrentPosition();
        long duration = f74083a3.getDuration();
        Log.e("SaveLocation", "Position : " + currentPosition);
        Log.e("SaveLocation", "Duration : " + duration);
        String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        if (m4955V == null || m4955V.size() == 0) {
            bundle = this.f74085R2;
            sb = new StringBuilder();
            sb.append("Insert into logs values (");
            sb.append(this.f74087T2);
            sb.append(",");
            sb.append(duration);
            sb.append(", ");
            sb.append(currentPosition);
            sb.append(", '");
            sb.append(format);
            str = "')";
        } else {
            bundle = this.f74085R2;
            sb = new StringBuilder();
            sb.append("Update logs set duration=");
            sb.append(duration);
            sb.append(", position=");
            sb.append(currentPosition);
            sb.append(", vDate='");
            sb.append(format);
            sb.append("' where id = ");
            str = this.f74087T2;
        }
        sb.append(str);
        compressHelper.m4897m(bundle, sb.toString());
    }

    /* renamed from: n0 */
    public void m4759n0() {
        Context applicationContext;
        String str;
        float f = this.f74088U2;
        float f2 = this.f74091X2;
        if (f == f2) {
            this.f74088U2 = this.f74092Y2;
            applicationContext = getApplicationContext();
            str = "2x";
        } else if (f == this.f74092Y2) {
            this.f74088U2 = this.f74093Z2;
            applicationContext = getApplicationContext();
            str = "3x";
        } else if (f == this.f74093Z2) {
            this.f74088U2 = this.f74089V2;
            applicationContext = getApplicationContext();
            str = "1x";
        } else {
            float f3 = this.f74090W2;
            if (f != f3) {
                if (f == this.f74089V2) {
                    this.f74088U2 = f3;
                    applicationContext = getApplicationContext();
                    str = "1.2x";
                }
                f74083a3.mo36857l(new PlaybackParameters(this.f74088U2));
            }
            this.f74088U2 = f2;
            applicationContext = getApplicationContext();
            str = "1.5x";
        }
        Toast.makeText(applicationContext, str, 0).show();
        f74083a3.mo36857l(new PlaybackParameters(this.f74088U2));
    }

    /* renamed from: o0 */
    public float m4758o0() {
        return this.f74088U2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark", false)) {
            AppCompatDelegate.m52839N(2);
        } else {
            AppCompatDelegate.m52839N(1);
        }
        if (PreferenceManager.getDefaultSharedPreferences(this).getBoolean("wakelock", true)) {
            getWindow().addFlags(128);
        }
        setContentView(C4804R.C4810layout.f87108activity_player);
        String stringExtra = getIntent().getStringExtra("Address");
        this.f74085R2 = getIntent().getBundleExtra("DB");
        this.f74086S2 = getIntent().getLongExtra(HttpHeaders.f53988m0, 0L);
        this.f74087T2 = getIntent().getStringExtra("VideoID");
        this.f74084Q2 = (StyledPlayerView) findViewById(C4804R.C4808id.f86889exo_player_view);
        try {
            f74083a3 = new SimpleExoPlayer.Builder(this).m36760z();
            DataSpec dataSpec = new DataSpec(Uri.parse(stringExtra));
            final InputStreamDataSource inputStreamDataSource = new InputStreamDataSource(this, dataSpec);
            try {
                inputStreamDataSource.mo4752a(dataSpec);
            } catch (IOException e) {
                e.printStackTrace();
            }
            ProgressiveMediaSource mo32856h = new ProgressiveMediaSource.Factory(new DataSource.Factory() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.Player.1
                @Override // com.google.android.exoplayer2.upstream.DataSource.Factory
                /* renamed from: a */
                public DataSource mo4749a() {
                    return inputStreamDataSource;
                }
            }).mo32856h(inputStreamDataSource.mo4750r());
            this.f74084Q2.setPlayer(f74083a3);
            f74083a3.mo36829t0(mo32856h);
            f74083a3.mo36889d();
            m4754s0(this.f74089V2);
            f74083a3.mo36911X0(true);
            if (this.f74086S2 != 0) {
                Log.e("Player", "Going to position : " + this.f74086S2);
                f74083a3.mo36918V(0, this.f74086S2);
            }
            final GestureDetector gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.Player.2
                @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
                public boolean onDoubleTap(MotionEvent motionEvent) {
                    return true;
                }

                @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
                public void onLongPress(MotionEvent motionEvent) {
                    super.onLongPress(motionEvent);
                }
            });
            this.f74084Q2.setOnTouchListener(new View.OnTouchListener() { // from class: net.imedicaldoctor.imd.Fragments.CMEInfo.Player.3
                @Override // android.view.View.OnTouchListener
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    return gestureDetector.onTouchEvent(motionEvent);
                }
            });
            getWindow().getDecorView().setSystemUiVisibility(4);
            ActionBar actionBar = getActionBar();
            if (actionBar != null) {
                actionBar.hide();
            }
        } catch (Exception e2) {
            Log.e("MainAcvtivity", " exoplayer error " + e2.toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        m4755r0();
        m4756q0();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onPause() {
        super.onPause();
        m4755r0();
        m4757p0();
    }

    /* renamed from: p0 */
    public boolean m4757p0() {
        return f74083a3.mo36894c() == 3 && f74083a3.mo36905Z();
    }

    /* renamed from: s0 */
    public void m4754s0(float f) {
        this.f74088U2 = f;
        f74083a3.mo36857l(new PlaybackParameters(f));
    }
}
