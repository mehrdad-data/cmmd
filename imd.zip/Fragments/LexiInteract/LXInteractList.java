package net.imedicaldoctor.imd.Fragments.LexiInteract;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.extractor.p010ts.TsExtractor;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractResult;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullDeleteViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class LXInteractList extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class LXInteractListFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private ArrayAdapter<Bundle> f74806b4;

        /* renamed from: c4 */
        private ArrayList<Bundle> f74807c4;

        /* renamed from: d4 */
        private ArrayList<String> f74808d4;

        /* renamed from: e4 */
        public Button f74809e4;

        /* renamed from: f4 */
        public SpellSearchAdapter f74810f4;

        /* renamed from: o3 */
        private void m4468o3() {
            if (this.f74807c4.size() == 0) {
                mo3542i3("Search to add Drugs");
            } else {
                mo3543h3();
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            ArrayList<String> arrayList;
            View view = this.f75221R3;
            if (view != null) {
                return view;
            }
            this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87149fragment_epointeract, viewGroup, false);
            if (bundle == null || !bundle.containsKey("mDrugs")) {
                this.f74807c4 = new ArrayList<>();
                arrayList = new ArrayList<>();
            } else {
                this.f74807c4 = bundle.getParcelableArrayList("mDrugs");
                arrayList = bundle.getStringArrayList("mIds");
            }
            this.f74808d4 = arrayList;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            mo4335T2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            appBarLayout.m27445s(false, false);
            appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractList.LXInteractListFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    relativeLayout.setVisibility(0);
                }
            }, 800L);
            Button button = (Button) this.f75221R3.findViewById(C4804R.C4808id.f87006result_button);
            this.f74809e4 = button;
            button.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractList.LXInteractListFragment.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (LXInteractListFragment.this.f74807c4.size() == 0) {
                        CompressHelper.m4921e2(LXInteractListFragment.this.m44716w(), "There is no drug added", 1);
                        return;
                    }
                    Bundle bundle2 = new Bundle();
                    bundle2.putParcelableArrayList("Drugs", LXInteractListFragment.this.f74807c4);
                    bundle2.putBundle("DB", LXInteractListFragment.this.f75212I3);
                    new CompressHelper(LXInteractListFragment.this.m44716w()).m4979N(LXInteractResult.class, LXInteractResult.LXInteractResultFragment.class, bundle2);
                }
            });
            ChaptersAdapter chaptersAdapter = new ChaptersAdapter(m44716w(), this.f74807c4, "name", C4804R.C4810layout.f87266list_view_item_ripple_text_full_delete) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractList.LXInteractListFragment.3
                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: e0 */
                public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                    RippleTextFullDeleteViewHolder rippleTextFullDeleteViewHolder = (RippleTextFullDeleteViewHolder) viewHolder;
                    rippleTextFullDeleteViewHolder.f83278I.setText(bundle2.getString("name"));
                    rippleTextFullDeleteViewHolder.f83283N.setVisibility(0);
                    rippleTextFullDeleteViewHolder.f83281L.setVisibility(0);
                    final String string = bundle2.getString("id");
                    rippleTextFullDeleteViewHolder.f83282M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractList.LXInteractListFragment.3.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            LXInteractListFragment.this.m4330Y2();
                            ArrayList<? extends Parcelable> arrayList2 = new ArrayList<>();
                            arrayList2.add(bundle2);
                            Bundle bundle3 = new Bundle();
                            bundle3.putParcelableArrayList("Drugs", arrayList2);
                            bundle3.putBundle("DB", LXInteractListFragment.this.f75212I3);
                            new CompressHelper(LXInteractListFragment.this.m44716w()).m4979N(LXInteractResult.class, LXInteractResult.LXInteractResultFragment.class, bundle3);
                        }
                    });
                    rippleTextFullDeleteViewHolder.f83283N.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractList.LXInteractListFragment.3.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            LXInteractListFragment.this.f74807c4.remove(bundle2);
                            LXInteractListFragment.this.f74808d4.remove(string);
                            LXInteractListFragment lXInteractListFragment = LXInteractListFragment.this;
                            ((ChaptersAdapter) lXInteractListFragment.f75216M3).m3404g0(lXInteractListFragment.f74807c4);
                            LXInteractListFragment.this.m4469n3();
                            LXInteractListFragment.this.f75216M3.m42860G();
                            LXInteractListFragment lXInteractListFragment2 = LXInteractListFragment.this;
                            lXInteractListFragment2.f75227X3.setAdapter(lXInteractListFragment2.f75216M3);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
                /* renamed from: h0 */
                public RecyclerView.ViewHolder mo3403h0(View view2) {
                    RippleTextFullDeleteViewHolder rippleTextFullDeleteViewHolder = new RippleTextFullDeleteViewHolder(view2);
                    rippleTextFullDeleteViewHolder.f83280K.setVisibility(8);
                    rippleTextFullDeleteViewHolder.f83279J.setVisibility(8);
                    return rippleTextFullDeleteViewHolder;
                }
            };
            this.f75216M3 = chaptersAdapter;
            chaptersAdapter.f83219h = "Search To Add Drug";
            this.f74810f4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "name", null, C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractList.LXInteractListFragment.4
                @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
                /* renamed from: e0 */
                public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                    RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                    rippleTextFullViewHolder.f83284I.setText(bundle2.getString("name"));
                    rippleTextFullViewHolder.f83287L.setVisibility(8);
                    final String string = bundle2.getString("id");
                    if (LXInteractListFragment.this.f74808d4.contains(string)) {
                        rippleTextFullViewHolder.f83284I.setTextColor(Color.rgb((int) TsExtractor.f35065I, (int) TsExtractor.f35065I, (int) TsExtractor.f35065I));
                        return;
                    }
                    rippleTextFullViewHolder.f83284I.setTextColor(Color.rgb(0, 0, 0));
                    rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractList.LXInteractListFragment.4.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            LXInteractListFragment.this.m4330Y2();
                            LXInteractListFragment.this.f74807c4.add(bundle2);
                            LXInteractListFragment.this.f74808d4.add(string);
                            LXInteractListFragment.this.f75223T3.m51655i0("", false);
                            LXInteractListFragment lXInteractListFragment = LXInteractListFragment.this;
                            ((ChaptersAdapter) lXInteractListFragment.f75216M3).m3404g0(lXInteractListFragment.f74807c4);
                            LXInteractListFragment.this.f75216M3.m42860G();
                            LXInteractListFragment lXInteractListFragment2 = LXInteractListFragment.this;
                            lXInteractListFragment2.f75227X3.setAdapter(lXInteractListFragment2.f75216M3);
                            LXInteractListFragment.this.m4469n3();
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
                /* renamed from: h0 */
                public void mo3379h0(Bundle bundle2) {
                    LXInteractListFragment.this.m4330Y2();
                    LXInteractListFragment.this.f75223T3.m51655i0(bundle2.getString("word"), true);
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
                /* renamed from: j0 */
                public RecyclerView.ViewHolder mo3377j0(View view2) {
                    RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view2);
                    rippleTextFullViewHolder.f83286K.setVisibility(8);
                    rippleTextFullViewHolder.f83285J.setVisibility(8);
                    return rippleTextFullViewHolder;
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(false);
            return this.f75221R3;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: a3 */
        public void mo3982a3() {
            this.f74810f4.m3378i0(this.f75219P3, this.f75220Q3);
            this.f75227X3.setAdapter(this.f74810f4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4952W(bundle, "Select rowid as _id,* from search where name match '" + str + "*'", "fsearch.db");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4952W(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'", "fsearch.db");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        /* renamed from: n3 */
        public void m4469n3() {
            ArrayList<Bundle> arrayList = this.f74807c4;
            if (arrayList == null || arrayList.size() == 0) {
                this.f74809e4.setEnabled(false);
                this.f74809e4.setBackgroundColor(Color.rgb(100, 100, 100));
                this.f74809e4.setText("Nothing Added");
                return;
            }
            this.f74809e4.setText("Show Interactions");
            this.f74809e4.setEnabled(true);
            this.f74809e4.setBackgroundColor(Color.rgb(64, 140, 83));
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new LXInteractListFragment());
    }
}
