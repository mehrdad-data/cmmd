package net.imedicaldoctor.imd.Fragments.LexiInteract;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class LXIvInteractDrugList extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f74856g4;

    /* renamed from: h4 */
    private String f74857h4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87154fragment_general_search_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        final SearchView searchView = (SearchView) inflate.findViewById(C4804R.C4808id.f87012search_view);
        if (Build.VERSION.SDK_INT >= 26) {
            searchView.setImportantForAutofill(8);
        }
        searchView.setQueryHint("Search IV Drugs");
        searchView.setIconifiedByDefault(false);
        ((TextView) searchView.findViewById(C4804R.C4808id.search_src_text)).setTextColor(m44782a0().getColor(C4804R.C4806color.f86093black));
        this.f74856g4 = m44859B().getBundle("db");
        final String string = m44859B().getString("Drugs");
        final CompressHelper compressHelper = new CompressHelper(m44716w());
        listView.setAdapter((ListAdapter) new CursorAdapter(m44716w(), null, 0) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractDrugList.1
            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: d */
            public void mo3522d(View view, Context context, Cursor cursor) {
                ((TextView) view.getTag()).setText(cursor.getString(cursor.getColumnIndex("name")));
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getItemViewType(int i) {
                return 0;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getViewTypeCount() {
                return 1;
            }

            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: i */
            public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                View inflate2 = LayoutInflater.from(LXIvInteractDrugList.this.m44716w()).inflate(C4804R.C4810layout.f87284list_view_item_simple_text, viewGroup, false);
                inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                return inflate2;
            }
        });
        searchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractDrugList.2
            @Override // androidx.appcompat.widget.SearchView.OnSuggestionListener
            /* renamed from: a */
            public boolean mo3524a(int i) {
                Cursor mo45341b = searchView.getSuggestionsAdapter().mo45341b();
                if (mo45341b.moveToPosition(i)) {
                    Bundle m4956U1 = new CompressHelper(LXIvInteractDrugList.this.m44716w()).m4956U1(mo45341b);
                    if (m4956U1.containsKey("word")) {
                        searchView.m51655i0(m4956U1.getString("word"), false);
                        return false;
                    }
                    ((LXIvInteract.LXIvInteractFragment) LXIvInteractDrugList.this.m44753k0()).m4460s3(m4956U1);
                    LXIvInteractDrugList.this.mo27003Q2();
                }
                return false;
            }

            @Override // androidx.appcompat.widget.SearchView.OnSuggestionListener
            /* renamed from: b */
            public boolean mo3523b(int i) {
                return mo3524a(i);
            }
        });
        searchView.setSuggestionsAdapter(new CursorAdapter(m44716w(), null, 0) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractDrugList.3
            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: d */
            public void mo3522d(View view, Context context, Cursor cursor) {
                ((TextView) view.getTag()).setText(cursor.getString(cursor.getColumnIndex(cursor.getColumnIndex("word") <= -1 ? "name" : "word")));
            }

            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: i */
            public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                View inflate2 = LayoutInflater.from(context).inflate(C4804R.C4810layout.f87293list_view_item_spell, viewGroup, false);
                inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                return inflate2;
            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractDrugList.4
            @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
            /* renamed from: a */
            public boolean mo3520a(final String str) {
                if (str.length() > 1) {
                    new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractDrugList.4.1
                        @Override // android.os.AsyncTask
                        protected Object doInBackground(Object[] objArr) {
                            String[] split;
                            String str2 = str.trim().split(StringUtils.SPACE)[split.length - 1];
                            String str3 = "";
                            for (int i = 0; i < split.length - 1; i++) {
                                str3 = str3 + StringUtils.SPACE + split[i];
                            }
                            searchView.setTag(str3.trim());
                            C39764 c39764 = C39764.this;
                            ArrayList<Bundle> m4952W = compressHelper.m4952W(LXIvInteractDrugList.this.f74856g4, "Select rowid as _id,rowid,* from search where name match '" + str + "*' AND (NOT generic_id in (" + string + "))", "fsearch.db");
                            if (m4952W == null) {
                                C39764 c397642 = C39764.this;
                                return compressHelper.m4955V(LXIvInteractDrugList.this.f74856g4, "Select rowid as _id,rowid,word from spell where word match '" + str2 + "*'");
                            }
                            return m4952W;
                        }

                        @Override // android.os.AsyncTask
                        protected void onPostExecute(Object obj) {
                            searchView.getSuggestionsAdapter().mo45336l(compressHelper.m4912h((ArrayList) obj));
                        }
                    }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
                    return true;
                }
                return false;
            }

            @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
            /* renamed from: b */
            public boolean mo3519b(String str) {
                return false;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractDrugList.5
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                if (mo45341b.moveToPosition(i)) {
                    ((LXIvInteract.LXIvInteractFragment) LXIvInteractDrugList.this.m44753k0()).m4460s3(new CompressHelper(LXIvInteractDrugList.this.m44716w()).m4956U1(mo45341b));
                    LXIvInteractDrugList.this.mo27003Q2();
                }
            }
        });
        builder.setView(inflate);
        return builder.create();
    }
}
