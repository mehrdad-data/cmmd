package net.imedicaldoctor.imd.Fragments.LexiInteract;

import android.database.DataSetObserver;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.common.net.HttpHeaders;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.LexiInteract.LXIVInteractResult;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Views.ButtonSmall;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class LXIvInteract extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class LXIvInteractFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private ArrayList<Bundle> f74838b4;

        /* renamed from: c4 */
        private ArrayList<Bundle> f74839c4;

        /* renamed from: d4 */
        private ArrayList<Bundle> f74840d4;

        /* renamed from: e4 */
        public ButtonSmall f74841e4;

        /* renamed from: f4 */
        private ArrayList<Bundle> f74842f4;

        /* renamed from: g4 */
        private ArrayList<Bundle> f74843g4;

        /* loaded from: classes2.dex */
        public class HeaderViewHolder {

            /* renamed from: a */
            public final TextView f74854a;

            public HeaderViewHolder(View view) {
                this.f74854a = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            ArrayList<Bundle> arrayList;
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87164fragment_lxiv_interact, viewGroup, false);
            this.f75221R3 = inflate;
            super.mo3277U0(layoutInflater, viewGroup, bundle);
            this.f75222S3 = (Toolbar) this.f75221R3.findViewById(C4804R.C4808id.f87063toolbar);
            this.f74841e4 = (ButtonSmall) this.f75221R3.findViewById(C4804R.C4808id.f86802back_button);
            this.f75222S3.setNavigationOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract.LXIvInteractFragment.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    LXIvInteractFragment.this.f75215L3.m4998G1(true);
                }
            });
            ButtonSmall buttonSmall = this.f74841e4;
            if (buttonSmall != null) {
                buttonSmall.setDrawableIcon(m44716w().getResources().getDrawable(C4804R.C4807drawable.f86482back_icon));
                this.f74841e4.setRippleColor(m44716w().getResources().getColor(C4804R.C4806color.f86409toolbar_item_ripple_color));
                this.f74841e4.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract.LXIvInteractFragment.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        LXIvInteractFragment.this.f75215L3.m4998G1(true);
                    }
                });
                this.f74841e4.setOnLongClickListener(new View.OnLongClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract.LXIvInteractFragment.3
                    @Override // android.view.View.OnLongClickListener
                    public boolean onLongClick(View view) {
                        LXIvInteractFragment.this.f75215L3.m4989J1(true);
                        return true;
                    }
                });
            }
            mo4325g3();
            if (bundle == null || !bundle.containsKey("mDrugs")) {
                this.f74838b4 = new ArrayList<>();
                this.f74839c4 = new ArrayList<>();
                arrayList = new ArrayList<>();
            } else {
                this.f74838b4 = bundle.getParcelableArrayList("mIVDrugs");
                this.f74839c4 = bundle.getParcelableArrayList("mSites");
                arrayList = bundle.getParcelableArrayList("mSolutions");
            }
            this.f74840d4 = arrayList;
            final CompressHelper compressHelper = new CompressHelper(m44716w());
            this.f74842f4 = compressHelper.m4955V(this.f75212I3, "Select * from site order by name");
            this.f74843g4 = compressHelper.m4955V(this.f75212I3, "Select * from solution order by name");
            ListAdapter listAdapter = new ListAdapter() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract.LXIvInteractFragment.4
                @Override // android.widget.Adapter
                /* renamed from: a */
                public Bundle getItem(int i) {
                    ArrayList arrayList2;
                    int size;
                    int i2;
                    String str;
                    Bundle bundle2 = new Bundle();
                    if (i == 0) {
                        bundle2.putString("Type", "Header");
                        str = "DRUGS";
                    } else if (i == 1) {
                        bundle2.putString("Type", "Add");
                        str = "Add Drug";
                    } else if (i == LXIvInteractFragment.this.f74838b4.size() + 2) {
                        bundle2.putString("Type", "Header");
                        str = "AT SITES";
                    } else if (i == LXIvInteractFragment.this.f74838b4.size() + 3) {
                        bundle2.putString("Type", "Add");
                        str = "All Sites";
                    } else if (i == LXIvInteractFragment.this.f74838b4.size() + 4 + LXIvInteractFragment.this.f74839c4.size()) {
                        bundle2.putString("Type", "Header");
                        str = "IN SOLUTIONS";
                    } else if (i != LXIvInteractFragment.this.f74838b4.size() + 5 + LXIvInteractFragment.this.f74839c4.size()) {
                        if (i <= 1 || i >= LXIvInteractFragment.this.f74838b4.size() + 2) {
                            if (i <= LXIvInteractFragment.this.f74838b4.size() + 3 || i >= LXIvInteractFragment.this.f74838b4.size() + 4 + LXIvInteractFragment.this.f74839c4.size()) {
                                if (i > LXIvInteractFragment.this.f74838b4.size() + 5 + LXIvInteractFragment.this.f74839c4.size()) {
                                    bundle2.putString("Type", "SolutionItem");
                                    arrayList2 = LXIvInteractFragment.this.f74840d4;
                                    size = LXIvInteractFragment.this.f74838b4.size() + 6 + LXIvInteractFragment.this.f74839c4.size();
                                }
                                return bundle2;
                            }
                            bundle2.putString("Type", "SiteItem");
                            arrayList2 = LXIvInteractFragment.this.f74839c4;
                            size = LXIvInteractFragment.this.f74838b4.size() + 4;
                            i2 = i - size;
                        } else {
                            bundle2.putString("Type", "DrugItem");
                            arrayList2 = LXIvInteractFragment.this.f74838b4;
                            i2 = i - 2;
                        }
                        bundle2.putBundle("Item", (Bundle) arrayList2.get(i2));
                        return bundle2;
                    } else {
                        bundle2.putString("Type", "Add");
                        str = "All Solutions";
                    }
                    bundle2.putString("Text", str);
                    return bundle2;
                }

                @Override // android.widget.ListAdapter
                public boolean areAllItemsEnabled() {
                    return false;
                }

                @Override // android.widget.Adapter
                public int getCount() {
                    return LXIvInteractFragment.this.f74838b4.size() + 2 + 2 + LXIvInteractFragment.this.f74839c4.size() + 2 + LXIvInteractFragment.this.f74840d4.size();
                }

                @Override // android.widget.Adapter
                public long getItemId(int i) {
                    return 0L;
                }

                @Override // android.widget.Adapter
                public int getItemViewType(int i) {
                    Bundle item = getItem(i);
                    if (item.getString("Type").equals("Header")) {
                        return 0;
                    }
                    return item.getString("Type").equals("Add") ? 1 : 2;
                }

                @Override // android.widget.Adapter
                public View getView(int i, View view, ViewGroup viewGroup2) {
                    TextView textView;
                    Bundle item = getItem(i);
                    final String string = item.getString("Type");
                    if (string.equals("Header")) {
                        if (view == null) {
                            view = LayoutInflater.from(LXIvInteractFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup2, false);
                            view.setTag(new HeaderViewHolder(view));
                        }
                        textView = ((HeaderViewHolder) view.getTag()).f74854a;
                    } else if (!string.equals("Add")) {
                        if (view == null) {
                            view = LayoutInflater.from(LXIvInteractFragment.this.m44716w()).inflate(C4804R.C4810layout.f87233list_view_item_delete, viewGroup2, false);
                            view.setTag(view.findViewById(C4804R.C4808id.text));
                        }
                        final Bundle bundle2 = item.getBundle("Item");
                        ((TextView) view.getTag()).setText(bundle2.getString("name"));
                        ((TextView) view.findViewById(C4804R.C4808id.f86861delete_button)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract.LXIvInteractFragment.4.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view2) {
                                ArrayList arrayList2;
                                if (string.equals("DrugItem")) {
                                    arrayList2 = LXIvInteractFragment.this.f74838b4;
                                } else if (!string.equals("SiteItem")) {
                                    if (string.equals("SolutionItem")) {
                                        arrayList2 = LXIvInteractFragment.this.f74840d4;
                                    }
                                    LXIvInteractFragment.this.f75211H3.setAdapter(LXIvInteractFragment.this.f75211H3.getAdapter());
                                } else {
                                    arrayList2 = LXIvInteractFragment.this.f74839c4;
                                }
                                arrayList2.remove(bundle2);
                                LXIvInteractFragment.this.f75211H3.setAdapter(LXIvInteractFragment.this.f75211H3.getAdapter());
                            }
                        });
                        return view;
                    } else {
                        if (view == null) {
                            view = LayoutInflater.from(LXIvInteractFragment.this.m44716w()).inflate(C4804R.C4810layout.f87219list_view_item_add, viewGroup2, false);
                            view.setTag(view.findViewById(C4804R.C4808id.text));
                        }
                        textView = (TextView) view.getTag();
                    }
                    textView.setText(item.getString("Text"));
                    return view;
                }

                @Override // android.widget.Adapter
                public int getViewTypeCount() {
                    return 3;
                }

                @Override // android.widget.Adapter
                public boolean hasStableIds() {
                    return false;
                }

                @Override // android.widget.Adapter
                public boolean isEmpty() {
                    return false;
                }

                @Override // android.widget.ListAdapter
                public boolean isEnabled(int i) {
                    String string = getItem(i).getString("Type");
                    return string.equals("Add") || string.equals("DrugItem");
                }

                @Override // android.widget.Adapter
                public void registerDataSetObserver(DataSetObserver dataSetObserver) {
                }

                @Override // android.widget.Adapter
                public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
                }
            };
            ((Button) this.f75221R3.findViewById(C4804R.C4808id.f86943interac_button)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract.LXIvInteractFragment.5
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    CompressHelper compressHelper2 = new CompressHelper(LXIvInteractFragment.this.m44716w());
                    if (LXIvInteractFragment.this.f74838b4.size() == 0) {
                        CompressHelper.m4921e2(LXIvInteractFragment.this.m44716w(), "You must at least add one drug", 1);
                    } else if (LXIvInteractFragment.this.f74838b4.size() != 1) {
                        Bundle bundle2 = new Bundle();
                        bundle2.putParcelableArrayList("Sites", LXIvInteractFragment.this.m4457v3());
                        bundle2.putParcelableArrayList("Solutions", LXIvInteractFragment.this.m4455x3());
                        bundle2.putParcelableArrayList("Drugs", LXIvInteractFragment.this.f74838b4);
                        bundle2.putBundle("DB", LXIvInteractFragment.this.f75212I3);
                        if (LXIvInteractFragment.this.f74839c4.size() != 0 || LXIvInteractFragment.this.f74840d4.size() != 0) {
                            bundle2.putString(HttpHeaders.f53975g, "Note: Information shown represents only the sites and solutions you have chosen.");
                        }
                        new CompressHelper(LXIvInteractFragment.this.m44716w()).m4979N(LXIVInteractResult.class, LXIVInteractResult.LXIvInteractResultFragment.class, bundle2);
                    } else {
                        Bundle bundle3 = (Bundle) LXIvInteractFragment.this.f74838b4.get(0);
                        String string = bundle3.getString("rowid");
                        Bundle bundle4 = LXIvInteractFragment.this.f75212I3;
                        ArrayList<Bundle> m4955V = compressHelper2.m4955V(bundle4, "Select d.id, vf.sequence, vf.label, f.content, f.fieldtype_id from document d join field f on f.document_id = d.id join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id and vf.fieldtype_id = f.fieldtype_id join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id join generic g on d.globalid = g.global_id  join item i on i.generic_id = g.id left join ivsolution l on f.document_id = l.document_id and f.fieldtype_id = l.fieldtype_id where i.rowid = " + string + " and f.fieldtype_id != 38 and f.fieldtype_id != 42 and s.site_id in (" + LXIvInteractFragment.this.m4458u3() + ")  and (l.solution_id is null or l.solution_id in (" + LXIvInteractFragment.this.m4456w3() + ")) union select d.id, vf.sequence, vf.label, iv.content, iv.fieldtype_id from document d join ivfield iv on iv.document_id = d.id join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id and vf.fieldtype_id = iv.fieldtype_id join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id join generic g on d.globalid = g.global_id join item i on i.generic_id = g.id  left join ivsolution l on iv.document_id = l.document_id and iv.fieldtype_id = l.fieldtype_id  left join solution sol on l.solution_id = sol.id  where i.rowid = " + string + " and iv.fieldtype_id != 38 and iv.fieldtype_id != 42  order by vf.sequence");
                        Bundle bundle5 = new Bundle();
                        bundle5.putParcelableArrayList("ivMonograph", m4955V);
                        bundle5.putParcelableArrayList("Solutions", LXIvInteractFragment.this.m4455x3());
                        bundle5.putParcelableArrayList("Sites", LXIvInteractFragment.this.m4457v3());
                        bundle5.putInt("Mode", 2);
                        if (LXIvInteractFragment.this.f74839c4.size() != 0 || LXIvInteractFragment.this.f74840d4.size() != 0) {
                            bundle5.putString(HttpHeaders.f53975g, "Note: Information shown represents only the sites and solutions you have chosen.");
                        }
                        compressHelper2.m4880r1(LXIvInteractFragment.this.f75212I3, bundle3.getString("rowid"), null, null, bundle5);
                    }
                }
            });
            this.f75211H3.setDivider(new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, new int[]{-1, -1465341784}));
            this.f75211H3.setDividerHeight(1);
            this.f75211H3.setAdapter(listAdapter);
            this.f75211H3.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract.LXIvInteractFragment.6
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    LXIvInteractList lXIvInteractList;
                    FragmentManager m44820L;
                    String str;
                    LXIvInteractFragment lXIvInteractFragment = LXIvInteractFragment.this;
                    lXIvInteractFragment.f75209F3 = i;
                    Bundle bundle2 = (Bundle) lXIvInteractFragment.f75211H3.getAdapter().getItem(i);
                    String string = bundle2.getString("Type");
                    String string2 = bundle2.getString("Text");
                    if (!string.equals("Add")) {
                        if (string.equals("DrugItem")) {
                            String string3 = bundle2.getBundle("Item").getString("rowid");
                            CompressHelper compressHelper2 = compressHelper;
                            Bundle bundle3 = LXIvInteractFragment.this.f75212I3;
                            ArrayList<Bundle> m4955V = compressHelper2.m4955V(bundle3, "Select d.id, vf.sequence, vf.label, f.content, f.fieldtype_id from document d join field f on f.document_id = d.id join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id and vf.fieldtype_id = f.fieldtype_id join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id join generic g on d.globalid = g.global_id  join item i on i.generic_id = g.id left join ivsolution l on f.document_id = l.document_id and f.fieldtype_id = l.fieldtype_id where i.rowid = " + string3 + " and f.fieldtype_id != 38 and f.fieldtype_id != 42 and s.site_id in (" + LXIvInteractFragment.this.m4458u3() + ")  and (l.solution_id is null or l.solution_id in (" + LXIvInteractFragment.this.m4456w3() + ")) union select d.id, vf.sequence, vf.label, iv.content, iv.fieldtype_id from document d join ivfield iv on iv.document_id = d.id join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id and vf.fieldtype_id = iv.fieldtype_id join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id join generic g on d.globalid = g.global_id join item i on i.generic_id = g.id  left join ivsolution l on iv.document_id = l.document_id and iv.fieldtype_id = l.fieldtype_id  left join solution sol on l.solution_id = sol.id  where i.rowid = " + string3 + " and iv.fieldtype_id != 38 and iv.fieldtype_id != 42  order by vf.sequence");
                            Bundle bundle4 = new Bundle();
                            bundle4.putParcelableArrayList("ivMonograph", m4955V);
                            bundle4.putParcelableArrayList("Solutions", LXIvInteractFragment.this.m4455x3());
                            bundle4.putParcelableArrayList("Sites", LXIvInteractFragment.this.m4457v3());
                            bundle4.putInt("Mode", 2);
                            if (LXIvInteractFragment.this.f74839c4.size() != 0 || LXIvInteractFragment.this.f74840d4.size() != 0) {
                                bundle4.putString(HttpHeaders.f53975g, "Note: Information shown represents only the sites and solutions you have chosen.");
                            }
                            compressHelper.m4880r1(LXIvInteractFragment.this.f75212I3, bundle2.getBundle("Item").getString("rowid"), null, null, bundle4);
                        }
                    } else if (string2.contains("Drug")) {
                        LXIvInteractDrugList lXIvInteractDrugList = new LXIvInteractDrugList();
                        Bundle bundle5 = new Bundle();
                        bundle5.putBundle("db", LXIvInteractFragment.this.f75212I3);
                        bundle5.putString("Drugs", CompressHelper.m4865w1(LXIvInteractFragment.this.f74838b4, "generic_id", ",", "'", "'"));
                        lXIvInteractDrugList.m44751k2(bundle5);
                        lXIvInteractDrugList.m44870c3(true);
                        lXIvInteractDrugList.m44844E2(LXIvInteractFragment.this, 0);
                        lXIvInteractDrugList.mo29915h3(LXIvInteractFragment.this.m44820L(), "LXIVInteractDrugsList");
                    } else {
                        if (string2.contains("Solution")) {
                            lXIvInteractList = new LXIvInteractList();
                            Bundle bundle6 = new Bundle();
                            bundle6.putBundle("db", LXIvInteractFragment.this.f75212I3);
                            ArrayList<? extends Parcelable> arrayList2 = new ArrayList<>();
                            arrayList2.addAll(LXIvInteractFragment.this.f74843g4);
                            arrayList2.removeAll(LXIvInteractFragment.this.f74840d4);
                            if (arrayList2.size() == 0) {
                                CompressHelper.m4921e2(LXIvInteractFragment.this.m44716w(), "There is nothing to select", 1);
                            }
                            bundle6.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, arrayList2);
                            bundle6.putString("titleProperty", "name");
                            bundle6.putString("type", "Solution");
                            lXIvInteractList.m44751k2(bundle6);
                            lXIvInteractList.m44870c3(true);
                            lXIvInteractList.m44844E2(LXIvInteractFragment.this, 0);
                            m44820L = LXIvInteractFragment.this.m44820L();
                            str = "LXIVInteractListSolution";
                        } else if (!string2.contains("Site")) {
                            return;
                        } else {
                            lXIvInteractList = new LXIvInteractList();
                            Bundle bundle7 = new Bundle();
                            bundle7.putBundle("db", LXIvInteractFragment.this.f75212I3);
                            ArrayList<? extends Parcelable> arrayList3 = new ArrayList<>();
                            arrayList3.addAll(LXIvInteractFragment.this.f74842f4);
                            arrayList3.removeAll(LXIvInteractFragment.this.f74839c4);
                            if (arrayList3.size() == 0) {
                                CompressHelper.m4921e2(LXIvInteractFragment.this.m44716w(), "There is nothing to select", 1);
                            }
                            bundle7.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, arrayList3);
                            bundle7.putString("titleProperty", "name");
                            bundle7.putString("type", "Site");
                            lXIvInteractList.m44751k2(bundle7);
                            lXIvInteractList.m44870c3(true);
                            lXIvInteractList.m44844E2(LXIvInteractFragment.this, 0);
                            m44820L = LXIvInteractFragment.this.m44820L();
                            str = "LXIVInteractListSite";
                        }
                        lXIvInteractList.mo29915h3(m44820L, str);
                    }
                }
            });
            this.f75211H3.setSelection(this.f75209F3);
            m44735q2(true);
            mo3543h3();
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: g3 */
        public void mo4325g3() {
            if (PreferenceManager.getDefaultSharedPreferences(m44716w()).getBoolean("HideStatusBar", false)) {
                float dimension = m44782a0().getDimension(C4804R.dimen.f86462toolbar_padding);
                Toolbar toolbar = this.f75222S3;
                if (toolbar != null) {
                    toolbar.setPadding(0, (int) dimension, 0, 0);
                    CollapsingToolbarLayout collapsingToolbarLayout = (CollapsingToolbarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86847collapsing_toolbar);
                }
            }
        }

        /* renamed from: l3 */
        public String m4467l3() {
            new ArrayList();
            return CompressHelper.m4868v1(this.f74842f4, "id");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        /* renamed from: m3 */
        public String m4466m3() {
            new ArrayList();
            return CompressHelper.m4868v1(this.f74843g4, "id");
        }

        /* renamed from: s3 */
        public void m4460s3(Bundle bundle) {
            if (this.f74838b4.contains(bundle)) {
                CompressHelper.m4921e2(m44716w(), "You Already added this drug", 1);
                return;
            }
            this.f74838b4.add(bundle);
            ListView listView = this.f75211H3;
            listView.setAdapter(listView.getAdapter());
        }

        /* renamed from: t3 */
        public void m4459t3(Bundle bundle, String str) {
            ArrayList<Bundle> arrayList;
            if (!str.equals("Solution")) {
                if (str.equals("Site")) {
                    if (this.f74839c4.contains(bundle)) {
                        CompressHelper.m4921e2(m44716w(), "You Already added this Site", 1);
                        return;
                    }
                    arrayList = this.f74839c4;
                }
                ListView listView = this.f75211H3;
                listView.setAdapter(listView.getAdapter());
            } else if (this.f74840d4.contains(bundle)) {
                CompressHelper.m4921e2(m44716w(), "You Already added this Solution", 1);
                return;
            } else {
                arrayList = this.f74840d4;
            }
            arrayList.add(bundle);
            ListView listView2 = this.f75211H3;
            listView2.setAdapter(listView2.getAdapter());
        }

        /* renamed from: u3 */
        public String m4458u3() {
            return CompressHelper.m4868v1(m4457v3(), "id");
        }

        /* renamed from: v3 */
        public ArrayList<Bundle> m4457v3() {
            ArrayList<Bundle> arrayList = this.f74839c4.size() == 0 ? this.f74842f4 : this.f74839c4;
            Bundle bundle = new Bundle();
            bundle.putString("id", "0");
            arrayList.add(bundle);
            return arrayList;
        }

        /* renamed from: w3 */
        public String m4456w3() {
            return CompressHelper.m4868v1(m4455x3(), "id");
        }

        /* renamed from: x3 */
        public ArrayList<Bundle> m4455x3() {
            return this.f74840d4.size() == 0 ? this.f74843g4 : this.f74840d4;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new LXIvInteractFragment());
    }
}
