package net.imedicaldoctor.imd.Fragments.LexiInteract;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class LXInteractResult extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class LXInteractResultFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private ArrayList<Bundle> f74824b4;

        /* renamed from: c4 */
        private ArrayList<Bundle> f74825c4;

        /* renamed from: d4 */
        public NotStickySectionAdapter f74826d4;

        /* loaded from: classes2.dex */
        public class HeaderViewHolder {

            /* renamed from: a */
            public final TextView f74832a;

            public HeaderViewHolder(View view) {
                this.f74832a = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
            }
        }

        /* loaded from: classes2.dex */
        public class InteractionViewHolder {

            /* renamed from: a */
            public final TextView f74834a;

            /* renamed from: b */
            public final ImageView f74835b;

            /* renamed from: c */
            public final TextView f74836c;

            public InteractionViewHolder(View view) {
                this.f74836c = (TextView) view.findViewById(C4804R.C4808id.f86883drug_two_text);
                this.f74834a = (TextView) view.findViewById(C4804R.C4808id.f86882drug_one_text);
                this.f74835b = (ImageView) view.findViewById(C4804R.C4808id.image);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            CompressHelper compressHelper;
            Bundle bundle2;
            String str;
            View view = this.f75221R3;
            if (view != null) {
                return view;
            }
            this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            m4329Z2(bundle);
            m4333V2();
            this.f75225V3.setText("");
            this.f75222S3.setTitle("Interaction Results");
            SearchView searchView = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            this.f75223T3 = searchView;
            if (Build.VERSION.SDK_INT >= 26) {
                searchView.setImportantForAutofill(8);
            }
            this.f75223T3.setVisibility(8);
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            appBarLayout.m27445s(false, false);
            appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractResult.LXInteractResultFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    relativeLayout.setVisibility(0);
                }
            }, 800L);
            this.f74825c4 = m44859B().containsKey("Drugs") ? m44859B().getParcelableArrayList("Drugs") : new ArrayList<>();
            if (bundle == null || !bundle.containsKey("mInteractionSections")) {
                new ArrayList();
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                Iterator<Bundle> it2 = this.f74825c4.iterator();
                while (it2.hasNext()) {
                    Bundle next = it2.next();
                    arrayList2.add(next.getString("id"));
                    if (next.getString("brand_id").length() > 0) {
                        arrayList.add(next.getString("brand_id"));
                    }
                }
                String join = TextUtils.join(",", arrayList2);
                String join2 = arrayList.size() > 0 ? TextUtils.join(",", arrayList) : "";
                this.f75215L3.m4897m(this.f75212I3, "drop table if exists temp_categories;");
                CompressHelper compressHelper2 = this.f75215L3;
                Bundle bundle3 = this.f75212I3;
                compressHelper2.m4897m(bundle3, "create table temp_categories as select c.id as id, b.generic_id as generic_id, b.name as name, b.id as brand_id from category c,category_generic_xref cgx, brand b where cgx.generic_id = b.generic_id and b.id in (" + join2 + ") and c.id = cgx.category_id union select c.id as id, cgx.generic_id as generic_id, g.name as name, cast(null as integer) as brand_id from category c, category_generic_xref cgx, generic g where cgx.generic_id in (" + join + ") and c.id = cgx.category_id and g.id = cgx.generic_id");
                if (this.f74825c4.size() == 1) {
                    compressHelper = this.f75215L3;
                    bundle2 = this.f75212I3;
                    str = "select m.id as id, m.risk as risk, c1.name as text1, t.generic_id, t.brand_id, c2.name as text2, m.filter                              from temp_categories t         join monograph m on (m.object_id = t.id)         join category c1 on (c1.id = m.object_id)         join category c2 on (c2.id = m.precipitant_id)         where not exists (select mgx.monograph_id from monograph_generic_exception_xref mgx                           where mgx.generic_id = t.generic_id                           and mgx.category_id = t.id                           and mgx.monograph_id = m.id)         and not exists (select mbx.monograph_id from monograph_brand_exception_xref mbx                         where mbx.brand_id = t.brand_id                         and mbx.monograph_id = m.id)         union         select m.id, m.risk as risk, c1.name as text1, t.generic_id, t.brand_id, c2.name as text2, m.filter         from temp_categories t         join monograph m on (m.precipitant_id = t.id)         join category c1 on (c1.id = m.object_id)         join category c2 on (c2.id = m.precipitant_id)         where not exists (select mgx.monograph_id from monograph_generic_exception_xref mgx                           where mgx.generic_id = t.generic_id                           and mgx.category_id = t.id                            and mgx.monograph_id = m.id)          and not exists (select mbx.monograph_id from monograph_brand_exception_xref mbx                          where mbx.brand_id = t.brand_id                          and mbx.monograph_id = m.id)          order by risk desc, text1, text2";
                } else {
                    compressHelper = this.f75215L3;
                    bundle2 = this.f75212I3;
                    str = "select m.id, m.risk as risk, c1.name as text1, c1.generic_id, c1.brand_id, c2.name as text2, c2.generic_id, c2.brand_id, m.filter                            from temp_categories c1                            join temp_categories c2 on (c1.generic_id != c2.generic_id)                            join monograph m on (m.object_id = c1.id and m.precipitant_id = c2.id)                            and not exists (                                            select mgx.monograph_id from monograph_generic_exception_xref mgx                                            where (mgx.generic_id = c1.generic_id and mgx.category_id = c1.id or mgx .generic_id = c2.generic_id and mgx.category_id = c2.id)                                            and mgx.monograph_id = m.id )                            and not exists (                                             select mbx.monograph_id                                            from monograph_brand_exception_xref mbx                                            where mbx.brand_id = c1.brand_id or mbx.brand_id = c2.brand_id and mbx.monograph_id = m.id ) group by m.id                           order by m.risk desc, text1, text2";
                }
                this.f74824b4 = this.f75215L3.m4941Z1(compressHelper.m4955V(bundle2, str), "risk");
            } else {
                this.f74824b4 = bundle.getParcelableArrayList("mInteractionSections");
                this.f74825c4 = bundle.getParcelableArrayList("mDrugs");
            }
            NotStickySectionAdapter notStickySectionAdapter = new NotStickySectionAdapter(m44716w(), this.f74824b4, "title", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractResult.LXInteractResultFragment.2
                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: f0 */
                public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle4, int i) {
                    RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                    String string = bundle4.getString("text1");
                    String string2 = bundle4.getString("text2");
                    rippleTextFullViewHolder.f83284I.setText(string);
                    rippleTextFullViewHolder.f83285J.setText(string2);
                    String string3 = bundle4.getString("risk");
                    rippleTextFullViewHolder.f83286K.setImageDrawable(LXInteractResultFragment.this.m44782a0().getDrawable(string3.equals("5") ? C4804R.C4807drawable.f86754xinteraction : string3.equals("4") ? C4804R.C4807drawable.f86564dinteraction : string3.equals(ExifInterface.f14411T4) ? C4804R.C4807drawable.f86552cinteraction : string3.equals(ExifInterface.f14403S4) ? C4804R.C4807drawable.f86515binteraction : string3.equals(IcyHeaders.f35463C2) ? C4804R.C4807drawable.f86476ainteraction : 0));
                    rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXInteractResult.LXInteractResultFragment.2.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            LXInteractResultFragment lXInteractResultFragment = LXInteractResultFragment.this;
                            CompressHelper compressHelper3 = lXInteractResultFragment.f75215L3;
                            Bundle bundle5 = lXInteractResultFragment.f75212I3;
                            Bundle m4907i1 = compressHelper3.m4907i1(compressHelper3.m4955V(bundle5, "SELECT                                                   o.name||' / '||p.name as title,                                                   m.risk                as risk,                                                   m.summary             as summary,                                                   s.severity            as severity,                                                   onset.onset           as onset,                                                   r.reliability         as reliability,                                                   m.management          as management,                                                   m.discussion          as discussion,                                                   m.footnotes           as footnotes,                                                    m.dependencies                                                   as dependencies                                                    FROM monograph m                                                    JOIN severity s ON s.id = m.severity_id                                                    JOIN category o ON o.id = m.object_id                                                   JOIN category p ON p.id = m.precipitant_id                                                    JOIN reliability r ON r.id = m.reliability_id                                                   LEFT JOIN onset ON onset.id = m.onset_id                                                   WHERE m.id = " + bundle4.getString("id")));
                            LXInteractResultFragment lXInteractResultFragment2 = LXInteractResultFragment.this;
                            CompressHelper compressHelper4 = lXInteractResultFragment2.f75215L3;
                            Bundle bundle6 = lXInteractResultFragment2.f75212I3;
                            ArrayList<Bundle> m4955V = compressHelper4.m4955V(bundle6, "select c.name, c.id, g.name, g.id, mgx.category_id from monograph m join category c on m.object_id = c.id join category_generic_xref cgx on cgx.category_id = c.id join generic g on g.id = cgx.generic_id and not g.combination left join monograph_generic_exception_xref mgx on mgx.monograph_id = m.id and mgx.category_id = c.id and mgx.generic_id = g.id  where m.id = " + bundle4.getString("id") + " union select c.name, c.id, g.name, g.id, mgx.category_id  from monograph m join category c on m.precipitant_id = c.id  join category_generic_xref cgx on cgx.category_id = c.id  join generic g on g.id = cgx.generic_id and not g.combination  left join monograph_generic_exception_xref mgx on mgx.monograph_id = m.id and mgx.category_id = c.id and mgx.generic_id = g.id  where m.id = " + bundle4.getString("id") + ";");
                            Bundle bundle7 = new Bundle();
                            bundle7.putBundle("monograph", m4907i1);
                            bundle7.putParcelableArrayList("monographMembers", m4955V);
                            bundle7.putBundle("monographItem", bundle4);
                            bundle7.putInt("Mode", 1);
                            LXInteractResultFragment lXInteractResultFragment3 = LXInteractResultFragment.this;
                            lXInteractResultFragment3.f75215L3.m4880r1(lXInteractResultFragment3.f75212I3, bundle4.getString("id"), null, null, bundle7);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: i0 */
                public String mo3387i0(String str2) {
                    return str2.equals("5") ? "X: Avoid combination" : str2.equals("4") ? "D: Consider therapy modification" : str2.equals(ExifInterface.f14411T4) ? "C: Monitor therapy" : str2.equals(ExifInterface.f14403S4) ? "B: No action needed" : str2.equals(IcyHeaders.f35463C2) ? "A: No known interaction" : str2;
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: k0 */
                public RecyclerView.ViewHolder mo3385k0(View view2) {
                    return new RippleTextFullViewHolder(view2);
                }
            };
            this.f74826d4 = notStickySectionAdapter;
            notStickySectionAdapter.f83255i = "No Interactions Found";
            this.f75227X3.setAdapter(notStickySectionAdapter);
            m4338Q2();
            m44735q2(false);
            m4330Y2();
            return this.f75221R3;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new LXInteractResultFragment());
    }
}
