package net.imedicaldoctor.imd.Fragments.LexiInteract;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteract;

/* loaded from: classes2.dex */
public class LXIvInteractList extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f74869g4;

    /* renamed from: h4 */
    private ArrayList<Bundle> f74870h4;

    /* renamed from: i4 */
    private String f74871i4;

    /* renamed from: j4 */
    private String f74872j4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f74869g4 = m44859B().getBundle("db");
        this.f74870h4 = m44859B().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0);
        this.f74871i4 = m44859B().getString("titleProperty");
        this.f74872j4 = m44859B().getString("type");
        new CompressHelper(m44716w());
        listView.setAdapter((ListAdapter) new ArrayAdapter<Bundle>(m44716w(), C4804R.C4810layout.f87284list_view_item_simple_text, C4804R.C4808id.text, this.f74870h4) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractList.1
            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i, View view, ViewGroup viewGroup) {
                if (view == null) {
                    view = LayoutInflater.from(LXIvInteractList.this.m44716w()).inflate(C4804R.C4810layout.f87284list_view_item_simple_text, viewGroup, false);
                    view.setTag(view.findViewById(C4804R.C4808id.text));
                }
                ((TextView) view.getTag()).setText(((Bundle) LXIvInteractList.this.f74870h4.get(i)).getString(LXIvInteractList.this.f74871i4));
                return view;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIvInteractList.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                ((LXIvInteract.LXIvInteractFragment) LXIvInteractList.this.m44753k0()).m4459t3((Bundle) LXIvInteractList.this.f74870h4.get(i), LXIvInteractList.this.f74872j4);
                LXIvInteractList.this.mo27003Q2();
            }
        });
        builder.setView(inflate);
        return builder.create();
    }
}
