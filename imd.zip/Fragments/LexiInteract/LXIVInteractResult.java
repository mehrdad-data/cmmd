package net.imedicaldoctor.imd.Fragments.LexiInteract;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.google.common.net.HttpHeaders;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class LXIVInteractResult extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class LXIvInteractResultFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private ArrayList<Bundle> f74789b4;

        /* renamed from: c4 */
        private ArrayList<Bundle> f74790c4;

        /* renamed from: d4 */
        private ArrayList<Bundle> f74791d4;

        /* renamed from: e4 */
        private ArrayList<Bundle> f74792e4;

        /* renamed from: f4 */
        public NotStickySectionAdapter f74793f4;

        /* renamed from: g4 */
        private String f74794g4;

        /* loaded from: classes2.dex */
        public class HeaderViewHolder {

            /* renamed from: a */
            public final TextView f74800a;

            public HeaderViewHolder(View view) {
                this.f74800a = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
            }
        }

        /* loaded from: classes2.dex */
        public class InteractionViewHolder {

            /* renamed from: a */
            public final TextView f74802a;

            /* renamed from: b */
            public final ImageView f74803b;

            /* renamed from: c */
            public final TextView f74804c;

            public InteractionViewHolder(View view) {
                this.f74804c = (TextView) view.findViewById(C4804R.C4808id.f86883drug_two_text);
                this.f74802a = (TextView) view.findViewById(C4804R.C4808id.f86882drug_one_text);
                this.f74803b = (ImageView) view.findViewById(C4804R.C4808id.image);
            }
        }

        /* renamed from: p3 */
        private void m4473p3() {
            ArrayList<Bundle> arrayList = this.f74789b4;
            if (arrayList == null || arrayList.size() == 0) {
                mo3542i3("No Information found");
            } else {
                mo3543h3();
            }
            FragmentActivity m44716w = m44716w();
            m44716w.setTitle("Founded " + this.f74790c4.size() + " Interactions");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75221R3;
            if (view != null) {
                return view;
            }
            this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            m4329Z2(bundle);
            m4333V2();
            this.f75225V3.setText("");
            this.f75222S3.setTitle("Interaction Results");
            SearchView searchView = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            this.f75223T3 = searchView;
            if (Build.VERSION.SDK_INT >= 26) {
                searchView.setImportantForAutofill(8);
            }
            this.f75223T3.setVisibility(8);
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            appBarLayout.m27445s(false, false);
            appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIVInteractResult.LXIvInteractResultFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    relativeLayout.setVisibility(0);
                }
            }, 800L);
            if (m44859B().containsKey("Drugs")) {
                this.f74790c4 = m44859B().getParcelableArrayList("Drugs");
                this.f74791d4 = m44859B().getParcelableArrayList("Sites");
                this.f74792e4 = m44859B().getParcelableArrayList("Solutions");
                if (m44859B().containsKey(HttpHeaders.f53975g)) {
                    this.f74794g4 = m44859B().getString(HttpHeaders.f53975g);
                    if (bundle == null && bundle.containsKey("mInteractionSections")) {
                        this.f74789b4 = bundle.getParcelableArrayList("mInteractionSections");
                        this.f74790c4 = bundle.getParcelableArrayList("mDrugs");
                        this.f74791d4 = bundle.getParcelableArrayList("mSites");
                        this.f74792e4 = bundle.getParcelableArrayList("mSolutions");
                        this.f74794g4 = bundle.getString("mWarning");
                    } else {
                        new ArrayList();
                        String m4868v1 = CompressHelper.m4868v1(this.f74790c4, "rowid");
                        String m4868v12 = CompressHelper.m4868v1(this.f74791d4, "id");
                        String m4868v13 = CompressHelper.m4868v1(this.f74792e4, "id");
                        this.f75215L3.m4897m(this.f75212I3, "drop table if exists temp_generic;");
                        CompressHelper compressHelper = this.f75215L3;
                        Bundle bundle2 = this.f75212I3;
                        compressHelper.m4897m(bundle2, "create table temp_generic as select i.rowid as rowid, i.generic_id as id, i.name as name from item i where i.rowid in (" + m4868v1 + ")");
                        CompressHelper compressHelper2 = this.f75215L3;
                        Bundle bundle3 = this.f75212I3;
                        this.f74789b4 = this.f75215L3.m4941Z1(compressHelper2.m4955V(bundle3, "select distinct p.document_id, p.level, g1.rowid, g1.name as text1, g1.id, g2.rowid, g2.name as text2, g2.id from temp_generic g1 join temp_generic g2 on g2.id != g1.id join pair p on p.generic1_id = g1.id and p.generic2_id = g2.id join ivsolution iv on p.document_id = iv.document_id left join fieldtypesite f on iv.fieldtype_id = f.fieldtype_id where f.site_id in (" + m4868v12 + ") and iv.solution_id in (" + m4868v13 + ") order by p.level asc, g1.name, g2.name"), FirebaseAnalytics.Param.f55224t);
                    }
                    NotStickySectionAdapter notStickySectionAdapter = new NotStickySectionAdapter(m44716w(), this.f74789b4, "title", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIVInteractResult.LXIvInteractResultFragment.2
                        @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                        /* renamed from: f0 */
                        public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle4, int i) {
                            RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                            String string = bundle4.getString("text1");
                            String string2 = bundle4.getString("text2");
                            rippleTextFullViewHolder.f83284I.setText(string);
                            rippleTextFullViewHolder.f83285J.setText(string2);
                            String string3 = bundle4.getString(FirebaseAnalytics.Param.f55224t);
                            rippleTextFullViewHolder.f83286K.setImageDrawable(LXIvInteractResultFragment.this.m44782a0().getDrawable(string3.equals("5") ? C4804R.C4807drawable.f86622ivc_compatible : string3.equals(ExifInterface.f14411T4) ? C4804R.C4807drawable.f86623ivc_conflict : (string3.equals("6") || string3.equals(IcyHeaders.f35463C2)) ? C4804R.C4807drawable.f86624ivc_incompatible : 0));
                            rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIVInteractResult.LXIvInteractResultFragment.2.1
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view2) {
                                    LXIvInteractResultFragment lXIvInteractResultFragment = LXIvInteractResultFragment.this;
                                    CompressHelper compressHelper3 = lXIvInteractResultFragment.f75215L3;
                                    Bundle bundle5 = lXIvInteractResultFragment.f75212I3;
                                    ArrayList<Bundle> m4955V = compressHelper3.m4955V(bundle5, "select vf.sequence as sequence, vf.label as label, f.content as content, vf.fieldtype_id as typeId from document d join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id left join field f on f.document_id = d.id and vf.fieldtype_id = f.fieldtype_id left join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id left join ivsolution l on d.id = l.document_id and vf.fieldtype_id = l.fieldtype_id where d.id =" + bundle4.getString("document_id") + " and (f.content is not null or l.solution_id is not null) and f.fieldtype_id != 38 and f.fieldtype_id != 42 union select vf.sequence, vf.label, iv.content, vf.fieldtype_id from document d join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id left join ivfield iv on iv.document_id = d.id and vf.fieldtype_id = iv.fieldtype_id left join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id left join ivsolution l on d.id = l.document_id and vf.fieldtype_id = l.fieldtype_id where d.id =" + bundle4.getString("document_id") + " and (iv.content is not null or l.solution_id is not null) and iv.fieldtype_id != 38 and iv.fieldtype_id != 42");
                                    Bundle bundle6 = new Bundle();
                                    bundle6.putParcelableArrayList("ivMonograph", m4955V);
                                    bundle6.putParcelableArrayList("Solutions", LXIvInteractResultFragment.this.f74792e4);
                                    bundle6.putParcelableArrayList("Sites", LXIvInteractResultFragment.this.f74791d4);
                                    bundle6.putInt("Mode", 3);
                                    bundle6.putString(HttpHeaders.f53975g, LXIvInteractResultFragment.this.f74794g4);
                                    bundle6.putString("docId", bundle4.getString("document_id"));
                                    LXIvInteractResultFragment lXIvInteractResultFragment2 = LXIvInteractResultFragment.this;
                                    CompressHelper compressHelper4 = lXIvInteractResultFragment2.f75215L3;
                                    Bundle bundle7 = lXIvInteractResultFragment2.f75212I3;
                                    compressHelper4.m4880r1(bundle7, "Pair - " + bundle4.getString("document_id"), null, null, bundle6);
                                }
                            });
                        }

                        @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                        /* renamed from: i0 */
                        public String mo3387i0(String str) {
                            return str.equals("5") ? "Compatible" : str.equals(ExifInterface.f14411T4) ? "Conflicting Reports" : str.equals("6") ? "Don't Know. Ask Lexi" : str.equals(IcyHeaders.f35463C2) ? "InCompatible" : str;
                        }

                        @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                        /* renamed from: k0 */
                        public RecyclerView.ViewHolder mo3385k0(View view2) {
                            return new RippleTextFullViewHolder(view2);
                        }
                    };
                    this.f74793f4 = notStickySectionAdapter;
                    notStickySectionAdapter.f83255i = "No Information Found";
                    this.f75227X3.setAdapter(notStickySectionAdapter);
                    m4338Q2();
                    m44735q2(false);
                    m4330Y2();
                    return this.f75221R3;
                }
            } else {
                this.f74790c4 = new ArrayList<>();
                this.f74791d4 = new ArrayList<>();
                this.f74792e4 = new ArrayList<>();
            }
            this.f74794g4 = "";
            if (bundle == null) {
            }
            new ArrayList();
            String m4868v14 = CompressHelper.m4868v1(this.f74790c4, "rowid");
            String m4868v122 = CompressHelper.m4868v1(this.f74791d4, "id");
            String m4868v132 = CompressHelper.m4868v1(this.f74792e4, "id");
            this.f75215L3.m4897m(this.f75212I3, "drop table if exists temp_generic;");
            CompressHelper compressHelper3 = this.f75215L3;
            Bundle bundle22 = this.f75212I3;
            compressHelper3.m4897m(bundle22, "create table temp_generic as select i.rowid as rowid, i.generic_id as id, i.name as name from item i where i.rowid in (" + m4868v14 + ")");
            CompressHelper compressHelper22 = this.f75215L3;
            Bundle bundle32 = this.f75212I3;
            this.f74789b4 = this.f75215L3.m4941Z1(compressHelper22.m4955V(bundle32, "select distinct p.document_id, p.level, g1.rowid, g1.name as text1, g1.id, g2.rowid, g2.name as text2, g2.id from temp_generic g1 join temp_generic g2 on g2.id != g1.id join pair p on p.generic1_id = g1.id and p.generic2_id = g2.id join ivsolution iv on p.document_id = iv.document_id left join fieldtypesite f on iv.fieldtype_id = f.fieldtype_id where f.site_id in (" + m4868v122 + ") and iv.solution_id in (" + m4868v132 + ") order by p.level asc, g1.name, g2.name"), FirebaseAnalytics.Param.f55224t);
            NotStickySectionAdapter notStickySectionAdapter2 = new NotStickySectionAdapter(m44716w(), this.f74789b4, "title", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIVInteractResult.LXIvInteractResultFragment.2
                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: f0 */
                public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle4, int i) {
                    RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                    String string = bundle4.getString("text1");
                    String string2 = bundle4.getString("text2");
                    rippleTextFullViewHolder.f83284I.setText(string);
                    rippleTextFullViewHolder.f83285J.setText(string2);
                    String string3 = bundle4.getString(FirebaseAnalytics.Param.f55224t);
                    rippleTextFullViewHolder.f83286K.setImageDrawable(LXIvInteractResultFragment.this.m44782a0().getDrawable(string3.equals("5") ? C4804R.C4807drawable.f86622ivc_compatible : string3.equals(ExifInterface.f14411T4) ? C4804R.C4807drawable.f86623ivc_conflict : (string3.equals("6") || string3.equals(IcyHeaders.f35463C2)) ? C4804R.C4807drawable.f86624ivc_incompatible : 0));
                    rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.LexiInteract.LXIVInteractResult.LXIvInteractResultFragment.2.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            LXIvInteractResultFragment lXIvInteractResultFragment = LXIvInteractResultFragment.this;
                            CompressHelper compressHelper32 = lXIvInteractResultFragment.f75215L3;
                            Bundle bundle5 = lXIvInteractResultFragment.f75212I3;
                            ArrayList<Bundle> m4955V = compressHelper32.m4955V(bundle5, "select vf.sequence as sequence, vf.label as label, f.content as content, vf.fieldtype_id as typeId from document d join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id left join field f on f.document_id = d.id and vf.fieldtype_id = f.fieldtype_id left join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id left join ivsolution l on d.id = l.document_id and vf.fieldtype_id = l.fieldtype_id where d.id =" + bundle4.getString("document_id") + " and (f.content is not null or l.solution_id is not null) and f.fieldtype_id != 38 and f.fieldtype_id != 42 union select vf.sequence, vf.label, iv.content, vf.fieldtype_id from document d join chapter c on c.id = d.chapter_id join view v on v.id = c.view_id join viewfield vf on vf.view_id = v.id left join ivfield iv on iv.document_id = d.id and vf.fieldtype_id = iv.fieldtype_id left join fieldtypesite s on vf.fieldtype_id = s.fieldtype_id left join ivsolution l on d.id = l.document_id and vf.fieldtype_id = l.fieldtype_id where d.id =" + bundle4.getString("document_id") + " and (iv.content is not null or l.solution_id is not null) and iv.fieldtype_id != 38 and iv.fieldtype_id != 42");
                            Bundle bundle6 = new Bundle();
                            bundle6.putParcelableArrayList("ivMonograph", m4955V);
                            bundle6.putParcelableArrayList("Solutions", LXIvInteractResultFragment.this.f74792e4);
                            bundle6.putParcelableArrayList("Sites", LXIvInteractResultFragment.this.f74791d4);
                            bundle6.putInt("Mode", 3);
                            bundle6.putString(HttpHeaders.f53975g, LXIvInteractResultFragment.this.f74794g4);
                            bundle6.putString("docId", bundle4.getString("document_id"));
                            LXIvInteractResultFragment lXIvInteractResultFragment2 = LXIvInteractResultFragment.this;
                            CompressHelper compressHelper4 = lXIvInteractResultFragment2.f75215L3;
                            Bundle bundle7 = lXIvInteractResultFragment2.f75212I3;
                            compressHelper4.m4880r1(bundle7, "Pair - " + bundle4.getString("document_id"), null, null, bundle6);
                        }
                    });
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: i0 */
                public String mo3387i0(String str) {
                    return str.equals("5") ? "Compatible" : str.equals(ExifInterface.f14411T4) ? "Conflicting Reports" : str.equals("6") ? "Don't Know. Ask Lexi" : str.equals(IcyHeaders.f35463C2) ? "InCompatible" : str;
                }

                @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                /* renamed from: k0 */
                public RecyclerView.ViewHolder mo3385k0(View view2) {
                    return new RippleTextFullViewHolder(view2);
                }
            };
            this.f74793f4 = notStickySectionAdapter2;
            notStickySectionAdapter2.f83255i = "No Information Found";
            this.f75227X3.setAdapter(notStickySectionAdapter2);
            m4338Q2();
            m44735q2(false);
            m4330Y2();
            return this.f75221R3;
        }

        /* renamed from: l3 */
        public Bundle m4477l3(int i, ArrayList<Bundle> arrayList) {
            Iterator<Bundle> it2 = arrayList.iterator();
            int i2 = 0;
            while (it2.hasNext()) {
                Bundle next = it2.next();
                if (i == i2) {
                    Bundle bundle = new Bundle();
                    bundle.putString("Title", next.getString("title"));
                    return bundle;
                }
                int size = i2 + next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
                if (i <= size) {
                    Bundle bundle2 = new Bundle();
                    bundle2.putBundle("Item", (Bundle) next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).get((i - (size - next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size())) - 1));
                    return bundle2;
                }
                i2 = size + 1;
            }
            return null;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        /* renamed from: q3 */
        public int m4472q3(ArrayList<Bundle> arrayList) {
            int i = 0;
            if (arrayList == null) {
                return 0;
            }
            Iterator<Bundle> it2 = arrayList.iterator();
            while (it2.hasNext()) {
                i = i + it2.next().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size() + 1;
            }
            return i;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new LXIvInteractResultFragment());
    }
}
