package net.imedicaldoctor.imd.Fragments.UptodateDDX;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;

/* loaded from: classes2.dex */
public class UTDDViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class UTDDViewerFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        private BaseAdapter f75811A4;

        /* renamed from: w4 */
        private ArrayList<Bundle> f75812w4;

        /* renamed from: x4 */
        private ArrayList<Bundle> f75813x4;

        /* renamed from: y4 */
        private ArrayList<Bundle> f75814y4;

        /* renamed from: z4 */
        private ListView f75815z4;

        /* renamed from: B4 */
        public void m4153B4() {
            ((ListView) this.f75849b4.findViewById(C4804R.C4808id.f86950list_view)).setVisibility(0);
            ((TextView) this.f75849b4.findViewById(C4804R.C4808id.f87029status_label)).setVisibility(8);
            ((LinearLayout) this.f75849b4.findViewById(C4804R.C4808id.f87030status_layout)).setVisibility(8);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87394menu_utddviewer, menu);
            m4096h4(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87193fragment_utdd_viewer, viewGroup, false);
            if (bundle != null && bundle.containsKey("Restoring")) {
                this.f75827F3 = true;
                if (bundle.containsKey("Find")) {
                    this.f75828G3 = bundle.getString("Find");
                    this.f75836O3 = bundle.getInt("FindIndex");
                }
                if (bundle.containsKey("mFinalHTML")) {
                    this.f75847Z3 = bundle.getString("mFinalHTML");
                }
                if (bundle.containsKey("mTitle")) {
                    this.f75852e4 = bundle.getString("mTitle");
                }
                this.f75812w4 = bundle.getParcelableArrayList("mDiagnoses");
                this.f75813x4 = bundle.getParcelableArrayList("mDiagnosesIn");
                this.f75814y4 = bundle.getParcelableArrayList("mDescriptions");
            }
            this.f75849b4 = inflate;
            this.f75858k4 = (Toolbar) inflate.findViewById(C4804R.C4808id.f87063toolbar);
            this.f75850c4 = m44859B().getBundle("DB");
            this.f75851d4 = m44859B().getString("URL");
            this.f75863p4 = new CompressHelper(m44716w());
            TabHost tabHost = (TabHost) inflate.findViewById(C4804R.C4808id.f86896findtabhost);
            this.f75844W3 = tabHost;
            if (tabHost != null) {
                tabHost.setup();
            }
            this.f75815z4 = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
            if (m44859B() == null) {
                return inflate;
            }
            try {
                if (this.f75812w4 == null) {
                    CompressHelper compressHelper = this.f75863p4;
                    Bundle bundle2 = this.f75850c4;
                    Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(bundle2, "select * from diagnoses where id=" + this.f75851d4));
                    CompressHelper compressHelper2 = this.f75863p4;
                    Bundle bundle3 = this.f75850c4;
                    ArrayList<Bundle> m4955V = compressHelper2.m4955V(bundle3, "select * from ddx where id1=" + this.f75851d4);
                    this.f75812w4 = m4955V;
                    if (m4955V == null) {
                        this.f75812w4 = new ArrayList<>();
                    }
                    CompressHelper compressHelper3 = this.f75863p4;
                    Bundle bundle4 = this.f75850c4;
                    ArrayList<Bundle> m4955V2 = compressHelper3.m4955V(bundle4, "select * from ddx where id2=" + this.f75851d4);
                    this.f75813x4 = m4955V2;
                    if (m4955V2 == null) {
                        this.f75813x4 = new ArrayList<>();
                    }
                    this.f75814y4 = new ArrayList<>();
                    this.f75852e4 = m4858z.getString("diagnosisName");
                    this.f75847Z3 = "";
                }
                BaseAdapter baseAdapter = new BaseAdapter() { // from class: net.imedicaldoctor.imd.Fragments.UptodateDDX.UTDDViewerActivity.UTDDViewerFragment.1
                    /* renamed from: a */
                    public Bundle m4149a(int i) {
                        int i2;
                        String str;
                        Bundle bundle5 = new Bundle();
                        if (UTDDViewerFragment.this.f75812w4.size() == 0) {
                            i++;
                        }
                        int i3 = 0;
                        if (i == 0) {
                            bundle5.putString("Type", "Header");
                            str = "DIFFERENTIAL DIAGNOSES:";
                        } else if (i != UTDDViewerFragment.this.f75812w4.size() + UTDDViewerFragment.this.f75814y4.size() + 1) {
                            if (i > UTDDViewerFragment.this.f75812w4.size() + UTDDViewerFragment.this.f75814y4.size() + 1) {
                                bundle5.putString("Type", "InItem");
                                bundle5.putBundle("Item", (Bundle) UTDDViewerFragment.this.f75813x4.get(i - ((UTDDViewerFragment.this.f75812w4.size() + UTDDViewerFragment.this.f75814y4.size()) + 2)));
                                bundle5.putInt("TypeInteger", 1);
                            } else {
                                Iterator it2 = UTDDViewerFragment.this.f75812w4.iterator();
                                while (true) {
                                    if (!it2.hasNext()) {
                                        break;
                                    }
                                    Bundle bundle6 = (Bundle) it2.next();
                                    i3++;
                                    if (i != i3) {
                                        if (UTDDViewerFragment.this.f75814y4.contains(bundle6) && i == (i3 = i3 + 1)) {
                                            bundle5.putString("Type", "DItemDesc");
                                            bundle5.putBundle("Item", bundle6);
                                            i2 = 4;
                                            break;
                                        }
                                    } else if (UTDDViewerFragment.this.f75814y4.contains(bundle6)) {
                                        bundle5.putString("Type", "DItemUp");
                                        bundle5.putBundle("Item", bundle6);
                                        bundle5.putInt("TypeInteger", 2);
                                    } else {
                                        bundle5.putString("Type", "DItemDown");
                                        bundle5.putBundle("Item", bundle6);
                                        i2 = 3;
                                    }
                                }
                                bundle5.putInt("TypeInteger", i2);
                            }
                            return bundle5;
                        } else {
                            bundle5.putString("Type", "Header");
                            str = "IN DIFFERENTIAL DIAGNOSIS OF :";
                        }
                        bundle5.putString("Text", str);
                        bundle5.putInt("TypeInteger", 0);
                        return bundle5;
                    }

                    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
                    public boolean areAllItemsEnabled() {
                        return false;
                    }

                    @Override // android.widget.Adapter
                    public int getCount() {
                        int size = (UTDDViewerFragment.this.f75812w4.size() > 0 ? 1 : 0) + UTDDViewerFragment.this.f75812w4.size() + UTDDViewerFragment.this.f75814y4.size();
                        return UTDDViewerFragment.this.f75813x4.size() > 0 ? size + 1 + UTDDViewerFragment.this.f75813x4.size() : size;
                    }

                    @Override // android.widget.Adapter
                    public Object getItem(int i) {
                        return m4149a(i);
                    }

                    @Override // android.widget.Adapter
                    public long getItemId(int i) {
                        return 0L;
                    }

                    @Override // android.widget.BaseAdapter, android.widget.Adapter
                    public int getItemViewType(int i) {
                        return m4149a(i).getInt("TypeInteger");
                    }

                    @Override // android.widget.Adapter
                    public View getView(int i, View view, ViewGroup viewGroup2) {
                        TextView textView;
                        CharSequence fromHtml;
                        ImageView imageView;
                        View.OnClickListener onClickListener;
                        String str;
                        Bundle bundle5 = (Bundle) getItem(i);
                        String string = bundle5.getString("Type");
                        if (string.equals("Header")) {
                            if (view == null) {
                                view = LayoutInflater.from(UTDDViewerFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup2, false);
                                view.setTag(view.findViewById(C4804R.C4808id.f86913header_text));
                            }
                            textView = (TextView) view.getTag();
                            str = "Text";
                        } else if (!string.equals("InItem")) {
                            if (string.equals("DItemUp")) {
                                if (view == null) {
                                    view = LayoutInflater.from(UTDDViewerFragment.this.m44716w()).inflate(C4804R.C4810layout.f87287list_view_item_simple_text_arrow_up, viewGroup2, false);
                                    TextView textView2 = (TextView) view.findViewById(C4804R.C4808id.text);
                                    textView2.setTextColor(-16776961);
                                    view.setTag(textView2);
                                }
                                final Bundle bundle6 = bundle5.getBundle("Item");
                                ((TextView) view.getTag()).setText(bundle6.getString("id2diagnosis"));
                                imageView = (ImageView) view.findViewById(C4804R.C4808id.f86968next_icon);
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UptodateDDX.UTDDViewerActivity.UTDDViewerFragment.1.1
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view2) {
                                        UTDDViewerFragment.this.f75814y4.remove(bundle6);
                                        UTDDViewerFragment.this.f75811A4.notifyDataSetChanged();
                                    }
                                };
                            } else if (!string.equals("DItemDown")) {
                                if (string.equals("DItemDesc")) {
                                    if (view == null) {
                                        view = LayoutInflater.from(UTDDViewerFragment.this.m44716w()).inflate(C4804R.C4810layout.f87284list_view_item_simple_text, viewGroup2, false);
                                        view.setTag(view.findViewById(C4804R.C4808id.text));
                                    }
                                    Bundle bundle7 = bundle5.getBundle("Item");
                                    textView = (TextView) view.getTag();
                                    fromHtml = Html.fromHtml("<font color=\"red\"><b>Signs & Symptoms: </b></font></div>" + bundle7.getString("signs").replace("&deg;", "°") + "<font color=\"red\"><b><br/><br/>Tests: </b></div></font>" + bundle7.getString("tests").replace("&deg;", "°"));
                                    textView.setText(fromHtml);
                                }
                                return view;
                            } else {
                                if (view == null) {
                                    view = LayoutInflater.from(UTDDViewerFragment.this.m44716w()).inflate(C4804R.C4810layout.f87286list_view_item_simple_text_arrow_down, viewGroup2, false);
                                    TextView textView3 = (TextView) view.findViewById(C4804R.C4808id.text);
                                    textView3.setTextColor(-16776961);
                                    view.setTag(textView3);
                                }
                                final Bundle bundle8 = bundle5.getBundle("Item");
                                ((TextView) view.getTag()).setText(bundle8.getString("id2diagnosis"));
                                imageView = (ImageView) view.findViewById(C4804R.C4808id.f86968next_icon);
                                onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UptodateDDX.UTDDViewerActivity.UTDDViewerFragment.1.2
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view2) {
                                        UTDDViewerFragment.this.f75814y4.add(bundle8);
                                        UTDDViewerFragment.this.f75811A4.notifyDataSetChanged();
                                    }
                                };
                            }
                            imageView.setOnClickListener(onClickListener);
                            return view;
                        } else {
                            if (view == null) {
                                view = LayoutInflater.from(UTDDViewerFragment.this.m44716w()).inflate(C4804R.C4810layout.f87285list_view_item_simple_text_arrow, viewGroup2, false);
                                view.setTag(view.findViewById(C4804R.C4808id.text));
                            }
                            bundle5 = bundle5.getBundle("Item");
                            textView = (TextView) view.getTag();
                            str = "id1diagnosis";
                        }
                        fromHtml = bundle5.getString(str);
                        textView.setText(fromHtml);
                        return view;
                    }

                    @Override // android.widget.BaseAdapter, android.widget.Adapter
                    public int getViewTypeCount() {
                        return 5;
                    }

                    @Override // android.widget.BaseAdapter, android.widget.Adapter
                    public boolean hasStableIds() {
                        return false;
                    }

                    @Override // android.widget.BaseAdapter, android.widget.Adapter
                    public boolean isEmpty() {
                        return false;
                    }

                    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
                    public boolean isEnabled(int i) {
                        return getItemViewType(i) == 1;
                    }
                };
                this.f75811A4 = baseAdapter;
                this.f75815z4.setAdapter((ListAdapter) baseAdapter);
                if (!this.f75863p4.m4892n1()) {
                    m4102d4(this.f75852e4);
                }
                this.f75815z4.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UptodateDDX.UTDDViewerActivity.UTDDViewerFragment.2
                    @Override // android.widget.AdapterView.OnItemClickListener
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                        Bundle bundle5 = (Bundle) adapterView.getItemAtPosition(i);
                        if (bundle5.getString("Type").equals("InItem")) {
                            UTDDViewerFragment uTDDViewerFragment = UTDDViewerFragment.this;
                            uTDDViewerFragment.f75863p4.m4883q1(uTDDViewerFragment.f75850c4, bundle5.getBundle("Item").getString("id1"), null, null);
                        }
                    }
                });
                m44716w().setTitle(this.f75852e4);
                m44735q2(false);
                this.f75858k4.setNavigationIcon(C4804R.C4807drawable.f86484back_icon_small);
                this.f75858k4.setNavigationOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UptodateDDX.UTDDViewerActivity.UTDDViewerFragment.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (!UTDDViewerFragment.this.m44859B().containsKey("Dialog")) {
                            UTDDViewerFragment.this.f75863p4.m4998G1(false);
                            return;
                        }
                        try {
                            UTDDViewerFragment.this.m44855C().m44464r().m44309I(C4804R.anim.f85978to_fade_in, C4804R.anim.f85979to_fade_out).mo44279x(UTDDViewerFragment.this).mo44289n();
                        } catch (Exception e) {
                            FirebaseCrashlytics.m18030d().m18027g(e);
                            e.printStackTrace();
                        }
                    }
                });
                this.f75858k4.setTitle(this.f75852e4);
                this.f75858k4.m51503x(C4804R.C4811menu.f87394menu_utddviewer);
                m4096h4(this.f75858k4.getMenu());
                this.f75858k4.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.UptodateDDX.UTDDViewerActivity.UTDDViewerFragment.4
                    @Override // androidx.appcompat.widget.Toolbar.OnMenuItemClickListener
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        UTDDViewerFragment.this.mo3709e1(menuItem);
                        return true;
                    }
                });
                m4099g3();
                m4140G3();
                return inflate;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                m4080r4(e);
                return inflate;
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: l1 */
        public void mo3541l1() {
            super.mo3541l1();
            m4140G3();
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: l4 */
        public void mo4088l4() {
            if (PreferenceManager.getDefaultSharedPreferences(m44716w()).getBoolean("HideStatusBar", false)) {
                float dimension = m44782a0().getDimension(C4804R.dimen.f86462toolbar_padding);
                Toolbar toolbar = this.f75858k4;
                if (toolbar != null) {
                    toolbar.setPadding(0, (int) dimension, 0, 0);
                }
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new UTDDViewerFragment(), bundle);
    }
}
