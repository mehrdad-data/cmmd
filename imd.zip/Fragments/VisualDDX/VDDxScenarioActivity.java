package net.imedicaldoctor.imd.Fragments.VisualDDX;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextArrowViewHolder;
import net.imedicaldoctor.imd.iMDActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.p024io.FileUtils;
import org.json.JSONArray;

/* loaded from: classes2.dex */
public class VDDxScenarioActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class VDDxScenarioFragment extends SearchHelperFragment {

        /* renamed from: b4 */
        private ListAdapter f76044b4;

        /* renamed from: c4 */
        private int f76045c4;

        /* loaded from: classes2.dex */
        public class DatabaseHeaderViewHolder {

            /* renamed from: a */
            public final TextView f76054a;

            public DatabaseHeaderViewHolder(View view) {
                this.f76054a = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            mo4335T2();
            this.f75223T3.setVisibility(8);
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            String m4945Y0 = CompressHelper.m4945Y0(this.f75212I3, "focusAreaList.json");
            final CompressHelper compressHelper = new CompressHelper(m44716w());
            try {
                ArrayList<Bundle> m5003F = compressHelper.m5003F(new JSONArray(FileUtils.readFileToString(new File(m4945Y0), "UTF-8")));
                AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
                final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
                if (m44859B() == null || !m44859B().containsKey("Parent")) {
                    appBarLayout.m27445s(true, false);
                    relativeLayout.setVisibility(0);
                    this.f76045c4 = 0;
                } else {
                    this.f76045c4 = m44859B().getInt("Parent");
                    appBarLayout.m27445s(false, false);
                    appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxScenarioActivity.VDDxScenarioFragment.1
                        @Override // java.lang.Runnable
                        public void run() {
                            relativeLayout.setVisibility(0);
                        }
                    }, 800L);
                }
                this.f76045c4--;
                ArrayList arrayList = new ArrayList();
                int i = this.f76045c4;
                if (i == -1) {
                    Bundle bundle2 = new Bundle();
                    bundle2.putString("title", "Select A Clinical Scenario");
                    bundle2.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, m5003F);
                    arrayList.add(bundle2);
                } else {
                    int size = m5003F.get(i).getParcelableArrayList("children").size();
                    for (int i2 = 0; i2 < size; i2++) {
                        Bundle bundle3 = new Bundle();
                        Bundle bundle4 = (Bundle) m5003F.get(this.f76045c4).getParcelableArrayList("children").get(i2);
                        bundle3.putString("title", bundle4.getString("name"));
                        bundle3.putParcelableArrayList(FirebaseAnalytics.Param.f55203f0, bundle4.getParcelableArrayList("children"));
                        arrayList.add(bundle3);
                    }
                }
                this.f75216M3 = new NotStickySectionAdapter(m44716w(), arrayList, "title", C4804R.C4810layout.f87262list_view_item_ripple_text_arrow) { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxScenarioActivity.VDDxScenarioFragment.2
                    @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                    /* renamed from: f0 */
                    public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle5, int i3) {
                        MaterialRippleLayout materialRippleLayout;
                        View.OnClickListener onClickListener;
                        RippleTextArrowViewHolder rippleTextArrowViewHolder = (RippleTextArrowViewHolder) viewHolder;
                        rippleTextArrowViewHolder.f83267I.setText(bundle5.getString("name"));
                        if (bundle5.getString("moduleId").equals("-1")) {
                            rippleTextArrowViewHolder.f83269K.setVisibility(0);
                            materialRippleLayout = rippleTextArrowViewHolder.f83268J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxScenarioActivity.VDDxScenarioFragment.2.1
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    Bundle bundle6 = new Bundle();
                                    bundle6.putInt("Parent", bundle5.getInt("Index") + 1);
                                    bundle6.putBundle("DB", VDDxScenarioFragment.this.f75212I3);
                                    compressHelper.m4979N(VDDxScenarioActivity.class, VDDxScenarioFragment.class, bundle6);
                                }
                            };
                        } else {
                            rippleTextArrowViewHolder.f83269K.setVisibility(8);
                            materialRippleLayout = rippleTextArrowViewHolder.f83268J;
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxScenarioActivity.VDDxScenarioFragment.2.2
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    Bundle bundle6 = new Bundle();
                                    bundle6.putBundle("moduleInfo", bundle5);
                                    C44142 c44142 = C44142.this;
                                    compressHelper.m4880r1(VDDxScenarioFragment.this.f75212I3, bundle5.getString("moduleId"), null, null, bundle6);
                                }
                            };
                        }
                        materialRippleLayout.setOnClickListener(onClickListener);
                    }

                    @Override // net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter
                    /* renamed from: k0 */
                    public RecyclerView.ViewHolder mo3385k0(View view) {
                        return new RippleTextArrowViewHolder(view);
                    }
                };
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                iMDLogger.m3294f("JSON error", "Error in Parsing " + m4945Y0);
            }
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(false);
            return inflate;
        }

        /* renamed from: l3 */
        public Bundle m4020l3(int i, ArrayList<Bundle> arrayList) {
            Iterator<Bundle> it2 = arrayList.iterator();
            int i2 = 0;
            while (it2.hasNext()) {
                Bundle next = it2.next();
                if (i == i2) {
                    Bundle bundle = new Bundle();
                    bundle.putString("Title", next.getString("title"));
                    return bundle;
                }
                int size = i2 + next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
                if (i <= size) {
                    int size2 = (i - (size - next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size())) - 1;
                    Bundle bundle2 = new Bundle();
                    bundle2.putBundle("Item", (Bundle) next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).get(size2));
                    bundle2.putInt("Index", size2);
                    return bundle2;
                }
                i2 = size + 1;
            }
            return null;
        }

        /* renamed from: m3 */
        public int m4019m3(ArrayList<Bundle> arrayList) {
            int i = 0;
            if (arrayList == null) {
                return 0;
            }
            Iterator<Bundle> it2 = arrayList.iterator();
            while (it2.hasNext()) {
                i = i + it2.next().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size() + 1;
            }
            return i;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new VDDxScenarioFragment());
    }
}
