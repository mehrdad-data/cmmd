package net.imedicaldoctor.imd.Fragments.VisualDDX;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class VDDxResultActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class PlaceholderFragment extends Fragment {
        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            return layoutInflater.inflate(C4804R.C4810layout.f87204fragment_vddx_result, viewGroup, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87118activity_vddx_result);
        if (bundle == null) {
            m44690E().m44464r().m44301b(C4804R.C4808id.container, new PlaceholderFragment()).mo44289n();
        }
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        menuItem.getItemId();
        return super.onOptionsItemSelected(menuItem);
    }
}
