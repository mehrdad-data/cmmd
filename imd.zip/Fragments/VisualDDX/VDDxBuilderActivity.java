package net.imedicaldoctor.imd.Fragments.VisualDDX;

import android.content.Context;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDialogListInterface;
import net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxFindingsDialog;
import net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDxKeyQuestionsDialog;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class VDDxBuilderActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class VDDXBuilderFragment extends ViewerHelperFragment implements VDDialogListInterface {

        /* renamed from: A4 */
        private Bundle f75995A4;

        /* renamed from: B4 */
        private ArrayList<String> f75996B4;

        /* renamed from: C4 */
        private ArrayList<Bundle> f75997C4;

        /* renamed from: D4 */
        private ArrayList<Bundle> f75998D4;

        /* renamed from: E4 */
        private ArrayList<String> f75999E4;

        /* renamed from: F4 */
        private ArrayList<String> f76000F4;

        /* renamed from: G4 */
        private ArrayList<String> f76001G4;

        /* renamed from: H4 */
        private int f76002H4;

        /* renamed from: I4 */
        private ListView f76003I4;

        /* renamed from: w4 */
        private boolean f76004w4;

        /* renamed from: x4 */
        private Bundle f76005x4;

        /* renamed from: y4 */
        private int f76006y4;

        /* renamed from: z4 */
        private ArrayList<Bundle> f76007z4;

        /* renamed from: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity$VDDXBuilderFragment$1 */
        /* loaded from: classes2.dex */
        class C43931 extends BaseAdapter {
            C43931() {
            }

            @Override // android.widget.BaseAdapter, android.widget.ListAdapter
            public boolean areAllItemsEnabled() {
                return false;
            }

            @Override // android.widget.Adapter
            public int getCount() {
                VDDXBuilderFragment vDDXBuilderFragment = VDDXBuilderFragment.this;
                return vDDXBuilderFragment.m4024Q4(vDDXBuilderFragment.f75996B4);
            }

            @Override // android.widget.Adapter
            public Object getItem(int i) {
                VDDXBuilderFragment vDDXBuilderFragment = VDDXBuilderFragment.this;
                return vDDXBuilderFragment.m4023x4(i, vDDXBuilderFragment.f75996B4);
            }

            @Override // android.widget.Adapter
            public long getItemId(int i) {
                return 0L;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getItemViewType(int i) {
                Bundle bundle = (Bundle) getItem(i);
                String string = bundle.getString("Type");
                if (!string.equals("Header") && string.equals("Item")) {
                    String string2 = bundle.getString("Section");
                    int i2 = bundle.getInt("Index");
                    if (string2.equals("Visual Findings")) {
                        if (i2 == 0) {
                            return 1;
                        }
                        if (i2 == 1) {
                            return 2;
                        }
                    } else if (string2.equals("Body Location Findings")) {
                        return i2 == 0 ? 3 : 4;
                    } else if (string2.equals("Distribution Findings")) {
                        return 5;
                    } else {
                        if (string2.equals("Key Questions")) {
                            return i2 == 0 ? 3 : 4;
                        } else if (string2.equals("Add Other Findings")) {
                            return i2 == 0 ? 3 : 4;
                        }
                    }
                }
                return 0;
            }

            @Override // android.widget.Adapter
            public View getView(int i, View view, ViewGroup viewGroup) {
                TextView textView;
                View.OnClickListener onClickListener;
                TextView textView2;
                String str;
                ArrayList arrayList;
                int size;
                RecyclerView.Adapter adapter;
                Bundle bundle = (Bundle) getItem(i);
                if (bundle.getString("Type").equals("Header")) {
                    if (view == null) {
                        view = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87230list_view_item_database_header, viewGroup, false);
                        view.setTag(view.findViewById(C4804R.C4808id.f86913header_text));
                    }
                    ((TextView) view.getTag()).setText(bundle.getString("Text"));
                    return view;
                } else if (bundle.getString("Type").equals("Item")) {
                    String string = bundle.getString("Section");
                    final int i2 = bundle.getInt("Index");
                    if (string.equals("Visual Findings")) {
                        if (view != null) {
                            ((RecyclerView) view.getTag()).getAdapter().m42860G();
                            return view;
                        }
                        View inflate = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87254list_view_item_recycleview, viewGroup, false);
                        inflate.setTag(inflate.findViewById(C4804R.C4808id.f87001recycler_view));
                        final RecyclerView recyclerView = (RecyclerView) inflate.getTag();
                        recyclerView.setLayoutManager(new LinearLayoutManager(VDDXBuilderFragment.this.m44716w(), 0, false));
                        recyclerView.setItemAnimator(new DefaultItemAnimator());
                        recyclerView.setOnTouchListener(new View.OnTouchListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.1
                            @Override // android.view.View.OnTouchListener
                            public boolean onTouch(View view2, MotionEvent motionEvent) {
                                VDDXBuilderFragment.this.f76003I4.requestDisallowInterceptTouchEvent(true);
                                if (motionEvent.getActionMasked() == 1) {
                                    VDDXBuilderFragment.this.f76003I4.requestDisallowInterceptTouchEvent(false);
                                }
                                return false;
                            }
                        });
                        if (i2 == 0) {
                            adapter = new RecyclerView.Adapter() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.2
                                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                                /* renamed from: R */
                                public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i3) {
                                    PhotoCaptionPlaceHolder photoCaptionPlaceHolder = (PhotoCaptionPlaceHolder) viewHolder;
                                    final Bundle bundle2 = (Bundle) VDDXBuilderFragment.this.f76005x4.getParcelableArrayList("visualFindingIconImageList").get(i3);
                                    String m4945Y0 = CompressHelper.m4945Y0(VDDXBuilderFragment.this.f75850c4, bundle2.getString("imageName"));
                                    String m4945Y02 = CompressHelper.m4945Y0(VDDXBuilderFragment.this.f75850c4, bundle2.getString("mouseoverImageName"));
                                    photoCaptionPlaceHolder.f76041I.setText(VDDXBuilderFragment.this.f75995A4.getString(bundle2.getString("findingId")));
                                    if (VDDXBuilderFragment.this.f76001G4.contains(bundle2.getString("findingId"))) {
                                        photoCaptionPlaceHolder.f76043K.setVisibility(0);
                                    } else {
                                        photoCaptionPlaceHolder.f76043K.setVisibility(8);
                                    }
                                    AnimationDrawable animationDrawable = new AnimationDrawable();
                                    animationDrawable.addFrame(new BitmapDrawable(BitmapFactory.decodeFile(m4945Y0)), 1000);
                                    animationDrawable.addFrame(new BitmapDrawable(BitmapFactory.decodeFile(m4945Y02)), 1000);
                                    animationDrawable.setOneShot(false);
                                    photoCaptionPlaceHolder.f76042J.setImageDrawable(animationDrawable);
                                    photoCaptionPlaceHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.2.1
                                        @Override // android.view.View.OnClickListener
                                        public void onClick(View view2) {
                                            int i4 = i3;
                                            if (i4 != VDDXBuilderFragment.this.f76002H4) {
                                                VDDXBuilderFragment.this.f76002H4 = i4;
                                                if (bundle2.getParcelableArrayList("childIcons").size() > 0) {
                                                    VDDXBuilderFragment.this.f76006y4 = 2;
                                                    ((BaseAdapter) VDDXBuilderFragment.this.f76003I4.getAdapter()).notifyDataSetChanged();
                                                    return;
                                                }
                                                VDDXBuilderFragment.this.f76006y4 = 1;
                                                ((BaseAdapter) VDDXBuilderFragment.this.f76003I4.getAdapter()).notifyDataSetChanged();
                                            }
                                            String string2 = bundle2.getString("findingId");
                                            if (VDDXBuilderFragment.this.f76001G4.contains(string2)) {
                                                VDDXBuilderFragment.this.f76001G4.remove(string2);
                                            } else {
                                                VDDXBuilderFragment.this.f76001G4.add(string2);
                                            }
                                            recyclerView.getAdapter().m42859H(i3);
                                        }
                                    });
                                }

                                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                                /* renamed from: T */
                                public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup2, int i3) {
                                    return new PhotoCaptionPlaceHolder(LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87209grid_view_item_image_caption_checkmark, viewGroup2, false));
                                }

                                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                                /* renamed from: s */
                                public int mo3359s() {
                                    return VDDXBuilderFragment.this.f76005x4.getParcelableArrayList("visualFindingIconImageList").size();
                                }
                            };
                        } else if (i2 != 1) {
                            return inflate;
                        } else {
                            adapter = new RecyclerView.Adapter() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.3
                                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                                /* renamed from: R */
                                public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i3) {
                                    PhotoCaptionPlaceHolder photoCaptionPlaceHolder = (PhotoCaptionPlaceHolder) viewHolder;
                                    final Bundle bundle2 = (Bundle) ((Bundle) VDDXBuilderFragment.this.f76005x4.getParcelableArrayList("visualFindingIconImageList").get(VDDXBuilderFragment.this.f76002H4)).getParcelableArrayList("childIcons").get(i3);
                                    String m4945Y0 = CompressHelper.m4945Y0(VDDXBuilderFragment.this.f75850c4, bundle2.getString("imageName"));
                                    String m4945Y02 = CompressHelper.m4945Y0(VDDXBuilderFragment.this.f75850c4, bundle2.getString("mouseoverImageName"));
                                    photoCaptionPlaceHolder.f76041I.setText(VDDXBuilderFragment.this.f75995A4.getString(bundle2.getString("findingId")));
                                    if (VDDXBuilderFragment.this.f76001G4.contains(bundle2.getString("findingId"))) {
                                        photoCaptionPlaceHolder.f76043K.setVisibility(0);
                                    } else {
                                        photoCaptionPlaceHolder.f76043K.setVisibility(8);
                                    }
                                    AnimationDrawable animationDrawable = new AnimationDrawable();
                                    animationDrawable.addFrame(new BitmapDrawable(BitmapFactory.decodeFile(m4945Y0)), 1000);
                                    animationDrawable.addFrame(new BitmapDrawable(BitmapFactory.decodeFile(m4945Y02)), 1000);
                                    animationDrawable.setOneShot(false);
                                    photoCaptionPlaceHolder.f76042J.setImageDrawable(animationDrawable);
                                    photoCaptionPlaceHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.3.1
                                        @Override // android.view.View.OnClickListener
                                        public void onClick(View view2) {
                                            String string2 = bundle2.getString("findingId");
                                            if (VDDXBuilderFragment.this.f76001G4.contains(string2)) {
                                                VDDXBuilderFragment.this.f76001G4.remove(string2);
                                            } else {
                                                VDDXBuilderFragment.this.f76001G4.add(string2);
                                            }
                                            recyclerView.getAdapter().m42859H(i3);
                                        }
                                    });
                                }

                                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                                /* renamed from: T */
                                public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup2, int i3) {
                                    return new PhotoCaptionPlaceHolder(LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87209grid_view_item_image_caption_checkmark, viewGroup2, false));
                                }

                                @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                                /* renamed from: s */
                                public int mo3359s() {
                                    return ((Bundle) VDDXBuilderFragment.this.f76005x4.getParcelableArrayList("visualFindingIconImageList").get(VDDXBuilderFragment.this.f76002H4)).getParcelableArrayList("childIcons").size();
                                }
                            };
                        }
                        recyclerView.setAdapter(adapter);
                        return inflate;
                    } else if (string.equals("Body Location Findings")) {
                        if (i2 == 0) {
                            if (view == null) {
                                View inflate2 = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87219list_view_item_add, viewGroup, false);
                                inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                                view = inflate2;
                            }
                            textView2 = (TextView) view.getTag();
                            str = "Add Body Location";
                            textView2.setText(str);
                            return view;
                        }
                        if (i2 <= VDDXBuilderFragment.this.f75997C4.size()) {
                            arrayList = VDDXBuilderFragment.this.f75997C4;
                            size = i2 - 1;
                        } else {
                            arrayList = VDDXBuilderFragment.this.f75998D4;
                            size = (i2 - VDDXBuilderFragment.this.f75997C4.size()) - 1;
                        }
                        Bundle bundle2 = (Bundle) arrayList.get(size);
                        String string2 = bundle2.getString("title");
                        if (string2.length() == 0) {
                            string2 = VDDXBuilderFragment.this.f75995A4.getString(bundle2.getStringArrayList("findingIds").get(0));
                        }
                        if (view == null) {
                            view = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87233list_view_item_delete, viewGroup, false);
                            view.setTag(view.findViewById(C4804R.C4808id.text));
                        }
                        textView = (TextView) view.findViewById(C4804R.C4808id.f86861delete_button);
                        ((TextView) view.getTag()).setText(string2);
                        onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.4
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view2) {
                                ArrayList arrayList2;
                                int size2;
                                if (i2 <= VDDXBuilderFragment.this.f75997C4.size()) {
                                    arrayList2 = VDDXBuilderFragment.this.f75997C4;
                                    size2 = i2;
                                } else {
                                    arrayList2 = VDDXBuilderFragment.this.f75998D4;
                                    size2 = i2 - VDDXBuilderFragment.this.f75997C4.size();
                                }
                                arrayList2.remove(size2 - 1);
                                ((BaseAdapter) VDDXBuilderFragment.this.f76003I4.getAdapter()).notifyDataSetChanged();
                            }
                        };
                        textView.setOnClickListener(onClickListener);
                        return view;
                    } else if (string.equals("Distribution Findings")) {
                        if (view != null) {
                            ((RecyclerView) view.getTag()).getAdapter().m42860G();
                            return view;
                        }
                        View inflate3 = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87254list_view_item_recycleview, viewGroup, false);
                        inflate3.setTag(inflate3.findViewById(C4804R.C4808id.f87001recycler_view));
                        final RecyclerView recyclerView2 = (RecyclerView) inflate3.getTag();
                        recyclerView2.setLayoutManager(new LinearLayoutManager(VDDXBuilderFragment.this.m44716w(), 0, false));
                        recyclerView2.setItemAnimator(new DefaultItemAnimator());
                        recyclerView2.setOnTouchListener(new View.OnTouchListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.5
                            @Override // android.view.View.OnTouchListener
                            public boolean onTouch(View view2, MotionEvent motionEvent) {
                                VDDXBuilderFragment.this.f76003I4.requestDisallowInterceptTouchEvent(true);
                                if (motionEvent.getActionMasked() == 1) {
                                    VDDXBuilderFragment.this.f76003I4.requestDisallowInterceptTouchEvent(false);
                                }
                                return false;
                            }
                        });
                        recyclerView2.setAdapter(new RecyclerView.Adapter() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.6
                            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                            /* renamed from: R */
                            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i3) {
                                PhotoCaptionPlaceHolder photoCaptionPlaceHolder = (PhotoCaptionPlaceHolder) viewHolder;
                                final Bundle bundle3 = (Bundle) VDDXBuilderFragment.this.f76005x4.getParcelableArrayList("distributionFindingIconImageList").get(i3);
                                String m4945Y0 = CompressHelper.m4945Y0(VDDXBuilderFragment.this.f75850c4, bundle3.getString("imageName"));
                                String m4945Y02 = CompressHelper.m4945Y0(VDDXBuilderFragment.this.f75850c4, bundle3.getString("mouseoverImageName"));
                                photoCaptionPlaceHolder.f76041I.setText(VDDXBuilderFragment.this.f75995A4.getString(bundle3.getString("findingId")));
                                if (VDDXBuilderFragment.this.f76001G4.contains(bundle3.getString("findingId"))) {
                                    photoCaptionPlaceHolder.f76043K.setVisibility(0);
                                } else {
                                    photoCaptionPlaceHolder.f76043K.setVisibility(8);
                                }
                                AnimationDrawable animationDrawable = new AnimationDrawable();
                                animationDrawable.addFrame(new BitmapDrawable(BitmapFactory.decodeFile(m4945Y0)), 1000);
                                animationDrawable.addFrame(new BitmapDrawable(BitmapFactory.decodeFile(m4945Y02)), 1000);
                                animationDrawable.setOneShot(false);
                                photoCaptionPlaceHolder.f76042J.setImageDrawable(animationDrawable);
                                photoCaptionPlaceHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.6.1
                                    @Override // android.view.View.OnClickListener
                                    public void onClick(View view2) {
                                        String string3 = bundle3.getString("findingId");
                                        if (VDDXBuilderFragment.this.f76001G4.contains(string3)) {
                                            VDDXBuilderFragment.this.f76001G4.remove(string3);
                                        } else {
                                            VDDXBuilderFragment.this.f76001G4.add(string3);
                                        }
                                        recyclerView2.getAdapter().m42859H(i3);
                                    }
                                });
                            }

                            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                            /* renamed from: T */
                            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup2, int i3) {
                                return new PhotoCaptionPlaceHolder(LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87209grid_view_item_image_caption_checkmark, viewGroup2, false));
                            }

                            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
                            /* renamed from: s */
                            public int mo3359s() {
                                return VDDXBuilderFragment.this.f76005x4.getParcelableArrayList("distributionFindingIconImageList").size();
                            }
                        });
                        return inflate3;
                    } else {
                        if (string.equals("Key Questions")) {
                            if (i2 == 0) {
                                if (view == null) {
                                    View inflate4 = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87219list_view_item_add, viewGroup, false);
                                    inflate4.setTag(inflate4.findViewById(C4804R.C4808id.text));
                                    view = inflate4;
                                }
                                textView2 = (TextView) view.getTag();
                                str = "Add Key Questions";
                                textView2.setText(str);
                                return view;
                            }
                            final String str2 = (String) VDDXBuilderFragment.this.f75999E4.get(i2 - 1);
                            String string3 = VDDXBuilderFragment.this.f75995A4.getString(str2);
                            if (view == null) {
                                view = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87233list_view_item_delete, viewGroup, false);
                                view.setTag(view.findViewById(C4804R.C4808id.text));
                            }
                            textView = (TextView) view.findViewById(C4804R.C4808id.f86861delete_button);
                            ((TextView) view.getTag()).setText(string3);
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.7
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view2) {
                                    VDDXBuilderFragment.this.f75999E4.remove(str2);
                                    ((BaseAdapter) VDDXBuilderFragment.this.f76003I4.getAdapter()).notifyDataSetChanged();
                                }
                            };
                        } else if (!string.equals("Add Other Findings")) {
                            return view;
                        } else {
                            if (i2 == 0) {
                                if (view == null) {
                                    View inflate5 = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87219list_view_item_add, viewGroup, false);
                                    inflate5.setTag(inflate5.findViewById(C4804R.C4808id.text));
                                    view = inflate5;
                                }
                                ((TextView) view.getTag()).setText("Add Other Findings");
                                return view;
                            }
                            final String str3 = (String) VDDXBuilderFragment.this.f76000F4.get(i2 - 1);
                            String string4 = VDDXBuilderFragment.this.f75995A4.getString(str3);
                            if (view == null) {
                                view = LayoutInflater.from(VDDXBuilderFragment.this.m44716w()).inflate(C4804R.C4810layout.f87233list_view_item_delete, viewGroup, false);
                                view.setTag(view.findViewById(C4804R.C4808id.text));
                            }
                            textView = (TextView) view.findViewById(C4804R.C4808id.f86861delete_button);
                            ((TextView) view.getTag()).setText(string4);
                            onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.1.8
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view2) {
                                    VDDXBuilderFragment.this.f76000F4.remove(str3);
                                    ((BaseAdapter) VDDXBuilderFragment.this.f76003I4.getAdapter()).notifyDataSetChanged();
                                }
                            };
                        }
                        textView.setOnClickListener(onClickListener);
                        return view;
                    }
                } else {
                    return view;
                }
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getViewTypeCount() {
                return 6;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public boolean hasStableIds() {
                return false;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public boolean isEmpty() {
                return false;
            }

            @Override // android.widget.BaseAdapter, android.widget.ListAdapter
            public boolean isEnabled(int i) {
                Bundle bundle = (Bundle) getItem(i);
                return bundle.getString("Type").equals("Item") && bundle.getInt("Index") == 0;
            }
        }

        /* loaded from: classes2.dex */
        public static class PhotoCaptionPlaceHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f76041I;

            /* renamed from: J */
            public ImageView f76042J;

            /* renamed from: K */
            public ImageView f76043K;

            public PhotoCaptionPlaceHolder(View view) {
                super(view);
                this.f76041I = (TextView) view.findViewById(C4804R.C4808id.f86834caption);
                this.f76042J = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
                this.f76043K = (ImageView) view.findViewById(C4804R.C4808id.f86841checkmark);
            }
        }

        /* renamed from: M4 */
        public void m4028M4() {
            if (Build.VERSION.SDK_INT >= 26) {
                this.f75838Q3.setImportantForAutofill(8);
            }
            this.f75838Q3.setIconifiedByDefault(false);
            this.f75838Q3.setQueryHint("Add Findings");
            this.f75838Q3.setOnSuggestionListener(new SearchView.OnSuggestionListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.5
                @Override // androidx.appcompat.widget.SearchView.OnSuggestionListener
                /* renamed from: a */
                public boolean mo3524a(int i) {
                    Cursor mo45341b = VDDXBuilderFragment.this.f75838Q3.getSuggestionsAdapter().mo45341b();
                    if (mo45341b.moveToPosition(i)) {
                        String string = mo45341b.getString(mo45341b.getColumnIndex("id"));
                        if (VDDXBuilderFragment.this.f76007z4.contains(string)) {
                            VDDXBuilderFragment.this.f75838Q3.m51655i0("", true);
                            VDDXBuilderFragment.this.m4140G3();
                            return true;
                        }
                        VDDXBuilderFragment.this.f76000F4.add(string);
                        VDDXBuilderFragment.this.f75838Q3.m51655i0("", true);
                        VDDXBuilderFragment.this.m4140G3();
                        ((BaseAdapter) VDDXBuilderFragment.this.f76003I4.getAdapter()).notifyDataSetChanged();
                        return false;
                    }
                    return false;
                }

                @Override // androidx.appcompat.widget.SearchView.OnSuggestionListener
                /* renamed from: b */
                public boolean mo3523b(int i) {
                    mo3524a(i);
                    return false;
                }
            });
            ((ImageView) this.f75838Q3.findViewById(C4804R.C4808id.search_close_btn)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.6
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    VDDXBuilderFragment.this.f75838Q3.m51655i0("", false);
                    VDDXBuilderFragment.this.f75838Q3.clearFocus();
                    VDDXBuilderFragment.this.m4140G3();
                }
            });
            this.f75838Q3.setSuggestionsAdapter(new CursorAdapter(m44716w(), null, 0) { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.7
                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: d */
                public void mo3522d(View view, Context context, Cursor cursor) {
                    TextView textView = (TextView) view.getTag();
                    if (VDDXBuilderFragment.this.f76000F4.contains(cursor.getString(cursor.getColumnIndex("id")))) {
                        textView.setTextColor(-7829368);
                    }
                    textView.setText(cursor.getString(cursor.getColumnIndex("longName")));
                }

                @Override // androidx.cursoradapter.widget.CursorAdapter
                /* renamed from: i */
                public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                    View inflate = LayoutInflater.from(context).inflate(C4804R.C4810layout.f87294list_view_item_spell_drug, viewGroup, false);
                    inflate.setTag(inflate.findViewById(C4804R.C4808id.text));
                    return inflate;
                }

                @Override // android.widget.BaseAdapter, android.widget.ListAdapter
                public boolean isEnabled(int i) {
                    Cursor cursor = (Cursor) getItem(i);
                    return !VDDXBuilderFragment.this.f76000F4.contains(cursor.getString(cursor.getColumnIndex("id")));
                }
            });
            this.f75838Q3.setOnQueryTextListener(new SearchView.OnQueryTextListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.8
                @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
                /* renamed from: a */
                public boolean mo3520a(final String str) {
                    if (str.length() > 1) {
                        new AsyncTask() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.8.1
                            @Override // android.os.AsyncTask
                            protected Object doInBackground(Object[] objArr) {
                                String str2 = "Select rowid as _id,* from FindingsSearch where longNameSearch match '" + str + "*' order by longName asc";
                                VDDXBuilderFragment vDDXBuilderFragment = VDDXBuilderFragment.this;
                                return vDDXBuilderFragment.f75863p4.m4955V(vDDXBuilderFragment.f75850c4, str2);
                            }

                            @Override // android.os.AsyncTask
                            protected void onPostExecute(Object obj) {
                                VDDXBuilderFragment.this.f75838Q3.getSuggestionsAdapter().mo45336l(VDDXBuilderFragment.this.f75863p4.m4912h((ArrayList) obj));
                            }
                        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[0]);
                        return true;
                    }
                    return false;
                }

                @Override // androidx.appcompat.widget.SearchView.OnQueryTextListener
                /* renamed from: b */
                public boolean mo3519b(String str) {
                    return false;
                }
            });
            this.f75838Q3.clearFocus();
        }

        /* renamed from: N4 */
        public ArrayList<String> m4027N4() {
            ArrayList<String> arrayList = new ArrayList<>();
            arrayList.addAll(this.f76001G4);
            Iterator<Bundle> it2 = this.f75997C4.iterator();
            while (it2.hasNext()) {
                arrayList.addAll(it2.next().getStringArrayList("findingIds"));
            }
            Iterator<Bundle> it3 = this.f75998D4.iterator();
            while (it3.hasNext()) {
                arrayList.addAll(it3.next().getStringArrayList("findingIds"));
            }
            arrayList.addAll(this.f75999E4);
            return arrayList;
        }

        /* renamed from: O4 */
        public int m4026O4(String str) {
            ArrayList<String> arrayList;
            int size;
            if (str.equals("Visual Findings")) {
                return this.f76006y4;
            }
            if (str.equals("Body Location Findings")) {
                size = this.f75997C4.size() + this.f75998D4.size();
            } else if (str.equals("Distribution Findings")) {
                return 1;
            } else {
                if (str.equals("Key Questions")) {
                    arrayList = this.f75999E4;
                } else if (!str.equals("Add Other Findings")) {
                    return 0;
                } else {
                    arrayList = this.f76000F4;
                }
                size = arrayList.size();
            }
            return size + 1;
        }

        /* renamed from: P4 */
        public void m4025P4() {
            ((ListView) this.f75849b4.findViewById(C4804R.C4808id.f86950list_view)).setVisibility(0);
            ((TextView) this.f75849b4.findViewById(C4804R.C4808id.f87029status_label)).setVisibility(8);
            ((LinearLayout) this.f75849b4.findViewById(C4804R.C4808id.f87030status_layout)).setVisibility(8);
        }

        /* renamed from: Q4 */
        public int m4024Q4(ArrayList<String> arrayList) {
            int i = 0;
            if (arrayList == null) {
                return 0;
            }
            Iterator<String> it2 = arrayList.iterator();
            while (it2.hasNext()) {
                i = i + m4026O4(it2.next()) + 1;
            }
            return i;
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75838Q3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4028M4();
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87201fragment_vddx_builder, viewGroup, false);
            if (bundle != null && bundle.containsKey("Restoring")) {
                this.f75827F3 = true;
                if (bundle.containsKey("Find")) {
                    this.f75828G3 = bundle.getString("Find");
                    this.f75836O3 = bundle.getInt("FindIndex");
                }
                if (bundle.containsKey("mFinalHTML")) {
                    this.f75847Z3 = bundle.getString("mFinalHTML");
                }
                if (bundle.containsKey("mTitle")) {
                    this.f75852e4 = bundle.getString("mTitle");
                }
                this.f76007z4 = bundle.getParcelableArrayList("mAllFindings");
                this.f76005x4 = bundle.getBundle("mModule");
                this.f76006y4 = bundle.getInt("mGridViewCount");
                this.f75996B4 = bundle.getStringArrayList("mSections");
                this.f75998D4 = bundle.getParcelableArrayList("mDistributionSelectedItems");
                this.f75997C4 = bundle.getParcelableArrayList("mLocationSelectedItems");
                this.f75999E4 = bundle.getStringArrayList("mKeyQuestionSelectedItems");
                this.f76000F4 = bundle.getStringArrayList("mOtherFindingsSelectedItems");
                this.f76001G4 = bundle.getStringArrayList("mLesionsSelected");
                this.f76002H4 = bundle.getInt("mVisualIndex");
                this.f75995A4 = bundle.getBundle("mAllFindingsDic");
            }
            this.f75849b4 = inflate;
            this.f75850c4 = m44859B().getBundle("DB");
            this.f75851d4 = m44859B().getString("URL");
            TabHost tabHost = (TabHost) inflate.findViewById(C4804R.C4808id.f86896findtabhost);
            this.f75844W3 = tabHost;
            if (tabHost != null) {
                tabHost.setup();
            }
            this.f76003I4 = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
            if (m44859B() == null) {
                return inflate;
            }
            try {
                this.f75863p4 = new CompressHelper(m44716w());
                if (this.f76005x4 == null) {
                    Bundle bundle2 = this.f75850c4;
                    this.f76005x4 = this.f75863p4.m5000G(new JSONObject(FileUtils.readFileToString(new File(CompressHelper.m4942Z0(bundle2, this.f75851d4 + ".JS", "modules")), "UTF-8")));
                    CompressHelper compressHelper = this.f75863p4;
                    Bundle bundle3 = this.f75850c4;
                    this.f76007z4 = compressHelper.m4955V(bundle3, "SELECT id, shortName, longName, children, leaf, ',' || supportedModules || ',' as modules FROM Findings where modules like '%," + this.f75851d4 + ",%'");
                    this.f75995A4 = new Bundle();
                    Iterator<Bundle> it2 = this.f76007z4.iterator();
                    while (it2.hasNext()) {
                        Bundle next = it2.next();
                        this.f75995A4.putString(next.getString("id"), next.getString("shortName"));
                    }
                    this.f76006y4 = 1;
                    ArrayList<String> arrayList = new ArrayList<>();
                    this.f75996B4 = arrayList;
                    arrayList.add("Visual Findings");
                    this.f75996B4.add("Body Location Findings");
                    if (this.f76005x4.getParcelableArrayList("distributionFindingIconImageList").size() > 0) {
                        this.f75996B4.add("Distribution Findings");
                    }
                    if (this.f76005x4.getParcelableArrayList("keyQuestionList").size() > 0) {
                        this.f75996B4.add("Key Questions");
                    }
                    this.f75996B4.add("Add Other Findings");
                    this.f75852e4 = "";
                    this.f75847Z3 = "";
                    this.f76001G4 = new ArrayList<>();
                    this.f75997C4 = new ArrayList<>();
                    this.f75998D4 = new ArrayList<>();
                    this.f75999E4 = new ArrayList<>();
                    this.f76000F4 = new ArrayList<>();
                }
                this.f76003I4.setAdapter((ListAdapter) new C43931());
                this.f76003I4.setDivider(new ColorDrawable(Color.parseColor("#e5e5e5")));
                this.f76003I4.setDividerHeight(1);
                if (!this.f75863p4.m4892n1()) {
                    m4102d4(this.f75852e4);
                }
                this.f76003I4.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.2
                    @Override // android.widget.AdapterView.OnItemClickListener
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                        DialogFragment vDDxFindingsDialog;
                        Bundle bundle4;
                        Bundle bundle5 = (Bundle) adapterView.getItemAtPosition(i);
                        if (bundle5.getString("Type").equals("Item")) {
                            String string = bundle5.getString("Section");
                            int i2 = bundle5.getInt("Index");
                            if (string.equals("Visual Findings")) {
                                return;
                            }
                            if (string.equals("Body Location Findings")) {
                                if (i2 != 0) {
                                    return;
                                }
                                vDDxFindingsDialog = new VDDxBodyPartDialog();
                                bundle4 = new Bundle();
                                bundle4.putBundle("db", VDDXBuilderFragment.this.f75850c4);
                                bundle4.putBundle("allFindings", VDDXBuilderFragment.this.f75995A4);
                                bundle4.putParcelableArrayList("distribution", VDDXBuilderFragment.this.f75998D4);
                                bundle4.putParcelableArrayList(FirebaseAnalytics.Param.f55223s, VDDXBuilderFragment.this.f75997C4);
                                bundle4.putString("bodyFolder", VDDXBuilderFragment.this.m44859B().getBundle("moduleInfo").getString("bodyLocation"));
                            } else if (string.equals("Distribution Findings")) {
                                return;
                            } else {
                                if (string.equals("Key Questions")) {
                                    if (i2 != 0) {
                                        return;
                                    }
                                    vDDxFindingsDialog = new VDDxKeyQuestionsDialog();
                                    bundle4 = new Bundle();
                                    bundle4.putBundle("db", VDDXBuilderFragment.this.f75850c4);
                                    bundle4.putBundle("allFindings", VDDXBuilderFragment.this.f75995A4);
                                    bundle4.putStringArrayList("selectedKeyQuestions", VDDXBuilderFragment.this.f75999E4);
                                    bundle4.putParcelableArrayList("allKeyQuestions", VDDXBuilderFragment.this.f76005x4.getParcelableArrayList("keyQuestionList"));
                                } else if (!string.equals("Add Other Findings") || i2 != 0) {
                                    return;
                                } else {
                                    vDDxFindingsDialog = new VDDxFindingsDialog();
                                    bundle4 = new Bundle();
                                    bundle4.putBundle("db", VDDXBuilderFragment.this.f75850c4);
                                    bundle4.putBundle("allFindings", VDDXBuilderFragment.this.f75995A4);
                                    bundle4.putStringArrayList("selectedFindings", VDDXBuilderFragment.this.f76000F4);
                                    bundle4.putBundle("parent", new Bundle());
                                    bundle4.putString("moduleId", VDDXBuilderFragment.this.f75851d4);
                                    bundle4.putStringArrayList("disabledItems", VDDXBuilderFragment.this.m4027N4());
                                }
                            }
                            vDDxFindingsDialog.m44751k2(bundle4);
                            vDDxFindingsDialog.m44870c3(true);
                            vDDxFindingsDialog.m44844E2(VDDXBuilderFragment.this, 0);
                            vDDxFindingsDialog.mo29915h3(VDDXBuilderFragment.this.m44820L(), "VDDialogFragment");
                        }
                    }
                });
                m44716w().setTitle(this.f75852e4);
                ((Button) this.f75849b4.findViewById(C4804R.C4808id.f86858ddx_button)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CompressHelper compressHelper2;
                        Bundle bundle4;
                        String str;
                        String[] strArr;
                        String str2;
                        ArrayList<String> m4027N4 = VDDXBuilderFragment.this.m4027N4();
                        Bundle bundle5 = new Bundle();
                        bundle5.putString("moduleId", VDDXBuilderFragment.this.f75851d4);
                        if (m4027N4.size() > 0) {
                            VDDXBuilderFragment vDDXBuilderFragment = VDDXBuilderFragment.this;
                            CompressHelper compressHelper3 = vDDXBuilderFragment.f75863p4;
                            Bundle bundle6 = vDDXBuilderFragment.f75850c4;
                            strArr = null;
                            str2 = null;
                            compressHelper2 = compressHelper3;
                            bundle4 = bundle6;
                            str = "ddx-" + StringUtils.join(m4027N4, ",");
                        } else {
                            VDDXBuilderFragment vDDXBuilderFragment2 = VDDXBuilderFragment.this;
                            compressHelper2 = vDDXBuilderFragment2.f75863p4;
                            bundle4 = vDDXBuilderFragment2.f75850c4;
                            str = "ddx-";
                            strArr = null;
                            str2 = null;
                        }
                        compressHelper2.m4880r1(bundle4, str, strArr, str2, bundle5);
                    }
                });
                m44735q2(false);
                Toolbar toolbar = (Toolbar) this.f75849b4.findViewById(C4804R.C4808id.f87063toolbar);
                this.f75858k4 = toolbar;
                toolbar.m51503x(C4804R.C4811menu.f87405search);
                this.f75858k4.setNavigationIcon(C4804R.C4807drawable.f86484back_icon_small);
                this.f75858k4.setNavigationOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity.VDDXBuilderFragment.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (!VDDXBuilderFragment.this.m44859B().containsKey("Dialog")) {
                            VDDXBuilderFragment.this.f75863p4.m4998G1(false);
                            return;
                        }
                        try {
                            VDDXBuilderFragment.this.m44855C().m44464r().m44309I(C4804R.anim.f85978to_fade_in, C4804R.anim.f85979to_fade_out).mo44279x(VDDXBuilderFragment.this).mo44289n();
                        } catch (Exception e) {
                            FirebaseCrashlytics.m18030d().m18027g(e);
                            e.printStackTrace();
                        }
                    }
                });
                this.f75838Q3 = (SearchView) this.f75858k4.getMenu().findItem(C4804R.C4808id.f86789action_search).getActionView();
                m4028M4();
                m4025P4();
                m4140G3();
                return inflate;
            } catch (Exception e) {
                FirebaseCrashlytics.m18030d().m18027g(e);
                m4080r4(e);
                return inflate;
            }
        }

        @Override // net.imedicaldoctor.imd.Fragments.VisualDXLookup.VDDialogListInterface
        /* renamed from: g */
        public void mo3977g(Bundle bundle, String str) {
            str.equals("Module");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: l1 */
        public void mo3541l1() {
            super.mo3541l1();
            m4140G3();
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        /* renamed from: x4 */
        public Bundle m4023x4(int i, ArrayList<String> arrayList) {
            Iterator<String> it2 = arrayList.iterator();
            int i2 = 0;
            while (it2.hasNext()) {
                String next = it2.next();
                if (i == i2) {
                    Bundle bundle = new Bundle();
                    bundle.putString("Text", next);
                    bundle.putString("Type", "Header");
                    return bundle;
                }
                int m4026O4 = i2 + m4026O4(next);
                if (i <= m4026O4) {
                    Bundle bundle2 = new Bundle();
                    bundle2.putString("Section", next);
                    bundle2.putInt("Index", (i - (m4026O4 - m4026O4(next))) - 1);
                    bundle2.putString("Type", "Item");
                    return bundle2;
                }
                i2 = m4026O4 + 1;
            }
            return null;
        }

        /* renamed from: y4 */
        public void m4022y4() {
            ListView listView = this.f76003I4;
            listView.setAdapter(listView.getAdapter());
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new VDDXBuilderFragment(), bundle);
    }
}
