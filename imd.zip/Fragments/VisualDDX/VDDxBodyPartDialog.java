package net.imedicaldoctor.imd.Fragments.VisualDDX;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import info.hoang8f.android.segmented.SegmentedGroup;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBuilderActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.p024io.FileUtils;
import org.json.JSONObject;

/* loaded from: classes2.dex */
public class VDDxBodyPartDialog extends DialogFragment {

    /* renamed from: g4 */
    public RelativeLayout f75974g4;

    /* renamed from: h4 */
    private Bundle f75975h4;

    /* renamed from: i4 */
    private Bundle f75976i4;

    /* renamed from: j4 */
    private SegmentedGroup f75977j4;

    /* renamed from: k4 */
    private ArrayList<Bundle> f75978k4;

    /* renamed from: l4 */
    private ArrayList<Bundle> f75979l4;

    /* renamed from: m4 */
    private String f75980m4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87200fragment_vddx_body_part_dialog, (ViewGroup) null);
        final CompressHelper compressHelper = new CompressHelper(m44716w());
        final ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f75974g4 = (RelativeLayout) inflate.findViewById(C4804R.C4808id.f86813body_parts);
        RadioButton radioButton = (RadioButton) inflate.findViewById(C4804R.C4808id.f86825button1);
        RadioButton radioButton2 = (RadioButton) inflate.findViewById(C4804R.C4808id.f86826button2);
        this.f75977j4 = (SegmentedGroup) inflate.findViewById(C4804R.C4808id.f87013segment);
        RadioButton radioButton3 = (RadioButton) inflate.findViewById(C4804R.C4808id.f86828buttongender1);
        RadioButton radioButton4 = (RadioButton) inflate.findViewById(C4804R.C4808id.f86829buttongender2);
        SegmentedGroup segmentedGroup = (SegmentedGroup) inflate.findViewById(C4804R.C4808id.f87014segmentgender);
        this.f75975h4 = m44859B().getBundle("db");
        final Bundle bundle2 = m44859B().getBundle("allFindings");
        this.f75978k4 = m44859B().getParcelableArrayList("distribution");
        this.f75979l4 = m44859B().getParcelableArrayList(FirebaseAnalytics.Param.f55223s);
        final String string = m44859B().getString("bodyFolder");
        this.f75980m4 = CompressHelper.m4942Z0(this.f75975h4, string, "BodyLocation");
        String str = this.f75980m4 + "/info.js";
        this.f75977j4.setSelected(true);
        try {
            JSONObject jSONObject = new JSONObject(FileUtils.readFileToString(new File(str), "UTF-8"));
            m4045r3(this.f75980m4 + "/homunculus.gif");
            Bundle m5000G = compressHelper.m5000G(jSONObject);
            this.f75976i4 = m5000G;
            if (m5000G.getParcelableArrayList("bodyDistribution").size() == 0) {
                radioButton2.setVisibility(8);
            }
            if (!bundle2.keySet().contains("20200")) {
                radioButton2.setVisibility(8);
            }
            final ArrayAdapter<Bundle> arrayAdapter = new ArrayAdapter<Bundle>(m44716w(), C4804R.C4810layout.f87288list_view_item_simple_text_check) { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBodyPartDialog.1
                @Override // android.widget.ArrayAdapter, android.widget.Adapter
                /* renamed from: a */
                public Bundle getItem(int i) {
                    return (Bundle) VDDxBodyPartDialog.this.f75976i4.getParcelableArrayList("bodyLocation").get(i);
                }

                @Override // android.widget.ArrayAdapter, android.widget.Adapter
                public int getCount() {
                    return VDDxBodyPartDialog.this.f75976i4.getParcelableArrayList("bodyLocation").size();
                }

                @Override // android.widget.ArrayAdapter, android.widget.Adapter
                public View getView(int i, View view, ViewGroup viewGroup) {
                    if (view == null) {
                        view = LayoutInflater.from(VDDxBodyPartDialog.this.m44716w()).inflate(C4804R.C4810layout.f87288list_view_item_simple_text_check, viewGroup, false);
                    }
                    Bundle item = getItem(i);
                    TextView textView = (TextView) view.findViewById(C4804R.C4808id.text);
                    ImageView imageView = (ImageView) view.findViewById(C4804R.C4808id.f86840check_icon);
                    String string2 = item.getString("title");
                    if (string2.length() == 0) {
                        string2 = bundle2.getString(item.getStringArrayList("findingIds").get(0));
                    }
                    textView.setText(string2);
                    if (CompressHelper.m4936b(VDDxBodyPartDialog.this.f75979l4, item, "imageName") > -1 || CompressHelper.m4936b(VDDxBodyPartDialog.this.f75978k4, item, "imageName") > -1) {
                        imageView.setVisibility(0);
                    } else {
                        imageView.setVisibility(4);
                    }
                    return view;
                }
            };
            final ArrayAdapter<Bundle> arrayAdapter2 = new ArrayAdapter<Bundle>(m44716w(), C4804R.C4810layout.f87288list_view_item_simple_text_check) { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBodyPartDialog.2
                @Override // android.widget.ArrayAdapter, android.widget.Adapter
                /* renamed from: a */
                public Bundle getItem(int i) {
                    return (Bundle) VDDxBodyPartDialog.this.f75976i4.getParcelableArrayList("bodyDistribution").get(i);
                }

                @Override // android.widget.ArrayAdapter, android.widget.Adapter
                public int getCount() {
                    return VDDxBodyPartDialog.this.f75976i4.getParcelableArrayList("bodyDistribution").size();
                }

                @Override // android.widget.ArrayAdapter, android.widget.Adapter
                public View getView(int i, View view, ViewGroup viewGroup) {
                    if (view == null) {
                        view = LayoutInflater.from(VDDxBodyPartDialog.this.m44716w()).inflate(C4804R.C4810layout.f87288list_view_item_simple_text_check, viewGroup, false);
                    }
                    Bundle item = getItem(i);
                    TextView textView = (TextView) view.findViewById(C4804R.C4808id.text);
                    ImageView imageView = (ImageView) view.findViewById(C4804R.C4808id.f86840check_icon);
                    String string2 = item.getString("title");
                    if (string2.length() == 0) {
                        string2 = bundle2.getString(item.getStringArrayList("findingIds").get(0));
                    }
                    textView.setText(string2);
                    if (CompressHelper.m4936b(VDDxBodyPartDialog.this.f75979l4, item, "imageName") > -1 || CompressHelper.m4936b(VDDxBodyPartDialog.this.f75978k4, item, "imageName") > -1) {
                        imageView.setVisibility(0);
                    } else {
                        imageView.setVisibility(4);
                    }
                    return view;
                }
            };
            listView.setAdapter((ListAdapter) arrayAdapter);
            this.f75977j4.check(C4804R.C4808id.f86825button1);
            segmentedGroup.check(C4804R.C4808id.f86828buttongender1);
            this.f75977j4.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBodyPartDialog.3
                @Override // android.widget.RadioGroup.OnCheckedChangeListener
                public void onCheckedChanged(RadioGroup radioGroup, int i) {
                    ListView listView2;
                    ArrayAdapter arrayAdapter3;
                    if (i == C4804R.C4808id.f86825button1) {
                        listView2 = listView;
                        arrayAdapter3 = arrayAdapter;
                    } else {
                        listView2 = listView;
                        arrayAdapter3 = arrayAdapter2;
                    }
                    listView2.setAdapter((ListAdapter) arrayAdapter3);
                    VDDxBodyPartDialog.this.m4044s3();
                }
            });
            segmentedGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBodyPartDialog.4
                @Override // android.widget.RadioGroup.OnCheckedChangeListener
                public void onCheckedChanged(RadioGroup radioGroup, int i) {
                    VDDxBodyPartDialog vDDxBodyPartDialog;
                    Bundle bundle3;
                    String replace;
                    if (i == C4804R.C4808id.f86828buttongender1) {
                        vDDxBodyPartDialog = VDDxBodyPartDialog.this;
                        bundle3 = vDDxBodyPartDialog.f75975h4;
                        replace = string.replace("Female", "Male");
                    } else {
                        vDDxBodyPartDialog = VDDxBodyPartDialog.this;
                        bundle3 = vDDxBodyPartDialog.f75975h4;
                        replace = string.replace("Male", "Female");
                    }
                    vDDxBodyPartDialog.f75980m4 = CompressHelper.m4942Z0(bundle3, replace, "BodyLocation");
                    try {
                        JSONObject jSONObject2 = new JSONObject(FileUtils.readFileToString(new File(VDDxBodyPartDialog.this.f75980m4 + "/info.js"), "UTF-8"));
                        VDDxBodyPartDialog.this.f75976i4 = compressHelper.m5000G(jSONObject2);
                        VDDxBodyPartDialog vDDxBodyPartDialog2 = VDDxBodyPartDialog.this;
                        vDDxBodyPartDialog2.m4045r3(VDDxBodyPartDialog.this.f75980m4 + "/homunculus.gif");
                        VDDxBodyPartDialog.this.f75974g4.removeAllViews();
                        VDDxBodyPartDialog vDDxBodyPartDialog3 = VDDxBodyPartDialog.this;
                        vDDxBodyPartDialog3.m4045r3(VDDxBodyPartDialog.this.f75980m4 + "/homunculus.gif");
                        ListView listView2 = listView;
                        listView2.setAdapter(listView2.getAdapter());
                        VDDxBodyPartDialog.this.m4044s3();
                    } catch (Exception unused) {
                    }
                }
            });
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.VisualDDX.VDDxBodyPartDialog.5
                /* JADX WARN: Type inference failed for: r6v10, types: [android.widget.Adapter] */
                /* JADX WARN: Type inference failed for: r6v2, types: [android.widget.Adapter] */
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    Bundle bundle3;
                    int m4936b;
                    ArrayList arrayList;
                    ArrayList arrayList2;
                    VDDxBuilderActivity.VDDXBuilderFragment vDDXBuilderFragment = (VDDxBuilderActivity.VDDXBuilderFragment) VDDxBodyPartDialog.this.m44753k0();
                    if (adapterView.getAdapter() == arrayAdapter) {
                        bundle3 = (Bundle) adapterView.getAdapter().getItem(i);
                        m4936b = CompressHelper.m4936b(VDDxBodyPartDialog.this.f75979l4, bundle3, "imageName");
                        if (m4936b > -1) {
                            arrayList2 = VDDxBodyPartDialog.this.f75979l4;
                            arrayList2.remove(m4936b);
                        } else {
                            arrayList = VDDxBodyPartDialog.this.f75979l4;
                            arrayList.add(bundle3);
                        }
                    } else {
                        bundle3 = (Bundle) adapterView.getAdapter().getItem(i);
                        m4936b = CompressHelper.m4936b(VDDxBodyPartDialog.this.f75978k4, bundle3, "imageName");
                        if (m4936b > -1) {
                            arrayList2 = VDDxBodyPartDialog.this.f75978k4;
                            arrayList2.remove(m4936b);
                        } else {
                            arrayList = VDDxBodyPartDialog.this.f75978k4;
                            arrayList.add(bundle3);
                        }
                    }
                    vDDXBuilderFragment.m4022y4();
                    ((ArrayAdapter) adapterView.getAdapter()).notifyDataSetChanged();
                    VDDxBodyPartDialog.this.m4044s3();
                }
            });
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            iMDLogger.m3294f("VDDxBodyDialog", "Error in dialog : " + e.toString());
        }
        builder.setView(inflate);
        return builder.create();
    }

    /* renamed from: q3 */
    public void m4046q3(String str) {
        String str2 = this.f75980m4 + "/" + str + "_highlight.png";
        if (!new File(str2).exists()) {
            str2 = this.f75980m4 + "/" + str + ".png";
        }
        View findViewWithTag = this.f75974g4.findViewWithTag(str2);
        if (findViewWithTag != null) {
            findViewWithTag.setVisibility(0);
            return;
        }
        ImageView imageView = new ImageView(m44716w());
        Glide.m40315G(m44716w()).mo40150i(new File(str2)).m40191t2(imageView);
        imageView.setTag(str2);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setLayoutParams(layoutParams);
        this.f75974g4.addView(imageView);
    }

    /* renamed from: r3 */
    public void m4045r3(String str) {
        if (this.f75974g4.findViewWithTag(str) != null) {
            return;
        }
        ImageView imageView = new ImageView(m44716w());
        Glide.m40315G(m44716w()).mo40150i(new File(str)).m40191t2(imageView);
        imageView.setTag(str);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setLayoutParams(layoutParams);
        this.f75974g4.addView(imageView);
    }

    /* renamed from: s3 */
    public void m4044s3() {
        ArrayList<Bundle> arrayList = this.f75977j4.getCheckedRadioButtonId() == C4804R.C4808id.f86825button1 ? this.f75979l4 : this.f75978k4;
        Iterator it2 = this.f75976i4.getParcelableArrayList("bodyLocation").iterator();
        while (it2.hasNext()) {
            Bundle bundle = (Bundle) it2.next();
            int m4936b = CompressHelper.m4936b(arrayList, bundle, "imageName");
            String string = bundle.getString("imageName");
            if (m4936b > -1) {
                m4046q3(string);
            } else {
                m4043t3(string);
            }
        }
        Iterator it3 = this.f75976i4.getParcelableArrayList("bodyDistribution").iterator();
        while (it3.hasNext()) {
            Bundle bundle2 = (Bundle) it3.next();
            int m4936b2 = CompressHelper.m4936b(arrayList, bundle2, "imageName");
            String string2 = bundle2.getString("imageName");
            if (m4936b2 > -1) {
                m4046q3(string2);
            } else {
                m4043t3(string2);
            }
        }
    }

    /* renamed from: t3 */
    public void m4043t3(String str) {
        String str2 = this.f75980m4 + "/" + str + "_highlight.png";
        if (!new File(str2).exists()) {
            str2 = this.f75980m4 + "/" + str + ".png";
        }
        View findViewWithTag = this.f75974g4.findViewWithTag(str2);
        if (findViewWithTag != null) {
            findViewWithTag.setVisibility(4);
        }
    }
}
