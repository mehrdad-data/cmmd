package net.imedicaldoctor.imd.Fragments.IranGenericDrugs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.AppBarLayout;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter;
import net.imedicaldoctor.imd.ViewHolders.RippleTextFullViewHolder;
import net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter;
import org.apache.commons.lang3.StringUtils;

/* loaded from: classes2.dex */
public class IranGenericDrugsListFragment extends SearchHelperFragment {

    /* renamed from: b4 */
    public SpellSearchAdapter f74730b4;

    /* renamed from: c4 */
    public String f74731c4;

    /* renamed from: d4 */
    public ArrayList<Bundle> f74732d4;

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f75221R3 = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
        m4329Z2(bundle);
        m4333V2();
        this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
        mo4335T2();
        this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
        this.f74732d4 = new ArrayList<>();
        ((AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar)).m27445s(true, false);
        ((RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout)).setVisibility(0);
        this.f75216M3 = new ChaptersAdapter(m44716w(), this.f75218O3, "name", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.IranGenericDrugs.IranGenericDrugsListFragment.1
            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: e0 */
            public void mo3406e0(RecyclerView.ViewHolder viewHolder, Bundle bundle2, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle2.getString("shortForm") + StringUtils.SPACE + bundle2.getString("name") + StringUtils.SPACE + bundle2.getString("dose"));
                rippleTextFullViewHolder.f83285J.setVisibility(8);
                if (bundle2.getString("genName").length() > 0) {
                    rippleTextFullViewHolder.f83285J.setText(bundle2.getString("genForm") + StringUtils.SPACE + bundle2.getString("genName") + StringUtils.SPACE + bundle2.getString("genDose"));
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                }
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter
            /* renamed from: h0 */
            public RecyclerView.ViewHolder mo3403h0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                rippleTextFullViewHolder.f83287L.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f74730b4 = new SpellSearchAdapter(m44716w(), this.f75219P3, "text", "content", C4804R.C4810layout.f87265list_view_item_ripple_text_full) { // from class: net.imedicaldoctor.imd.Fragments.IranGenericDrugs.IranGenericDrugsListFragment.2
            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: e0 */
            public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle2, int i) {
                RippleTextFullViewHolder rippleTextFullViewHolder = (RippleTextFullViewHolder) viewHolder;
                rippleTextFullViewHolder.f83284I.setText(bundle2.getString("shortForm") + StringUtils.SPACE + bundle2.getString("name") + StringUtils.SPACE + bundle2.getString("dose"));
                rippleTextFullViewHolder.f83285J.setVisibility(8);
                if (bundle2.getString("genName").length() > 0) {
                    rippleTextFullViewHolder.f83285J.setText(bundle2.getString("genForm") + StringUtils.SPACE + bundle2.getString("genName") + StringUtils.SPACE + bundle2.getString("genDose"));
                    rippleTextFullViewHolder.f83285J.setVisibility(0);
                }
                rippleTextFullViewHolder.f83288M.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.IranGenericDrugs.IranGenericDrugsListFragment.2.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        IranGenericDrugsListFragment.this.m4330Y2();
                        IranGenericDrugsListFragment.this.f74732d4.add(bundle2);
                        IranGenericDrugsListFragment.this.f75223T3.m51655i0("", false);
                        IranGenericDrugsListFragment iranGenericDrugsListFragment = IranGenericDrugsListFragment.this;
                        ((ChaptersAdapter) iranGenericDrugsListFragment.f75216M3).m3404g0(iranGenericDrugsListFragment.f74732d4);
                        IranGenericDrugsListFragment.this.f75216M3.m42860G();
                        IranGenericDrugsListFragment iranGenericDrugsListFragment2 = IranGenericDrugsListFragment.this;
                        iranGenericDrugsListFragment2.f75227X3.setAdapter(iranGenericDrugsListFragment2.f75216M3);
                    }
                });
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: h0 */
            public void mo3379h0(Bundle bundle2) {
                IranGenericDrugsListFragment.this.m4330Y2();
                IranGenericDrugsListFragment.this.f75223T3.m51655i0(bundle2.getString("word"), true);
            }

            @Override // net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter
            /* renamed from: j0 */
            public RecyclerView.ViewHolder mo3377j0(View view) {
                RippleTextFullViewHolder rippleTextFullViewHolder = new RippleTextFullViewHolder(view);
                rippleTextFullViewHolder.f83286K.setVisibility(8);
                return rippleTextFullViewHolder;
            }
        };
        this.f75227X3.setAdapter(this.f75216M3);
        m4338Q2();
        m44735q2(false);
        return this.f75221R3;
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: a3 */
    public void mo3982a3() {
        this.f74730b4.m3378i0(this.f75219P3, this.f75220Q3);
        this.f75227X3.setAdapter(this.f74730b4);
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: d3 */
    public ArrayList<Bundle> mo3981d3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select * from search where search match 'name:" + str + "*'");
    }

    @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
    /* renamed from: j3 */
    public ArrayList<Bundle> mo3980j3(String str) {
        CompressHelper compressHelper = this.f75215L3;
        Bundle bundle = this.f75212I3;
        return compressHelper.m4955V(bundle, "Select word from spell where word match '" + str + "*'");
    }
}
