package net.imedicaldoctor.imd.Fragments.OVID;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SearchView;
import androidx.exifinterface.media.ExifInterface;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.material.appbar.AppBarLayout;
import com.itextpdf.tool.xml.html.HTML;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.SearchHelperFragment;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;
import net.imedicaldoctor.imd.ViewHolders.MessageViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleSearchContentViewHolder;
import net.imedicaldoctor.imd.ViewHolders.RippleTextViewHolder;
import net.imedicaldoctor.imd.iMDActivity;

/* loaded from: classes2.dex */
public class OvidChaptersActivity extends iMDActivity {

    /* loaded from: classes2.dex */
    public static class OvidChaptersFragment extends SearchHelperFragment {

        /* renamed from: d4 */
        private static String f75093d4;

        /* renamed from: b4 */
        private String f75094b4;

        /* renamed from: c4 */
        private OvidContentSearchAdapter f75095c4;

        /* loaded from: classes2.dex */
        public class OvidChaptersAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f75100d;

            /* renamed from: e */
            public ArrayList<Bundle> f75101e;

            /* renamed from: f */
            public String f75102f;

            public OvidChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
                this.f75100d = context;
                this.f75101e = arrayList;
                this.f75102f = str;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                ArrayList<Bundle> arrayList = this.f75101e;
                if (arrayList == null) {
                    return 0;
                }
                Bundle bundle = arrayList.get(i);
                if (bundle.getString("leaf").equals(IcyHeaders.f35463C2)) {
                    return 0;
                }
                return (bundle.getString("xpath").length() > 0 || bundle.getString(HTML.Tag.f65890V).length() > 0) ? 1 : 2;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                if (viewHolder.m42556F() == 0 || viewHolder.m42556F() == 2) {
                    RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                    final Bundle bundle = this.f75101e.get(i);
                    rippleTextViewHolder.f83300I.setText(bundle.getString(this.f75102f));
                    rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidChaptersAdapter.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            OvidChaptersAdapter.this.mo4376e0(bundle, i);
                        }
                    });
                } else if (viewHolder.m42556F() == 1) {
                    RippleInfoTextViewHolder rippleInfoTextViewHolder = (RippleInfoTextViewHolder) viewHolder;
                    final Bundle bundle2 = this.f75101e.get(i);
                    rippleInfoTextViewHolder.f75130I.setText(bundle2.getString(this.f75102f));
                    rippleInfoTextViewHolder.f75132K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidChaptersAdapter.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            OvidChaptersAdapter.this.mo4376e0(bundle2, i);
                        }
                    });
                    rippleInfoTextViewHolder.f75131J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidChaptersAdapter.3
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            OvidChaptersAdapter.this.mo4377d0(bundle2, i);
                        }
                    });
                }
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                if (i == 0) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f75100d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
                }
                if (i == 1) {
                    return new RippleInfoTextViewHolder(LayoutInflater.from(this.f75100d).inflate(C4804R.C4810layout.f87259list_view_item_ripple_goto_arrow, viewGroup, false));
                } else if (i == 2) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f75100d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
                } else {
                    return null;
                }
            }

            /* renamed from: d0 */
            public void mo4377d0(Bundle bundle, int i) {
            }

            /* renamed from: e0 */
            public void mo4376e0(Bundle bundle, int i) {
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                ArrayList<Bundle> arrayList = this.f75101e;
                if (arrayList == null) {
                    return 0;
                }
                return arrayList.size();
            }
        }

        /* loaded from: classes2.dex */
        public class OvidContentSearchAdapter extends RecyclerView.Adapter {

            /* renamed from: d */
            public Context f75113d;

            /* renamed from: e */
            public ArrayList<Bundle> f75114e;

            /* renamed from: f */
            public String f75115f;

            /* renamed from: g */
            public String f75116g;

            public OvidContentSearchAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2) {
                this.f75113d = context;
                this.f75114e = arrayList;
                this.f75115f = str;
                this.f75116g = str2;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: C */
            public int mo3384C(int i) {
                ArrayList<Bundle> arrayList = this.f75114e;
                if (arrayList == null || arrayList.size() == 0) {
                    return 0;
                }
                if (this.f75114e.get(i).getString("type").equals("0")) {
                    OvidChaptersFragment ovidChaptersFragment = OvidChaptersFragment.this;
                    CompressHelper compressHelper = ovidChaptersFragment.f75215L3;
                    Bundle bundle = ovidChaptersFragment.f75212I3;
                    Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(bundle, "Select * from TOC where id=" + this.f75114e.get(i).getString("contentId")));
                    if (m4858z.getString("leaf").equals(IcyHeaders.f35463C2)) {
                        return 0;
                    }
                    return (m4858z.getString("xpath").length() > 0 || m4858z.getString(HTML.Tag.f65890V).length() > 0) ? 1 : 2;
                }
                return 3;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: R */
            public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
                MaterialRippleLayout materialRippleLayout;
                View.OnClickListener onClickListener;
                ArrayList<Bundle> arrayList = this.f75114e;
                if (arrayList == null || arrayList.size() == 0) {
                    MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
                    return;
                }
                if (viewHolder.m42556F() == 3) {
                    RippleSearchContentViewHolder rippleSearchContentViewHolder = (RippleSearchContentViewHolder) viewHolder;
                    final Bundle bundle = this.f75114e.get(i);
                    rippleSearchContentViewHolder.f83264I.setText(bundle.getString(this.f75115f));
                    if (this.f75116g == null) {
                        rippleSearchContentViewHolder.f83265J.setVisibility(8);
                    } else {
                        rippleSearchContentViewHolder.f83265J.setVisibility(0);
                        rippleSearchContentViewHolder.f83265J.setText(Html.fromHtml(bundle.getString(this.f75116g)));
                    }
                    materialRippleLayout = rippleSearchContentViewHolder.f83266K;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidContentSearchAdapter.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            OvidContentSearchAdapter.this.mo4374e0(bundle, i);
                        }
                    };
                } else {
                    OvidChaptersFragment ovidChaptersFragment = OvidChaptersFragment.this;
                    CompressHelper compressHelper = ovidChaptersFragment.f75215L3;
                    Bundle bundle2 = ovidChaptersFragment.f75212I3;
                    final Bundle m4858z = compressHelper.m4858z(compressHelper.m4955V(bundle2, "Select * from TOC where id=" + this.f75114e.get(i).getString("contentId")));
                    if (viewHolder.m42556F() != 0 && viewHolder.m42556F() != 2) {
                        if (viewHolder.m42556F() == 1) {
                            RippleInfoTextViewHolder rippleInfoTextViewHolder = (RippleInfoTextViewHolder) viewHolder;
                            rippleInfoTextViewHolder.f75130I.setText(m4858z.getString("name"));
                            rippleInfoTextViewHolder.f75132K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidContentSearchAdapter.3
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    OvidContentSearchAdapter.this.mo4374e0(m4858z, i);
                                }
                            });
                            rippleInfoTextViewHolder.f75131J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidContentSearchAdapter.4
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    OvidContentSearchAdapter.this.mo4375d0(m4858z, i);
                                }
                            });
                            return;
                        }
                        return;
                    }
                    RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
                    rippleTextViewHolder.f83300I.setText(m4858z.getString("name"));
                    materialRippleLayout = rippleTextViewHolder.f83301J;
                    onClickListener = new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidContentSearchAdapter.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            OvidContentSearchAdapter.this.mo4374e0(m4858z, i);
                        }
                    };
                }
                materialRippleLayout.setOnClickListener(onClickListener);
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: T */
            public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
                ArrayList<Bundle> arrayList = this.f75114e;
                if (arrayList == null || arrayList.size() == 0) {
                    return new MessageViewHolder(this.f75113d, LayoutInflater.from(this.f75113d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
                } else if (i == 0) {
                    return new RippleTextViewHolder(LayoutInflater.from(this.f75113d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
                } else {
                    if (i == 1) {
                        return new RippleInfoTextViewHolder(LayoutInflater.from(this.f75113d).inflate(C4804R.C4810layout.f87259list_view_item_ripple_goto_arrow, viewGroup, false));
                    } else if (i == 2) {
                        return new RippleTextViewHolder(LayoutInflater.from(this.f75113d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
                    } else {
                        if (i == 3) {
                            return new RippleSearchContentViewHolder(LayoutInflater.from(this.f75113d).inflate(C4804R.C4810layout.f87274list_view_item_search_content_ripple, viewGroup, false));
                        }
                        return null;
                    }
                }
            }

            /* renamed from: d0 */
            public void mo4375d0(Bundle bundle, int i) {
            }

            /* renamed from: e0 */
            public void mo4374e0(Bundle bundle, int i) {
            }

            /* renamed from: f0 */
            public void m4373f0(ArrayList<Bundle> arrayList) {
                this.f75114e = arrayList;
                m42860G();
            }

            @Override // androidx.recyclerview.widget.RecyclerView.Adapter
            /* renamed from: s */
            public int mo3359s() {
                ArrayList<Bundle> arrayList = this.f75114e;
                if (arrayList == null || arrayList.size() == 0) {
                    return 1;
                }
                return this.f75114e.size();
            }
        }

        /* loaded from: classes2.dex */
        public class RippleInfoTextViewHolder extends RecyclerView.ViewHolder {

            /* renamed from: I */
            public TextView f75130I;

            /* renamed from: J */
            public ImageView f75131J;

            /* renamed from: K */
            public MaterialRippleLayout f75132K;

            public RippleInfoTextViewHolder(View view) {
                super(view);
                this.f75130I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
                this.f75132K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
                this.f75131J = (ImageView) view.findViewById(C4804R.C4808id.f86940info_button);
            }
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87405search, menu);
            this.f75223T3 = (SearchView) menu.findItem(C4804R.C4808id.f86789action_search).getActionView();
            m4337R2();
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            String str;
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87168fragment_new_list, viewGroup, false);
            this.f75221R3 = inflate;
            m4329Z2(bundle);
            m4333V2();
            this.f75223T3 = (SearchView) this.f75221R3.findViewById(C4804R.C4808id.f87012search_view);
            m4337R2();
            this.f75227X3 = (RecyclerView) this.f75221R3.findViewById(C4804R.C4808id.f87001recycler_view);
            AppBarLayout appBarLayout = (AppBarLayout) this.f75221R3.findViewById(C4804R.C4808id.f86799appbar);
            final RelativeLayout relativeLayout = (RelativeLayout) this.f75221R3.findViewById(C4804R.C4808id.f86803background_layout);
            if (m44859B() == null || !m44859B().containsKey("ParentId")) {
                appBarLayout.m27445s(true, false);
                relativeLayout.setVisibility(0);
                str = "0";
            } else {
                appBarLayout.m27445s(false, false);
                appBarLayout.postDelayed(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.1
                    @Override // java.lang.Runnable
                    public void run() {
                        relativeLayout.setVisibility(0);
                    }
                }, 800L);
                str = m44859B().getString("ParentId");
            }
            this.f75094b4 = str;
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle2 = this.f75212I3;
            this.f75218O3 = compressHelper.m4955V(bundle2, "Select id as _id,* from toc where parentId = " + this.f75094b4);
            this.f75216M3 = new OvidChaptersAdapter(m44716w(), this.f75218O3, "name") { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.2
                @Override // net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidChaptersAdapter
                /* renamed from: d0 */
                public void mo4377d0(Bundle bundle3, int i) {
                    OvidChaptersFragment.this.m4330Y2();
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("gotoSection", bundle3);
                    OvidChaptersFragment ovidChaptersFragment = OvidChaptersFragment.this;
                    ovidChaptersFragment.f75215L3.m4880r1(ovidChaptersFragment.f75212I3, bundle3.getString("bookId"), null, null, bundle4);
                }

                @Override // net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidChaptersAdapter
                /* renamed from: e0 */
                public void mo4376e0(Bundle bundle3, int i) {
                    OvidChaptersFragment.this.m4330Y2();
                    String string = bundle3.getString("leaf");
                    String string2 = bundle3.getString("bookId");
                    if (string.equals(IcyHeaders.f35463C2)) {
                        Bundle bundle4 = new Bundle();
                        bundle4.putBundle("gotoSection", bundle3);
                        OvidChaptersFragment ovidChaptersFragment = OvidChaptersFragment.this;
                        ovidChaptersFragment.f75215L3.m4880r1(ovidChaptersFragment.f75212I3, string2, null, null, bundle4);
                        return;
                    }
                    Bundle bundle5 = new Bundle();
                    bundle5.putBundle("DB", OvidChaptersFragment.this.f75212I3);
                    bundle5.putString("ParentId", bundle3.getString("id"));
                    OvidChaptersFragment.this.f75215L3.m4979N(OvidChaptersActivity.class, OvidChaptersFragment.class, bundle5);
                }
            };
            this.f75095c4 = new OvidContentSearchAdapter(m44716w(), this.f75219P3, "text", "subText") { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.3
                @Override // net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidContentSearchAdapter
                /* renamed from: d0 */
                public void mo4375d0(Bundle bundle3, int i) {
                    OvidChaptersFragment.this.m4330Y2();
                    Bundle bundle4 = new Bundle();
                    bundle4.putBundle("gotoSection", bundle3);
                    OvidChaptersFragment ovidChaptersFragment = OvidChaptersFragment.this;
                    ovidChaptersFragment.f75215L3.m4880r1(ovidChaptersFragment.f75212I3, bundle3.getString("bookId"), null, null, bundle4);
                }

                @Override // net.imedicaldoctor.imd.Fragments.OVID.OvidChaptersActivity.OvidChaptersFragment.OvidContentSearchAdapter
                /* renamed from: e0 */
                public void mo4374e0(Bundle bundle3, int i) {
                    Bundle m4923e0;
                    OvidChaptersFragment.this.m4330Y2();
                    if (!bundle3.containsKey("type")) {
                        String string = bundle3.getString("leaf");
                        String string2 = bundle3.getString("bookId");
                        if (string.equals(IcyHeaders.f35463C2)) {
                            Bundle bundle4 = new Bundle();
                            bundle4.putBundle("gotoSection", bundle3);
                            OvidChaptersFragment ovidChaptersFragment = OvidChaptersFragment.this;
                            ovidChaptersFragment.f75215L3.m4880r1(ovidChaptersFragment.f75212I3, string2, null, null, bundle4);
                            return;
                        }
                        Bundle bundle5 = new Bundle();
                        bundle5.putBundle("DB", OvidChaptersFragment.this.f75212I3);
                        bundle5.putString("ParentId", bundle3.getString("id"));
                        OvidChaptersFragment.this.f75215L3.m4979N(OvidChaptersActivity.class, OvidChaptersFragment.class, bundle5);
                        return;
                    }
                    String string3 = bundle3.getString("type");
                    String string4 = bundle3.getString("contentId");
                    if (string3.equals("0")) {
                        OvidChaptersFragment ovidChaptersFragment2 = OvidChaptersFragment.this;
                        CompressHelper compressHelper2 = ovidChaptersFragment2.f75215L3;
                        Bundle bundle6 = ovidChaptersFragment2.f75212I3;
                        Bundle m4907i1 = compressHelper2.m4907i1(compressHelper2.m4955V(bundle6, "Select * from TOC where id=" + string4));
                        if (m4907i1.getString("leaf").equals(IcyHeaders.f35463C2)) {
                            Bundle bundle7 = new Bundle();
                            bundle7.putBundle("gotoSection", m4907i1);
                            OvidChaptersFragment ovidChaptersFragment3 = OvidChaptersFragment.this;
                            ovidChaptersFragment3.f75215L3.m4880r1(ovidChaptersFragment3.f75212I3, m4907i1.getString("bookId"), null, null, bundle7);
                            return;
                        }
                        Bundle bundle8 = new Bundle();
                        bundle8.putBundle("DB", OvidChaptersFragment.this.f75212I3);
                        bundle8.putString("ParentId", m4907i1.getString("id"));
                        OvidChaptersFragment.this.f75215L3.m4979N(OvidChaptersActivity.class, OvidChaptersFragment.class, bundle8);
                    } else if (string3.equals(IcyHeaders.f35463C2)) {
                        OvidChaptersFragment ovidChaptersFragment4 = OvidChaptersFragment.this;
                        ovidChaptersFragment4.f75215L3.m4883q1(ovidChaptersFragment4.f75212I3, string4, null, null);
                    } else if (string3.equals(ExifInterface.f14403S4)) {
                    } else {
                        if (string3.equals(ExifInterface.f14411T4)) {
                            OvidChaptersFragment ovidChaptersFragment5 = OvidChaptersFragment.this;
                            CompressHelper compressHelper3 = ovidChaptersFragment5.f75215L3;
                            Bundle bundle9 = ovidChaptersFragment5.f75212I3;
                            m4923e0 = compressHelper3.m4923e0(bundle9, "select * from images where imagename='" + string4 + "'");
                            if (m4923e0 == null) {
                                return;
                            }
                        } else if (!string3.equals("4")) {
                            if (string3.equals("5")) {
                                OvidChaptersFragment ovidChaptersFragment6 = OvidChaptersFragment.this;
                                ovidChaptersFragment6.f75215L3.m4883q1(ovidChaptersFragment6.f75212I3, string4, ovidChaptersFragment6.m4332W2(bundle3.getString("subText")), null);
                                return;
                            }
                            return;
                        } else {
                            OvidChaptersFragment ovidChaptersFragment7 = OvidChaptersFragment.this;
                            CompressHelper compressHelper4 = ovidChaptersFragment7.f75215L3;
                            Bundle bundle10 = ovidChaptersFragment7.f75212I3;
                            m4923e0 = compressHelper4.m4923e0(bundle10, "select * from tables where id=" + string4);
                            if (m4923e0 == null) {
                                return;
                            }
                        }
                        String string5 = m4923e0.getString("bookId");
                        String string6 = m4923e0.getString("goto");
                        OvidChaptersFragment ovidChaptersFragment8 = OvidChaptersFragment.this;
                        ovidChaptersFragment8.f75215L3.m4883q1(ovidChaptersFragment8.f75212I3, string5, null, string6);
                    }
                }
            };
            this.f75227X3.setAdapter(this.f75216M3);
            m4338Q2();
            m44735q2(false);
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: a3 */
        public void mo3982a3() {
            this.f75095c4.m4373f0(this.f75219P3);
            this.f75227X3.setAdapter(this.f75095c4);
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: d3 */
        public ArrayList<Bundle> mo3981d3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id, Text as text,snippet(search) as subText, type, contentId from search where search match '" + str + "' ORDER BY rank(matchinfo(search)) DESC");
        }

        @Override // net.imedicaldoctor.imd.Fragments.SearchHelperFragment
        /* renamed from: j3 */
        public ArrayList<Bundle> mo3980j3(String str) {
            CompressHelper compressHelper = this.f75215L3;
            Bundle bundle = this.f75212I3;
            return compressHelper.m4955V(bundle, "Select rowid as _id,word from spell where word match '" + str + "*'");
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        m3300p0(bundle, new OvidChaptersFragment());
    }
}
