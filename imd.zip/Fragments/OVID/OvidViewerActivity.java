package net.imedicaldoctor.imd.Fragments.OVID;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.tool.xml.html.HTML;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.ViewerHelperActivity;
import net.imedicaldoctor.imd.Fragments.ViewerHelperFragment;
import net.imedicaldoctor.imd.Gallery.GalleryActivity;
import net.imedicaldoctor.imd.iMDLogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class OvidViewerActivity extends ViewerHelperActivity {

    /* loaded from: classes2.dex */
    public static class OvidViewerFragment extends ViewerHelperFragment {

        /* renamed from: A4 */
        private boolean f75142A4;

        /* renamed from: w4 */
        private String f75143w4;

        /* renamed from: x4 */
        private MenuItem f75144x4;

        /* renamed from: y4 */
        public ArrayList<Bundle> f75145y4;

        /* renamed from: z4 */
        private Bundle f75146z4;

        /* renamed from: C4 */
        private void m4369C4(String str) {
            if (str.contains("?")) {
                str = str.split("\\?")[0];
            }
            ArrayList<Bundle> arrayList = this.f75145y4;
            if (arrayList == null || arrayList.size() == 0) {
                CompressHelper.m4921e2(m44716w(), "There is no images in this document", 1);
                return;
            }
            int i = 0;
            for (int i2 = 0; i2 < this.f75145y4.size(); i2++) {
                if (this.f75145y4.get(i2).getString("id").equals(str)) {
                    i = i2;
                }
            }
            Intent intent = new Intent(m44716w(), GalleryActivity.class);
            intent.putExtra("Images", this.f75145y4);
            intent.putExtra("Start", i);
            mo4139H2(intent);
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: x4 */
        public void m4368x4() {
            MenuItem menuItem;
            boolean z;
            String[] strArr;
            ArrayList arrayList;
            String str;
            CompressHelper compressHelper;
            String m4942Z0;
            String str2;
            CompressHelper compressHelper2 = new CompressHelper(m44716w());
            Bundle bundle = this.f75850c4;
            ArrayList<Bundle> m4955V = compressHelper2.m4955V(bundle, "Select rowid as _id, * from images where bookid='" + this.f75851d4 + "'");
            ArrayList<Bundle> arrayList2 = new ArrayList<>();
            ArrayList arrayList3 = new ArrayList();
            if (m4955V == null) {
                m4955V = new ArrayList<>();
            }
            Iterator<Bundle> it2 = m4955V.iterator();
            while (true) {
                String str3 = "base";
                if (!it2.hasNext()) {
                    break;
                }
                Bundle next = it2.next();
                String[] split = StringUtils.split(next.getString("imagename"), "|");
                Iterator<Bundle> it3 = it2;
                int length = split.length;
                ArrayList<Bundle> arrayList4 = arrayList2;
                int i = 0;
                while (i < length) {
                    int i2 = length;
                    String str4 = split[i];
                    String[] strArr2 = split;
                    String m4942Z02 = CompressHelper.m4942Z0(this.f75850c4, str4, str3);
                    int i3 = i;
                    Bundle bundle2 = new Bundle();
                    File file = new File(m4942Z02);
                    ArrayList arrayList5 = arrayList3;
                    try {
                        String m4942Z03 = CompressHelper.m4942Z0(this.f75850c4, str4, str3);
                        str2 = str3;
                        try {
                            if (!new File(m4942Z03).exists()) {
                                FileUtils.writeByteArrayToFile(new File(m4942Z03), compressHelper2.m4867w(FileUtils.readFileToByteArray(file), file.getName(), "127"), false);
                            }
                        } catch (Exception e) {
                            e = e;
                            FirebaseCrashlytics.m18030d().m18027g(e);
                            iMDLogger.m3294f("LoadResourcesOther", "Error in loading " + m4942Z02 + " . error " + e.getLocalizedMessage());
                            e.printStackTrace();
                            bundle2.putString("ImagePath", m4942Z02);
                            bundle2.putString("Description", next.getString("descriptionSimple"));
                            bundle2.putString("id", str4);
                            arrayList3 = arrayList5;
                            arrayList3.add(str4);
                            arrayList4.add(bundle2);
                            i = i3 + 1;
                            length = i2;
                            split = strArr2;
                            str3 = str2;
                        }
                    } catch (Exception e2) {
                        e = e2;
                        str2 = str3;
                    }
                    bundle2.putString("ImagePath", m4942Z02);
                    bundle2.putString("Description", next.getString("descriptionSimple"));
                    bundle2.putString("id", str4);
                    arrayList3 = arrayList5;
                    arrayList3.add(str4);
                    arrayList4.add(bundle2);
                    i = i3 + 1;
                    length = i2;
                    split = strArr2;
                    str3 = str2;
                }
                it2 = it3;
                arrayList2 = arrayList4;
            }
            String str5 = "base";
            this.f75145y4 = arrayList2;
            if (this.f75143w4.length() == 0) {
                return;
            }
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(this.f75143w4, "|");
            int length2 = splitByWholeSeparator.length;
            int i4 = 0;
            while (i4 < length2) {
                String str6 = splitByWholeSeparator[i4];
                String m4942Z04 = CompressHelper.m4942Z0(this.f75850c4, str6, "Resources-E");
                if (arrayList3.contains(str6)) {
                    strArr = splitByWholeSeparator;
                    arrayList = arrayList3;
                    str = str5;
                } else {
                    Bundle bundle3 = new Bundle();
                    strArr = splitByWholeSeparator;
                    arrayList = arrayList3;
                    str = str5;
                    bundle3.putString("ImagePath", CompressHelper.m4942Z0(this.f75850c4, str6, str));
                    bundle3.putString("Description", "");
                    bundle3.putString("id", str6);
                    if (new File(m4942Z04).length() > 5000) {
                        this.f75145y4.add(bundle3);
                    }
                }
                if (new File(m4942Z04).exists()) {
                    File file2 = new File(m4942Z04);
                    try {
                        m4942Z0 = CompressHelper.m4942Z0(this.f75850c4, str6, str);
                    } catch (Exception e3) {
                        e = e3;
                        compressHelper = compressHelper2;
                    }
                    if (!new File(m4942Z0).exists()) {
                        compressHelper = compressHelper2;
                        try {
                            FileUtils.writeByteArrayToFile(new File(m4942Z0), compressHelper2.m4867w(FileUtils.readFileToByteArray(file2), file2.getName(), "127"), false);
                        } catch (Exception e4) {
                            e = e4;
                            FirebaseCrashlytics.m18030d().m18027g(e);
                            iMDLogger.m3294f("LoadResourcesOther", "Error in loading " + m4942Z04 + " . error " + e.getLocalizedMessage());
                            e.printStackTrace();
                            i4++;
                            str5 = str;
                            splitByWholeSeparator = strArr;
                            compressHelper2 = compressHelper;
                            arrayList3 = arrayList;
                        }
                        i4++;
                        str5 = str;
                        splitByWholeSeparator = strArr;
                        compressHelper2 = compressHelper;
                        arrayList3 = arrayList;
                    }
                }
                compressHelper = compressHelper2;
                i4++;
                str5 = str;
                splitByWholeSeparator = strArr;
                compressHelper2 = compressHelper;
                arrayList3 = arrayList;
            }
            if (this.f75144x4 != null) {
                if (this.f75145y4.size() == 0) {
                    menuItem = this.f75144x4;
                    z = false;
                } else {
                    menuItem = this.f75144x4;
                    z = true;
                }
                menuItem.setVisible(z);
            }
        }

        /* renamed from: B4 */
        public void m4370B4(Bundle bundle) {
            CompressHelper compressHelper = new CompressHelper(m44716w());
            Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(this.f75850c4, "Select * from Docs Where bookid = '" + this.f75851d4 + "'"));
            if (bundle.getString(HTML.Tag.f65890V).length() > 0) {
                this.f75853f4.loadUrl("javascript:showSection('" + bundle.getString(HTML.Tag.f65890V) + "');");
                return;
            }
            String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(bundle.getString("xpath").replace(m4907i1.getString("xpath"), ""), "/");
            this.f75853f4.loadUrl("javascript:jump = document;");
            for (String str : splitByWholeSeparator) {
                if (str.contains("[")) {
                    this.f75853f4.loadUrl("javascript:" + ("jump = jump.getElementsByClassName('" + str.substring(0, str.indexOf("[")) + "')[" + String.valueOf(Integer.valueOf(CompressHelper.m4920f(str, "[", "]")).intValue() - 1) + "];"));
                }
            }
            this.f75853f4.loadUrl("javascript:jump.scrollIntoView(true);");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S2 */
        public String mo3979S2() {
            ArrayList<Bundle> arrayList;
            Bundle m4073v3;
            if (this.f75145y4.size() <= 0 || (arrayList = this.f75145y4) == null || arrayList.size() <= 0 || (m4073v3 = m4073v3(this.f75145y4)) == null) {
                return null;
            }
            return m4073v3.getString("ImagePath");
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: S3 */
        public void mo3569S3(WebView webView, String str) {
            super.mo3569S3(webView, str);
            Bundle bundle = this.f75146z4;
            if (bundle != null) {
                m4370B4(bundle);
                this.f75146z4 = null;
            }
            this.f75853f4.loadUrl("javascript:fixAllImages2();");
            this.f75853f4.loadUrl("javascript:ConvertAllImages();");
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: T0 */
        public void mo3545T0(Menu menu, MenuInflater menuInflater) {
            menuInflater.inflate(C4804R.C4811menu.f87322elsviewer, menu);
            m4096h4(menu);
            mo3568e3(menu);
        }

        @Override // androidx.fragment.app.Fragment
        /* renamed from: U0 */
        public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
            View view = this.f75849b4;
            if (view != null) {
                return view;
            }
            View inflate = layoutInflater.inflate(C4804R.C4810layout.f87177fragment_new_viewer, viewGroup, false);
            m4094i4(inflate, bundle);
            if (bundle != null) {
                this.f75143w4 = bundle.getString("mResources");
                this.f75145y4 = bundle.getParcelableArrayList("mImages");
            }
            if (m44859B() == null) {
                return inflate;
            }
            m4122U2(new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidViewerActivity.OvidViewerFragment.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        CompressHelper compressHelper = new CompressHelper(OvidViewerFragment.this.m44716w());
                        String str = OvidViewerFragment.this.f75847Z3;
                        if (str == null || str.length() == 0) {
                            if (OvidViewerFragment.this.m44859B() != null && OvidViewerFragment.this.m44859B().containsKey("gotoSection")) {
                                OvidViewerFragment ovidViewerFragment = OvidViewerFragment.this;
                                ovidViewerFragment.f75146z4 = ovidViewerFragment.m44859B().getBundle("gotoSection");
                            }
                            Bundle bundle2 = OvidViewerFragment.this.f75850c4;
                            Bundle m4923e0 = compressHelper.m4923e0(bundle2, "Select * from Docs Where bookid = '" + OvidViewerFragment.this.f75851d4 + "'");
                            if (m4923e0 == null) {
                                OvidViewerFragment.this.f75837P3 = "Document doesn't exist";
                                return;
                            }
                            String string = m4923e0.getString("mainContent");
                            OvidViewerFragment.this.f75143w4 = m4923e0.getString("resources");
                            OvidViewerFragment.this.f75852e4 = m4923e0.getString("name");
                            String str2 = new String(compressHelper.m4870v(string, m4923e0.getString("bookid"), "127"));
                            OvidViewerFragment ovidViewerFragment2 = OvidViewerFragment.this;
                            String m4117W3 = ovidViewerFragment2.m4117W3(ovidViewerFragment2.m44716w(), "OVIDHeader.css");
                            OvidViewerFragment ovidViewerFragment3 = OvidViewerFragment.this;
                            String m4117W32 = ovidViewerFragment3.m4117W3(ovidViewerFragment3.m44716w(), "OVIDFooter.css");
                            String replace = m4117W3.replace("[size]", "200").replace("[title]", OvidViewerFragment.this.f75852e4);
                            String replace2 = (replace + str2 + m4117W32).replace("<div class=\"FG\"", "<div class=\"FG\" style=\"width:100%;overflow: scroll;\"").replace("<div class=\"TB\"", "<div class=\"TB\" style=\"width:100%;overflow: scroll;\"").replace("<div class=\"MATH\"", "<div class=\"MATH\" style=\"width:100%;overflow: scroll;\"");
                            OvidViewerFragment.this.m4087m3();
                            OvidViewerFragment ovidViewerFragment4 = OvidViewerFragment.this;
                            ovidViewerFragment4.f75847Z3 = replace2;
                            ovidViewerFragment4.m4368x4();
                        }
                        if (!compressHelper.m4892n1()) {
                            OvidViewerFragment.this.m4102d4("Chapter");
                        }
                        OvidViewerFragment.this.m4097h3(CompressHelper.m4945Y0(OvidViewerFragment.this.f75850c4, "base"));
                    } catch (Exception e) {
                        FirebaseCrashlytics.m18030d().m18027g(e);
                        e.printStackTrace();
                        OvidViewerFragment.this.f75837P3 = e.getLocalizedMessage();
                    }
                }
            }, new Runnable() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidViewerActivity.OvidViewerFragment.2
                @Override // java.lang.Runnable
                public void run() {
                    String str = OvidViewerFragment.this.f75837P3;
                    if (str != null && str.length() > 0) {
                        OvidViewerFragment ovidViewerFragment = OvidViewerFragment.this;
                        ovidViewerFragment.m4078s4(ovidViewerFragment.f75837P3);
                        return;
                    }
                    File file = new File(CompressHelper.m4945Y0(OvidViewerFragment.this.f75850c4, "base"));
                    OvidViewerFragment ovidViewerFragment2 = OvidViewerFragment.this;
                    ovidViewerFragment2.f75853f4.loadDataWithBaseURL("file://" + file.getAbsolutePath() + "/", ovidViewerFragment2.f75847Z3, "text/html", "utf-8", null);
                    OvidViewerFragment.this.m4092j4();
                    OvidViewerFragment.this.m4098g4();
                    OvidViewerFragment.this.m4100f3(C4804R.C4811menu.f87323elsviewer2);
                    OvidViewerFragment.this.m44735q2(false);
                    OvidViewerFragment.this.m4140G3();
                }
            });
            return inflate;
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: e1 */
        public boolean mo3709e1(MenuItem menuItem) {
            int itemId = menuItem.getItemId();
            if (itemId == C4804R.C4808id.f86774action_gallery) {
                m4369C4("soheilvb");
            }
            if (itemId == C4804R.C4808id.f86776action_menu) {
                CompressHelper compressHelper = new CompressHelper(m44716w());
                Bundle bundle = this.f75850c4;
                Bundle m4907i1 = compressHelper.m4907i1(compressHelper.m4955V(bundle, "Select id from toc where bookid='" + this.f75851d4 + "' AND section='" + this.f75851d4 + "'"));
                OvidSectionsViewer ovidSectionsViewer = new OvidSectionsViewer();
                Bundle bundle2 = new Bundle();
                bundle2.putBundle("db", this.f75850c4);
                bundle2.putString("parentId", m4907i1.getString("id"));
                ovidSectionsViewer.m44751k2(bundle2);
                ovidSectionsViewer.m44870c3(true);
                ovidSectionsViewer.m44844E2(this, 0);
                ovidSectionsViewer.mo29915h3(m44820L(), "OvidSectionsViewer");
            }
            return super.mo3709e1(menuItem);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: e3 */
        public void mo3568e3(Menu menu) {
            MenuItem menuItem;
            boolean z;
            this.f75144x4 = menu.findItem(C4804R.C4808id.f86774action_gallery);
            ArrayList<Bundle> arrayList = this.f75145y4;
            if (arrayList == null || arrayList.size() == 0) {
                menuItem = this.f75144x4;
                z = false;
            } else {
                menuItem = this.f75144x4;
                z = true;
            }
            menuItem.setVisible(z);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment, androidx.fragment.app.Fragment
        /* renamed from: m1 */
        public void mo3501m1(Bundle bundle) {
            super.mo3501m1(bundle);
        }

        @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperFragment
        /* renamed from: p4 */
        public boolean mo3564p4(WebView webView, String str, String str2, String str3) {
            iMDLogger.m3290j("Override", "Url : " + str + ", Scheme : " + str2 + ", Resource : " + str3);
            CompressHelper compressHelper = new CompressHelper(m44716w());
            if (str2.equals("image")) {
                try {
                    String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str3, "/");
                    m4369C4(splitByWholeSeparator[splitByWholeSeparator.length - 1]);
                } catch (Exception e) {
                    FirebaseCrashlytics.m18030d().m18027g(e);
                }
                return true;
            }
            if (str2.equals("chapter")) {
                String substring = str3.substring(2);
                if (substring.substring(0, 2).equals("PG")) {
                    ArrayList<Bundle> m4955V = compressHelper.m4955V(this.f75850c4, "Select * from pages where pagenum=" + substring.substring(2));
                    if (m4955V.size() == 0) {
                        return true;
                    }
                    compressHelper.m4883q1(this.f75850c4, m4955V.get(0).getString("bookid"), null, substring);
                } else {
                    compressHelper.m4883q1(this.f75850c4, substring, null, substring);
                }
            }
            String str4 = str3 + "&";
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str4, "/");
            if (!str4.contains("Book+Image") && splitByWholeSeparator2[splitByWholeSeparator2.length - 1].substring(0, 1).equals("#")) {
                String replace = splitByWholeSeparator2[splitByWholeSeparator2.length - 1].substring(1).replace("&", "");
                this.f75853f4.loadUrl("javascript:showSection('" + replace + "')");
            }
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // net.imedicaldoctor.imd.Fragments.ViewerHelperActivity, net.imedicaldoctor.imd.iMDActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C4804R.C4810layout.f87098activity_general_viewer);
        m3302n0(new OvidViewerFragment(), bundle);
    }
}
