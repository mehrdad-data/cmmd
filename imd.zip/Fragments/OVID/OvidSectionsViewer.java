package net.imedicaldoctor.imd.Fragments.OVID;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.fragment.app.DialogFragment;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.itextpdf.tool.xml.html.HTML;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;
import net.imedicaldoctor.imd.Fragments.OVID.OvidViewerActivity;

/* loaded from: classes2.dex */
public class OvidSectionsViewer extends DialogFragment {

    /* renamed from: g4 */
    private Bundle f75134g4;

    /* renamed from: h4 */
    private String f75135h4;

    @Override // androidx.fragment.app.DialogFragment
    /* renamed from: X2 */
    public Dialog mo3313X2(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(m44716w());
        View inflate = m44716w().getLayoutInflater().inflate(C4804R.C4810layout.f87155fragment_general_section_viewer, (ViewGroup) null);
        ListView listView = (ListView) inflate.findViewById(C4804R.C4808id.f86950list_view);
        this.f75134g4 = m44859B().getBundle("db");
        this.f75135h4 = m44859B().getString("parentId");
        final CompressHelper compressHelper = new CompressHelper(m44716w());
        Bundle bundle2 = this.f75134g4;
        listView.setAdapter((ListAdapter) new CursorAdapter(m44716w(), compressHelper.m4912h(compressHelper.m4955V(bundle2, "Select id as _id,* from toc where parentId = " + this.f75135h4)), 0) { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidSectionsViewer.1
            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: d */
            public void mo3522d(View view, Context context, Cursor cursor) {
                TextView textView = (TextView) view.getTag();
                final Bundle m4956U1 = compressHelper.m4956U1(cursor);
                if (!cursor.getString(cursor.getColumnIndex("leaf")).equals(IcyHeaders.f35463C2) && (cursor.getString(cursor.getColumnIndex("xpath")).length() > 0 || cursor.getString(cursor.getColumnIndex(HTML.Tag.f65890V)).length() > 0)) {
                    ((ImageView) view.findViewById(C4804R.C4808id.f86940info_button)).setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidSectionsViewer.1.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            ((OvidViewerActivity.OvidViewerFragment) OvidSectionsViewer.this.m44753k0()).m4370B4(m4956U1);
                            OvidSectionsViewer.this.mo27003Q2();
                        }
                    });
                }
                textView.setText(cursor.getString(cursor.getColumnIndex("name")));
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getItemViewType(int i) {
                Cursor cursor = (Cursor) getItem(i);
                if (cursor.getString(cursor.getColumnIndex("leaf")).equals(IcyHeaders.f35463C2)) {
                    return 0;
                }
                return (cursor.getString(cursor.getColumnIndex("xpath")).length() > 0 || cursor.getString(cursor.getColumnIndex(HTML.Tag.f65890V)).length() > 0) ? 1 : 2;
            }

            @Override // android.widget.BaseAdapter, android.widget.Adapter
            public int getViewTypeCount() {
                return 3;
            }

            @Override // androidx.cursoradapter.widget.CursorAdapter
            /* renamed from: i */
            public View mo3521i(Context context, Cursor cursor, ViewGroup viewGroup) {
                View inflate2 = LayoutInflater.from(context).inflate(cursor.getString(cursor.getColumnIndex("leaf")).equals(IcyHeaders.f35463C2) ? C4804R.C4810layout.f87284list_view_item_simple_text : (cursor.getString(cursor.getColumnIndex("xpath")).length() > 0 || cursor.getString(cursor.getColumnIndex(HTML.Tag.f65890V)).length() > 0) ? C4804R.C4810layout.f87290list_view_item_simple_text_goto_arrow : C4804R.C4810layout.f87285list_view_item_simple_text_arrow, viewGroup, false);
                inflate2.setTag(inflate2.findViewById(C4804R.C4808id.text));
                return inflate2;
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: net.imedicaldoctor.imd.Fragments.OVID.OvidSectionsViewer.2
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                Cursor mo45341b = ((CursorAdapter) adapterView.getAdapter()).mo45341b();
                if (mo45341b.moveToPosition(i)) {
                    String string = mo45341b.getString(mo45341b.getColumnIndex("leaf"));
                    mo45341b.getString(mo45341b.getColumnIndex("bookId"));
                    if (string.equals(IcyHeaders.f35463C2)) {
                        ((OvidViewerActivity.OvidViewerFragment) OvidSectionsViewer.this.m44753k0()).m4370B4(compressHelper.m4956U1(mo45341b));
                    } else {
                        OvidSectionsViewer ovidSectionsViewer = new OvidSectionsViewer();
                        Bundle bundle3 = new Bundle();
                        bundle3.putBundle("db", OvidSectionsViewer.this.f75134g4);
                        bundle3.putString("parentId", mo45341b.getString(mo45341b.getColumnIndex("id")));
                        ovidSectionsViewer.m44751k2(bundle3);
                        ovidSectionsViewer.m44870c3(true);
                        ovidSectionsViewer.m44844E2(OvidSectionsViewer.this.m44753k0(), 0);
                        ovidSectionsViewer.mo29915h3(OvidSectionsViewer.this.m44820L(), "OvidSectionsViewer");
                    }
                    OvidSectionsViewer.this.mo27003Q2();
                }
            }
        });
        builder.setView(inflate);
        return builder.create();
    }
}
