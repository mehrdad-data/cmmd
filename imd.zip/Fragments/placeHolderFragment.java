package net.imedicaldoctor.imd.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class placeHolderFragment extends Fragment {
    @Override // androidx.fragment.app.Fragment
    @Nullable
    /* renamed from: U0 */
    public View mo3277U0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(C4804R.C4810layout.f87184fragment_placeholder, viewGroup, false);
    }
}
