package net.imedicaldoctor.imd.Fragments;

import android.graphics.drawable.Drawable;

/* loaded from: classes2.dex */
public class DrawableUtils {

    /* renamed from: a */
    private static final int[] f74337a = new int[0];

    /* renamed from: a */
    public static void m4675a(Drawable drawable) {
        if (drawable != null) {
            drawable.setState(f74337a);
        }
    }
}
