package net.imedicaldoctor.imd;

import android.content.Context;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils;
import com.google.android.exoplayer2.metadata.icy.IcyHeaders;
import com.google.android.exoplayer2.text.ttml.TtmlNode;
import com.google.common.base.Ascii;
import com.google.common.primitives.SignedBytes;
import com.google.common.primitives.UnsignedBytes;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.itextpdf.text.DocWriter;
import com.itextpdf.text.pdf.PdfWriter;
import com.p009dd.plist.ASCIIPropertyListParser;
import com.p009dd.plist.NSDictionary;
import com.p009dd.plist.PropertyListParser;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import net.imedicaldoctor.imd.Data.CompressHelper;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.p024io.FileUtils;

/* loaded from: classes2.dex */
public class VBHelper {

    /* renamed from: d */
    static String[] f83208d;

    /* renamed from: e */
    static String f83209e;

    /* renamed from: f */
    static String f83210f;

    /* renamed from: g */
    static String f83211g;

    /* renamed from: a */
    Context f83212a;

    /* renamed from: b */
    CompressHelper f83213b;

    /* renamed from: c */
    Bundle f83214c;

    public VBHelper(Context context) {
        this.f83212a = context;
    }

    /* renamed from: a */
    public byte[] m3432a() {
        String str;
        String string = PreferenceManager.getDefaultSharedPreferences(this.f83212a).getString("ActivationCode", "");
        if (string.length() == 0) {
            return null;
        }
        try {
            str = new String(m3425h(m3421l().toCharArray(), new byte[]{122, 12, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A}, new byte[]{117, 115, 111, 102, 103, 104, 111, 111, 108, 122, 120, 119, 111, 91, 110, 109}, m3413t(string)));
        } catch (Exception unused) {
            str = null;
        }
        if (str == null) {
            PreferenceManager.getDefaultSharedPreferences(this.f83212a).edit().remove("ActivationCode").commit();
            return null;
        }
        return m3413t(string);
    }

    /* renamed from: b */
    public Bundle m3431b(byte[] bArr) {
        return m3429d(bArr, null);
    }

    /* renamed from: c */
    public Bundle m3430c(File file) {
        try {
            return m3429d(FileUtils.readFileToByteArray(file), file);
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            iMDLogger.m3294f("analyzeVBE vbeFile", "Error in reading vbe file " + e.toString());
            e.printStackTrace();
            return null;
        }
    }

    /* renamed from: d */
    public Bundle m3429d(byte[] bArr, File file) {
        String m3427f;
        Bundle m3422k;
        String[] m38518w;
        if (this.f83213b == null) {
            this.f83213b = new CompressHelper(this.f83212a);
        }
        if (file != null) {
            try {
                m3427f = m3427f(file.getAbsolutePath(), (file.length() + file.lastModified()) + "");
            } catch (Exception e) {
                iMDLogger.m3294f("AnalyzeVBE", "Error in decrypting " + e.getMessage());
                e.printStackTrace();
                return null;
            }
        } else {
            m3427f = null;
        }
        boolean z = true;
        if (m3427f == null) {
            NSDictionary nSDictionary = (NSDictionary) PropertyListParser.m38465h(new String(m3425h(TextUtils.split(m3410w(m3421l()).replace("||", "::"), "::")[1].toCharArray(), "info.vb ".getBytes("UTF-8"), new byte[]{17, 115, 105, 102, 103, 104, 111, 107, 108, 122, 120, 119, 118, 98, 110, 109}, bArr)).replace("&", "&amp;").getBytes("UTF-8"));
            m3422k = new Bundle();
            for (String str : nSDictionary.m38518w()) {
                m3422k.putString(str, nSDictionary.m38531S(str).toString().replace("soheilvb", "&"));
            }
            if (file != null) {
                this.f83213b.m4875t0(file.getAbsolutePath(), m3411v(m3422k), (file.length() + file.lastModified()) + "");
            }
        } else {
            m3422k = m3422k(m3427f);
        }
        StringBuilder sb = new StringBuilder();
        if (m3422k.containsKey("Version")) {
            z = m3409x(m3422k.getString("Name"), m3422k.getString("Version"), sb);
            if (sb.toString().length() > 0) {
                m3422k.putString("ExpDate", sb.toString());
            }
        }
        if (!z) {
            m3422k.putString("Inactive", IcyHeaders.f35463C2);
            if (m3412u(m3422k.getString("Type"))) {
                m3422k.putString("Demu", IcyHeaders.f35463C2);
            }
        }
        return m3422k;
    }

    /* renamed from: e */
    public String m3428e(byte[] bArr) {
        char[] cArr = {'0', '1', PdfWriter.f63161R3, PdfWriter.f63163S3, PdfWriter.f63165T3, PdfWriter.f63167U3, PdfWriter.f63169V3, PdfWriter.f63171W3, '8', '9', 'A', ASCIIPropertyListParser.f30133u, 'C', ASCIIPropertyListParser.f30132t, 'E', 'F'};
        char[] cArr2 = new char[bArr.length * 2];
        for (int i = 0; i < bArr.length; i++) {
            int i2 = bArr[i] & UnsignedBytes.f54281b;
            int i3 = i * 2;
            cArr2[i3] = cArr[i2 >>> 4];
            cArr2[i3 + 1] = cArr[i2 & 15];
        }
        return new String(cArr2);
    }

    /* renamed from: f */
    public String m3427f(String str, String str2) {
        Bundle m3414s = m3414s();
        if (m3414s.containsKey(str)) {
            Bundle bundle = m3414s.getBundle(str);
            if (bundle.getString("cachevalidation").equals(str2)) {
                return bundle.getString("cachecontent");
            }
            CompressHelper compressHelper = this.f83213b;
            String m4863x0 = compressHelper.m4863x0();
            compressHelper.m4885q(m4863x0, "Delete from cache where cachekey = '" + str + "'");
        }
        return null;
    }

    /* renamed from: g */
    public byte[] m3426g(char[] cArr, byte[] bArr, byte[] bArr2, byte[] bArr3) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(new PBEKeySpec(cArr, bArr, 19, 128)).getEncoded(), "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(bArr2);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
        cipher.init(1, secretKeySpec, ivParameterSpec);
        return cipher.doFinal(bArr3);
    }

    /* renamed from: h */
    public byte[] m3425h(char[] cArr, byte[] bArr, byte[] bArr2, byte[] bArr3) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(new PBEKeySpec(cArr, bArr, 19, 128)).getEncoded(), "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(bArr2);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
        cipher.init(2, secretKeySpec, ivParameterSpec);
        return cipher.doFinal(bArr3);
    }

    /* renamed from: i */
    public String m3424i(String str, String str2) {
        if (str2.equals("127")) {
            byte[] bArr = {Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36, 37, 38, 39, Ascii.f51309H, Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36};
            try {
                return new String(m3425h("hs;d,hghdk[;ak".toCharArray(), new byte[]{122, 12, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A}, bArr, m3413t(str)));
            } catch (Exception unused) {
                return null;
            }
        }
        return null;
    }

    /* renamed from: j */
    public String m3423j(String str, String str2, String str3) {
        if (str2.equals("127")) {
            byte[] bArr = {Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36, 37, 38, 39, Ascii.f51309H, Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36};
            try {
                return new String(m3425h(str3.toCharArray(), new byte[]{122, 12, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A}, bArr, m3413t(str)));
            } catch (Exception unused) {
                return null;
            }
        }
        return null;
    }

    /* renamed from: k */
    public Bundle m3422k(String str) {
        String[] splitByWholeSeparator = StringUtils.splitByWholeSeparator(str, "$$$");
        Bundle bundle = new Bundle();
        for (String str2 : splitByWholeSeparator) {
            String[] splitByWholeSeparator2 = StringUtils.splitByWholeSeparator(str2, ":::");
            bundle.putString(splitByWholeSeparator2[0], splitByWholeSeparator2[1]);
        }
        return bundle;
    }

    /* renamed from: l */
    public String m3421l() {
        int i = 0;
        try {
            i = this.f83212a.getPackageManager().getPackageInfo(this.f83212a.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
        }
        String string = Settings.Secure.getString(this.f83212a.getContentResolver(), "android_id");
        if (string == null) {
            string = "soheilvb";
        }
        if (PreferenceManager.getDefaultSharedPreferences(this.f83212a).contains("DS")) {
            String string2 = PreferenceManager.getDefaultSharedPreferences(this.f83212a).getString("DS", "");
            String m3423j = m3423j(string2, "127", string + "30");
            if (m3423j != null) {
                return m3423j;
            }
        }
        byte[] bArr = {Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36, 37, 38, 39, Ascii.f51309H, Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36};
        byte[] bArr2 = {122, 13, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A};
        try {
            String replace = m3428e(m3426g("hs;d,hghdk[;".toCharArray(), bArr2, bArr, (UUID.randomUUID().toString() + ",,,,," + String.valueOf(i)).getBytes("UTF-8"))).replace("\n", "XX");
            String m3419n = m3419n(replace, "127", string + "30");
            if (PreferenceManager.getDefaultSharedPreferences(this.f83212a).contains("DS")) {
                PreferenceManager.getDefaultSharedPreferences(this.f83212a).edit().remove("DS").commit();
            }
            PreferenceManager.getDefaultSharedPreferences(this.f83212a).edit().putString("DS", m3419n).commit();
            return replace;
        } catch (Exception e2) {
            FirebaseCrashlytics.m18030d().m18027g(e2);
            return null;
        }
    }

    /* renamed from: m */
    public String m3420m(String str, String str2) {
        if (str2.equals("127")) {
            byte[] bArr = {Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36, 37, 38, 39, Ascii.f51309H, Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36};
            try {
                return m3428e(m3426g("hs;d,hghdk[;ak".toCharArray(), new byte[]{122, 12, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A}, bArr, str.getBytes("UTF-8")));
            } catch (Exception unused) {
                return null;
            }
        }
        return null;
    }

    /* renamed from: n */
    public String m3419n(String str, String str2, String str3) {
        if (str2.equals("127")) {
            byte[] bArr = {Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36, 37, 38, 39, Ascii.f51309H, Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36};
            try {
                return m3428e(m3426g(str3.toCharArray(), new byte[]{122, 12, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A}, bArr, str.getBytes("UTF-8")));
            } catch (Exception unused) {
                return null;
            }
        }
        return null;
    }

    /* renamed from: o */
    public String m3418o(byte[] bArr, String str) {
        if (str.equals("127")) {
            byte[] bArr2 = {Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36, 37, 38, 39, Ascii.f51309H, Ascii.f51310I, 32, 33, DocWriter.f59886G2, 35, 36};
            try {
                return m3428e(m3426g("hs;d,hghdk[;ak".toCharArray(), new byte[]{122, 12, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A}, bArr2, bArr));
            } catch (Exception unused) {
                return null;
            }
        }
        return null;
    }

    /* renamed from: p */
    public String m3417p(String str, String str2) {
        for (int length = str2.length(); length < 8; length++) {
            str2 = str2 + StringUtils.SPACE;
        }
        try {
            return m3428e(m3426g("soheilvb'ghndhj,v".toCharArray(), str2.getBytes("UTF-8"), new byte[]{117, 115, 111, 102, 103, 104, 111, 111, 108, 122, 120, 119, 111, 91, 110, 109}, str.getBytes("UTF-8")));
        } catch (Exception e) {
            FirebaseCrashlytics.m18030d().m18027g(e);
            return null;
        }
    }

    /* renamed from: q */
    public String m3416q() {
        return PreferenceManager.getDefaultSharedPreferences(this.f83212a).getString("ActivationCode", "");
    }

    /* renamed from: r */
    public void m3415r() {
        String m3416q = m3416q();
        if (m3416q == f83209e) {
            return;
        }
        String[] split = TextUtils.split(m3410w(m3421l()).replace("||", "::"), "::");
        String str = split[1];
        String[] split2 = TextUtils.split(split[3], ",");
        f83209e = m3416q;
        f83208d = split2;
    }

    /* renamed from: s */
    public Bundle m3414s() {
        if (this.f83214c == null) {
            Bundle bundle = new Bundle();
            CompressHelper compressHelper = this.f83213b;
            ArrayList<Bundle> m4946Y = compressHelper.m4946Y(compressHelper.m4863x0(), "Select * from cache");
            if (m4946Y == null) {
                return bundle;
            }
            Iterator<Bundle> it2 = m4946Y.iterator();
            while (it2.hasNext()) {
                Bundle next = it2.next();
                bundle.putBundle(next.getString("cachekey"), next);
            }
            this.f83214c = bundle;
        }
        return this.f83214c;
    }

    /* renamed from: t */
    public byte[] m3413t(String str) {
        String trim = str.trim();
        int length = trim.length();
        byte[] bArr = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            bArr[i / 2] = (byte) ((Character.digit(trim.charAt(i), 16) << 4) + Character.digit(trim.charAt(i + 1), 16));
        }
        return bArr;
    }

    /* renamed from: u */
    public boolean m3412u(String str) {
        return TextUtils.split(m3410w(m3421l()).replace("||", "::"), "::")[6].equals("0");
    }

    /* renamed from: v */
    public String m3411v(Bundle bundle) {
        ArrayList arrayList = new ArrayList();
        for (String str : bundle.keySet()) {
            arrayList.add(str + ":::" + bundle.getString(str));
        }
        return StringUtils.join(arrayList, "$$$");
    }

    /* renamed from: w */
    public String m3410w(String str) {
        String str2;
        String m3416q = m3416q();
        if (f83211g == m3416q) {
            return f83210f;
        }
        try {
            str2 = new String(m3425h(str.toCharArray(), new byte[]{122, 12, 11, 120, 32, DocWriter.f59886G2, 56, 78, Ascii.f51341y, Ascii.f51303B, 76, Ascii.f51341y, 65, 32, 76, Ascii.f51310I, Ascii.f51303B, SignedBytes.f54277a, Ascii.f51302A}, new byte[]{117, 115, 111, 102, 103, 104, 111, 111, 108, 122, 120, 119, 111, 91, 110, 109}, m3432a()));
        } catch (Exception unused) {
            str2 = null;
        }
        if (str2 == null) {
            PreferenceManager.getDefaultSharedPreferences(this.f83212a).edit().remove("ActivationCode").commit();
            return null;
        }
        FirebaseCrashlytics.m18030d().m18016r(TextUtils.split(str2.replace("||", "::"), "::")[9]);
        f83210f = str2;
        f83211g = m3416q;
        return str2;
    }

    /* renamed from: x */
    public boolean m3409x(String str, String str2, StringBuilder sb) {
        String[] strArr;
        ArrayList arrayList = new ArrayList();
        Bundle bundle = new Bundle();
        m3415r();
        for (String str3 : f83208d) {
            if (str3.contains("$$$")) {
                String str4 = StringUtils.splitByWholeSeparator(str3, "$$$")[0];
                if (str4.contains("-expired")) {
                    str4 = str4.replace("-expired", "");
                }
                arrayList.add(str4);
                bundle.putString(str4, StringUtils.splitByWholeSeparator(str3, "$$$")[1]);
            } else {
                arrayList.add(str3);
            }
        }
        if (!arrayList.contains(TtmlNode.f38128r0)) {
            if (!arrayList.contains(str)) {
                return false;
            }
            if (bundle.containsKey(str)) {
                String string = bundle.getString(str);
                String format = new SimpleDateFormat("yyyyMMdd").format(new Date());
                sb.append(string);
                if (str2.length() == 6) {
                    string = string.substring(0, 6);
                    format = format.substring(0, 6);
                }
                if (string.compareTo(str2) < 0) {
                    return false;
                }
                if (str.equals("uptodateonline") && string.compareTo(format) < 0) {
                    return false;
                }
            }
        }
        return true;
    }

    /* renamed from: y */
    public Bundle m3408y() {
        String[] strArr;
        m3415r();
        Bundle bundle = new Bundle();
        for (String str : f83208d) {
            if (str.contains("$$$")) {
                String str2 = StringUtils.splitByWholeSeparator(str, "$$$")[0];
                if (str2.contains("-expired")) {
                    str2 = str2.replace("-expired", "");
                }
                bundle.putString(str2, StringUtils.splitByWholeSeparator(str, "$$$")[1]);
            } else {
                bundle.putString(str, "0");
            }
        }
        return bundle;
    }
}
