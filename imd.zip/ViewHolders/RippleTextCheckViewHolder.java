package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextCheckViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83270I;

    /* renamed from: J */
    public MaterialRippleLayout f83271J;

    /* renamed from: K */
    public ImageView f83272K;

    public RippleTextCheckViewHolder(View view) {
        super(view);
        this.f83270I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83271J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83272K = (ImageView) view.findViewById(C4804R.C4808id.f86840check_icon);
    }
}
