package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextFullViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83284I;

    /* renamed from: J */
    public TextView f83285J;

    /* renamed from: K */
    public ImageView f83286K;

    /* renamed from: L */
    public ImageView f83287L;

    /* renamed from: M */
    public MaterialRippleLayout f83288M;

    public RippleTextFullViewHolder(View view) {
        super(view);
        this.f83284I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83285J = (TextView) view.findViewById(C4804R.C4808id.f87032sub_text_view);
        this.f83288M = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83286K = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        this.f83287L = (ImageView) view.findViewById(C4804R.C4808id.f86800arrow);
    }
}
