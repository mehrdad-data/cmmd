package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextCircleViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83273I;

    /* renamed from: J */
    public TextView f83274J;

    /* renamed from: K */
    public ImageView f83275K;

    /* renamed from: L */
    public ImageView f83276L;

    /* renamed from: M */
    public MaterialRippleLayout f83277M;

    public RippleTextCircleViewHolder(View view) {
        super(view);
        this.f83273I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83277M = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83275K = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        this.f83276L = (ImageView) view.findViewById(C4804R.C4808id.f86800arrow);
        this.f83274J = (TextView) view.findViewById(C4804R.C4808id.f87053text_number);
    }
}
