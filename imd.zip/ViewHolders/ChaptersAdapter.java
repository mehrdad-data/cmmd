package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class ChaptersAdapter extends RecyclerView.Adapter {

    /* renamed from: d */
    public Context f83215d;

    /* renamed from: e */
    public ArrayList<Bundle> f83216e;

    /* renamed from: f */
    public String f83217f;

    /* renamed from: g */
    public int f83218g;

    /* renamed from: h */
    public String f83219h;

    public ChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
        this(context, arrayList, str, C4804R.C4810layout.f87261list_view_item_ripple_text);
    }

    public ChaptersAdapter(Context context, ArrayList<Bundle> arrayList, String str, int i) {
        this.f83215d = context;
        this.f83216e = arrayList;
        this.f83217f = str;
        this.f83218g = i;
        this.f83219h = "Nothing";
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
        ArrayList<Bundle> arrayList = this.f83216e;
        if (arrayList == null || arrayList.size() == 0) {
            ((MessageViewHolder) viewHolder).f83248I.setText(this.f83219h);
        } else {
            mo3406e0(viewHolder, this.f83216e.get(i), i);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        ArrayList<Bundle> arrayList = this.f83216e;
        if (arrayList == null || arrayList.size() == 0) {
            return new MessageViewHolder(this.f83215d, LayoutInflater.from(this.f83215d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
        }
        return mo3403h0(LayoutInflater.from(this.f83215d).inflate(this.f83218g, viewGroup, false));
    }

    /* renamed from: d0 */
    public String mo3407d0(String str) {
        return str;
    }

    /* renamed from: e0 */
    public void mo3406e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle, final int i) {
        RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
        rippleTextViewHolder.f83300I.setText(mo3407d0(bundle.getString(this.f83217f)));
        rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.ChaptersAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChaptersAdapter.this.mo3405f0(bundle, i);
            }
        });
    }

    /* renamed from: f0 */
    public void mo3405f0(Bundle bundle, int i) {
    }

    /* renamed from: g0 */
    public void m3404g0(ArrayList<Bundle> arrayList) {
        this.f83216e = arrayList;
        m42860G();
    }

    /* renamed from: h0 */
    public RecyclerView.ViewHolder mo3403h0(View view) {
        return new RippleTextViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        ArrayList<Bundle> arrayList = this.f83216e;
        if (arrayList == null || arrayList.size() == 0) {
            return 1;
        }
        return this.f83216e.size();
    }
}
