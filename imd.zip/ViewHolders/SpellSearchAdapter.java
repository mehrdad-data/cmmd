package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class SpellSearchAdapter extends RecyclerView.Adapter {

    /* renamed from: d */
    public Context f83303d;

    /* renamed from: e */
    public ArrayList<Bundle> f83304e;

    /* renamed from: f */
    public ArrayList<Bundle> f83305f;

    /* renamed from: g */
    public String f83306g;

    /* renamed from: h */
    public String f83307h;

    /* renamed from: i */
    public int f83308i;

    public SpellSearchAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2) {
        this(context, arrayList, str, str2, C4804R.C4810layout.f87274list_view_item_search_content_ripple);
    }

    public SpellSearchAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2, int i) {
        this.f83303d = context;
        this.f83304e = arrayList;
        this.f83306g = str;
        this.f83307h = str2;
        this.f83308i = i;
        this.f83305f = new ArrayList<>();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: C */
    public int mo3384C(int i) {
        if (m3381f0() == 0) {
            return 0;
        }
        ArrayList<Bundle> arrayList = this.f83304e;
        if (arrayList == null || arrayList.size() <= 0) {
            return i == 0 ? 3 : 4;
        } else if (i == 0) {
            return 1;
        } else {
            if (i < this.f83304e.size() + 1) {
                return 2;
            }
            return i == this.f83304e.size() + 1 ? 3 : 4;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
        TextView textView;
        String str;
        if (m3381f0() == 0) {
            MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
            return;
        }
        int m42556F = viewHolder.m42556F();
        if (m42556F == 1) {
            textView = ((SpellHeaderViewHolder) viewHolder).f83302I;
            str = "Matched";
        } else if (m42556F == 2) {
            int i2 = i - 1;
            mo3382e0(viewHolder, this.f83304e.get(i2), i2);
            return;
        } else if (m42556F != 3) {
            if (m42556F == 4) {
                SpellTextViewHolder spellTextViewHolder = (SpellTextViewHolder) viewHolder;
                ArrayList<Bundle> arrayList = this.f83304e;
                int i3 = 0;
                if (arrayList != null && arrayList.size() > 0) {
                    i3 = this.f83304e.size() + 0 + 1;
                }
                int i4 = i - (i3 + 1);
                ArrayList<Bundle> arrayList2 = this.f83305f;
                if (arrayList2 != null && i4 <= arrayList2.size() - 1) {
                    final Bundle bundle = this.f83305f.get(i4);
                    spellTextViewHolder.f83314I.setText(bundle.getString("word"));
                    spellTextViewHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            SpellSearchAdapter.this.mo3379h0(bundle);
                        }
                    });
                    return;
                }
                return;
            }
            return;
        } else {
            textView = ((SpellHeaderViewHolder) viewHolder).f83302I;
            str = "Did you mean";
        }
        textView.setText(str);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return new MessageViewHolder(this.f83303d, LayoutInflater.from(this.f83303d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
        } else if (i == 1) {
            return new SpellHeaderViewHolder(LayoutInflater.from(this.f83303d).inflate(C4804R.C4810layout.f87295list_view_item_spell_header, viewGroup, false));
        } else {
            if (i == 2) {
                return mo3377j0(LayoutInflater.from(this.f83303d).inflate(this.f83308i, viewGroup, false));
            }
            if (i == 3) {
                return new SpellHeaderViewHolder(LayoutInflater.from(this.f83303d).inflate(C4804R.C4810layout.f87295list_view_item_spell_header, viewGroup, false));
            }
            if (i == 4) {
                return new SpellTextViewHolder(LayoutInflater.from(this.f83303d).inflate(C4804R.C4810layout.f87278list_view_item_search_spell, viewGroup, false));
            }
            return null;
        }
    }

    /* renamed from: d0 */
    public String mo3383d0(String str) {
        return str;
    }

    /* renamed from: e0 */
    public void mo3382e0(RecyclerView.ViewHolder viewHolder, final Bundle bundle, final int i) {
        RippleSearchContentViewHolder rippleSearchContentViewHolder = (RippleSearchContentViewHolder) viewHolder;
        rippleSearchContentViewHolder.f83264I.setText(mo3383d0(bundle.getString(this.f83306g)));
        if (this.f83307h == null) {
            rippleSearchContentViewHolder.f83265J.setVisibility(8);
        } else {
            rippleSearchContentViewHolder.f83265J.setVisibility(0);
            rippleSearchContentViewHolder.f83265J.setText(Html.fromHtml(bundle.getString(this.f83307h)));
        }
        rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.SpellSearchAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SpellSearchAdapter.this.mo3380g0(bundle, i);
            }
        });
    }

    /* renamed from: f0 */
    public int m3381f0() {
        ArrayList<Bundle> arrayList = this.f83304e;
        int size = arrayList != null ? 0 + arrayList.size() : 0;
        ArrayList<Bundle> arrayList2 = this.f83305f;
        return arrayList2 != null ? size + arrayList2.size() : size;
    }

    /* renamed from: g0 */
    public void mo3380g0(Bundle bundle, int i) {
    }

    /* renamed from: h0 */
    public void mo3379h0(Bundle bundle) {
    }

    /* renamed from: i0 */
    public void m3378i0(ArrayList<Bundle> arrayList, ArrayList<Bundle> arrayList2) {
        this.f83304e = arrayList;
        this.f83305f = arrayList2;
        m42860G();
    }

    /* renamed from: j0 */
    public RecyclerView.ViewHolder mo3377j0(View view) {
        return new RippleSearchContentViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        int m3381f0 = m3381f0();
        if (m3381f0 == 0) {
            return 1;
        }
        return m3381f0 + 2;
    }
}
