package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class StickySectionAdapter extends RecyclerView.Adapter implements StickyRecyclerHeadersAdapter {

    /* renamed from: d */
    public Context f83318d;

    /* renamed from: e */
    public ArrayList<Bundle> f83319e;

    /* renamed from: f */
    public String f83320f;

    /* renamed from: g */
    public int f83321g;

    public StickySectionAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
        this(context, arrayList, str, C4804R.C4810layout.f87261list_view_item_ripple_text);
    }

    public StickySectionAdapter(Context context, ArrayList<Bundle> arrayList, String str, int i) {
        this.f83318d = context;
        this.f83319e = arrayList;
        this.f83320f = str;
        this.f83321g = i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
        m3372g0(viewHolder, m3374e0(i, this.f83319e).getBundle("Item"), i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        return m3367l0(LayoutInflater.from(this.f83318d).inflate(this.f83321g, viewGroup, false));
    }

    /* renamed from: d0 */
    public int m3375d0(int i, ArrayList<Bundle> arrayList) {
        int i2 = 0;
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            i2 += arrayList.get(i3).getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
            if (i < i2) {
                return i3;
            }
        }
        return 0;
    }

    /* renamed from: e0 */
    public Bundle m3374e0(int i, ArrayList<Bundle> arrayList) {
        Iterator<Bundle> it2 = arrayList.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            Bundle next = it2.next();
            i2 += next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
            if (i < i2) {
                int size = i - (i2 - next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size());
                Bundle bundle = new Bundle();
                bundle.putBundle("Item", (Bundle) next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).get(size));
                bundle.putString("Title", next.getString("title"));
                return bundle;
            }
        }
        return null;
    }

    /* renamed from: f0 */
    public String m3373f0(String str) {
        return str;
    }

    /* renamed from: g0 */
    public void m3372g0(RecyclerView.ViewHolder viewHolder, final Bundle bundle, final int i) {
        RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
        rippleTextViewHolder.f83300I.setText(m3373f0(bundle.getString(this.f83320f)));
        rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.StickySectionAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                StickySectionAdapter.this.mo3371h0(bundle, i);
            }
        });
    }

    /* renamed from: h0 */
    public void mo3371h0(Bundle bundle, int i) {
    }

    /* renamed from: i0 */
    public void m3370i0(ArrayList<Bundle> arrayList) {
        this.f83319e = arrayList;
        m42860G();
    }

    /* renamed from: j0 */
    public String mo3369j0(String str) {
        return str;
    }

    /* renamed from: k0 */
    public int m3368k0(ArrayList<Bundle> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return 0;
        }
        Iterator<Bundle> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            i += it2.next().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
        }
        return i;
    }

    /* renamed from: l0 */
    public RecyclerView.ViewHolder m3367l0(View view) {
        return new RippleTextViewHolder(view);
    }

    @Override // com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter
    /* renamed from: n */
    public RecyclerView.ViewHolder mo3366n(ViewGroup viewGroup) {
        return new SpellHeaderViewHolder(LayoutInflater.from(this.f83318d).inflate(C4804R.C4810layout.f87295list_view_item_spell_header, viewGroup, false));
    }

    @Override // com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter
    /* renamed from: o */
    public void mo3365o(RecyclerView.ViewHolder viewHolder, int i) {
        SpellHeaderViewHolder spellHeaderViewHolder = (SpellHeaderViewHolder) viewHolder;
        ArrayList<Bundle> arrayList = this.f83319e;
        if (arrayList == null) {
            return;
        }
        spellHeaderViewHolder.f83302I.setText(mo3369j0(m3374e0(i, arrayList).getString("Title")));
    }

    @Override // com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter
    /* renamed from: q */
    public long mo3364q(int i) {
        return Long.valueOf(m3375d0(i, this.f83319e)).longValue();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        return m3368k0(this.f83319e);
    }
}
