package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextImageViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83297I;

    /* renamed from: J */
    public ImageView f83298J;

    /* renamed from: K */
    public MaterialRippleLayout f83299K;

    public RippleTextImageViewHolder(View view) {
        super(view);
        this.f83297I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83299K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83298J = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
    }
}
