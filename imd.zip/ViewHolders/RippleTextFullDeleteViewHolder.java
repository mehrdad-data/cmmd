package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextFullDeleteViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83278I;

    /* renamed from: J */
    public TextView f83279J;

    /* renamed from: K */
    public ImageView f83280K;

    /* renamed from: L */
    public ImageView f83281L;

    /* renamed from: M */
    public MaterialRippleLayout f83282M;

    /* renamed from: N */
    public ImageView f83283N;

    public RippleTextFullDeleteViewHolder(View view) {
        super(view);
        this.f83278I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83279J = (TextView) view.findViewById(C4804R.C4808id.f87032sub_text_view);
        this.f83282M = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83280K = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        this.f83281L = (ImageView) view.findViewById(C4804R.C4808id.f86800arrow);
        this.f83283N = (ImageView) view.findViewById(C4804R.C4808id.f87005remove_icon);
    }
}
