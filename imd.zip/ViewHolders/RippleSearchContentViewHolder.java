package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleSearchContentViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83264I;

    /* renamed from: J */
    public TextView f83265J;

    /* renamed from: K */
    public MaterialRippleLayout f83266K;

    public RippleSearchContentViewHolder(View view) {
        super(view);
        this.f83264I = (TextView) view.findViewById(C4804R.C4808id.f87060title_text);
        this.f83265J = (TextView) view.findViewById(C4804R.C4808id.f87036subtitle_text);
        this.f83266K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
    }
}
