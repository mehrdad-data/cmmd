package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextGotoViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83289I;

    /* renamed from: J */
    public MaterialRippleLayout f83290J;

    /* renamed from: K */
    public ImageView f83291K;

    /* renamed from: L */
    public ImageView f83292L;

    public RippleTextGotoViewHolder(View view) {
        super(view);
        this.f83289I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83290J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83291K = (ImageView) view.findViewById(C4804R.C4808id.f86940info_button);
        this.f83292L = (ImageView) view.findViewById(C4804R.C4808id.f86968next_icon);
    }
}
