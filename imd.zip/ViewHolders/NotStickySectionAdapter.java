package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.analytics.FirebaseAnalytics;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class NotStickySectionAdapter extends RecyclerView.Adapter {

    /* renamed from: d */
    public Context f83250d;

    /* renamed from: e */
    public ArrayList<Bundle> f83251e;

    /* renamed from: f */
    public String f83252f;

    /* renamed from: g */
    public int f83253g;

    /* renamed from: h */
    public int f83254h;

    /* renamed from: i */
    public String f83255i;

    /* loaded from: classes2.dex */
    public static class HeaderCellViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f83259I;

        public HeaderCellViewHolder(View view) {
            super(view);
            this.f83259I = (TextView) view.findViewById(C4804R.C4808id.f86913header_text);
        }
    }

    public NotStickySectionAdapter(Context context, ArrayList<Bundle> arrayList, String str) {
        this(context, arrayList, str, C4804R.C4810layout.f87261list_view_item_ripple_text);
    }

    public NotStickySectionAdapter(Context context, ArrayList<Bundle> arrayList, String str, int i) {
        this(context, arrayList, str, i, C4804R.C4810layout.f87228list_view_item_database_card_header);
    }

    public NotStickySectionAdapter(Context context, ArrayList<Bundle> arrayList, String str, int i, int i2) {
        this.f83250d = context;
        this.f83251e = arrayList;
        this.f83252f = str;
        this.f83253g = i;
        this.f83254h = i2;
        this.f83255i = "Nothing";
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: C */
    public int mo3384C(int i) {
        ArrayList<Bundle> arrayList = this.f83251e;
        if (arrayList == null || arrayList.size() == 0) {
            return 2;
        }
        return m3392d0(i, this.f83251e).containsKey("Title") ? 1 : 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
        int m42556F = viewHolder.m42556F();
        if (m42556F == 0) {
            Bundle m3392d0 = m3392d0(i, this.f83251e);
            int i2 = m3392d0.containsKey("Index") ? m3392d0.getInt("Index") : -2;
            Bundle bundle = m3392d0.getBundle("Item");
            if (i2 > -2) {
                bundle.putInt("Index", i2);
            }
            mo3390f0(viewHolder, bundle, i);
        } else if (m42556F == 1) {
            ((HeaderCellViewHolder) viewHolder).f83259I.setText(mo3387i0(m3392d0(i, this.f83251e).getString("Title")));
        } else if (m42556F == 2) {
            ((MessageViewHolder) viewHolder).f83248I.setText(this.f83255i);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        if (i == 0) {
            return mo3385k0(LayoutInflater.from(this.f83250d).inflate(this.f83253g, viewGroup, false));
        }
        if (i == 1) {
            return new HeaderCellViewHolder(LayoutInflater.from(this.f83250d).inflate(this.f83254h, viewGroup, false));
        }
        if (i == 2) {
            return new MessageViewHolder(this.f83250d, LayoutInflater.from(this.f83250d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
        }
        return null;
    }

    /* renamed from: d0 */
    public Bundle m3392d0(int i, ArrayList<Bundle> arrayList) {
        Iterator<Bundle> it2 = arrayList.iterator();
        int i2 = 0;
        int i3 = 0;
        while (it2.hasNext()) {
            Bundle next = it2.next();
            if (i == i2) {
                Bundle bundle = new Bundle();
                bundle.putString("Title", next.getString("title"));
                bundle.putInt("Row", 0);
                bundle.putInt("Section", i3);
                bundle.putInt("Row2", 1);
                bundle.putInt("Section2", i3 - 1);
                return bundle;
            }
            int size = i2 + next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
            if (i <= size) {
                int size2 = (i - (size - next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size())) - 1;
                Bundle bundle2 = new Bundle();
                bundle2.putBundle("Item", (Bundle) next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).get(size2));
                bundle2.putInt("Row", size2);
                bundle2.putInt("Index", size2);
                bundle2.putInt("Section", i3);
                return bundle2;
            }
            i2 = size + 1;
            i3++;
        }
        return null;
    }

    /* renamed from: e0 */
    public String m3391e0(String str) {
        return str;
    }

    /* renamed from: f0 */
    public void mo3390f0(RecyclerView.ViewHolder viewHolder, final Bundle bundle, final int i) {
        RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
        rippleTextViewHolder.f83300I.setText(m3391e0(bundle.getString(this.f83252f)));
        rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.NotStickySectionAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NotStickySectionAdapter.this.m3389g0(bundle, i);
            }
        });
    }

    /* renamed from: g0 */
    public void m3389g0(Bundle bundle, int i) {
    }

    /* renamed from: h0 */
    public void m3388h0(ArrayList<Bundle> arrayList) {
        this.f83251e = arrayList;
        m42860G();
    }

    /* renamed from: i0 */
    public String mo3387i0(String str) {
        return str;
    }

    /* renamed from: j0 */
    public int m3386j0(ArrayList<Bundle> arrayList) {
        int i = 0;
        if (arrayList == null) {
            return 0;
        }
        Iterator<Bundle> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            i = i + it2.next().getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size() + 1;
        }
        return i;
    }

    /* renamed from: k0 */
    public RecyclerView.ViewHolder mo3385k0(View view) {
        return new RippleTextViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        ArrayList<Bundle> arrayList = this.f83251e;
        if (arrayList == null || arrayList.size() == 0) {
            return 1;
        }
        return m3386j0(this.f83251e);
    }
}
