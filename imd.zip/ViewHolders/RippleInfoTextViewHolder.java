package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleInfoTextViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83260I;

    /* renamed from: J */
    public ImageView f83261J;

    /* renamed from: K */
    public MaterialRippleLayout f83262K;

    /* renamed from: L */
    public ImageView f83263L;

    public RippleInfoTextViewHolder(View view) {
        super(view);
        this.f83260I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83262K = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83261J = (ImageView) view.findViewById(C4804R.C4808id.f86940info_button);
        this.f83263L = (ImageView) view.findViewById(C4804R.C4808id.f86968next_icon);
    }
}
