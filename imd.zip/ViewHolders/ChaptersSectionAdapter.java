package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter;
import java.util.ArrayList;
import java.util.Iterator;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Data.CompressHelper;

/* loaded from: classes2.dex */
public class ChaptersSectionAdapter extends RecyclerView.Adapter implements StickyRecyclerHeadersAdapter {

    /* renamed from: d */
    public Context f83223d;

    /* renamed from: e */
    public ArrayList<Bundle> f83224e;

    /* renamed from: f */
    public ArrayList<Bundle> f83225f;

    /* renamed from: g */
    public String f83226g;

    /* renamed from: h */
    public String f83227h;

    /* loaded from: classes2.dex */
    public class EmptyViewHolder extends RecyclerView.ViewHolder {
        public EmptyViewHolder(View view) {
            super(view);
        }
    }

    /* loaded from: classes2.dex */
    public class SectionHeaderViewHolder extends RecyclerView.ViewHolder {

        /* renamed from: I */
        public TextView f83232I;

        public SectionHeaderViewHolder(Context context, View view) {
            super(view);
            this.f83232I = (TextView) view.findViewById(C4804R.C4808id.text);
        }
    }

    public ChaptersSectionAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2) {
        this.f83223d = context;
        this.f83224e = arrayList;
        this.f83226g = str;
        this.f83227h = str2;
        this.f83225f = new CompressHelper(this.f83223d).m4941Z1(this.f83224e, this.f83227h);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
        ArrayList<Bundle> arrayList = this.f83224e;
        if (arrayList == null || arrayList.size() == 0) {
            ((MessageViewHolder) viewHolder).f83248I.setText("Search");
            return;
        }
        RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
        final Bundle bundle = this.f83224e.get(i);
        rippleTextViewHolder.f83300I.setText(bundle.getString(this.f83226g));
        rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.ChaptersSectionAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ChaptersSectionAdapter.this.mo3400f0(bundle, i);
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        ArrayList<Bundle> arrayList = this.f83224e;
        if (arrayList == null || arrayList.size() == 0) {
            return new MessageViewHolder(this.f83223d, LayoutInflater.from(this.f83223d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
        }
        return new RippleTextViewHolder(LayoutInflater.from(this.f83223d).inflate(C4804R.C4810layout.f87262list_view_item_ripple_text_arrow, viewGroup, false));
    }

    /* renamed from: d0 */
    public int m3402d0(int i, ArrayList<Bundle> arrayList) {
        ArrayList<Bundle> arrayList2 = this.f83224e;
        if (arrayList2 != null && arrayList2.size() != 0) {
            int i2 = 0;
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                i2 += arrayList.get(i3).getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
                if (i < i2) {
                    return i3;
                }
            }
        }
        return 0;
    }

    /* renamed from: e0 */
    public Bundle m3401e0(int i, ArrayList<Bundle> arrayList) {
        if (arrayList == null) {
            return null;
        }
        Iterator<Bundle> it2 = arrayList.iterator();
        int i2 = 0;
        while (it2.hasNext()) {
            Bundle next = it2.next();
            i2 += next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size();
            if (i < i2) {
                Bundle bundle = new Bundle();
                bundle.putBundle("Item", (Bundle) next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).get(i - (i2 - next.getParcelableArrayList(FirebaseAnalytics.Param.f55203f0).size())));
                bundle.putString("Title", next.getString("title"));
                return bundle;
            }
        }
        return null;
    }

    /* renamed from: f0 */
    public void mo3400f0(Bundle bundle, int i) {
    }

    /* renamed from: g0 */
    public void m3399g0(ArrayList<Bundle> arrayList) {
        this.f83224e = arrayList;
        this.f83225f = new CompressHelper(this.f83223d).m4941Z1(this.f83224e, this.f83227h);
        m42860G();
    }

    @Override // com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter
    /* renamed from: n */
    public RecyclerView.ViewHolder mo3366n(ViewGroup viewGroup) {
        ArrayList<Bundle> arrayList = this.f83224e;
        if (arrayList == null || arrayList.size() == 0) {
            return new EmptyViewHolder(LayoutInflater.from(this.f83223d).inflate(C4804R.C4810layout.f87245list_view_item_header_keeper, viewGroup, false));
        }
        return new SectionHeaderViewHolder(this.f83223d, LayoutInflater.from(this.f83223d).inflate(C4804R.C4810layout.f87279list_view_item_section_header, viewGroup, false));
    }

    @Override // com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter
    /* renamed from: o */
    public void mo3365o(RecyclerView.ViewHolder viewHolder, int i) {
        ArrayList<Bundle> arrayList = this.f83224e;
        if (arrayList == null || arrayList.size() == 0) {
            return;
        }
        ((SectionHeaderViewHolder) viewHolder).f83232I.setText(m3401e0(i, this.f83225f).getString("Title"));
    }

    @Override // com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter
    /* renamed from: q */
    public long mo3364q(int i) {
        return Long.valueOf(m3402d0(i, this.f83225f)).longValue();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        ArrayList<Bundle> arrayList = this.f83224e;
        if (arrayList == null || arrayList.size() == 0) {
            return 1;
        }
        return this.f83224e.size();
    }
}
