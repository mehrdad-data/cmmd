package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextImageArrowViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83293I;

    /* renamed from: J */
    public ImageView f83294J;

    /* renamed from: K */
    public ImageView f83295K;

    /* renamed from: L */
    public MaterialRippleLayout f83296L;

    public RippleTextImageArrowViewHolder(View view) {
        super(view);
        this.f83293I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83296L = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83294J = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        this.f83295K = (ImageView) view.findViewById(C4804R.C4808id.f86800arrow);
    }
}
