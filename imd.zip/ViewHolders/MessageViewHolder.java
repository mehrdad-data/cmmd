package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class MessageViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83248I;

    /* renamed from: J */
    public ImageView f83249J;

    public MessageViewHolder(Context context, View view) {
        super(view);
        this.f83248I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83249J = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        this.f83248I.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/HelveticaNeue-Light.otf"));
    }
}
