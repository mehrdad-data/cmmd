package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class StatusAdapter extends RecyclerView.Adapter {

    /* renamed from: d */
    public Context f83315d;

    /* renamed from: e */
    public String f83316e;

    public StatusAdapter(Context context, String str) {
        this.f83315d = context;
        this.f83316e = str;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
        MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
        messageViewHolder.f83248I.setText(this.f83316e);
        messageViewHolder.f18491a.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.StatusAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                StatusAdapter.this.mo3376d0();
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        return new MessageViewHolder(this.f83315d, LayoutInflater.from(this.f83315d).inflate(C4804R.C4810layout.f87221list_view_item_card_status, viewGroup, false));
    }

    /* renamed from: d0 */
    public void mo3376d0() {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        return 1;
    }
}
