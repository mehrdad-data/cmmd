package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class ContentSearchAdapter extends RecyclerView.Adapter {

    /* renamed from: d */
    public Context f83234d;

    /* renamed from: e */
    public ArrayList<Bundle> f83235e;

    /* renamed from: f */
    public String f83236f;

    /* renamed from: g */
    public String f83237g;

    /* renamed from: h */
    public int f83238h;

    public ContentSearchAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2) {
        this.f83234d = context;
        this.f83235e = arrayList;
        this.f83236f = str;
        this.f83237g = str2;
        this.f83238h = C4804R.C4810layout.f87274list_view_item_search_content_ripple;
    }

    public ContentSearchAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2, int i) {
        this.f83234d = context;
        this.f83235e = arrayList;
        this.f83236f = str;
        this.f83237g = str2;
        this.f83238h = i;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, int i) {
        ArrayList<Bundle> arrayList = this.f83235e;
        if (arrayList == null || arrayList.size() == 0) {
            MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
        } else {
            mo3398d0(viewHolder, i, this.f83235e.get(i));
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        ArrayList<Bundle> arrayList = this.f83235e;
        if (arrayList == null || arrayList.size() == 0) {
            return new MessageViewHolder(this.f83234d, LayoutInflater.from(this.f83234d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
        }
        return new RippleSearchContentViewHolder(LayoutInflater.from(this.f83234d).inflate(this.f83238h, viewGroup, false));
    }

    /* renamed from: d0 */
    public void mo3398d0(RecyclerView.ViewHolder viewHolder, final int i, final Bundle bundle) {
        RippleSearchContentViewHolder rippleSearchContentViewHolder = (RippleSearchContentViewHolder) viewHolder;
        rippleSearchContentViewHolder.f83264I.setText(bundle.getString(this.f83236f));
        if (this.f83237g == null) {
            rippleSearchContentViewHolder.f83265J.setVisibility(8);
        } else {
            rippleSearchContentViewHolder.f83265J.setVisibility(0);
            rippleSearchContentViewHolder.f83265J.setText(Html.fromHtml(bundle.getString(this.f83237g)));
        }
        rippleSearchContentViewHolder.f83266K.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.ContentSearchAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ContentSearchAdapter.this.mo3397e0(bundle, i);
            }
        });
    }

    /* renamed from: e0 */
    public void mo3397e0(Bundle bundle, int i) {
    }

    /* renamed from: f0 */
    public void m3396f0(ArrayList<Bundle> arrayList) {
        this.f83235e = arrayList;
        m42860G();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        ArrayList<Bundle> arrayList = this.f83235e;
        if (arrayList == null || arrayList.size() == 0) {
            return 1;
        }
        return this.f83235e.size();
    }
}
