package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class SpellHeaderViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83302I;

    public SpellHeaderViewHolder(View view) {
        super(view);
        this.f83302I = (TextView) view.findViewById(C4804R.C4808id.text);
    }
}
