package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
public class UTDSearchAdapter extends RecyclerView.Adapter {

    /* renamed from: d */
    public Context f83325d;

    /* renamed from: e */
    public ArrayList<Bundle> f83326e;

    /* renamed from: f */
    public String f83327f;

    /* renamed from: g */
    public String f83328g;

    public UTDSearchAdapter(Context context, ArrayList<Bundle> arrayList, String str, String str2) {
        this.f83325d = context;
        this.f83326e = arrayList;
        this.f83327f = str;
        this.f83328g = str2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: R */
    public void mo3363R(RecyclerView.ViewHolder viewHolder, final int i) {
        ArrayList<Bundle> arrayList = this.f83326e;
        if (arrayList == null || arrayList.size() == 0) {
            MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
            return;
        }
        RippleTextViewHolder rippleTextViewHolder = (RippleTextViewHolder) viewHolder;
        final Bundle bundle = this.f83326e.get(i);
        rippleTextViewHolder.f83300I.setText(bundle.getString(this.f83327f));
        rippleTextViewHolder.f83301J.setOnClickListener(new View.OnClickListener() { // from class: net.imedicaldoctor.imd.ViewHolders.UTDSearchAdapter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                UTDSearchAdapter.this.mo3361d0(bundle, i);
            }
        });
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: T */
    public RecyclerView.ViewHolder mo3362T(ViewGroup viewGroup, int i) {
        ArrayList<Bundle> arrayList = this.f83326e;
        if (arrayList == null || arrayList.size() == 0) {
            return new MessageViewHolder(this.f83325d, LayoutInflater.from(this.f83325d).inflate(C4804R.C4810layout.f87220list_view_item_card_notfound, viewGroup, false));
        }
        return new RippleTextViewHolder(LayoutInflater.from(this.f83325d).inflate(C4804R.C4810layout.f87261list_view_item_ripple_text, viewGroup, false));
    }

    /* renamed from: d0 */
    public void mo3361d0(Bundle bundle, int i) {
    }

    /* renamed from: e0 */
    public void m3360e0(ArrayList<Bundle> arrayList) {
        this.f83326e = arrayList;
        m42860G();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    /* renamed from: s */
    public int mo3359s() {
        ArrayList<Bundle> arrayList = this.f83326e;
        if (arrayList == null || arrayList.size() == 0) {
            return 1;
        }
        return this.f83326e.size();
    }
}
