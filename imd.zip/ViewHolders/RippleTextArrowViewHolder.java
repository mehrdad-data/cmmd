package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextArrowViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83267I;

    /* renamed from: J */
    public MaterialRippleLayout f83268J;

    /* renamed from: K */
    public ImageView f83269K;

    public RippleTextArrowViewHolder(View view) {
        super(view);
        this.f83267I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83268J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
        this.f83269K = (ImageView) view.findViewById(C4804R.C4808id.f86968next_icon);
    }
}
