package net.imedicaldoctor.imd.ViewHolders;

import android.content.Context;
import android.util.TypedValue;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes2.dex */
public class GridAutoFitLayoutManager extends GridLayoutManager {

    /* renamed from: a0 */
    private int f83242a0;

    /* renamed from: b0 */
    public int f83243b0;

    /* renamed from: c0 */
    private boolean f83244c0;

    public GridAutoFitLayoutManager(Context context, int i) {
        super(context, 1);
        this.f83244c0 = true;
        m3394R3(m3395Q3(context, i));
    }

    public GridAutoFitLayoutManager(Context context, int i, int i2, boolean z) {
        super(context, 1, i2, z);
        this.f83244c0 = true;
        m3394R3(m3395Q3(context, i));
    }

    /* renamed from: Q3 */
    private int m3395Q3(Context context, int i) {
        return i <= 0 ? (int) TypedValue.applyDimension(1, 48.0f, context.getResources().getDisplayMetrics()) : i;
    }

    /* renamed from: R3 */
    public void m3394R3(int i) {
        if (i <= 0 || i == this.f83242a0) {
            return;
        }
        this.f83242a0 = i;
        this.f83244c0 = true;
    }

    @Override // androidx.recyclerview.widget.GridLayoutManager, androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
    /* renamed from: o1 */
    public void mo3393o1(RecyclerView.Recycler recycler, RecyclerView.State state) {
        int m42730e0;
        int m42708m0;
        if (this.f83244c0 && this.f83242a0 > 0) {
            if (m43182M2() == 1) {
                m42730e0 = m42686z0() - m42704p0();
                m42708m0 = m42705o0();
            } else {
                m42730e0 = m42730e0() - m42700r0();
                m42708m0 = m42708m0();
            }
            int max = Math.max(1, (m42730e0 - m42708m0) / this.f83242a0);
            m43288M3(max);
            this.f83243b0 = max;
            this.f83244c0 = false;
        }
        super.mo3393o1(recycler, state);
    }
}
