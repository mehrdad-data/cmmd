package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class ImageViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public ImageView f83246I;

    /* renamed from: J */
    public MaterialRippleLayout f83247J;

    public ImageViewHolder(View view) {
        super(view);
        this.f83246I = (ImageView) view.findViewById(C4804R.C4808id.f86937image_view);
        this.f83247J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
    }
}
