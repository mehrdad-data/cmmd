package net.imedicaldoctor.imd.ViewHolders;

import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.Utils.MaterialRippleLayout;

/* loaded from: classes2.dex */
public class RippleTextViewHolder extends RecyclerView.ViewHolder {

    /* renamed from: I */
    public TextView f83300I;

    /* renamed from: J */
    public MaterialRippleLayout f83301J;

    public RippleTextViewHolder(View view) {
        super(view);
        this.f83300I = (TextView) view.findViewById(C4804R.C4808id.f87058text_view);
        this.f83301J = (MaterialRippleLayout) view.findViewById(C4804R.C4808id.f87007ripple_layout);
    }
}
