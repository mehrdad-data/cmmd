package net.imedicaldoctor.imd.Utils;

/* loaded from: classes2.dex */
public class ActionModeResponse {
    /* renamed from: a */
    public void mo3481a() {
    }

    /* renamed from: b */
    public void mo3480b() {
    }
}
