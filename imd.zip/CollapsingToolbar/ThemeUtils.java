package net.imedicaldoctor.imd.CollapsingToolbar;

import android.content.Context;
import android.content.res.TypedArray;
import net.imedicaldoctor.imd.C4804R;

/* loaded from: classes2.dex */
class ThemeUtils {

    /* renamed from: a */
    private static final int[] f73731a = {C4804R.attr.colorPrimary};

    ThemeUtils() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: a */
    public static void m5081a(Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(f73731a);
        boolean z = !obtainStyledAttributes.hasValue(0);
        obtainStyledAttributes.recycle();
        if (z) {
            throw new IllegalArgumentException("You need to use a Theme.AppCompat theme (or descendant) with the design library.");
        }
    }
}
