package net.imedicaldoctor.imd.CollapsingToolbar;

import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Interpolator;
import androidx.annotation.ColorInt;
import androidx.appcompat.C0068R;
import androidx.core.text.TextDirectionHeuristicsCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import com.google.android.exoplayer2.extractor.p010ts.TsExtractor;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes2.dex */
public final class CollapsingTextHelper {

    /* renamed from: Z */
    private static final boolean f73645Z = false;

    /* renamed from: A */
    private Paint f73647A;

    /* renamed from: B */
    private float f73648B;

    /* renamed from: C */
    private float f73649C;

    /* renamed from: D */
    private int[] f73650D;

    /* renamed from: E */
    private boolean f73651E;

    /* renamed from: G */
    private Interpolator f73653G;

    /* renamed from: H */
    private Interpolator f73654H;

    /* renamed from: I */
    private float f73655I;

    /* renamed from: J */
    private float f73656J;

    /* renamed from: K */
    private float f73657K;

    /* renamed from: L */
    private int f73658L;

    /* renamed from: M */
    private float f73659M;

    /* renamed from: N */
    private float f73660N;

    /* renamed from: O */
    private float f73661O;

    /* renamed from: P */
    private int f73662P;

    /* renamed from: Q */
    private CharSequence f73663Q;

    /* renamed from: R */
    private Bitmap f73664R;

    /* renamed from: S */
    private Bitmap f73665S;

    /* renamed from: T */
    private StaticLayout f73666T;

    /* renamed from: U */
    private float f73667U;

    /* renamed from: V */
    private float f73668V;

    /* renamed from: W */
    private float f73669W;

    /* renamed from: a */
    private final View f73671a;

    /* renamed from: b */
    private boolean f73672b;

    /* renamed from: c */
    private float f73673c;

    /* renamed from: k */
    private ColorStateList f73681k;

    /* renamed from: l */
    private ColorStateList f73682l;

    /* renamed from: m */
    private float f73683m;

    /* renamed from: n */
    private float f73684n;

    /* renamed from: o */
    private float f73685o;

    /* renamed from: p */
    private float f73686p;

    /* renamed from: q */
    private float f73687q;

    /* renamed from: r */
    private float f73688r;

    /* renamed from: s */
    private Typeface f73689s;

    /* renamed from: t */
    private Typeface f73690t;

    /* renamed from: u */
    private Typeface f73691u;

    /* renamed from: v */
    private CharSequence f73692v;

    /* renamed from: w */
    private CharSequence f73693w;

    /* renamed from: x */
    private boolean f73694x;

    /* renamed from: y */
    private boolean f73695y;

    /* renamed from: z */
    private Bitmap f73696z;

    /* renamed from: Y */
    private static final boolean f73644Y = false;

    /* renamed from: a0 */
    private static final Paint f73646a0 = null;

    /* renamed from: g */
    private int f73677g = 16;

    /* renamed from: h */
    private int f73678h = 16;

    /* renamed from: i */
    private float f73679i = 8.0f;

    /* renamed from: j */
    private float f73680j = 8.0f;

    /* renamed from: X */
    private int f73670X = 3;

    /* renamed from: F */
    private final TextPaint f73652F = new TextPaint((int) TsExtractor.f35063G);

    /* renamed from: e */
    private final Rect f73675e = new Rect();

    /* renamed from: d */
    private final Rect f73674d = new Rect();

    /* renamed from: f */
    private final RectF f73676f = new RectF();

    public CollapsingTextHelper(View view) {
        this.f73671a = view;
    }

    /* renamed from: B */
    private static float m5158B(float f, float f2, float f3, Interpolator interpolator) {
        if (interpolator != null) {
            f3 = interpolator.getInterpolation(f3);
        }
        return AnimationUtils.m5161a(f, f2, f3);
    }

    /* renamed from: D */
    private Typeface m5156D(int i) {
        TypedArray obtainStyledAttributes = this.f73671a.getContext().obtainStyledAttributes(i, new int[]{16843692});
        try {
            String string = obtainStyledAttributes.getString(0);
            if (string != null) {
                return Typeface.create(string, 0);
            }
            obtainStyledAttributes.recycle();
            return null;
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: F */
    private static boolean m5154F(Rect rect, int i, int i2, int i3, int i4) {
        return rect.left == i && rect.top == i2 && rect.right == i3 && rect.bottom == i4;
    }

    /* renamed from: I */
    private void m5151I(float f) {
        this.f73667U = f;
        ViewCompat.m46439l1(this.f73671a);
    }

    /* renamed from: P */
    private void m5144P(float f) {
        this.f73668V = f;
        ViewCompat.m46439l1(this.f73671a);
    }

    /* renamed from: V */
    private void m5138V(float f) {
        m5126f(f);
        boolean z = f73644Y && this.f73648B != 1.0f;
        this.f73695y = z;
        if (z) {
            m5121k();
            m5123i();
            m5122j();
        }
        ViewCompat.m46439l1(this.f73671a);
    }

    /* renamed from: a */
    private static int m5133a(int i, int i2, float f) {
        float f2 = 1.0f - f;
        return Color.argb((int) ((Color.alpha(i) * f2) + (Color.alpha(i2) * f)), (int) ((Color.red(i) * f2) + (Color.red(i2) * f)), (int) ((Color.green(i) * f2) + (Color.green(i2) * f)), (int) ((Color.blue(i) * f2) + (Color.blue(i2) * f)));
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x007e  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0088  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x008d  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00d2  */
    /* renamed from: b */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void m5131b() {
        /*
            Method dump skipped, instructions count: 228
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: net.imedicaldoctor.imd.CollapsingToolbar.CollapsingTextHelper.m5131b():void");
    }

    /* renamed from: c */
    private void m5129c() {
        m5127e(this.f73673c);
    }

    /* renamed from: d */
    private boolean m5128d(CharSequence charSequence) {
        return (ViewCompat.m46494X(this.f73671a) == 1 ? TextDirectionHeuristicsCompat.f12807d : TextDirectionHeuristicsCompat.f12806c).isRtl(charSequence, 0, charSequence.length());
    }

    /* renamed from: e */
    private void m5127e(float f) {
        TextPaint textPaint;
        int m5116p;
        m5107y(f);
        this.f73687q = m5158B(this.f73685o, this.f73686p, f, this.f73653G);
        this.f73688r = m5158B(this.f73683m, this.f73684n, f, this.f73653G);
        m5138V(m5158B(this.f73679i, this.f73680j, f, this.f73654H));
        Interpolator interpolator = AnimationUtils.f73640b;
        m5151I(1.0f - m5158B(0.0f, 1.0f, 1.0f - f, interpolator));
        m5144P(m5158B(1.0f, 0.0f, f, interpolator));
        if (this.f73682l != this.f73681k) {
            textPaint = this.f73652F;
            m5116p = m5133a(m5115q(), m5116p(), f);
        } else {
            textPaint = this.f73652F;
            m5116p = m5116p();
        }
        textPaint.setColor(m5116p);
        this.f73652F.setShadowLayer(m5158B(this.f73659M, this.f73655I, f, null), m5158B(this.f73660N, this.f73656J, f, null), m5158B(this.f73661O, this.f73657K, f, null), m5133a(this.f73662P, this.f73658L, f));
        ViewCompat.m46439l1(this.f73671a);
    }

    /* renamed from: f */
    private void m5126f(float f) {
        boolean z;
        int i;
        float f2;
        CharSequence charSequence;
        boolean z2;
        if (this.f73692v == null) {
            return;
        }
        float width = this.f73675e.width();
        float width2 = this.f73674d.width();
        if (m5106z(f, this.f73680j)) {
            f2 = (this.f73680j / 3.0f) * 2.0f;
            this.f73648B = 1.0f;
            Typeface typeface = this.f73691u;
            Typeface typeface2 = this.f73689s;
            if (typeface != typeface2) {
                this.f73691u = typeface2;
                z2 = true;
            } else {
                z2 = false;
            }
            z = z2;
            width2 = width;
            i = 1;
        } else {
            float f3 = this.f73680j;
            Typeface typeface3 = this.f73691u;
            Typeface typeface4 = this.f73690t;
            if (typeface3 != typeface4) {
                this.f73691u = typeface4;
                z = true;
            } else {
                z = false;
            }
            if (m5106z(f, this.f73679i)) {
                this.f73648B = 1.0f;
            } else {
                this.f73648B = f / this.f73679i;
            }
            i = this.f73670X;
            f2 = f3;
        }
        if (width2 > 0.0f) {
            z = this.f73649C != f2 || this.f73651E || z;
            this.f73649C = f2;
            this.f73651E = false;
        }
        if (this.f73693w == null || z) {
            this.f73652F.setTextSize(this.f73649C);
            this.f73652F.setTypeface(this.f73691u);
            int i2 = (int) width2;
            StaticLayout staticLayout = new StaticLayout(this.f73692v, this.f73652F, i2, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
            if (staticLayout.getLineCount() > i) {
                int i3 = i - 1;
                CharSequence charSequence2 = "";
                String subSequence = i3 > 0 ? this.f73692v.subSequence(0, staticLayout.getLineEnd(i3 - 1)) : "";
                CharSequence subSequence2 = this.f73692v.subSequence(staticLayout.getLineStart(i3), staticLayout.getLineEnd(i3));
                if (subSequence2.charAt(subSequence2.length() - 1) == ' ') {
                    charSequence2 = subSequence2.subSequence(subSequence2.length() - 1, subSequence2.length());
                    subSequence2 = subSequence2.subSequence(0, subSequence2.length() - 1);
                }
                charSequence = TextUtils.concat(subSequence, TextUtils.ellipsize(TextUtils.concat(subSequence2, "…", charSequence2), this.f73652F, width2, TextUtils.TruncateAt.END));
            } else {
                charSequence = this.f73692v;
            }
            if (!TextUtils.equals(charSequence, this.f73693w)) {
                this.f73693w = charSequence;
                this.f73694x = m5128d(charSequence);
            }
            int i4 = this.f73677g & GravityCompat.f12970d;
            this.f73666T = new StaticLayout(this.f73693w, this.f73652F, i2, i4 != 1 ? (i4 == 5 || i4 == 8388613) ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
        }
    }

    /* renamed from: g */
    private void m5125g() {
        Bitmap bitmap = this.f73696z;
        if (bitmap != null) {
            bitmap.recycle();
            this.f73696z = null;
        }
        Bitmap bitmap2 = this.f73664R;
        if (bitmap2 != null) {
            bitmap2.recycle();
            this.f73664R = null;
        }
        Bitmap bitmap3 = this.f73665S;
        if (bitmap3 != null) {
            bitmap3.recycle();
            this.f73665S = null;
        }
    }

    /* renamed from: i */
    private void m5123i() {
        if (this.f73664R != null || this.f73675e.isEmpty() || TextUtils.isEmpty(this.f73693w)) {
            return;
        }
        m5127e(0.0f);
        TextPaint textPaint = this.f73652F;
        CharSequence charSequence = this.f73693w;
        int round = Math.round(textPaint.measureText(charSequence, 0, charSequence.length()));
        int round2 = Math.round(this.f73652F.descent() - this.f73652F.ascent());
        if (round > 0 || round2 > 0) {
            this.f73664R = Bitmap.createBitmap(round, round2, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(this.f73664R);
            CharSequence charSequence2 = this.f73663Q;
            canvas.drawText(charSequence2, 0, charSequence2.length(), 0.0f, (-this.f73652F.ascent()) / this.f73648B, this.f73652F);
            if (this.f73647A == null) {
                this.f73647A = new Paint(3);
            }
        }
    }

    /* renamed from: j */
    private void m5122j() {
        if (this.f73665S != null || this.f73675e.isEmpty() || TextUtils.isEmpty(this.f73693w)) {
            return;
        }
        m5127e(0.0f);
        int round = Math.round(this.f73652F.measureText(this.f73693w, this.f73666T.getLineStart(0), this.f73666T.getLineEnd(0)));
        int round2 = Math.round(this.f73652F.descent() - this.f73652F.ascent());
        if (round > 0 || round2 > 0) {
            this.f73665S = Bitmap.createBitmap(round, round2, Bitmap.Config.ARGB_8888);
            new Canvas(this.f73665S).drawText(this.f73693w, this.f73666T.getLineStart(0), this.f73666T.getLineEnd(0), 0.0f, (-this.f73652F.ascent()) / this.f73648B, this.f73652F);
            if (this.f73647A == null) {
                this.f73647A = new Paint(3);
            }
        }
    }

    /* renamed from: k */
    private void m5121k() {
        if (this.f73696z != null || this.f73674d.isEmpty() || TextUtils.isEmpty(this.f73693w)) {
            return;
        }
        m5127e(0.0f);
        int width = this.f73666T.getWidth();
        int height = this.f73666T.getHeight();
        if (width <= 0 || height <= 0) {
            return;
        }
        this.f73696z = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        this.f73666T.draw(new Canvas(this.f73696z));
        if (this.f73647A == null) {
            this.f73647A = new Paint(3);
        }
    }

    @ColorInt
    /* renamed from: p */
    private int m5116p() {
        int[] iArr = this.f73650D;
        return iArr != null ? this.f73682l.getColorForState(iArr, 0) : this.f73682l.getDefaultColor();
    }

    @ColorInt
    /* renamed from: q */
    private int m5115q() {
        int[] iArr = this.f73650D;
        return iArr != null ? this.f73681k.getColorForState(iArr, 0) : this.f73681k.getDefaultColor();
    }

    /* renamed from: y */
    private void m5107y(float f) {
        this.f73676f.left = m5158B(this.f73674d.left, this.f73675e.left, f, this.f73653G);
        this.f73676f.top = m5158B(this.f73683m, this.f73684n, f, this.f73653G);
        this.f73676f.right = m5158B(this.f73674d.right, this.f73675e.right, f, this.f73653G);
        this.f73676f.bottom = m5158B(this.f73674d.bottom, this.f73675e.bottom, f, this.f73653G);
    }

    /* renamed from: z */
    private static boolean m5106z(float f, float f2) {
        return Math.abs(f - f2) < 0.001f;
    }

    /* renamed from: A */
    final boolean m5159A() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2 = this.f73682l;
        return (colorStateList2 != null && colorStateList2.isStateful()) || ((colorStateList = this.f73681k) != null && colorStateList.isStateful());
    }

    /* renamed from: C */
    void m5157C() {
        this.f73672b = this.f73675e.width() > 0 && this.f73675e.height() > 0 && this.f73674d.width() > 0 && this.f73674d.height() > 0;
    }

    /* renamed from: E */
    public void m5155E() {
        if (this.f73671a.getHeight() <= 0 || this.f73671a.getWidth() <= 0) {
            return;
        }
        m5131b();
        m5129c();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: G */
    public void m5153G(int i, int i2, int i3, int i4) {
        if (m5154F(this.f73675e, i, i2, i3, i4)) {
            return;
        }
        this.f73675e.set(i, i2, i3, i4);
        this.f73651E = true;
        m5157C();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: H */
    public void m5152H(int i) {
        TypedArray obtainStyledAttributes = this.f73671a.getContext().obtainStyledAttributes(i, C0068R.styleable.f2319Z6);
        if (obtainStyledAttributes.hasValue(3)) {
            this.f73682l = obtainStyledAttributes.getColorStateList(3);
        }
        if (obtainStyledAttributes.hasValue(0)) {
            this.f73680j = obtainStyledAttributes.getDimensionPixelSize(0, (int) this.f73680j);
        }
        this.f73658L = obtainStyledAttributes.getInt(6, 0);
        this.f73656J = obtainStyledAttributes.getFloat(7, 0.0f);
        this.f73657K = obtainStyledAttributes.getFloat(8, 0.0f);
        this.f73655I = obtainStyledAttributes.getFloat(9, 0.0f);
        obtainStyledAttributes.recycle();
        this.f73689s = m5156D(i);
        m5155E();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: J */
    public void m5150J(ColorStateList colorStateList) {
        if (this.f73682l != colorStateList) {
            this.f73682l = colorStateList;
            m5155E();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: K */
    public void m5149K(int i) {
        if (this.f73678h != i) {
            this.f73678h = i;
            m5155E();
        }
    }

    /* renamed from: L */
    void m5148L(float f) {
        if (this.f73680j != f) {
            this.f73680j = f;
            m5155E();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: M */
    public void m5147M(Typeface typeface) {
        if (this.f73689s != typeface) {
            this.f73689s = typeface;
            m5155E();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: N */
    public void m5146N(int i, int i2, int i3, int i4) {
        if (m5154F(this.f73674d, i, i2, i3, i4)) {
            return;
        }
        this.f73674d.set(i, i2, i3, i4);
        this.f73651E = true;
        m5157C();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: O */
    public void m5145O(int i) {
        TypedArray obtainStyledAttributes = this.f73671a.getContext().obtainStyledAttributes(i, C0068R.styleable.f2319Z6);
        if (obtainStyledAttributes.hasValue(3)) {
            this.f73681k = obtainStyledAttributes.getColorStateList(3);
        }
        if (obtainStyledAttributes.hasValue(0)) {
            this.f73679i = obtainStyledAttributes.getDimensionPixelSize(0, (int) this.f73679i);
        }
        this.f73662P = obtainStyledAttributes.getInt(6, 0);
        this.f73660N = obtainStyledAttributes.getFloat(7, 0.0f);
        this.f73661O = obtainStyledAttributes.getFloat(8, 0.0f);
        this.f73659M = obtainStyledAttributes.getFloat(9, 0.0f);
        obtainStyledAttributes.recycle();
        this.f73690t = m5156D(i);
        m5155E();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: Q */
    public void m5143Q(ColorStateList colorStateList) {
        if (this.f73681k != colorStateList) {
            this.f73681k = colorStateList;
            m5155E();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: R */
    public void m5142R(int i) {
        if (this.f73677g != i) {
            this.f73677g = i;
            m5155E();
        }
    }

    /* renamed from: S */
    void m5141S(float f) {
        if (this.f73679i != f) {
            this.f73679i = f;
            m5155E();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: T */
    public void m5140T(Typeface typeface) {
        if (this.f73690t != typeface) {
            this.f73690t = typeface;
            m5155E();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: U */
    public void m5139U(float f) {
        float m5083a = MathUtils.m5083a(f, 0.0f, 1.0f);
        if (m5083a != this.f73673c) {
            this.f73673c = m5083a;
            m5129c();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: W */
    public void m5137W(int i) {
        if (i != this.f73670X) {
            this.f73670X = i;
            m5125g();
            m5155E();
        }
    }

    /* renamed from: X */
    void m5136X(Interpolator interpolator) {
        this.f73653G = interpolator;
        m5155E();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: Y */
    public final boolean m5135Y(int[] iArr) {
        this.f73650D = iArr;
        if (m5159A()) {
            m5155E();
            return true;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: Z */
    public void m5134Z(CharSequence charSequence) {
        if (charSequence == null || !charSequence.equals(this.f73692v)) {
            this.f73692v = charSequence;
            this.f73693w = null;
            m5125g();
            m5155E();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: a0 */
    public void m5132a0(Interpolator interpolator) {
        this.f73654H = interpolator;
        m5155E();
    }

    /* renamed from: b0 */
    void m5130b0(Typeface typeface) {
        this.f73690t = typeface;
        this.f73689s = typeface;
        m5155E();
    }

    /* renamed from: h */
    public void m5124h(Canvas canvas) {
        int save = canvas.save();
        if (this.f73693w != null && this.f73672b) {
            float f = this.f73687q;
            float f2 = this.f73688r;
            boolean z = this.f73695y && this.f73696z != null;
            this.f73652F.setTextSize(this.f73649C);
            float ascent = z ? 0.0f : this.f73652F.ascent() * this.f73648B;
            float f3 = this.f73648B;
            if (f3 != 1.0f) {
                canvas.scale(f3, f3, f, f2);
            }
            float lineLeft = (this.f73687q + this.f73666T.getLineLeft(0)) - (this.f73669W * 2.0f);
            if (z) {
                this.f73647A.setAlpha((int) (this.f73668V * 255.0f));
                canvas.drawBitmap(this.f73696z, lineLeft, f2, this.f73647A);
                this.f73647A.setAlpha((int) (this.f73667U * 255.0f));
                canvas.drawBitmap(this.f73664R, f, f2, this.f73647A);
                this.f73647A.setAlpha(255);
                canvas.drawBitmap(this.f73665S, f, f2, this.f73647A);
            } else {
                canvas.translate(lineLeft, f2);
                this.f73652F.setAlpha((int) (this.f73668V * 255.0f));
                this.f73666T.draw(canvas);
                canvas.translate(f - lineLeft, 0.0f);
                this.f73652F.setAlpha((int) (this.f73667U * 255.0f));
                CharSequence charSequence = this.f73663Q;
                float f4 = -ascent;
                canvas.drawText(charSequence, 0, charSequence.length(), 0.0f, f4 / this.f73648B, this.f73652F);
                this.f73652F.setAlpha(255);
                canvas.drawText(this.f73693w, this.f73666T.getLineStart(0), this.f73666T.getLineEnd(0), 0.0f, f4 / this.f73648B, this.f73652F);
            }
        }
        canvas.restoreToCount(save);
    }

    /* renamed from: l */
    ColorStateList m5120l() {
        return this.f73682l;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: m */
    public int m5119m() {
        return this.f73678h;
    }

    /* renamed from: n */
    float m5118n() {
        return this.f73680j;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: o */
    public Typeface m5117o() {
        Typeface typeface = this.f73689s;
        return typeface != null ? typeface : Typeface.DEFAULT;
    }

    /* renamed from: r */
    ColorStateList m5114r() {
        return this.f73681k;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: s */
    public int m5113s() {
        return this.f73677g;
    }

    /* renamed from: t */
    float m5112t() {
        return this.f73679i;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: u */
    public Typeface m5111u() {
        Typeface typeface = this.f73690t;
        return typeface != null ? typeface : Typeface.DEFAULT;
    }

    /* renamed from: v */
    float m5110v() {
        return this.f73673c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: w */
    public int m5109w() {
        return this.f73670X;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: x */
    public CharSequence m5108x() {
        return this.f73692v;
    }
}
