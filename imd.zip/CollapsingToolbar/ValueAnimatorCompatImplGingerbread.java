package net.imedicaldoctor.imd.CollapsingToolbar;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat;

/* loaded from: classes2.dex */
class ValueAnimatorCompatImplGingerbread extends ValueAnimatorCompat.Impl {

    /* renamed from: k */
    private static final int f73737k = 10;

    /* renamed from: l */
    private static final int f73738l = 200;

    /* renamed from: m */
    private static final Handler f73739m = new Handler(Looper.getMainLooper());

    /* renamed from: a */
    private long f73740a;

    /* renamed from: b */
    private boolean f73741b;

    /* renamed from: c */
    private float f73742c;

    /* renamed from: g */
    private Interpolator f73746g;

    /* renamed from: h */
    private ArrayList<ValueAnimatorCompat.Impl.AnimatorListenerProxy> f73747h;

    /* renamed from: i */
    private ArrayList<ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy> f73748i;

    /* renamed from: d */
    private final int[] f73743d = new int[2];

    /* renamed from: e */
    private final float[] f73744e = new float[2];

    /* renamed from: f */
    private long f73745f = 200;

    /* renamed from: j */
    private final Runnable f73749j = new Runnable() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompatImplGingerbread.1
        @Override // java.lang.Runnable
        public void run() {
            ValueAnimatorCompatImplGingerbread.this.m5053t();
        }
    };

    ValueAnimatorCompatImplGingerbread() {
    }

    /* renamed from: o */
    private void m5058o() {
        ArrayList<ValueAnimatorCompat.Impl.AnimatorListenerProxy> arrayList = this.f73747h;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.f73747h.get(i).mo5061b();
            }
        }
    }

    /* renamed from: p */
    private void m5057p() {
        ArrayList<ValueAnimatorCompat.Impl.AnimatorListenerProxy> arrayList = this.f73747h;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.f73747h.get(i).mo5062a();
            }
        }
    }

    /* renamed from: q */
    private void m5056q() {
        ArrayList<ValueAnimatorCompat.Impl.AnimatorListenerProxy> arrayList = this.f73747h;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.f73747h.get(i).mo5060c();
            }
        }
    }

    /* renamed from: r */
    private void m5055r() {
        ArrayList<ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy> arrayList = this.f73748i;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                this.f73748i.get(i).mo5059a();
            }
        }
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: a */
    public void mo5052a(ValueAnimatorCompat.Impl.AnimatorListenerProxy animatorListenerProxy) {
        if (this.f73747h == null) {
            this.f73747h = new ArrayList<>();
        }
        this.f73747h.add(animatorListenerProxy);
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: b */
    public void mo5051b(ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy animatorUpdateListenerProxy) {
        if (this.f73748i == null) {
            this.f73748i = new ArrayList<>();
        }
        this.f73748i.add(animatorUpdateListenerProxy);
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: c */
    public void mo5050c() {
        this.f73741b = false;
        f73739m.removeCallbacks(this.f73749j);
        m5058o();
        m5057p();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: d */
    public void mo5049d() {
        if (this.f73741b) {
            this.f73741b = false;
            f73739m.removeCallbacks(this.f73749j);
            this.f73742c = 1.0f;
            m5055r();
            m5057p();
        }
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: e */
    public float mo5048e() {
        float[] fArr = this.f73744e;
        return AnimationUtils.m5161a(fArr[0], fArr[1], mo5047f());
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: f */
    public float mo5047f() {
        return this.f73742c;
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: g */
    public int mo5046g() {
        int[] iArr = this.f73743d;
        return AnimationUtils.m5160b(iArr[0], iArr[1], mo5047f());
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: h */
    public long mo5045h() {
        return this.f73745f;
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: i */
    public boolean mo5044i() {
        return this.f73741b;
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: j */
    public void mo5043j(long j) {
        this.f73745f = j;
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: k */
    public void mo5042k(float f, float f2) {
        float[] fArr = this.f73744e;
        fArr[0] = f;
        fArr[1] = f2;
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: l */
    public void mo5041l(int i, int i2) {
        int[] iArr = this.f73743d;
        iArr[0] = i;
        iArr[1] = i2;
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: m */
    public void mo5040m(Interpolator interpolator) {
        this.f73746g = interpolator;
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: n */
    public void mo5039n() {
        if (this.f73741b) {
            return;
        }
        if (this.f73746g == null) {
            this.f73746g = new AccelerateDecelerateInterpolator();
        }
        this.f73741b = true;
        this.f73742c = 0.0f;
        m5054s();
    }

    /* renamed from: s */
    final void m5054s() {
        this.f73740a = SystemClock.uptimeMillis();
        m5055r();
        m5056q();
        f73739m.postDelayed(this.f73749j, 10L);
    }

    /* renamed from: t */
    final void m5053t() {
        if (this.f73741b) {
            float m5083a = MathUtils.m5083a(((float) (SystemClock.uptimeMillis() - this.f73740a)) / ((float) this.f73745f), 0.0f, 1.0f);
            Interpolator interpolator = this.f73746g;
            if (interpolator != null) {
                m5083a = interpolator.getInterpolation(m5083a);
            }
            this.f73742c = m5083a;
            m5055r();
            if (SystemClock.uptimeMillis() >= this.f73740a + this.f73745f) {
                this.f73741b = false;
                m5057p();
            }
        }
        if (this.f73741b) {
            f73739m.postDelayed(this.f73749j, 10L);
        }
    }
}
