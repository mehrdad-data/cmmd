package net.imedicaldoctor.imd.CollapsingToolbar;

import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import androidx.interpolator.view.animation.FastOutLinearInInterpolator;
import androidx.interpolator.view.animation.FastOutSlowInInterpolator;
import androidx.interpolator.view.animation.LinearOutSlowInInterpolator;

/* loaded from: classes2.dex */
class AnimationUtils {

    /* renamed from: a */
    static final Interpolator f73639a = new LinearInterpolator();

    /* renamed from: b */
    static final Interpolator f73640b = new FastOutSlowInInterpolator();

    /* renamed from: c */
    static final Interpolator f73641c = new FastOutLinearInInterpolator();

    /* renamed from: d */
    static final Interpolator f73642d = new LinearOutSlowInInterpolator();

    /* renamed from: e */
    static final Interpolator f73643e = new DecelerateInterpolator();

    /* loaded from: classes2.dex */
    static class AnimationListenerAdapter implements Animation.AnimationListener {
        AnimationListenerAdapter() {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    AnimationUtils() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: a */
    public static float m5161a(float f, float f2, float f3) {
        return f + (f3 * (f2 - f));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: b */
    public static int m5160b(int i, int i2, float f) {
        return i + Math.round(f * (i2 - i));
    }
}
