package net.imedicaldoctor.imd.CollapsingToolbar;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.StyleRes;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.C2286R;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.badge.BadgeDrawable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import net.imedicaldoctor.imd.C4804R;
import net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat;

/* loaded from: classes2.dex */
public class CollapsingToolbarLayout extends FrameLayout {

    /* renamed from: W2 */
    private static final int f73697W2 = 600;

    /* renamed from: A2 */
    private Toolbar f73698A2;

    /* renamed from: B2 */
    private View f73699B2;

    /* renamed from: C2 */
    private View f73700C2;

    /* renamed from: D2 */
    private int f73701D2;

    /* renamed from: E2 */
    private int f73702E2;

    /* renamed from: F2 */
    private int f73703F2;

    /* renamed from: G2 */
    private int f73704G2;

    /* renamed from: H2 */
    private int f73705H2;

    /* renamed from: I2 */
    private final Rect f73706I2;

    /* renamed from: J2 */
    private final CollapsingTextHelper f73707J2;

    /* renamed from: K2 */
    private boolean f73708K2;

    /* renamed from: L2 */
    private boolean f73709L2;

    /* renamed from: M2 */
    private Drawable f73710M2;

    /* renamed from: N2 */
    Drawable f73711N2;

    /* renamed from: O2 */
    private int f73712O2;

    /* renamed from: P2 */
    private boolean f73713P2;

    /* renamed from: Q2 */
    private ValueAnimatorCompat f73714Q2;

    /* renamed from: R2 */
    private long f73715R2;

    /* renamed from: S2 */
    private int f73716S2;

    /* renamed from: T2 */
    private AppBarLayout.OnOffsetChangedListener f73717T2;

    /* renamed from: U2 */
    int f73718U2;

    /* renamed from: V2 */
    WindowInsetsCompat f73719V2;

    /* renamed from: s */
    private boolean f73720s;

    /* renamed from: z2 */
    private int f73721z2;

    /* loaded from: classes2.dex */
    public static class LayoutParams extends FrameLayout.LayoutParams {

        /* renamed from: c */
        private static final float f73724c = 0.5f;

        /* renamed from: d */
        public static final int f73725d = 0;

        /* renamed from: e */
        public static final int f73726e = 1;

        /* renamed from: f */
        public static final int f73727f = 2;

        /* renamed from: a */
        int f73728a;

        /* renamed from: b */
        float f73729b;

        @Retention(RetentionPolicy.SOURCE)
        @RestrictTo({RestrictTo.Scope.GROUP_ID})
        /* loaded from: classes2.dex */
        @interface CollapseMode {
        }

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.f73728a = 0;
            this.f73729b = 0.5f;
        }

        public LayoutParams(int i, int i2, int i3) {
            super(i, i2, i3);
            this.f73728a = 0;
            this.f73729b = 0.5f;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f73728a = 0;
            this.f73729b = 0.5f;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C2286R.styleable.f47150O6);
            this.f73728a = obtainStyledAttributes.getInt(0, 0);
            m5085d(obtainStyledAttributes.getFloat(1, 0.5f));
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f73728a = 0;
            this.f73729b = 0.5f;
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f73728a = 0;
            this.f73729b = 0.5f;
        }

        public LayoutParams(FrameLayout.LayoutParams layoutParams) {
            super(layoutParams);
            this.f73728a = 0;
            this.f73729b = 0.5f;
        }

        /* renamed from: a */
        public int m5088a() {
            return this.f73728a;
        }

        /* renamed from: b */
        public float m5087b() {
            return this.f73729b;
        }

        /* renamed from: c */
        public void m5086c(int i) {
            this.f73728a = i;
        }

        /* renamed from: d */
        public void m5085d(float f) {
            this.f73729b = f;
        }
    }

    /* loaded from: classes2.dex */
    private class OffsetUpdateListener implements AppBarLayout.OnOffsetChangedListener {
        OffsetUpdateListener() {
        }

        @Override // com.google.android.material.appbar.AppBarLayout.OnOffsetChangedListener, com.google.android.material.appbar.AppBarLayout.BaseOnOffsetChangedListener
        /* renamed from: a */
        public void mo5084a(AppBarLayout appBarLayout, int i) {
            int m5082b;
            CollapsingToolbarLayout collapsingToolbarLayout = CollapsingToolbarLayout.this;
            collapsingToolbarLayout.f73718U2 = i;
            WindowInsetsCompat windowInsetsCompat = collapsingToolbarLayout.f73719V2;
            int m46164r = windowInsetsCompat != null ? windowInsetsCompat.m46164r() : 0;
            int childCount = CollapsingToolbarLayout.this.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = CollapsingToolbarLayout.this.getChildAt(i2);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                ViewOffsetHelper m5097i = CollapsingToolbarLayout.m5097i(childAt);
                int i3 = layoutParams.f73728a;
                if (i3 == 1) {
                    m5082b = MathUtils.m5082b(-i, 0, CollapsingToolbarLayout.this.m5098h(childAt));
                } else if (i3 == 2) {
                    m5082b = Math.round((-i) * layoutParams.f73729b);
                }
                m5097i.m5027g(m5082b);
            }
            CollapsingToolbarLayout.this.m5090p();
            CollapsingToolbarLayout collapsingToolbarLayout2 = CollapsingToolbarLayout.this;
            if (collapsingToolbarLayout2.f73711N2 != null && m46164r > 0) {
                ViewCompat.m46439l1(collapsingToolbarLayout2);
            }
            CollapsingToolbarLayout.this.f73707J2.m5139U(Math.abs(i) / ((CollapsingToolbarLayout.this.getHeight() - ViewCompat.m46476c0(CollapsingToolbarLayout.this)) - m46164r));
        }
    }

    public CollapsingToolbarLayout(Context context) {
        this(context, null);
    }

    public CollapsingToolbarLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CollapsingToolbarLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f73720s = true;
        this.f73706I2 = new Rect();
        this.f73716S2 = -1;
        ThemeUtils.m5081a(context);
        CollapsingTextHelper collapsingTextHelper = new CollapsingTextHelper(this);
        this.f73707J2 = collapsingTextHelper;
        collapsingTextHelper.m5132a0(AnimationUtils.f73643e);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C2286R.styleable.f48160t6, i, C4804R.style.Widget_Design_MultilineCollapsingToolbar);
        collapsingTextHelper.m5142R(obtainStyledAttributes.getInt(3, BadgeDrawable.f48547O2));
        collapsingTextHelper.m5149K(obtainStyledAttributes.getInt(0, 8388627));
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(4, 0);
        this.f73705H2 = dimensionPixelSize;
        this.f73704G2 = dimensionPixelSize;
        this.f73703F2 = dimensionPixelSize;
        this.f73702E2 = dimensionPixelSize;
        if (obtainStyledAttributes.hasValue(7)) {
            this.f73702E2 = obtainStyledAttributes.getDimensionPixelSize(7, 0);
        }
        if (obtainStyledAttributes.hasValue(6)) {
            this.f73704G2 = obtainStyledAttributes.getDimensionPixelSize(6, 0);
        }
        if (obtainStyledAttributes.hasValue(8)) {
            this.f73703F2 = obtainStyledAttributes.getDimensionPixelSize(8, 0);
        }
        if (obtainStyledAttributes.hasValue(5)) {
            this.f73705H2 = obtainStyledAttributes.getDimensionPixelSize(5, 0);
        }
        this.f73708K2 = obtainStyledAttributes.getBoolean(18, true);
        setTitle(obtainStyledAttributes.getText(16));
        collapsingTextHelper.m5145O(2131952039);
        collapsingTextHelper.m5152H(C4804R.style.ActionBar_Title);
        if (obtainStyledAttributes.hasValue(9)) {
            collapsingTextHelper.m5145O(obtainStyledAttributes.getResourceId(9, 0));
        }
        if (obtainStyledAttributes.hasValue(1)) {
            collapsingTextHelper.m5152H(obtainStyledAttributes.getResourceId(1, 0));
        }
        this.f73716S2 = obtainStyledAttributes.getDimensionPixelSize(14, -1);
        this.f73715R2 = obtainStyledAttributes.getInt(13, 600);
        setContentScrim(obtainStyledAttributes.getDrawable(2));
        setStatusBarScrim(obtainStyledAttributes.getDrawable(15));
        this.f73721z2 = obtainStyledAttributes.getResourceId(19, -1);
        obtainStyledAttributes.recycle();
        setWillNotDraw(false);
        ViewCompat.m46489Y1(this, new OnApplyWindowInsetsListener() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.CollapsingToolbarLayout.1
            @Override // androidx.core.view.OnApplyWindowInsetsListener
            /* renamed from: a */
            public WindowInsetsCompat mo5089a(View view, WindowInsetsCompat windowInsetsCompat) {
                return CollapsingToolbarLayout.this.m5094l(windowInsetsCompat);
            }
        });
        collapsingTextHelper.m5137W(context.obtainStyledAttributes(attributeSet, C4804R.styleable.f82819t8, i, 0).getInteger(0, 3));
    }

    /* renamed from: b */
    private void m5104b(int i) {
        m5103c();
        ValueAnimatorCompat valueAnimatorCompat = this.f73714Q2;
        if (valueAnimatorCompat == null) {
            ValueAnimatorCompat m5025a = ViewUtils.m5025a();
            this.f73714Q2 = m5025a;
            m5025a.m5071j(this.f73715R2);
            this.f73714Q2.m5068m(i > this.f73712O2 ? AnimationUtils.f73641c : AnimationUtils.f73642d);
            this.f73714Q2.m5079b(new ValueAnimatorCompat.AnimatorUpdateListener() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.CollapsingToolbarLayout.2
                @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.AnimatorUpdateListener
                /* renamed from: a */
                public void mo5063a(ValueAnimatorCompat valueAnimatorCompat2) {
                    CollapsingToolbarLayout.this.setScrimAlpha(valueAnimatorCompat2.m5074g());
                }
            });
        } else if (valueAnimatorCompat.m5072i()) {
            this.f73714Q2.m5078c();
        }
        this.f73714Q2.m5069l(this.f73712O2, i);
        this.f73714Q2.m5067n();
    }

    /* renamed from: c */
    private void m5103c() {
        if (this.f73720s) {
            Toolbar toolbar = null;
            this.f73698A2 = null;
            this.f73699B2 = null;
            int i = this.f73721z2;
            if (i != -1) {
                Toolbar toolbar2 = (Toolbar) findViewById(i);
                this.f73698A2 = toolbar2;
                if (toolbar2 != null) {
                    this.f73699B2 = m5102d(toolbar2);
                }
            }
            if (this.f73698A2 == null) {
                int childCount = getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        break;
                    }
                    View childAt = getChildAt(i2);
                    if (childAt instanceof Toolbar) {
                        toolbar = (Toolbar) childAt;
                        break;
                    }
                    i2++;
                }
                this.f73698A2 = toolbar;
            }
            m5091o();
            this.f73720s = false;
        }
    }

    /* renamed from: d */
    private View m5102d(View view) {
        for (ViewParent parent = view.getParent(); parent != this && parent != null; parent = parent.getParent()) {
            if (parent instanceof View) {
                view = (View) parent;
            }
        }
        return view;
    }

    /* renamed from: g */
    private static int m5099g(@NonNull View view) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            return view.getHeight() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
        }
        return view.getHeight();
    }

    /* renamed from: i */
    static ViewOffsetHelper m5097i(View view) {
        ViewOffsetHelper viewOffsetHelper = (ViewOffsetHelper) view.getTag(C4804R.C4808id.view_offset_helper);
        if (viewOffsetHelper == null) {
            ViewOffsetHelper viewOffsetHelper2 = new ViewOffsetHelper(view);
            view.setTag(C4804R.C4808id.view_offset_helper, viewOffsetHelper2);
            return viewOffsetHelper2;
        }
        return viewOffsetHelper;
    }

    /* renamed from: k */
    private boolean m5095k(View view) {
        int i = this.f73701D2;
        return i >= 0 && i == indexOfChild(view) + 1;
    }

    /* renamed from: o */
    private void m5091o() {
        View view;
        if (!this.f73708K2 && (view = this.f73700C2) != null) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.f73700C2);
            }
        }
        if (!this.f73708K2 || this.f73698A2 == null) {
            return;
        }
        if (this.f73700C2 == null) {
            this.f73700C2 = new View(getContext());
        }
        if (this.f73700C2.getParent() == null) {
            this.f73698A2.addView(this.f73700C2, -1, -1);
        }
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        Drawable drawable;
        super.draw(canvas);
        m5103c();
        if (this.f73698A2 == null && (drawable = this.f73710M2) != null && this.f73712O2 > 0) {
            drawable.mutate().setAlpha(this.f73712O2);
            this.f73710M2.draw(canvas);
        }
        if (this.f73708K2 && this.f73709L2) {
            this.f73707J2.m5124h(canvas);
        }
        if (this.f73711N2 == null || this.f73712O2 <= 0) {
            return;
        }
        WindowInsetsCompat windowInsetsCompat = this.f73719V2;
        int m46164r = windowInsetsCompat != null ? windowInsetsCompat.m46164r() : 0;
        if (m46164r > 0) {
            this.f73711N2.setBounds(0, -this.f73718U2, getWidth(), m46164r - this.f73718U2);
            this.f73711N2.mutate().setAlpha(this.f73712O2);
            this.f73711N2.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    protected boolean drawChild(Canvas canvas, View view, long j) {
        boolean drawChild = super.drawChild(canvas, view, j);
        if (this.f73710M2 == null || this.f73712O2 <= 0 || !m5095k(view)) {
            return drawChild;
        }
        this.f73710M2.mutate().setAlpha(this.f73712O2);
        this.f73710M2.draw(canvas);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f73711N2;
        boolean z = false;
        if (drawable != null && drawable.isStateful()) {
            z = false | drawable.setState(drawableState);
        }
        Drawable drawable2 = this.f73710M2;
        if (drawable2 != null && drawable2.isStateful()) {
            z |= drawable2.setState(drawableState);
        }
        CollapsingTextHelper collapsingTextHelper = this.f73707J2;
        if (collapsingTextHelper != null) {
            z |= collapsingTextHelper.m5135Y(drawableState);
        }
        if (z) {
            invalidate();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.FrameLayout, android.view.ViewGroup
    /* renamed from: e */
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.FrameLayout, android.view.ViewGroup
    /* renamed from: f */
    public FrameLayout.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public int getCollapsedTitleGravity() {
        return this.f73707J2.m5119m();
    }

    @NonNull
    public Typeface getCollapsedTitleTypeface() {
        return this.f73707J2.m5117o();
    }

    @Nullable
    public Drawable getContentScrim() {
        return this.f73710M2;
    }

    public int getExpandedTitleGravity() {
        return this.f73707J2.m5113s();
    }

    public int getExpandedTitleMarginBottom() {
        return this.f73705H2;
    }

    public int getExpandedTitleMarginEnd() {
        return this.f73704G2;
    }

    public int getExpandedTitleMarginStart() {
        return this.f73702E2;
    }

    public int getExpandedTitleMarginTop() {
        return this.f73703F2;
    }

    @NonNull
    public Typeface getExpandedTitleTypeface() {
        return this.f73707J2.m5111u();
    }

    public int getMaxLines() {
        return this.f73707J2.m5109w();
    }

    public long getScrimAnimationDuration() {
        return this.f73715R2;
    }

    public int getScrimVisibleHeightTrigger() {
        int i = this.f73716S2;
        if (i >= 0) {
            return i;
        }
        WindowInsetsCompat windowInsetsCompat = this.f73719V2;
        int m46164r = windowInsetsCompat != null ? windowInsetsCompat.m46164r() : 0;
        int m46476c0 = ViewCompat.m46476c0(this);
        return m46476c0 > 0 ? Math.min((m46476c0 * 2) + m46164r, getHeight()) : getHeight() / 3;
    }

    @Nullable
    public Drawable getStatusBarScrim() {
        return this.f73711N2;
    }

    @Nullable
    public CharSequence getTitle() {
        if (this.f73708K2) {
            return this.f73707J2.m5108x();
        }
        return null;
    }

    /* renamed from: h */
    final int m5098h(View view) {
        return ((getHeight() - m5097i(view).m5032b()) - view.getHeight()) - ((FrameLayout.LayoutParams) ((LayoutParams) view.getLayoutParams())).bottomMargin;
    }

    /* renamed from: j */
    public boolean m5096j() {
        return this.f73708K2;
    }

    /* renamed from: l */
    WindowInsetsCompat m5094l(WindowInsetsCompat windowInsetsCompat) {
        WindowInsetsCompat windowInsetsCompat2 = ViewCompat.m46509S(this) ? windowInsetsCompat : null;
        if (!ViewUtils.m5024b(this.f73719V2, windowInsetsCompat2)) {
            this.f73719V2 = windowInsetsCompat2;
            requestLayout();
        }
        return windowInsetsCompat.m46179c();
    }

    /* renamed from: m */
    public void m5093m(int i, int i2, int i3, int i4) {
        this.f73702E2 = i;
        this.f73703F2 = i2;
        this.f73704G2 = i3;
        this.f73705H2 = i4;
        requestLayout();
    }

    /* renamed from: n */
    public void m5092n(boolean z, boolean z2) {
        if (this.f73713P2 != z) {
            if (z2) {
                m5104b(z ? 255 : 0);
            } else {
                setScrimAlpha(z ? 255 : 0);
            }
            this.f73713P2 = z;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ViewParent parent = getParent();
        if (parent instanceof AppBarLayout) {
            ViewCompat.m46525M1(this, ViewCompat.m46509S((View) parent));
            if (this.f73717T2 == null) {
                this.f73717T2 = new OffsetUpdateListener();
            }
            ((AppBarLayout) parent).m27462b(this.f73717T2);
            ViewCompat.m46407t1(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        ViewParent parent = getParent();
        AppBarLayout.OnOffsetChangedListener onOffsetChangedListener = this.f73717T2;
        if (onOffsetChangedListener != null && (parent instanceof AppBarLayout)) {
            ((AppBarLayout) parent).m27447q(onOffsetChangedListener);
        }
        super.onDetachedFromWindow();
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        View view;
        View view2;
        super.onLayout(z, i, i2, i3, i4);
        WindowInsetsCompat windowInsetsCompat = this.f73719V2;
        if (windowInsetsCompat != null) {
            int m46164r = windowInsetsCompat.m46164r();
            int childCount = getChildCount();
            for (int i6 = 0; i6 < childCount; i6++) {
                View childAt = getChildAt(i6);
                if (!ViewCompat.m46509S(childAt) && childAt.getTop() < m46164r) {
                    ViewCompat.m46471d1(childAt, m46164r);
                }
            }
        }
        if (this.f73708K2 && (view2 = this.f73700C2) != null) {
            boolean z2 = ViewCompat.m46523N0(view2) && this.f73700C2.getVisibility() == 0;
            this.f73709L2 = z2;
            if (z2) {
                boolean z3 = ViewCompat.m46494X(this) == 1;
                View view3 = this.f73699B2;
                if (view3 == null) {
                    view3 = this.f73698A2;
                }
                int m5098h = m5098h(view3);
                ViewGroupUtils.m5038a(this, this.f73700C2, this.f73706I2);
                CollapsingTextHelper collapsingTextHelper = this.f73707J2;
                int i7 = this.f73706I2.left;
                Toolbar toolbar = this.f73698A2;
                int titleMarginEnd = i7 + (z3 ? toolbar.getTitleMarginEnd() : toolbar.getTitleMarginStart());
                int titleMarginTop = this.f73706I2.top + m5098h + this.f73698A2.getTitleMarginTop();
                int i8 = this.f73706I2.right;
                Toolbar toolbar2 = this.f73698A2;
                collapsingTextHelper.m5153G(titleMarginEnd, titleMarginTop, i8 + (z3 ? toolbar2.getTitleMarginStart() : toolbar2.getTitleMarginEnd()), (this.f73706I2.bottom + m5098h) - this.f73698A2.getTitleMarginBottom());
                this.f73707J2.m5146N(z3 ? this.f73704G2 : this.f73702E2, this.f73706I2.top + this.f73703F2, (i3 - i) - (z3 ? this.f73702E2 : this.f73704G2), (i4 - i2) - this.f73705H2);
                this.f73707J2.m5155E();
            }
        }
        int childCount2 = getChildCount();
        for (int i9 = 0; i9 < childCount2; i9++) {
            m5097i(getChildAt(i9)).m5029e();
        }
        if (this.f73698A2 != null) {
            if (this.f73708K2 && TextUtils.isEmpty(this.f73707J2.m5108x())) {
                this.f73707J2.m5134Z(this.f73698A2.getTitle());
            }
            View view4 = this.f73699B2;
            if (view4 == null || view4 == this) {
                setMinimumHeight(m5099g(this.f73698A2));
                view = this.f73698A2;
            } else {
                setMinimumHeight(m5099g(view4));
                view = this.f73699B2;
            }
            i5 = indexOfChild(view);
        } else {
            i5 = -1;
        }
        this.f73701D2 = i5;
        m5090p();
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int i, int i2) {
        m5103c();
        super.onMeasure(i, i2);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        Drawable drawable = this.f73710M2;
        if (drawable != null) {
            drawable.setBounds(0, 0, i, i2);
        }
    }

    /* renamed from: p */
    final void m5090p() {
        if (this.f73710M2 == null && this.f73711N2 == null) {
            return;
        }
        setScrimsShown(getHeight() + this.f73718U2 < getScrimVisibleHeightTrigger());
    }

    public void setCollapsedTitleGravity(int i) {
        this.f73707J2.m5149K(i);
    }

    public void setCollapsedTitleTextAppearance(@StyleRes int i) {
        this.f73707J2.m5152H(i);
    }

    public void setCollapsedTitleTextColor(@ColorInt int i) {
        setCollapsedTitleTextColor(ColorStateList.valueOf(i));
    }

    public void setCollapsedTitleTextColor(@NonNull ColorStateList colorStateList) {
        this.f73707J2.m5150J(colorStateList);
    }

    public void setCollapsedTitleTypeface(@Nullable Typeface typeface) {
        this.f73707J2.m5147M(typeface);
    }

    public void setContentScrim(@Nullable Drawable drawable) {
        Drawable drawable2 = this.f73710M2;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable mutate = drawable != null ? drawable.mutate() : null;
            this.f73710M2 = mutate;
            if (mutate != null) {
                mutate.setBounds(0, 0, getWidth(), getHeight());
                this.f73710M2.setCallback(this);
                this.f73710M2.setAlpha(this.f73712O2);
            }
            ViewCompat.m46439l1(this);
        }
    }

    public void setContentScrimColor(@ColorInt int i) {
        setContentScrim(new ColorDrawable(i));
    }

    public void setContentScrimResource(@DrawableRes int i) {
        setContentScrim(ContextCompat.m47744h(getContext(), i));
    }

    public void setExpandedTitleColor(@ColorInt int i) {
        setExpandedTitleTextColor(ColorStateList.valueOf(i));
    }

    public void setExpandedTitleGravity(int i) {
        this.f73707J2.m5142R(i);
    }

    public void setExpandedTitleMarginBottom(int i) {
        this.f73705H2 = i;
        requestLayout();
    }

    public void setExpandedTitleMarginEnd(int i) {
        this.f73704G2 = i;
        requestLayout();
    }

    public void setExpandedTitleMarginStart(int i) {
        this.f73702E2 = i;
        requestLayout();
    }

    public void setExpandedTitleMarginTop(int i) {
        this.f73703F2 = i;
        requestLayout();
    }

    public void setExpandedTitleTextAppearance(@StyleRes int i) {
        this.f73707J2.m5145O(i);
    }

    public void setExpandedTitleTextColor(@NonNull ColorStateList colorStateList) {
        this.f73707J2.m5143Q(colorStateList);
    }

    public void setExpandedTitleTypeface(@Nullable Typeface typeface) {
        this.f73707J2.m5140T(typeface);
    }

    public void setMaxLines(int i) {
        this.f73707J2.m5137W(i);
    }

    void setScrimAlpha(int i) {
        Toolbar toolbar;
        if (i != this.f73712O2) {
            if (this.f73710M2 != null && (toolbar = this.f73698A2) != null) {
                ViewCompat.m46439l1(toolbar);
            }
            this.f73712O2 = i;
            ViewCompat.m46439l1(this);
        }
    }

    public void setScrimAnimationDuration(@IntRange(from = 0) long j) {
        this.f73715R2 = j;
    }

    public void setScrimVisibleHeightTrigger(@IntRange(from = 0) int i) {
        if (this.f73716S2 != i) {
            this.f73716S2 = i;
            m5090p();
        }
    }

    public void setScrimsShown(boolean z) {
        m5092n(z, ViewCompat.m46505T0(this) && !isInEditMode());
    }

    public void setStatusBarScrim(@Nullable Drawable drawable) {
        Drawable drawable2 = this.f73711N2;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable mutate = drawable != null ? drawable.mutate() : null;
            this.f73711N2 = mutate;
            if (mutate != null) {
                if (mutate.isStateful()) {
                    this.f73711N2.setState(getDrawableState());
                }
                DrawableCompat.m47295m(this.f73711N2, ViewCompat.m46494X(this));
                this.f73711N2.setVisible(getVisibility() == 0, false);
                this.f73711N2.setCallback(this);
                this.f73711N2.setAlpha(this.f73712O2);
            }
            ViewCompat.m46439l1(this);
        }
    }

    public void setStatusBarScrimColor(@ColorInt int i) {
        setStatusBarScrim(new ColorDrawable(i));
    }

    public void setStatusBarScrimResource(@DrawableRes int i) {
        setStatusBarScrim(ContextCompat.m47744h(getContext(), i));
    }

    public void setTitle(@Nullable CharSequence charSequence) {
        this.f73707J2.m5134Z(charSequence);
    }

    public void setTitleEnabled(boolean z) {
        if (z != this.f73708K2) {
            this.f73708K2 = z;
            m5091o();
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f73711N2;
        if (drawable != null && drawable.isVisible() != z) {
            this.f73711N2.setVisible(z, false);
        }
        Drawable drawable2 = this.f73710M2;
        if (drawable2 == null || drawable2.isVisible() == z) {
            return;
        }
        this.f73710M2.setVisible(z, false);
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f73710M2 || drawable == this.f73711N2;
    }
}
