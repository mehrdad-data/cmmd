package net.imedicaldoctor.imd.CollapsingToolbar;

import android.view.animation.Interpolator;
import androidx.annotation.NonNull;

/* loaded from: classes2.dex */
class ValueAnimatorCompat {

    /* renamed from: a */
    private final Impl f73732a;

    /* loaded from: classes2.dex */
    interface AnimatorListener {
        /* renamed from: a */
        void mo5066a(ValueAnimatorCompat valueAnimatorCompat);

        /* renamed from: b */
        void mo5065b(ValueAnimatorCompat valueAnimatorCompat);

        /* renamed from: c */
        void mo5064c(ValueAnimatorCompat valueAnimatorCompat);
    }

    /* loaded from: classes2.dex */
    static class AnimatorListenerAdapter implements AnimatorListener {
        AnimatorListenerAdapter() {
        }

        @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.AnimatorListener
        /* renamed from: a */
        public void mo5066a(ValueAnimatorCompat valueAnimatorCompat) {
        }

        @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.AnimatorListener
        /* renamed from: b */
        public void mo5065b(ValueAnimatorCompat valueAnimatorCompat) {
        }

        @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.AnimatorListener
        /* renamed from: c */
        public void mo5064c(ValueAnimatorCompat valueAnimatorCompat) {
        }
    }

    /* loaded from: classes2.dex */
    interface AnimatorUpdateListener {
        /* renamed from: a */
        void mo5063a(ValueAnimatorCompat valueAnimatorCompat);
    }

    /* loaded from: classes2.dex */
    interface Creator {
        @NonNull
        /* renamed from: c */
        ValueAnimatorCompat mo5022c();
    }

    /* loaded from: classes2.dex */
    static abstract class Impl {

        /* loaded from: classes2.dex */
        interface AnimatorListenerProxy {
            /* renamed from: a */
            void mo5062a();

            /* renamed from: b */
            void mo5061b();

            /* renamed from: c */
            void mo5060c();
        }

        /* loaded from: classes2.dex */
        interface AnimatorUpdateListenerProxy {
            /* renamed from: a */
            void mo5059a();
        }

        /* renamed from: a */
        abstract void mo5052a(AnimatorListenerProxy animatorListenerProxy);

        /* renamed from: b */
        abstract void mo5051b(AnimatorUpdateListenerProxy animatorUpdateListenerProxy);

        /* renamed from: c */
        abstract void mo5050c();

        /* renamed from: d */
        abstract void mo5049d();

        /* renamed from: e */
        abstract float mo5048e();

        /* renamed from: f */
        abstract float mo5047f();

        /* renamed from: g */
        abstract int mo5046g();

        /* renamed from: h */
        abstract long mo5045h();

        /* renamed from: i */
        abstract boolean mo5044i();

        /* renamed from: j */
        abstract void mo5043j(long j);

        /* renamed from: k */
        abstract void mo5042k(float f, float f2);

        /* renamed from: l */
        abstract void mo5041l(int i, int i2);

        /* renamed from: m */
        abstract void mo5040m(Interpolator interpolator);

        /* renamed from: n */
        abstract void mo5039n();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ValueAnimatorCompat(Impl impl) {
        this.f73732a = impl;
    }

    /* renamed from: a */
    public void m5080a(final AnimatorListener animatorListener) {
        if (animatorListener != null) {
            this.f73732a.mo5052a(new Impl.AnimatorListenerProxy() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.2
                @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl.AnimatorListenerProxy
                /* renamed from: a */
                public void mo5062a() {
                    animatorListener.mo5066a(ValueAnimatorCompat.this);
                }

                @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl.AnimatorListenerProxy
                /* renamed from: b */
                public void mo5061b() {
                    animatorListener.mo5065b(ValueAnimatorCompat.this);
                }

                @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl.AnimatorListenerProxy
                /* renamed from: c */
                public void mo5060c() {
                    animatorListener.mo5064c(ValueAnimatorCompat.this);
                }
            });
        } else {
            this.f73732a.mo5052a(null);
        }
    }

    /* renamed from: b */
    public void m5079b(final AnimatorUpdateListener animatorUpdateListener) {
        if (animatorUpdateListener != null) {
            this.f73732a.mo5051b(new Impl.AnimatorUpdateListenerProxy() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.1
                @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy
                /* renamed from: a */
                public void mo5059a() {
                    animatorUpdateListener.mo5063a(ValueAnimatorCompat.this);
                }
            });
        } else {
            this.f73732a.mo5051b(null);
        }
    }

    /* renamed from: c */
    public void m5078c() {
        this.f73732a.mo5050c();
    }

    /* renamed from: d */
    public void m5077d() {
        this.f73732a.mo5049d();
    }

    /* renamed from: e */
    public float m5076e() {
        return this.f73732a.mo5048e();
    }

    /* renamed from: f */
    public float m5075f() {
        return this.f73732a.mo5047f();
    }

    /* renamed from: g */
    public int m5074g() {
        return this.f73732a.mo5046g();
    }

    /* renamed from: h */
    public long m5073h() {
        return this.f73732a.mo5045h();
    }

    /* renamed from: i */
    public boolean m5072i() {
        return this.f73732a.mo5044i();
    }

    /* renamed from: j */
    public void m5071j(long j) {
        this.f73732a.mo5043j(j);
    }

    /* renamed from: k */
    public void m5070k(float f, float f2) {
        this.f73732a.mo5042k(f, f2);
    }

    /* renamed from: l */
    public void m5069l(int i, int i2) {
        this.f73732a.mo5041l(i, i2);
    }

    /* renamed from: m */
    public void m5068m(Interpolator interpolator) {
        this.f73732a.mo5040m(interpolator);
    }

    /* renamed from: n */
    public void m5067n() {
        this.f73732a.mo5039n();
    }
}
