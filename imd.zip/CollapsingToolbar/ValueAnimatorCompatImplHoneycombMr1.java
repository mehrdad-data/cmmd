package net.imedicaldoctor.imd.CollapsingToolbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.view.animation.Interpolator;
import net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat;

@TargetApi(12)
/* loaded from: classes2.dex */
class ValueAnimatorCompatImplHoneycombMr1 extends ValueAnimatorCompat.Impl {

    /* renamed from: a */
    private final ValueAnimator f73751a = new ValueAnimator();

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: a */
    public void mo5052a(final ValueAnimatorCompat.Impl.AnimatorListenerProxy animatorListenerProxy) {
        this.f73751a.addListener(new AnimatorListenerAdapter() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompatImplHoneycombMr1.2
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationCancel(Animator animator) {
                animatorListenerProxy.mo5061b();
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                animatorListenerProxy.mo5062a();
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationStart(Animator animator) {
                animatorListenerProxy.mo5060c();
            }
        });
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: b */
    public void mo5051b(final ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy animatorUpdateListenerProxy) {
        this.f73751a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompatImplHoneycombMr1.1
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                animatorUpdateListenerProxy.mo5059a();
            }
        });
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: c */
    public void mo5050c() {
        this.f73751a.cancel();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: d */
    public void mo5049d() {
        this.f73751a.end();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: e */
    public float mo5048e() {
        return ((Float) this.f73751a.getAnimatedValue()).floatValue();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: f */
    public float mo5047f() {
        return this.f73751a.getAnimatedFraction();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: g */
    public int mo5046g() {
        return ((Integer) this.f73751a.getAnimatedValue()).intValue();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: h */
    public long mo5045h() {
        return this.f73751a.getDuration();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: i */
    public boolean mo5044i() {
        return this.f73751a.isRunning();
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: j */
    public void mo5043j(long j) {
        this.f73751a.setDuration(j);
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: k */
    public void mo5042k(float f, float f2) {
        this.f73751a.setFloatValues(f, f2);
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: l */
    public void mo5041l(int i, int i2) {
        this.f73751a.setIntValues(i, i2);
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: m */
    public void mo5040m(Interpolator interpolator) {
        this.f73751a.setInterpolator(interpolator);
    }

    @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Impl
    /* renamed from: n */
    public void mo5039n() {
        this.f73751a.start();
    }
}
