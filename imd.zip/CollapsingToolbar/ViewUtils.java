package net.imedicaldoctor.imd.CollapsingToolbar;

import android.graphics.PorterDuff;
import net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat;

/* loaded from: classes2.dex */
class ViewUtils {

    /* renamed from: a */
    static final ValueAnimatorCompat.Creator f73764a = new ValueAnimatorCompat.Creator() { // from class: net.imedicaldoctor.imd.CollapsingToolbar.ViewUtils.1
        @Override // net.imedicaldoctor.imd.CollapsingToolbar.ValueAnimatorCompat.Creator
        /* renamed from: c */
        public ValueAnimatorCompat mo5022c() {
            return new ValueAnimatorCompat(new ValueAnimatorCompatImplHoneycombMr1());
        }
    };

    ViewUtils() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: a */
    public static ValueAnimatorCompat m5025a() {
        return f73764a.mo5022c();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: b */
    public static boolean m5024b(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    /* renamed from: c */
    static PorterDuff.Mode m5023c(int i, PorterDuff.Mode mode) {
        return i != 3 ? i != 5 ? i != 9 ? i != 14 ? i != 15 ? mode : PorterDuff.Mode.SCREEN : PorterDuff.Mode.MULTIPLY : PorterDuff.Mode.SRC_ATOP : PorterDuff.Mode.SRC_IN : PorterDuff.Mode.SRC_OVER;
    }
}
