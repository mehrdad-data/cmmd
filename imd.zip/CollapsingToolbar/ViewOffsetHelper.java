package net.imedicaldoctor.imd.CollapsingToolbar;

import android.view.View;
import androidx.core.view.ViewCompat;

/* loaded from: classes2.dex */
class ViewOffsetHelper {

    /* renamed from: a */
    private final View f73759a;

    /* renamed from: b */
    private int f73760b;

    /* renamed from: c */
    private int f73761c;

    /* renamed from: d */
    private int f73762d;

    /* renamed from: e */
    private int f73763e;

    public ViewOffsetHelper(View view) {
        this.f73759a = view;
    }

    /* renamed from: h */
    private void m5026h() {
        View view = this.f73759a;
        ViewCompat.m46471d1(view, this.f73762d - (view.getTop() - this.f73760b));
        View view2 = this.f73759a;
        ViewCompat.m46475c1(view2, this.f73763e - (view2.getLeft() - this.f73761c));
    }

    /* renamed from: a */
    public int m5033a() {
        return this.f73761c;
    }

    /* renamed from: b */
    public int m5032b() {
        return this.f73760b;
    }

    /* renamed from: c */
    public int m5031c() {
        return this.f73763e;
    }

    /* renamed from: d */
    public int m5030d() {
        return this.f73762d;
    }

    /* renamed from: e */
    public void m5029e() {
        this.f73760b = this.f73759a.getTop();
        this.f73761c = this.f73759a.getLeft();
        m5026h();
    }

    /* renamed from: f */
    public boolean m5028f(int i) {
        if (this.f73763e != i) {
            this.f73763e = i;
            m5026h();
            return true;
        }
        return false;
    }

    /* renamed from: g */
    public boolean m5027g(int i) {
        if (this.f73762d != i) {
            this.f73762d = i;
            m5026h();
            return true;
        }
        return false;
    }
}
