package net.imedicaldoctor.imd.CollapsingToolbar;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes2.dex */
class ViewGroupUtils {

    /* renamed from: a */
    private static final ViewGroupUtilsImpl f73756a = new ViewGroupUtilsImplHoneycomb();

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes2.dex */
    public interface ViewGroupUtilsImpl {
        /* renamed from: a */
        void mo5036a(ViewGroup viewGroup, View view, Rect rect);
    }

    /* loaded from: classes2.dex */
    private static class ViewGroupUtilsImplBase implements ViewGroupUtilsImpl {
        ViewGroupUtilsImplBase() {
        }

        @Override // net.imedicaldoctor.imd.CollapsingToolbar.ViewGroupUtils.ViewGroupUtilsImpl
        /* renamed from: a */
        public void mo5036a(ViewGroup viewGroup, View view, Rect rect) {
            viewGroup.offsetDescendantRectToMyCoords(view, rect);
            rect.offset(view.getScrollX(), view.getScrollY());
        }
    }

    /* loaded from: classes2.dex */
    private static class ViewGroupUtilsImplHoneycomb implements ViewGroupUtilsImpl {
        ViewGroupUtilsImplHoneycomb() {
        }

        @Override // net.imedicaldoctor.imd.CollapsingToolbar.ViewGroupUtils.ViewGroupUtilsImpl
        /* renamed from: a */
        public void mo5036a(ViewGroup viewGroup, View view, Rect rect) {
            ViewGroupUtilsHoneycomb.m5034b(viewGroup, view, rect);
        }
    }

    ViewGroupUtils() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: a */
    public static void m5038a(ViewGroup viewGroup, View view, Rect rect) {
        rect.set(0, 0, view.getWidth(), view.getHeight());
        m5037b(viewGroup, view, rect);
    }

    /* renamed from: b */
    static void m5037b(ViewGroup viewGroup, View view, Rect rect) {
        f73756a.mo5036a(viewGroup, view, rect);
    }
}
